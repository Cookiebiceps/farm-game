using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// Runtime textures in the XNA 4.0 style (Texture2D.SetData).
    /// </summary>
    public sealed class Assets
    {
        public Texture2D Pixel;
        public Texture2D Shadow;
        public Texture2D[] Grass = new Texture2D[4];
        public Texture2D[] WoodsGrass = new Texture2D[4];
        public Texture2D[] Sand = new Texture2D[4];
        public Texture2D[] WetSand = new Texture2D[4];
        public Texture2D FarmSoil, Tilled, Wet, Fence, Roof, Cliff, Mountain, Cobble, Wall, WallWindow, Floor, Door, DoorOpen, Counter;
        public Texture2D[] CliffVar = new Texture2D[4];
        public Texture2D[] MountainVar = new Texture2D[4];
        public Texture2D[] GrassEdge = new Texture2D[4];
        public Texture2D[] MountainEdge = new Texture2D[4];
        public Texture2D[] MountainSouthDrop = new Texture2D[4];
        public Texture2D[] MountainNorthDrop = new Texture2D[4];
        public Texture2D[] MountainEastDrop = new Texture2D[4];
        public Texture2D[] MountainWestDrop = new Texture2D[4];
        public Texture2D CliffFoam;
        public Texture2D[] BridgeDeckEw = new Texture2D[2];
        public Texture2D[] BridgeDeckNs = new Texture2D[2];
        readonly Dictionary<string, Texture2D> _bridges = new Dictionary<string, Texture2D>();
        readonly Dictionary<int, Texture2D> _woodDecks = new Dictionary<int, Texture2D>();
        public Texture2D[] Signpost = new Texture2D[4];
        public Texture2D[] Path = new Texture2D[2];
        public Texture2D[] Water = new Texture2D[4];
        public Texture2D[] WaterRiver = new Texture2D[4];
        public Texture2D[] WaterCoast = new Texture2D[4];
        public Texture2D[] WaterOcean = new Texture2D[4];
        public Texture2D[] PlayerDown = new Texture2D[2];
        public Texture2D[] PlayerLeft = new Texture2D[2];
        public Texture2D[] PlayerRight = new Texture2D[2];
        public Texture2D[] PlayerUp = new Texture2D[2];
        public Texture2D Npc;
        public Texture2D Mira;
        public Texture2D Cob;
        public Texture2D Rowan;
        public Texture2D Finn;
        public Texture2D Piper;
        public Texture2D Lila;
        public Texture2D Bram;
        public Texture2D Nell;
        public Texture2D Ash;
        public Texture2D Bess;
        public readonly Texture2D[][][] CaveMobs = new Texture2D[CaveMobCatalog.Count][][];
        public readonly Texture2D[][][] Livestock = new Texture2D[AnimalCatalog.Count][][];
        public readonly Texture2D[][] SheepShorn = new Texture2D[4][];
        public Texture2D CharShadow;
        public Texture2D Tree;
        public Texture2D DarkTree;
        public Texture2D[] FarmTrunk = new Texture2D[4];
        public Texture2D[] FarmCanopy = new Texture2D[4];
        public Texture2D[] WoodsTrunk = new Texture2D[4];
        public Texture2D[] WoodsCanopy = new Texture2D[4];
        public Texture2D[] OakCanopy = new Texture2D[4];
        public Texture2D[] BirchCanopy = new Texture2D[4];
        public Texture2D[] PineTrunk = new Texture2D[4];
        public Texture2D[] PineNeedles = new Texture2D[4];
        public Texture2D[] SpruceNeedles = new Texture2D[4];
        public Texture2D[] WillowCanopy = new Texture2D[4];
        public Texture2D[] BlossomCanopy = new Texture2D[4];
        public Texture2D[] PalmTrunk = new Texture2D[4];
        public Texture2D[] PalmFronds = new Texture2D[4];
        public Texture2D[] DeadCrown = new Texture2D[4];
        public Texture2D Stump;
        public Texture2D Rock;
        public Texture2D Mineral;
        public Texture2D Dummy;
        public Texture2D Flower;
        public Texture2D Mushroom;
        public Texture2D Weed;
        public Texture2D[] Shells = new Texture2D[5];
        public Texture2D Seaweed;
        public Texture2D Bed;
        public Texture2D Bin;
        public Texture2D Barrel;
        public Texture2D Crate;
        public Texture2D FishCrate;
        public Texture2D FishRack;
        public Texture2D DockShark;
        public Texture2D DockSack;
        public Texture2D Rowboat;
        public Texture2D SailBlue;
        public Texture2D SailBrown;
        public Texture2D DockPiling;
        public Texture2D LogSlice;
        public Texture2D Chest;
        public Texture2D ChestOpen;
        public Texture2D Picnic;
        public Texture2D Bush;
        public Texture2D Stove;
        public Texture2D Sink;
        public Texture2D Table;
        public Texture2D IndoorPlant;
        public Texture2D Keg;
        public Texture2D Stairs;
        public Texture2D GreenhouseInside;
        public BarnSprite BarnOk;
        public BarnSprite BarnRuin;
        public Texture2D[] Fridge = new Texture2D[4];
        public Texture2D[] Shelf = new Texture2D[4];
        public Texture2D Hoe;
        public Texture2D Can;
        public Texture2D Scythe;
        public Texture2D Axe;
        public Texture2D Pickaxe;
        public Texture2D Sword;
        public Texture2D Rod;
        public Texture2D Pail;
        public Texture2D MilkIcon;
        public Texture2D Shears;
        public Texture2D WoolIcon;
        public Texture2D Seed;
        public Texture2D HeldHoe;
        public Texture2D HeldCan;
        public Texture2D HeldScythe;
        public Texture2D HeldAxe;
        public Texture2D HeldPickaxe;
        public Texture2D HeldSword;
        public Texture2D HeldRod;
        public Texture2D HeldPail;
        public Texture2D HeldShears;
        public Texture2D HeldShearsShut;
        public Texture2D HeldHand;
        public Texture2D DockPlank;
        public readonly Dictionary<string, Texture2D> FishIcons = new Dictionary<string, Texture2D>();
        public readonly Dictionary<string, Texture2D> AnimalIcons = new Dictionary<string, Texture2D>();
        public readonly Dictionary<string, Texture2D> HeldPouch = new Dictionary<string, Texture2D>();
        public Texture2D WoodIcon;
        public Texture2D PlankIcon;
        public Texture2D StoneIcon;
        public Texture2D FiberIcon;
        public Texture2D HayIcon;
        public Texture2D[] HayReady = new Texture2D[4];
        public Texture2D[] HayStubble = new Texture2D[2];
        public readonly Dictionary<string, Texture2D> MineralIcons = new Dictionary<string, Texture2D>();
        public readonly Dictionary<string, Texture2D> SeedPouch = new Dictionary<string, Texture2D>();
        public readonly Dictionary<string, Texture2D[]> CropFrames = new Dictionary<string, Texture2D[]>();
        readonly Dictionary<string, Texture2D> _houses = new Dictionary<string, Texture2D>();
        readonly Dictionary<string, Texture2D> _inWalls = new Dictionary<string, Texture2D>();
        readonly Dictionary<string, Texture2D> _inFloors = new Dictionary<string, Texture2D>();
        readonly Dictionary<string, Texture2D> _inDoors = new Dictionary<string, Texture2D>();
        readonly Dictionary<int, Texture2D> _lookFrames = new Dictionary<int, Texture2D>();
        GraphicsDevice _device;
        public PackAtlas Pack = new PackAtlas();

        public void Load(GraphicsDevice device)
        {
            _device = device;
            Pack.Load(device);
            Pixel = new Texture2D(device, 1, 1);
            Pixel.SetData(new[] { Color.White });
            Shadow = TileGen.Shadow(device);
            for (int i = 0; i < 4; i++)
            {
                Grass[i] = TileGen.Grass(device, i);
                WoodsGrass[i] = TileGen.WoodsGrass(device, i);
                Sand[i] = TileGen.Sand(device, i);
                WetSand[i] = TileGen.WetSand(device, i);
            }
            FarmSoil = TileGen.FarmSoil(device);
            Tilled = TileGen.Tilled(device);
            Wet = TileGen.Wet(device);
            Path[0] = TileGen.Path(device, 0);
            Path[1] = TileGen.Path(device, 1);
            Water[0] = TileGen.Water(device, 0);
            Water[1] = TileGen.Water(device, 1);
            Water[2] = TileGen.Water(device, 2);
            Water[3] = TileGen.Water(device, 3);
            for (int i = 0; i < 4; i++)
            {
                WaterRiver[i] = TileGen.WaterRiver(device, i);
                WaterCoast[i] = TileGen.WaterCoast(device, i);
                WaterOcean[i] = TileGen.WaterOcean(device, i);
            }
            Fence = TileGen.Fence(device);
            for (int i = 0; i < 4; i++)
                Signpost[i] = TileGen.Signpost(device, i);
            Roof = TileGen.Roof(device);
            for (int i = 0; i < 4; i++)
                MountainVar[i] = TileGen.Mountain(device, i);
            Mountain = MountainVar[0];
            for (int i = 0; i < 4; i++)
                CliffVar[i] = TileGen.Cliff(device, i);
            Cliff = CliffVar[0];
            CliffFoam = TileGen.CliffFoam(device);
            BridgeDeckEw[0] = TileGen.BridgeDeck(device, 0, false);
            BridgeDeckEw[1] = TileGen.BridgeDeck(device, 1, false);
            BridgeDeckNs[0] = TileGen.BridgeDeck(device, 0, true);
            BridgeDeckNs[1] = TileGen.BridgeDeck(device, 1, true);
            for (int i = 0; i < 4; i++)
                GrassEdge[i] = TileGen.GrassEdge(device, i);
            for (int i = 0; i < 4; i++)
            {
                MountainEdge[i] = TileGen.MountainEdge(device, i);
                MountainSouthDrop[i] = TileGen.MountainSouthDrop(device, i);
                MountainNorthDrop[i] = TileGen.MountainNorthDrop(device, i);
                MountainEastDrop[i] = TileGen.MountainEastDrop(device, i);
                MountainWestDrop[i] = TileGen.MountainWestDrop(device, i);
            }
            Cobble = TileGen.Cobble(device);
            Wall = TileGen.Wall(device, false);
            WallWindow = TileGen.Wall(device, true);
            Floor = TileGen.Floor(device);
            Door = TileGen.Door(device, false);
            DoorOpen = TileGen.Door(device, true);
            Counter = TileGen.Counter(device);
            Stove = TileGen.Stove(device);
            Sink = TileGen.Sink(device);
            Table = TileGen.Table(device);
            IndoorPlant = TileGen.IndoorPlant(device);
            Keg = TileGen.Keg(device);
            Stairs = TileGen.Stairs(device);
            GreenhouseInside = TileGen.GreenhouseInside(device, 12);
            BarnOk = TileGen.MakeBarnSprite(device, false);
            BarnRuin = TileGen.MakeBarnSprite(device, true);
            for (int i = 0; i < 4; i++)
            {
                Fridge[i] = TileGen.Fridge(device, i);
                Shelf[i] = TileGen.Shelf(device, i);
            }
            DockPlank = TileGen.Dock(device);

            Pack.SetExtraFill("fill_path", Path[0]);
            Pack.SetExtraFill("fill_water", WaterCoast[0]);
            Pack.SetExtraFill("fill_soil", FarmSoil);
            Pack.SetExtraFill("fill_sand", Sand[0]);
            Pack.SetExtraFill("fill_tilled", Tilled);
            Pack.SetExtraFill("fill_wet", Wet);
            Pack.SetExtraFill("fill_cobble", Cobble);
            Pack.SetExtraFill("fill_mountain", Mountain);
            Pack.SetFill("grass_path", false, Path[0]);
            Pack.SetFill("woods_path", false, Path[1]);
            Pack.SetFill("grass_water", false, WaterCoast[0]);
            Pack.SetFill("water_sand", false, WaterCoast[0]);
            Pack.SetFill("water_sand", true, Sand[0]);
            Pack.SetFill("grass_soil", false, FarmSoil);
            Pack.SetFill("grass_cobble", false, Cobble);

            PlayerDown[0] = Characters.Farmer(device, 0, 0);
            PlayerDown[1] = Characters.Farmer(device, 0, 1);
            PlayerLeft[0] = Characters.Farmer(device, 1, 0);
            PlayerLeft[1] = Characters.Farmer(device, 1, 1);
            PlayerRight[0] = Characters.Farmer(device, 2, 0);
            PlayerRight[1] = Characters.Farmer(device, 2, 1);
            PlayerUp[0] = Characters.Farmer(device, 3, 0);
            PlayerUp[1] = Characters.Farmer(device, 3, 1);

            Mira = Characters.Mira(device);
            Cob = Characters.Cob(device);
            Rowan = Characters.Rowan(device);
            Finn = Characters.Finn(device);
            Piper = Characters.Piper(device);
            Lila = Characters.Lila(device);
            Bram = Characters.Bram(device);
            Nell = Characters.Nell(device);
            Ash = Characters.Ash(device);
            Bess = Characters.Bess(device);
            for (int k = 0; k < CaveMobCatalog.Count; k++)
            {
                CaveMobs[k] = new Texture2D[4][];
                for (int d = 0; d < 4; d++)
                {
                    CaveMobs[k][d] = new Texture2D[2];
                    CaveMobs[k][d][0] = Characters.CaveMob(device, k, d, 0);
                    CaveMobs[k][d][1] = Characters.CaveMob(device, k, d, 1);
                }
            }
            for (int k = 0; k < AnimalCatalog.Count; k++)
            {
                Livestock[k] = new Texture2D[4][];
                for (int d = 0; d < 4; d++)
                {
                    Livestock[k][d] = new Texture2D[2];
                    Livestock[k][d][0] = Animals.Sprite(device, (AnimalKind)k, d, 0);
                    Livestock[k][d][1] = Animals.Sprite(device, (AnimalKind)k, d, 1);
                }
                AnimalIcons[AnimalCatalog.Ids[k]] = Livestock[k][0][0];
            }
            for (int d = 0; d < 4; d++)
            {
                SheepShorn[d] = new Texture2D[2];
                SheepShorn[d][0] = Animals.Sprite(device, AnimalKind.Sheep, d, 0, false);
                SheepShorn[d][1] = Animals.Sprite(device, AnimalKind.Sheep, d, 1, false);
            }
            Npc = Mira;
            CharShadow = Characters.GroundShadow(device);
            for (int i = 0; i < 4; i++)
            {
                FarmTrunk[i] = TileGen.TreeTrunk(device, i);
                FarmCanopy[i] = TileGen.TreeCanopy(device, i, false, true);
                WoodsTrunk[i] = TileGen.TreeTrunk(device, i + 4);
                WoodsCanopy[i] = TileGen.TreeCanopy(device, i + 4, true, false);
                OakCanopy[i] = TileGen.OakCanopy(device, i);
                BirchCanopy[i] = TileGen.BirchCanopy(device, i);
                PineTrunk[i] = TileGen.PineTrunk(device, i);
                PineNeedles[i] = TileGen.PineNeedles(device, i, false);
                SpruceNeedles[i] = TileGen.PineNeedles(device, i, true);
                WillowCanopy[i] = TileGen.WillowCanopy(device, i);
                BlossomCanopy[i] = TileGen.BlossomCanopy(device, i);
                PalmTrunk[i] = TileGen.PalmTrunk(device, i);
                PalmFronds[i] = TileGen.PalmFronds(device, i);
                DeadCrown[i] = TileGen.DeadCrown(device, i);
            }
            Tree = FarmCanopy[0];
            DarkTree = WoodsCanopy[1];
            Stump = TileGen.CanopyStump(device);
            Rock = TileGen.CanopyRock(device);
            Mineral = TileGen.MineralVein(device);
            Dummy = TileGen.Scarecrow(device);
            Flower = Bake(device, FlowerMap());
            Mushroom = Bake(device, MushroomMap());
            Weed = Bake(device, WeedMap());
            Bed = TileGen.Bed(device);
            Bin = Bake(device, BinMap());
            Barrel = TileGen.Barrel(device);
            Crate = TileGen.Crate(device);
            FishCrate = TileGen.FishCrate(device);
            FishRack = TileGen.FishRack(device);
            DockShark = TileGen.DockShark(device);
            DockSack = TileGen.DockSack(device);
            Rowboat = TileGen.Rowboat(device);
            SailBlue = TileGen.Sailboat(device, true);
            SailBrown = TileGen.Sailboat(device, false);
            DockPiling = TileGen.DockPiling(device);
            LogSlice = TileGen.LogSlice(device);
            Chest = TileGen.Chest(device, false);
            ChestOpen = TileGen.Chest(device, true);
            Picnic = TileGen.Picnic(device);
            Bush = TileGen.Bush(device);
            Hoe = Bake(device, HoeMap());
            Can = Bake(device, CanMap());
            Scythe = Bake(device, ScytheMap());
            Axe = Bake(device, AxeMap());
            Pickaxe = Bake(device, PickaxeMap());
            Sword = Bake(device, SwordMap());
            Rod = Bake(device, RodMap());
            Pail = Bake(device, PailMap());
            MilkIcon = Bake(device, MilkMap());
            Shears = Bake(device, ShearsMap());
            WoolIcon = Bake(device, WoolMap());
            Seed = Bake(device, SeedMap());
            HeldHoe = HeldTools.Hoe(device);
            HeldCan = HeldTools.Can(device);
            HeldScythe = HeldTools.Scythe(device);
            HeldAxe = HeldTools.Axe(device);
            HeldPickaxe = HeldTools.Pickaxe(device);
            HeldSword = HeldTools.Sword(device);
            HeldRod = HeldTools.FishingRod(device);
            HeldPail = HeldTools.Pail(device);
            HeldShears = HeldTools.Shears(device, true);
            HeldShearsShut = HeldTools.Shears(device, false);
            HeldHand = HeldTools.Hand(device);
            for (int i = 0; i < FishCatalog.Saltwater.Length; i++)
            {
                FishDef f = FishCatalog.Saltwater[i];
                FishIcons[FishCatalog.ItemId(f.Id)] = TileGen.FishIcon(device, f.Body, f.Fin);
            }
            WoodIcon = TileGen.WoodLog(device);
            PlankIcon = TileGen.PlankStack(device);
            StoneIcon = TileGen.StonePile(device);
            FiberIcon = TileGen.FiberBundle(device);
            HayIcon = TileGen.HayBale(device);
            for (int i = 0; i < HayReady.Length; i++)
                HayReady[i] = TileGen.HayField(device, i);
            for (int i = 0; i < HayStubble.Length; i++)
                HayStubble[i] = TileGen.HayStubble(device, i);
            MineralIcons["ore.gold"] = TileGen.OreChunk(device, new Color(214, 168, 64), new Color(168, 118, 36));
            MineralIcons["ore.silver"] = TileGen.OreChunk(device, new Color(210, 216, 224), new Color(132, 140, 152));
            MineralIcons["geode"] = TileGen.GeodeIcon(device);
            MineralIcons["gem.diamond"] = TileGen.GemIcon(device, new Color(210, 236, 246), new Color(148, 196, 220));
            MineralIcons["gem.emerald"] = TileGen.GemIcon(device, new Color(86, 186, 118), new Color(36, 118, 72));
            MineralIcons["gem.sapphire"] = TileGen.GemIcon(device, new Color(72, 118, 214), new Color(36, 64, 148));
            MineralIcons["gem.jade"] = TileGen.GemIcon(device, new Color(118, 176, 96), new Color(64, 112, 58));
            for (int i = 0; i < Shells.Length; i++)
            {
                Shells[i] = TileGen.BeachShell(device, i);
                MineralIcons[BeachForage.ShellIds[i]] = Shells[i];
            }
            Seaweed = TileGen.BeachSeaweed(device);
            MineralIcons[BeachForage.SeaweedId] = Seaweed;
            for (int i = 0; i < ItemCatalog.Foods.Length; i++)
            {
                ItemDef f = ItemCatalog.Foods[i];
                FishIcons[f.Id] = TileGen.FoodIcon(device, f.Id);
            }
            for (int i = 0; i < ItemCatalog.Drinks.Length; i++)
            {
                ItemDef f = ItemCatalog.Drinks[i];
                FishIcons[f.Id] = TileGen.FoodIcon(device, f.Id);
            }
            for (int i = 0; i < CropCatalog.All.Length; i++)
            {
                CropDef c = CropCatalog.All[i];
                SeedPouch[c.Id] = TileGen.SeedPouch(device, c.Fruit);
                HeldPouch[c.Id] = HeldTools.Pouch(device, c.Fruit);
            }

            CropFrames["turnip"] = new[] { Bake(device, Sprout()), Bake(device, TurnipMid()), Bake(device, TurnipRipe()) };
            CropFrames["potato"] = new[] { Bake(device, Sprout()), Bake(device, PotatoMid()), Bake(device, PotatoRipe()) };
            CropFrames["cabbage"] = new[] { Bake(device, Sprout()), Bake(device, CabbageMid()), Bake(device, CabbageRipe()) };
            CropFrames["melon"] = new[] { Bake(device, Sprout()), Bake(device, MelonMid()), Bake(device, MelonRipe()) };
            CropFrames["pumpkin"] = new[] { Bake(device, Sprout()), Bake(device, PumpkinMid()), Bake(device, PumpkinRipe()) };
            ApplyPackFills();
        }

        void ApplyPackFills()
        {
            Texture2D grass = Pack.FillOf("grass_path", true);
            if (grass != null)
            {
                for (int i = 0; i < Grass.Length; i++)
                    Grass[i] = grass;
            }
            Texture2D woods = Pack.FillOf("woods_path", true);
            if (woods != null)
            {
                for (int i = 0; i < WoodsGrass.Length; i++)
                    WoodsGrass[i] = woods;
            }
            Texture2D sand = Pack.FillOf("water_sand", true) ?? Pack.ExtraFill("fill_sand");
            if (sand != null)
            {
                for (int i = 0; i < Sand.Length; i++)
                    Sand[i] = sand;
            }
            Texture2D path = Pack.FillOf("grass_path", false) ?? Pack.ExtraFill("fill_path");
            if (path != null)
            {
                Path[0] = path;
                Path[1] = path;
            }
            Texture2D soil = Pack.FillOf("grass_soil", false) ?? Pack.ExtraFill("fill_soil");
            if (soil != null)
                FarmSoil = soil;
            Texture2D tilled = Pack.ExtraFill("fill_tilled");
            if (tilled != null)
                Tilled = tilled;
            Texture2D wet = Pack.ExtraFill("fill_wet");
            if (wet != null)
                Wet = wet;
            Texture2D cobble = Pack.FillOf("grass_cobble", false) ?? Pack.ExtraFill("fill_cobble");
            if (cobble != null)
                Cobble = cobble;
            Texture2D mountain = Pack.FillOf("mountain_water", true) ?? Pack.ExtraFill("fill_mountain");
            if (mountain != null)
                Mountain = mountain;
            Texture2D rock = Pack.Object("rock");
            if (rock != null)
                Rock = rock;
            Texture2D stump = Pack.Object("stump");
            if (stump != null)
                Stump = stump;
            Texture2D flower = Pack.Object("flower");
            if (flower != null)
                Flower = flower;
            Texture2D shroom = Pack.Object("mushroom");
            if (shroom != null)
                Mushroom = shroom;
            Texture2D weed = Pack.Object("weed");
            if (weed != null)
                Weed = weed;
            Texture2D bush = Pack.Object("bush");
            if (bush != null)
                Bush = bush;
        }

        public Texture2D HouseSprite(Building b)
        {
            return HouseSprite(b, false);
        }

        public Texture2D HouseSprite(Building b, bool open)
        {
            string key = (b.Kind == BuildingKind.Cave ? "cave:" : b.Kind.ToString() + ":")
                + b.Style.ToString() + ":" + b.W.ToString() + ":" + b.H.ToString() + ":" + b.DoorDx.ToString()
                + (open ? ":o" : ":c") + (b.Repaired ? ":ok" : ":ruin");
            Texture2D tex;
            if (!_houses.TryGetValue(key, out tex))
            {
                if (b.Kind == BuildingKind.Cave)
                    tex = TileGen.CaveMouth(_device, b.W, b.H, b.DoorDx, open);
                else if (b.Kind == BuildingKind.FishMarket)
                    tex = TileGen.FishShack(_device, b.W, b.H, b.DoorDx, open);
                else if (b.Kind == BuildingKind.Cottage)
                    tex = TileGen.Farmhouse(_device, b.W, b.H, b.DoorDx, open);
                else if (b.Kind == BuildingKind.Carpenter)
                    tex = TileGen.Blacksmith(_device, b.W, b.H, b.DoorDx, open);
                else if (b.Kind == BuildingKind.Silo)
                    tex = TileGen.Silo(_device, b.W, b.H, b.DoorDx);
                else if (b.IsFarmOutbuilding)
                    tex = TileGen.Outbuilding(_device, b.Kind, b.W, b.H, b.DoorDx, open, !b.Repaired);
                else
                    tex = TileGen.House(_device, b.W, b.H, b.Style, b.DoorDx, open);
                _houses[key] = tex;
            }
            return tex;
        }

        public Texture2D BridgeSprite(StoneBridge b)
        {
            string key = (b.NorthSouth ? "ns:" : "ew:") + b.W.ToString() + "x" + b.H.ToString();
            Texture2D tex;
            if (!_bridges.TryGetValue(key, out tex))
            {
                int span = b.NorthSouth ? b.H : b.W;
                tex = TileGen.BridgeSpan(_device, Math.Max(3, span), b.NorthSouth);
                _bridges[key] = tex;
            }
            return tex;
        }

        public Texture2D BridgeTile(World world, int tx, int ty)
        {
            bool e = world.TileAt(tx + 1, ty) == TileType.Bridge;
            bool w = world.TileAt(tx - 1, ty) == TileType.Bridge;
            bool n = world.TileAt(tx, ty - 1) == TileType.Bridge;
            bool s = world.TileAt(tx, ty + 1) == TileType.Bridge;
            int ns = (n ? 1 : 0) + (s ? 1 : 0);
            int ew = (e ? 1 : 0) + (w ? 1 : 0);
            bool northSouth = ns > ew;
            int variant = (tx + ty) & 1;
            int key = (n ? 1 : 0) | (s ? 2 : 0) | (e ? 4 : 0) | (w ? 8 : 0)
                | (northSouth ? 16 : 0) | (variant << 5);
            Texture2D tex;
            if (!_woodDecks.TryGetValue(key, out tex))
            {
                bool railN = !northSouth && !n;
                bool railS = !northSouth && !s;
                bool railE = northSouth && !e;
                bool railW = northSouth && !w;
                tex = TileGen.WoodBridgeDeck(_device, variant, northSouth, railN, railS, railE, railW);
                _woodDecks[key] = tex;
            }
            return tex;
        }

        public Texture2D WaterAt(int tx, int ty, float minutes)
        {
            int frame = ((int)(minutes / 5)) & 3;
            int look = GameConst.WaterLook(tx, ty);
            if (look == 2)
                return WaterOcean[frame];
            if (look == 1 || look == 3)
                return WaterRiver[frame];
            return Water[frame];
        }

        public Texture2D Underlay(int tx, int ty)
        {
            int v = (tx * 3 + ty * 7) & 3;
            if (ty < GameConst.VillageH)
                return Grass[v];
            if (ty < GameConst.FarmOy)
                return MountainVar[v];
            if (ty >= GameConst.BeachOy)
                return Sand[v];
            if (GameConst.InDeepForest(tx, ty))
                return WoodsGrass[v];
            return Grass[v];
        }

        public Texture2D Ground(TileType t, int tx, int ty, float minutes, Building inside)
        {
            return Ground(t, tx, ty, minutes, inside, null);
        }

        public Texture2D Ground(TileType t, int tx, int ty, float minutes, Building inside, World world)
        {
            if (world != null && inside == null)
            {
                Texture2D packed = Pack.Ground(world, t, tx, ty);
                if (packed != null)
                    return packed;
            }
            bool indoors = inside != null;
            int v = (tx * 3 + ty * 7) & 3;
            switch (t)
            {
                case TileType.Grass:
                case TileType.Flower:
                case TileType.Tree:
                case TileType.Dummy:
                case TileType.Stump:
                    if (indoors)
                        return InteriorFloor(inside);
                    if (ty >= GameConst.BeachOy)
                        return Sand[v];
                    if (GameConst.InDeepForest(tx, ty))
                        return WoodsGrass[v];
                    if (ty >= GameConst.VillageH && ty < GameConst.FarmOy)
                        return MountainVar[v];
                    return Grass[v];
                case TileType.Rock:
                case TileType.Mineral:
                    if (indoors)
                        return InteriorFloor(inside);
                    if (ty >= GameConst.BeachOy)
                        return Sand[v];
                    if (GameConst.InDeepForest(tx, ty))
                        return WoodsGrass[v];
                    if (ty >= GameConst.VillageH && ty < GameConst.FarmOy)
                        return MountainVar[v];
                    return Grass[v];
                case TileType.Sand:
                case TileType.Shell:
                case TileType.Seaweed:
                    if (world != null && TouchesWater(world, tx, ty))
                        return WetSand[v];
                    return Sand[v];
                case TileType.WoodsGrass:
                    return WoodsGrass[v];
                case TileType.Mountain:
                    return MountainVar[v];
                case TileType.Cliff:
                    return CliffVar[(tx * 5 + ty * 3) & 3];
                case TileType.Bridge:
                    return BridgeDeckEw[(tx + ty) & 1];
                case TileType.Cobble:
                    return Cobble;
                case TileType.Roof:
                case TileType.HouseWall:
                    return indoors ? InteriorWall(inside, false) : Underlay(tx, ty);
                case TileType.HouseWindow:
                    return indoors ? InteriorWall(inside, true) : Underlay(tx, ty);
                case TileType.FarmSoil:
                case TileType.Weed:
                    return FarmSoil;
                case TileType.Hay:
                case TileType.HayCut:
                    if (ty >= GameConst.BeachOy)
                        return Sand[v];
                    if (GameConst.InDeepForest(tx, ty))
                        return WoodsGrass[v];
                    return Grass[v];
                case TileType.Tilled:
                    return Tilled;
                case TileType.Wet:
                    return Wet;
                case TileType.Path:
                case TileType.Bin:
                    return Path[(tx + ty) & 1];
                case TileType.Water:
                    return WaterAt(tx, ty, minutes);
                case TileType.Fence:
                    return Fence;
                case TileType.HouseFloor:
                case TileType.Bed:
                    return indoors ? InteriorFloor(inside) : Floor;
                case TileType.Door:
                    return indoors ? InteriorDoorOf(inside, false) : Path[(tx + ty) & 1];
                case TileType.Counter:
                    if (indoors && inside != null)
                    {
                        FurnishKind fk = inside.FurnishAt(tx, ty);
                        if (fk == FurnishKind.Stove)
                            return Stove;
                        if (fk == FurnishKind.Sink)
                            return Sink;
                        if (fk == FurnishKind.Keg)
                            return Keg;
                        if (fk == FurnishKind.Fridge)
                            return Fridge[(tx + ty) & 3];
                        if (fk == FurnishKind.Shelf)
                            return Shelf[(tx + ty) & 3];
                    }
                    return Counter;
                case TileType.Chest:
                    return indoors ? InteriorFloor(inside) : Underlay(tx, ty);
                case TileType.Stairs:
                    return Stairs;
                case TileType.Dock:
                    return DockPlank;
                case TileType.InvisibleWall:
                    return Underlay(tx, ty);
                default:
                    return Grass[0];
            }
        }

        static bool TouchesWater(World world, int tx, int ty)
        {
            int[] dx = { 0, 0, -1, 1 };
            int[] dy = { -1, 1, 0, 0 };
            for (int i = 0; i < 4; i++)
            {
                TileType n = world.TileAt(tx + dx[i], ty + dy[i]);
                if (n == TileType.Water || n == TileType.Dock || n == TileType.Bridge)
                    return true;
            }
            return false;
        }

        Texture2D InteriorWall(Building b, bool window)
        {
            string key = b.Id + (window ? ":win" : ":wall");
            Texture2D tex;
            if (!_inWalls.TryGetValue(key, out tex))
            {
                tex = TileGen.Wall(_device, window, b.Theme);
                _inWalls[key] = tex;
            }
            return tex;
        }

        Texture2D InteriorFloor(Building b)
        {
            Texture2D tex;
            if (!_inFloors.TryGetValue(b.Id, out tex))
            {
                tex = TileGen.Floor(_device, b.Theme);
                _inFloors[b.Id] = tex;
            }
            return tex;
        }

        public Texture2D InteriorDoorOf(Building b, bool open)
        {
            string key = b.Id + (open ? ":dooro" : ":door");
            Texture2D tex;
            if (!_inDoors.TryGetValue(key, out tex))
            {
                tex = TileGen.Door(_device, open, b.Theme);
                _inDoors[key] = tex;
            }
            return tex;
        }

        public Texture2D Prop(int kind)
        {
            if (kind == DecoKind.Crate) return Crate;
            if (kind == DecoKind.Picnic) return Picnic;
            if (kind == DecoKind.Bush) return Bush;
            if (kind == DecoKind.FishCrate) return FishCrate;
            if (kind == DecoKind.FishRack) return FishRack;
            if (kind == DecoKind.Shark) return DockShark;
            if (kind == DecoKind.Sack) return DockSack;
            if (kind == DecoKind.Rowboat) return Rowboat;
            if (kind == DecoKind.SailBlue) return SailBlue;
            if (kind == DecoKind.SailBrown) return SailBrown;
            if (kind == DecoKind.LogSlice) return LogSlice;
            return Barrel;
        }

        public Texture2D PlayerFrame(int dir, int frame)
        {
            return PlayerFrame(FarmerLook.Classic, dir, frame);
        }

        public Texture2D PlayerFrame(FarmerLook look, int dir, int frame)
        {
            look.Clamp();
            if (dir < 0) dir = 0;
            if (dir > 3) dir = 3;
            if (frame < 0) frame = 0;
            if (frame >= Characters.PoseCount)
                frame = Characters.PoseIdle;
            int key = look.Packed * 32 + dir * 8 + frame;
            Texture2D tex;
            if (_lookFrames.TryGetValue(key, out tex))
                return tex;
            if (_lookFrames.Count > 896)
            {
                foreach (KeyValuePair<int, Texture2D> kv in _lookFrames)
                {
                    if (kv.Value != null)
                        kv.Value.Dispose();
                }
                _lookFrames.Clear();
            }
            tex = Characters.Farmer(_device, dir, frame, look);
            _lookFrames[key] = tex;
            return tex;
        }

        public Texture2D NpcSprite(string id)
        {
            if (id == "mira") return Mira;
            if (id == "cob") return Cob;
            if (id == "lila") return Lila;
            if (id == "bram") return Bram;
            if (id == "nell") return Nell;
            if (id == "ash") return Ash;
            if (id == "bess") return Bess;
            if (id == "piper") return Piper;
            if (id == "finn") return Finn;
            return Rowan;
        }

        public Texture2D ItemIcon(string id)
        {
            ItemDef def = ItemCatalog.Find(id);
            if (def == null)
                return Pixel;
            if (def.Kind == ItemKind.Tool)
                return ToolIcon(def.Tool);
            if (def.Kind == ItemKind.Seed)
            {
                Texture2D pouch;
                if (SeedPouch.TryGetValue(def.CropId, out pouch))
                    return pouch;
                return Seed;
            }
            if (def.Kind == ItemKind.Produce || def.Kind == ItemKind.Food)
            {
                Texture2D extra;
                if (FishIcons.TryGetValue(id, out extra))
                    return extra;
                Texture2D[] frames;
                if (!string.IsNullOrEmpty(def.CropId) && CropFrames.TryGetValue(def.CropId, out frames) && frames.Length > 2)
                    return frames[2];
            }
            if (id == "wood")
                return WoodIcon;
            if (id == "plank")
                return PlankIcon;
            if (id == "stone")
                return StoneIcon;
            if (id == "fence")
                return Fence;
            Texture2D animal;
            if (AnimalIcons.TryGetValue(id, out animal))
                return animal;
            if (id == "fiber")
                return FiberIcon;
            if (id == "hay")
                return HayIcon;
            if (id == "milk")
                return MilkIcon;
            if (id == "wool")
                return WoolIcon;
            Texture2D mineral;
            if (MineralIcons.TryGetValue(id, out mineral))
                return mineral;
            return Pixel;
        }

        public Texture2D ToolIcon(ToolId id)
        {
            if (id == ToolId.Hoe) return Hoe;
            if (id == ToolId.Can) return Can;
            if (id == ToolId.Scythe) return Scythe;
            if (id == ToolId.Axe) return Axe;
            if (id == ToolId.Pickaxe) return Pickaxe;
            if (id == ToolId.Sword) return Sword;
            if (id == ToolId.Rod) return Rod;
            if (id == ToolId.MilkPail) return Pail;
            if (id == ToolId.Shears) return Shears;
            return Seed;
        }

        public Texture2D HeldSprite(ItemDef def)
        {
            if (def == null)
                return Pixel;
            if (def.Kind == ItemKind.Tool)
            {
                if (def.Tool == ToolId.Hoe) return HeldHoe;
                if (def.Tool == ToolId.Can) return HeldCan;
                if (def.Tool == ToolId.Scythe) return HeldScythe;
                if (def.Tool == ToolId.Axe) return HeldAxe;
                if (def.Tool == ToolId.Pickaxe) return HeldPickaxe;
                if (def.Tool == ToolId.Sword) return HeldSword;
                if (def.Tool == ToolId.Rod) return HeldRod;
                if (def.Tool == ToolId.MilkPail) return HeldPail;
                if (def.Tool == ToolId.Shears) return HeldShears;
            }
            if (def.Kind == ItemKind.Seed)
            {
                Texture2D pouch;
                if (HeldPouch.TryGetValue(def.CropId, out pouch))
                    return pouch;
            }
            return ItemIcon(def.Id);
        }

        public Vector2 HeldGrip(ItemDef def)
        {
            if (def != null && def.Kind == ItemKind.Tool)
                return HeldTools.GripOf(def.Tool);
            if (def != null && def.Kind == ItemKind.Seed)
                return HeldTools.GripBag;
            Texture2D icon = ItemIcon(def != null ? def.Id : "");
            return new Vector2(icon.Width / 2f, icon.Height * 0.7f);
        }

        public Texture2D HeldToolFrame(ItemDef def, string act, float swingU)
        {
            if (def != null && def.Kind == ItemKind.Tool && def.Tool == ToolId.Shears)
            {
                bool shut = act == "shear" && swingU > 0.18f && swingU < 0.82f
                    && (((int)(swingU * 8f)) & 1) == 0;
                return shut ? HeldShearsShut : HeldShears;
            }
            return HeldSprite(def);
        }

        static readonly Dictionary<char, Color> Pal = new Dictionary<char, Color>
        {
            {'k', new Color(56, 40, 32)},
            {'s', new Color(240, 196, 154)},
            {'S', new Color(212, 154, 112)},
            {'h', new Color(78, 108, 72)},
            {'H', new Color(52, 78, 50)},
            {'p', new Color(198, 156, 92)},
            {'P', new Color(156, 112, 62)},
            {'w', new Color(224, 214, 196)},
            {'n', new Color(118, 74, 42)},
            {'N', new Color(78, 46, 26)},
            {'o', new Color(72, 102, 64)},
            {'O', new Color(48, 74, 46)},
            {'g', new Color(102, 128, 68)},
            {'G', new Color(72, 98, 52)},
            {'l', new Color(148, 154, 86)},
            {'v', new Color(48, 68, 40)},
            {'a', new Color(154, 168, 92)},
            {'t', new Color(150, 96, 52)},
            {'T', new Color(92, 56, 32)},
            {'m', new Color(186, 146, 94)},
            {'u', new Color(78, 128, 132)},
            {'U', new Color(54, 96, 104)},
            {'y', new Color(214, 176, 72)},
            {'Y', new Color(168, 128, 42)},
            {'r', new Color(196, 86, 64)},
            {'R', new Color(148, 52, 42)},
            {'b', new Color(86, 118, 62)},
            {'B', new Color(58, 88, 48)},
            {'f', new Color(168, 118, 42)},
            {'x', new Color(132, 132, 138)},
            {'z', new Color(84, 84, 90)},
            {'i', new Color(236, 220, 186)},
            {'c', new Color(176, 86, 48)},
            {'e', new Color(224, 122, 47)},
            {'E', new Color(186, 86, 28)},
            {'q', new Color(196, 156, 98)},
            {'Q', new Color(150, 110, 64)},
            {'d', new Color(92, 64, 48)},
            {'j', new Color(244, 244, 250)}
        };

        public static Texture2D Bake(GraphicsDevice device, string[] rows)
        {
            int h = rows.Length;
            int w = rows[0].Length;
            Color[] data = new Color[w * h];
            for (int y = 0; y < h; y++)
            {
                string row = rows[y];
                for (int x = 0; x < w; x++)
                {
                    char ch = x < row.Length ? row[x] : '.';
                    Color c;
                    if (ch != '.' && Pal.TryGetValue(ch, out c))
                        data[y * w + x] = c;
                }
            }
            return TileGen.Scale2(device, data, w, h);
        }

        static string[] TreeMap()
        {
            return new[]
            {
                ".........kkkk.........",
                "......kkgllllgkk......",
                "....kglaaaaaaalgk.....",
                "...kglaaaaaaaalglk....",
                "..kglaaGaaaaGaaalgk...",
                "..kglaGaaaaaaGaalgk...",
                ".kglaaaaerGaaaaalgk...",
                ".kglaaaGaaaaGaaalgk...",
                "..kglaaaaaaaaaalgk....",
                "..kggGaaaaaaaGggk.....",
                "...kglGaaaaaGglk......",
                "....kggGGGGGggk.......",
                "......kkGvvkk.........",
                ".......kNTTk..........",
                ".......kNTNk..........",
                ".......kNTTk..........",
                "......kkNTTkk.........",
                ".....kTNNNNNTk........"
            };
        }

        static string[] DarkTreeMap()
        {
            return new[]
            {
                "........kkkk........",
                "......kkvGGvkk......",
                "....kkvGGGGGvvkk....",
                "...kvGGGvGGGGvvk....",
                "..kvGGvvGGGGvGGvk...",
                "..kvGGGvvvvvGGGvk...",
                "...kvGGvvvvvGGvk....",
                "....kvGGGvvGGGvk....",
                ".....kvGGvvGvk......",
                "......kkvGGkk.......",
                "........kNTk........",
                "........kNNk........",
                "........kNTk........",
                ".......kNNNNk.......",
                "......kNNNNNNk......"
            };
        }

        static string[] StumpMap()
        {
            return new[]
            {
                "................",
                "................",
                "....kkkkkkkk....",
                "...kmjjmmjjmk...",
                "...kmmmmmmmmk...",
                "...kTmmmmmmTk...",
                "....kTTTTTTk....",
                ".....kkkkkk....."
            };
        }

        static string[] RockMap()
        {
            return new[]
            {
                "................",
                "......kkkk......",
                "....kkxjjxkk....",
                "...kxjjxxxxxk...",
                "..kxxxzxxxxzxk..",
                "..kxzxxxxxxzxk..",
                "...kzzzzzzzzk...",
                "....kkkkkkkk...."
            };
        }

        static string[] MushroomMap()
        {
            return new[]
            {
                "................",
                "......krrrk.....",
                "....krrRRrrk....",
                "...krrjjjrrrk...",
                "....krrrrrrk....",
                "......kwwk......",
                "......kwwk......",
                ".....kwwwwk....."
            };
        }

        static string[] FlowerMap()
        {
            return new[]
            {
                "................",
                ".....krrrrk.....",
                "....rryyyryr....",
                "...kryyyyyyrk...",
                "....rryryyrr....",
                ".....kkyykk.....",
                ".......Bb.......",
                ".......Bb.......",
                "......gBBg......",
                ".....Gg..gG....."
            };
        }

        static string[] WeedMap()
        {
            return new[]
            {
                "................",
                "....l.g..l.g....",
                "...gl.gg.g.l....",
                "...gBlgBglBg....",
                "....BGgBGgB.....",
                ".....GGGGG......",
                "......GvG.......",
                ".......v........"
            };
        }

        static string[] BinMap()
        {
            return new[]
            {
                "..kkkkkkkkkkkkkk..",
                ".kmmmmmmmmmmmmmmk.",
                ".kmTTTTTTTTTTTTmk.",
                ".kmTyyyyyyyyyyTmk.",
                ".kmTyYYYYYYYYyTmk.",
                ".kmTTTTTTTTTTTTmk.",
                ".kmmmmmmmmmmmmmmk.",
                ".kTTTTTTTTTTTTTTk.",
                ".kTNNNNNNNNNNNNTk.",
                "..kkkkkkkkkkkkkk.."
            };
        }

        static string[] HoeMap()
        {
            return new[]
            {
                "................",
                "........kkkk....",
                "......kkmmmmk...",
                ".....kmmjjmmk...",
                "......kkmmkk....",
                "........nk......",
                ".......knk......",
                "......knk.......",
                ".....knk........",
                "....kNk.........",
                "...kNk..........",
                "................"
            };
        }

        static string[] CanMap()
        {
            return new[]
            {
                "................",
                ".....kkkkk......",
                "....kuuuuuk.kk..",
                "....kuujuuukUUk.",
                "....kUUUUUkuuuk.",
                "....kUUUUUkuUk..",
                ".....kUUUk.kk...",
                "......kkk.......",
                "................"
            };
        }

        static string[] ScytheMap()
        {
            return new[]
            {
                "................",
                "..........kkkk..",
                "........kkwjjk..",
                ".......kwwwwk...",
                "......kwwkk.....",
                ".....kwk........",
                "....kNk.........",
                "...kNk..........",
                "..kNk...........",
                ".kNk............",
                "................"
            };
        }

        static string[] RodMap()
        {
            return new[]
            {
                "................",
                "...........kk...",
                "..........kjk...",
                ".........kNk....",
                "........kNk.....",
                ".......kNk......",
                "......kNk.......",
                ".....kNk........",
                "....knk.........",
                "...knn..........",
                "..kk............",
                "................"
            };
        }

        static string[] PailMap()
        {
            return new[]
            {
                "................",
                "......k..k......",
                ".....kkkkkk.....",
                "....kmmjjmmk....",
                "....kmjjjjmk....",
                "....kmmmmmmk....",
                ".....kNNNNNk....",
                "......kkkk......",
                "................"
            };
        }

        static string[] MilkMap()
        {
            return new[]
            {
                "................",
                "......kkkk......",
                ".....kjjjjk.....",
                ".....kjwwjk.....",
                "....kjjjjjjk....",
                "....kiiiiijk....",
                "....kjjjijjk....",
                ".....kkkkkk.....",
                "......kNNk......",
                "................"
            };
        }

        static string[] ShearsMap()
        {
            return new[]
            {
                "................",
                "....kk....kk....",
                "...kxk...kxk....",
                "....kxk.kxk.....",
                ".....kxkxk......",
                "......kNk.......",
                ".....kN.Nk......",
                "....kN...Nk.....",
                "...kN.....Nk....",
                "................"
            };
        }

        static string[] WoolMap()
        {
            return new[]
            {
                "................",
                ".....kkkk.......",
                "....kiiiik......",
                "...kiiwiiik.....",
                "...kiwwwwik.....",
                "...kiiwiiik.....",
                "....kiiiik......",
                ".....kkkk.......",
                "................"
            };
        }

        static string[] AxeMap()
        {
            return new[]
            {
                "................",
                "......kkkkk.....",
                ".....kxxxxxk....",
                ".....kxjjxxk....",
                "......kkxxk.....",
                "........nk......",
                ".......kNk......",
                "......kNk.......",
                ".....kNk........",
                "....kNk.........",
                "...kNk..........",
                "................"
            };
        }

        static string[] PickaxeMap()
        {
            return new[]
            {
                "................",
                ".....kkkkkkk....",
                "....kxxxxxxxk...",
                ".....kkkxkk.....",
                ".......kzk......",
                "........nk......",
                ".......kNk......",
                "......kNk.......",
                ".....kNk........",
                "....kNk.........",
                "...kNk..........",
                "................"
            };
        }

        static string[] SwordMap()
        {
            return new[]
            {
                "................",
                ".......jjk......",
                "......jxxxk.....",
                ".....jxjjxxk....",
                "......kxxxk.....",
                ".......kk.......",
                "......kxk.......",
                ".......nk.......",
                "......kNk.......",
                ".....kNk........",
                "....kNk.........",
                "................"
            };
        }

        static string[] SeedMap()
        {
            return new[]
            {
                "................",
                "......kkkk......",
                ".....kttttk.....",
                ".....ktTTtk.....",
                ".....kTmmTk.....",
                "......kTTk......",
                ".......kk.......",
                "................"
            };
        }

        static string[] Sprout()
        {
            return new[]
            {
                "................",
                "................",
                "................",
                ".......l........",
                "......lbl.......",
                ".......Bb.......",
                ".......Bb.......",
                "......kTTk......",
                "................"
            };
        }

        static string[] TurnipMid()
        {
            return new[]
            {
                "................",
                "......l..l......",
                ".....lb..bl.....",
                "......bBBb......",
                ".......BB.......",
                "......kwwkk.....",
                ".....kwwjjwk....",
                "......kwwwk.....",
                ".......kkk......"
            };
        }

        static string[] TurnipRipe()
        {
            return new[]
            {
                "......l.l.l.....",
                ".....lbBlbl.....",
                "......bBBBb.....",
                ".....kbwwwbk....",
                "....kwwjjwwwk...",
                "....kwwwwwwwk...",
                ".....kRwwwwk....",
                "......kRRRk.....",
                ".......kkk......"
            };
        }

        static string[] PotatoMid()
        {
            return new[]
            {
                "................",
                ".......l........",
                "......lbl.......",
                ".....lbBbl......",
                "......BBBb......",
                ".....kqqqQk.....",
                "......kQQk......",
                "................"
            };
        }

        static string[] PotatoRipe()
        {
            return new[]
            {
                "......l.l.......",
                ".....lbBlb......",
                "......BBBb......",
                "....kqqQQqqk....",
                "...kqQjjQQqk....",
                "...kqqQQqqQk....",
                "....kQqqqQk.....",
                ".....kkkkkk....."
            };
        }

        static string[] CabbageMid()
        {
            return new[]
            {
                "................",
                "......lll.......",
                ".....lbBbl......",
                "....lbBBBBl.....",
                ".....bBaaBb.....",
                "......bBBb......",
                ".......kk......."
            };
        }

        static string[] CabbageRipe()
        {
            return new[]
            {
                ".....lllll......",
                "....lbBBBBl.....",
                "...lbBaaaBbl....",
                "...lBaajaaBl....",
                "...lbBaaaBbl....",
                "....lbBBBBl.....",
                ".....lBBBl......",
                "......kkk......."
            };
        }

        static string[] MelonMid()
        {
            return new[]
            {
                "................",
                "......l.l.......",
                ".....lbBbl......",
                "......BBBb......",
                ".....kgagak.....",
                "......kggk......",
                ".......kk......."
            };
        }

        static string[] MelonRipe()
        {
            return new[]
            {
                "......l.l.......",
                ".....lbBbl......",
                "....kggaggk.....",
                "...kgGaGaGggk...",
                "...kggagagggk...",
                "...kgGaGaGggk...",
                "....kggggggk....",
                ".....kkkkkk....."
            };
        }

        static string[] PumpkinMid()
        {
            return new[]
            {
                "................",
                ".......b........",
                "......bBb.......",
                ".....keeEek.....",
                "......keeek.....",
                ".......kkk......"
            };
        }

        static string[] PumpkinRipe()
        {
            return new[]
            {
                ".......Bb.......",
                "......kBbk......",
                "....keeEeEek....",
                "...keEeEeEeEk...",
                "...keeEeEeEek...",
                "...keEeEeEeEk...",
                "....keeEeEek....",
                ".....kkkkkk....."
            };
        }
    }
}
