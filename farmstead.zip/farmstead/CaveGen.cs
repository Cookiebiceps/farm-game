using System;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    public sealed class CaveFloor
    {
        public TileType[,] Tiles;
        public int DeepX = -1;
        public int DeepY = -1;
        public int[] ChestX = new int[0];
        public int[] ChestY = new int[0];
        public bool Vault;
    }

    /// <summary>
    /// Deterministic Ridge Hollow labyrinth: 100 depths, recursive-backtracker
    /// mazes, and a gold vault on every tenth floor.
    /// </summary>
    public static class CaveGen
    {
        public const int Levels = 100;
        public const int Iw = 34;
        public const int Ih = 22;
        public const int BackX = 14;
        const int CellsX = 8;
        const int CellsY = 5;
        const int Span = 4;

        public static CaveFloor Build(int level)
        {
            if (level < 1)
                level = 1;
            if (level > Levels)
                level = Levels;
            CaveFloor floor = new CaveFloor();
            floor.Tiles = Blank();
            if (level % 10 == 0)
                CarveVault(floor, level);
            else
                CarveMaze(floor, level);
            PlaceBackDoor(floor);
            return floor;
        }

        static TileType[,] Blank()
        {
            TileType[,] map = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    map[x, y] = TileType.HouseWall;
            }
            return map;
        }

        static void PlaceBackDoor(CaveFloor floor)
        {
            int x = BackX;
            floor.Tiles[x, Ih - 1] = TileType.Door;
            floor.Tiles[x, Ih - 2] = TileType.HouseFloor;
            floor.Tiles[x - 1, Ih - 2] = TileType.HouseFloor;
            floor.Tiles[x + 1, Ih - 2] = TileType.HouseFloor;
        }

        static void CarveVault(CaveFloor floor, int level)
        {
            floor.Vault = true;
            int x0 = 6;
            int y0 = 3;
            int w = 22;
            int h = 16;
            Fill(floor.Tiles, x0, y0, w, h, TileType.HouseFloor);
            Fill(floor.Tiles, BackX - 1, y0 + h, 3, Ih - 2 - (y0 + h), TileType.HouseFloor);

            // Chests sit near the south of the hall so they are in view from the mouth.
            int[] cx = { x0 + w / 2, x0 + 5, x0 + w - 6 };
            int[] cy = { y0 + h - 3, y0 + h - 4, y0 + h - 4 };
            floor.ChestX = cx;
            floor.ChestY = cy;
            for (int i = 0; i < cx.Length; i++)
                floor.Tiles[cx[i], cy[i]] = TileType.Chest;

            Put(floor.Tiles, x0 + 2, y0 + 2, TileType.Rock);
            Put(floor.Tiles, x0 + w - 3, y0 + 2, TileType.Rock);
            Put(floor.Tiles, x0 + 2, y0 + 3, TileType.Flower);
            Put(floor.Tiles, x0 + w - 3, y0 + 3, TileType.Flower);
            Put(floor.Tiles, x0 + w / 2, y0 + 2, TileType.Mineral);

            if (level < Levels)
            {
                floor.DeepX = x0 + w / 2;
                floor.DeepY = y0 + 1;
                floor.Tiles[floor.DeepX, floor.DeepY] = TileType.Door;
            }
        }

        static void CarveMaze(CaveFloor floor, int level)
        {
            Random rng = new Random(7109 + level * 917);
            bool[,] seen = new bool[CellsX, CellsY];
            int startCx = 3;
            int startCy = CellsY - 1;
            Walk(floor.Tiles, seen, startCx, startCy, rng);
            ConnectSouth(floor.Tiles, startCx, startCy);

            int sx = CellX(startCx) + 1;
            int sy = CellY(startCy) + 1;
            int dx, dy;
            FarthestFloor(floor.Tiles, sx, sy, out dx, out dy);
            floor.DeepX = dx;
            floor.DeepY = dy;
            floor.Tiles[dx, dy] = TileType.Door;

            Scatter(floor.Tiles, rng, level);
        }

        static void Walk(TileType[,] map, bool[,] seen, int cx, int cy, Random rng)
        {
            CarveCell(map, cx, cy);
            seen[cx, cy] = true;
            int[] order = { 0, 1, 2, 3 };
            Shuffle(order, rng);
            for (int i = 0; i < 4; i++)
            {
                int dir = order[i];
                int nx = cx + (dir == 1 ? 1 : dir == 3 ? -1 : 0);
                int ny = cy + (dir == 0 ? 1 : dir == 2 ? -1 : 0);
                if (nx < 0 || ny < 0 || nx >= CellsX || ny >= CellsY || seen[nx, ny])
                    continue;
                if (dir == 0)
                    CarveV(map, cx, cy);
                else if (dir == 1)
                    CarveH(map, cx, cy);
                else if (dir == 2)
                    CarveV(map, nx, ny);
                else
                    CarveH(map, nx, ny);
                Walk(map, seen, nx, ny, rng);
            }
        }

        static void FarthestFloor(TileType[,] map, int sx, int sy, out int bx, out int by)
        {
            int cap = Iw * Ih;
            int[] qx = new int[cap];
            int[] qy = new int[cap];
            int[,] dist = new int[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    dist[x, y] = -1;
            }
            int qh = 0;
            int qt = 0;
            qx[qt] = sx;
            qy[qt] = sy;
            qt++;
            dist[sx, sy] = 0;
            bx = sx;
            by = sy;
            int best = 0;
            int[] ox = { 0, 1, 0, -1 };
            int[] oy = { 1, 0, -1, 0 };
            while (qh < qt)
            {
                int x = qx[qh];
                int y = qy[qh];
                qh++;
                if (dist[x, y] > best && y < Ih - 4)
                {
                    best = dist[x, y];
                    bx = x;
                    by = y;
                }
                for (int i = 0; i < 4; i++)
                {
                    int nx = x + ox[i];
                    int ny = y + oy[i];
                    if (nx <= 0 || ny <= 0 || nx >= Iw - 1 || ny >= Ih - 1)
                        continue;
                    if (dist[nx, ny] >= 0)
                        continue;
                    if (map[nx, ny] != TileType.HouseFloor)
                        continue;
                    dist[nx, ny] = dist[x, y] + 1;
                    qx[qt] = nx;
                    qy[qt] = ny;
                    qt++;
                }
            }
        }

        static void CarveCell(TileType[,] map, int cx, int cy)
        {
            int x = CellX(cx);
            int y = CellY(cy);
            Fill(map, x, y, 3, 3, TileType.HouseFloor);
        }

        static void CarveH(TileType[,] map, int cx, int cy)
        {
            int x = CellX(cx) + 3;
            int y = CellY(cy) + 1;
            Put(map, x, y, TileType.HouseFloor);
        }

        static void CarveV(TileType[,] map, int cx, int cy)
        {
            int x = CellX(cx) + 1;
            int y = CellY(cy) + 3;
            Put(map, x, y, TileType.HouseFloor);
        }

        static void ConnectSouth(TileType[,] map, int cx, int cy)
        {
            int x = CellX(cx) + 1;
            int y0 = CellY(cy) + 3;
            for (int y = y0; y <= Ih - 2; y++)
            {
                Put(map, x, y, TileType.HouseFloor);
                Put(map, x - 1, y, TileType.HouseFloor);
                Put(map, x + 1, y, TileType.HouseFloor);
            }
        }

        static int CellX(int cx)
        {
            return 1 + cx * Span;
        }

        static int CellY(int cy)
        {
            return 1 + cy * Span;
        }

        static void Scatter(TileType[,] map, Random rng, int level)
        {
            int rocks = 4 + level / 12;
            int veins = 3 + level / 15;
            int shrooms = 4;
            for (int i = 0; i < rocks; i++)
                ScatterOne(map, rng, TileType.Rock);
            for (int i = 0; i < veins; i++)
                ScatterOne(map, rng, TileType.Mineral);
            for (int i = 0; i < shrooms; i++)
                ScatterOne(map, rng, TileType.Flower);
        }

        static void ScatterOne(TileType[,] map, Random rng, TileType t)
        {
            for (int n = 0; n < 40; n++)
            {
                int x = rng.Next(2, Iw - 2);
                int y = rng.Next(2, Ih - 3);
                if (map[x, y] != TileType.HouseFloor)
                    continue;
                if (x == BackX && y >= Ih - 3)
                    continue;
                map[x, y] = t;
                return;
            }
        }

        static void Fill(TileType[,] map, int x0, int y0, int w, int h, TileType t)
        {
            for (int y = y0; y < y0 + h; y++)
            {
                for (int x = x0; x < x0 + w; x++)
                    Put(map, x, y, t);
            }
        }

        static void Put(TileType[,] map, int x, int y, TileType t)
        {
            if (x <= 0 || y < 0 || x >= Iw - 1 || y >= Ih - 1)
                return;
            if (y == 0 && t != TileType.Door)
                return;
            map[x, y] = t;
        }

        static void Shuffle(int[] a, Random rng)
        {
            for (int i = a.Length - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }

        public static Vector2 SpawnBack()
        {
            return new Vector2((BackX + 0.5f) * GameConst.Tile, (Ih - 2.55f) * GameConst.Tile);
        }

        public static Vector2 SpawnAt(int tx, int ty)
        {
            if (tx < 1)
                tx = 1;
            return new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 1.45f) * GameConst.Tile);
        }

        public static int ChestGold(int level, int chest)
        {
            int vault = level / 10;
            int baseGold = 40 * vault;
            if (level >= Levels)
                baseGold += 200;
            if (chest == 0)
                return baseGold + 20;
            return baseGold;
        }

        public static int LootBit(int level, int chest)
        {
            int vault = level / 10 - 1;
            if (vault < 0)
                vault = 0;
            return vault * 3 + chest;
        }
    }
}
