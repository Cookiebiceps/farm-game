using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// In-hand 3/4 tool models. Painted at 32×32 then Scale2x. Grip points
    /// are in texture pixels (after Scale2x) at the handle the farmer holds.
    /// </summary>
    public static class HeldTools
    {
        const int Src = 32;

        static readonly Color Ink = new Color(52, 34, 24);
        static readonly Color WoodHi = new Color(222, 164, 92);
        static readonly Color Wood = new Color(168, 108, 48);
        static readonly Color WoodLo = new Color(96, 56, 28);
        static readonly Color Wrap = new Color(138, 78, 42);
        static readonly Color WrapLo = new Color(92, 50, 28);
        static readonly Color SteelHi = new Color(236, 240, 246);
        static readonly Color Steel = new Color(164, 176, 190);
        static readonly Color SteelLo = new Color(88, 98, 114);
        static readonly Color CopperHi = new Color(236, 176, 96);
        static readonly Color Copper = new Color(186, 118, 52);
        static readonly Color CopperLo = new Color(118, 68, 32);
        static readonly Color SkinHi = new Color(248, 208, 168);
        static readonly Color Skin = new Color(232, 176, 132);
        static readonly Color SkinLo = new Color(196, 132, 92);
        static readonly Color Milk = new Color(250, 248, 236);
        static readonly Color Water = new Color(72, 148, 210);

        static Vector2 T(float x, float y)
        {
            return new Vector2(x * 2f, y * 2f);
        }

        public static Vector2 GripOf(ToolId id)
        {
            if (id == ToolId.Can)
                return T(14f, 20f);
            if (id == ToolId.MilkPail)
                return T(15f, 21f);
            if (id == ToolId.Rod)
                return T(11f, 25f);
            if (id == ToolId.Shears)
                return T(16f, 24f);
            if (id == ToolId.Sword)
                return T(16f, 26f);
            if (id == ToolId.Scythe)
                return T(13f, 26f);
            if (id == ToolId.Pickaxe)
                return T(16f, 26f);
            if (id == ToolId.Axe)
                return T(15f, 26f);
            return T(16f, 26f);
        }

        public static Vector2 GripLong
        {
            get { return T(16f, 26f); }
        }

        public static Vector2 GripCan
        {
            get { return T(14f, 20f); }
        }

        public static Vector2 GripBag
        {
            get { return T(16f, 21f); }
        }

        public static Texture2D Hoe(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 16, 10, 16, 29, 2, WoodHi, Wood, WoodLo);
                Band(d, w, 13, 22, 6, 3, Wrap, Wood, WrapLo);
                Band(d, w, 13, 9, 6, 3, SteelHi, Steel, SteelLo);
                for (int y = 4; y <= 10; y++)
                {
                    int flare = y <= 6 ? 10 : 8 - (y - 6);
                    int x0 = 16 - flare;
                    int x1 = 16 + flare;
                    for (int x = x0; x <= x1; x++)
                    {
                        Color c = y <= 5 ? SteelHi : y >= 9 ? SteelLo : Steel;
                        if (x <= x0 + 1)
                            c = SteelHi;
                        if (x >= x1 - 1)
                            c = Mix(c, Ink, 25);
                        Plot(d, w, x, y, c);
                    }
                    Plot(d, w, x0, y, Ink);
                    Plot(d, w, x1, y, Ink);
                }
                for (int x = 6; x <= 26; x++)
                {
                    Plot(d, w, x, 4, Ink);
                    Plot(d, w, x, 10, Ink);
                }
                Plot(d, w, 10, 5, SteelHi);
                Plot(d, w, 22, 6, SteelLo);
            });
        }

        public static Texture2D Axe(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 13, 12, 16, 29, 2, WoodHi, Wood, WoodLo);
                Band(d, w, 11, 21, 6, 3, Wrap, Wood, WrapLo);
                Band(d, w, 11, 11, 7, 3, SteelHi, Steel, SteelLo);
                for (int y = 5; y <= 16; y++)
                {
                    int inset = Math.Abs(y - 10);
                    int x0 = 15;
                    int x1 = 28 - inset;
                    if (x1 < x0 + 3)
                        x1 = x0 + 3;
                    for (int x = x0; x <= x1; x++)
                    {
                        float u = (x - x0) / (float)Math.Max(1, x1 - x0);
                        Color c = y <= 7 ? SteelHi : y >= 14 ? SteelLo : Mix(SteelHi, Steel, (int)(u * 55));
                        if (x >= x1 - 1)
                            c = SteelHi;
                        Plot(d, w, x, y, c);
                    }
                    Plot(d, w, x0, y, Ink);
                    Plot(d, w, x1, y, Ink);
                }
                for (int x = 15; x <= 28; x++)
                {
                    Plot(d, w, x, 5, Ink);
                    Plot(d, w, x, 16, Ink);
                }
                Fill(d, w, 11, 8, 5, 5, SteelLo);
                OutlineRect(d, w, 11, 8, 5, 5);
                Plot(d, w, 22, 7, SteelHi);
                Plot(d, w, 18, 14, SteelLo);
            });
        }

        public static Texture2D Pickaxe(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 16, 12, 16, 29, 2, WoodHi, Wood, WoodLo);
                Band(d, w, 13, 22, 6, 3, Wrap, Wood, WrapLo);
                Band(d, w, 13, 11, 6, 3, SteelHi, Steel, SteelLo);
                for (int i = 0; i <= 10; i++)
                {
                    int x = 16 + i;
                    int y = 8 - i / 3;
                    int thick = 3 - i / 5;
                    for (int t = 0; t <= thick; t++)
                    {
                        Color c = t == 0 ? SteelHi : t == thick ? SteelLo : Steel;
                        Plot(d, w, x, y + t, c);
                    }
                    Plot(d, w, x, y - 1, Ink);
                    Plot(d, w, x, y + thick + 1, Ink);
                }
                Plot(d, w, 27, 4, SteelHi);
                Plot(d, w, 27, 5, Ink);
                for (int i = 0; i <= 9; i++)
                {
                    int x = 16 - i;
                    int y = 10 + i / 2;
                    int thick = 3 - i / 5;
                    for (int t = 0; t <= thick; t++)
                    {
                        Color c = t == 0 ? Steel : SteelLo;
                        Plot(d, w, x, y + t, c);
                    }
                    Plot(d, w, x, y - 1, Ink);
                    Plot(d, w, x, y + thick + 1, Ink);
                }
                Plot(d, w, 6, 15, SteelLo);
                Plot(d, w, 6, 16, Ink);
            });
        }

        public static Texture2D Sword(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 16, 18, 16, 29, 2, Wrap, Wood, WrapLo);
                Fill(d, w, 14, 27, 4, 3, SteelLo);
                OutlineRect(d, w, 14, 27, 4, 3);
                Plot(d, w, 15, 28, SteelHi);
                Fill(d, w, 9, 16, 14, 3, Steel);
                Fill(d, w, 10, 16, 12, 1, SteelHi);
                Fill(d, w, 10, 18, 12, 1, SteelLo);
                OutlineRect(d, w, 9, 16, 14, 3);
                for (int y = 2; y <= 16; y++)
                {
                    int flare = y < 5 ? 1 : (y > 13 ? 2 : 2);
                    int x0 = 16 - flare;
                    int x1 = 16 + flare;
                    for (int x = x0; x <= x1; x++)
                    {
                        Color c = x <= 15 ? SteelHi : x >= 17 ? SteelLo : Steel;
                        Plot(d, w, x, y, c);
                    }
                    Plot(d, w, x0, y, Ink);
                    Plot(d, w, x1, y, Ink);
                }
                Plot(d, w, 15, 1, Ink);
                Plot(d, w, 16, 1, SteelHi);
                Plot(d, w, 17, 1, Ink);
                Plot(d, w, 16, 2, SteelHi);
            });
        }

        public static Texture2D FishingRod(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 9, 28, 24, 3, 1, WoodHi, Wood, WoodLo);
                Band(d, w, 8, 24, 5, 4, Wrap, Wood, WrapLo);
                Fill(d, w, 7, 23, 5, 4, SteelLo);
                OutlineRect(d, w, 7, 23, 5, 4);
                Plot(d, w, 9, 24, SteelHi);
                Plot(d, w, 10, 25, Steel);
                Plot(d, w, 24, 3, SteelHi);
                Plot(d, w, 25, 3, Steel);
                Plot(d, w, 24, 2, Ink);
                int lx = 25;
                int ly = 4;
                for (int i = 0; i < 10; i++)
                {
                    Plot(d, w, lx, ly, Mix(SteelHi, Water, 20));
                    lx += (i % 3 == 0) ? 1 : 0;
                    ly += 1;
                }
                Plot(d, w, lx, ly, new Color(214, 80, 72));
            });
        }

        public static Texture2D Scythe(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                Rod(d, w, 11, 10, 14, 29, 2, WoodHi, Wood, WoodLo);
                Band(d, w, 9, 22, 6, 3, Wrap, Wood, WrapLo);
                Band(d, w, 9, 9, 6, 3, SteelHi, Steel, SteelLo);
                int[] xs = { 14, 17, 20, 23, 26, 28, 28, 27, 25, 22, 19 };
                int[] ys = { 9, 7, 6, 5, 6, 8, 11, 14, 16, 17, 16 };
                for (int i = 0; i < xs.Length; i++)
                {
                    int x = xs[i];
                    int y = ys[i];
                    Plot(d, w, x, y, Ink);
                    Plot(d, w, x, y + 1, SteelHi);
                    Plot(d, w, x, y + 2, Steel);
                    Plot(d, w, x, y + 3, SteelLo);
                    Plot(d, w, x, y + 4, Ink);
                    Plot(d, w, x + 1, y + 1, SteelHi);
                    Plot(d, w, x + 1, y + 2, Steel);
                    Plot(d, w, x - 1, y + 2, Mix(Steel, Ink, 20));
                }
                Plot(d, w, 26, 8, SteelHi);
            });
        }

        public static Texture2D Can(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                for (int y = 11; y <= 24; y++)
                {
                    for (int x = 7; x <= 20; x++)
                    {
                        float u = (x - 7) / 13f;
                        Color c = u < 0.22f ? CopperHi : u < 0.55f ? Copper : CopperLo;
                        if (x == 7 || x == 20 || y == 11 || y == 24)
                            c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 8; x <= 19; x++)
                {
                    Plot(d, w, x, 10, Ink);
                    Plot(d, w, x, 12, Water);
                    Plot(d, w, x, 13, Mix(Water, Ink, 25));
                }
                Plot(d, w, 10, 11, CopperHi);
                Plot(d, w, 14, 11, Mix(Water, SteelHi, 40));
                Plot(d, w, 18, 11, CopperLo);
                for (int i = 0; i < 9; i++)
                {
                    int x = 20 + i;
                    int y = 13 + i / 3;
                    Plot(d, w, x, y, Ink);
                    Plot(d, w, x, y + 1, CopperHi);
                    Plot(d, w, x, y + 2, Copper);
                    Plot(d, w, x, y + 3, Ink);
                }
                Plot(d, w, 28, 15, SteelHi);
                Plot(d, w, 29, 16, Water);
                for (int i = 0; i < 6; i++)
                {
                    Plot(d, w, 10 - i / 2, 10 - i, Ink);
                    Plot(d, w, 17 + i / 2, 10 - i, Ink);
                    Plot(d, w, 10 - i / 2 + 1, 10 - i, Steel);
                    Plot(d, w, 17 + i / 2 - 1, 10 - i, Steel);
                }
                for (int x = 10; x <= 17; x++)
                    Plot(d, w, x, 4, Ink);
                for (int x = 11; x <= 16; x++)
                    Plot(d, w, x, 5, Steel);
            });
        }

        public static Texture2D Pail(GraphicsDevice gd)
        {
            return Build(gd, (d, w) =>
            {
                for (int y = 11; y <= 25; y++)
                {
                    int inset = y > 22 ? y - 22 : 0;
                    for (int x = 7 + inset; x <= 23 - inset; x++)
                    {
                        float u = (x - 7) / 16f;
                        Color c = u < 0.22f ? WoodHi : u < 0.55f ? Wood : WoodLo;
                        if (x == 7 + inset || x == 23 - inset || y == 11 || y == 25)
                            c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 8; x <= 22; x++)
                {
                    Plot(d, w, x, 10, Ink);
                    Plot(d, w, x, 12, Milk);
                    Plot(d, w, x, 13, Mix(Milk, Wood, 20));
                }
                Plot(d, w, 11, 11, WoodHi);
                Plot(d, w, 15, 11, Mix(Milk, SteelHi, 30));
                Plot(d, w, 19, 11, WoodLo);
                Band(d, w, 7, 16, 17, 3, SteelHi, Steel, SteelLo);
                Band(d, w, 8, 22, 15, 2, SteelLo, Steel, Ink);
                for (int i = 0; i < 6; i++)
                {
                    Plot(d, w, 11 - i / 2, 10 - i, Ink);
                    Plot(d, w, 19 + i / 2, 10 - i, Ink);
                    Plot(d, w, 11 - i / 2 + 1, 10 - i, Steel);
                    Plot(d, w, 19 + i / 2 - 1, 10 - i, Steel);
                }
                for (int x = 11; x <= 19; x++)
                    Plot(d, w, x, 4, Ink);
                for (int x = 12; x <= 18; x++)
                    Plot(d, w, x, 5, Steel);
            });
        }

        public static Texture2D Shears(GraphicsDevice gd)
        {
            return Shears(gd, true);
        }

        public static Texture2D Shears(GraphicsDevice gd, bool open)
        {
            return Build(gd, (d, w) =>
            {
                int spread = open ? 4 : 1;
                Rod(d, w, 16 - spread, 12, 11, 26, 2, Wrap, Wood, WrapLo);
                Rod(d, w, 16 + spread, 12, 21, 26, 2, Wrap, Wood, WrapLo);
                Disc(d, w, 11, 27, 3, SteelHi, Steel, Ink);
                Disc(d, w, 21, 27, 3, SteelHi, Steel, Ink);
                Plot(d, w, 11, 27, Ink);
                Plot(d, w, 21, 27, Ink);
                Band(d, w, 13, 12, 6, 3, SteelHi, Steel, SteelLo);
                for (int i = 0; i < 10; i++)
                {
                    int y = 12 - i;
                    int s = open ? i / 2 : i / 5;
                    Plot(d, w, 15 - s, y, Ink);
                    Plot(d, w, 16 - s, y, SteelHi);
                    Plot(d, w, 17 - s, y, Steel);
                    Plot(d, w, 15 + s, y, Ink);
                    Plot(d, w, 16 + s, y, Steel);
                    Plot(d, w, 17 + s, y, SteelHi);
                }
                Plot(d, w, open ? 10 : 14, 3, SteelHi);
                Plot(d, w, open ? 22 : 18, 3, SteelHi);
            });
        }

        public static Texture2D Pouch(GraphicsDevice gd, Color crop)
        {
            Color bag = new Color(176, 128, 72);
            Color bagLo = new Color(118, 78, 40);
            Color bagHi = new Color(214, 176, 118);
            return Build(gd, (d, w) =>
            {
                for (int y = 10; y <= 26; y++)
                {
                    int inset = y < 14 ? 14 - y : (y > 22 ? y - 22 : 0);
                    int x0 = 9 + inset;
                    int x1 = 23 - inset;
                    for (int x = x0; x <= x1; x++)
                    {
                        float u = (x - x0) / (float)Math.Max(1, x1 - x0);
                        Color c = u < 0.25f ? bagHi : u < 0.7f ? bag : bagLo;
                        if (x == x0 || x == x1 || y == 10 || y == 26)
                            c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 12; x <= 20; x++)
                {
                    Plot(d, w, x, 11, crop);
                    Plot(d, w, x, 12, Mix(crop, bagHi, 30));
                }
                Plot(d, w, 15, 8, Ink);
                Plot(d, w, 16, 7, Ink);
                Plot(d, w, 16, 8, bagHi);
                Plot(d, w, 17, 8, Ink);
                Plot(d, w, 14, 17, crop);
                Plot(d, w, 15, 17, crop);
                Plot(d, w, 16, 18, Mix(crop, Ink, 20));
                Band(d, w, 12, 20, 8, 2, Wrap, Wood, WrapLo);
            });
        }

        public static Texture2D Hand(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                Fill(d, w, 3, 6, 10, 8, Skin);
                Fill(d, w, 3, 6, 5, 5, SkinHi);
                Fill(d, w, 10, 9, 3, 5, SkinLo);
                OutlineRect(d, w, 3, 6, 10, 8);
                Plot(d, w, 5, 3, Ink);
                Plot(d, w, 8, 2, Ink);
                Plot(d, w, 11, 3, Ink);
                Plot(d, w, 5, 4, SkinHi);
                Plot(d, w, 8, 3, SkinHi);
                Plot(d, w, 11, 4, Skin);
                Plot(d, w, 5, 5, Skin);
                Plot(d, w, 8, 4, Skin);
                Plot(d, w, 11, 5, SkinLo);
                Plot(d, w, 13, 11, SkinLo);
            });
        }

        static void Disc(Color[] d, int w, int cx, int cy, int r, Color hi, Color mid, Color ink)
        {
            for (int y = -r; y <= r; y++)
            {
                for (int x = -r; x <= r; x++)
                {
                    if (x * x + y * y > r * r)
                        continue;
                    Color c = x + y < 0 ? hi : mid;
                    if (x * x + y * y > (r - 1) * (r - 1))
                        c = ink;
                    Plot(d, w, cx + x, cy + y, c);
                }
            }
        }

        static void Rod(Color[] d, int w, int x0, int y0, int x1, int y1, int r, Color hi, Color mid, Color lo)
        {
            int steps = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
            for (int i = 0; i <= steps; i++)
            {
                float t = steps == 0 ? 0f : i / (float)steps;
                int cx = x0 + (int)Math.Round((x1 - x0) * t);
                int cy = y0 + (int)Math.Round((y1 - y0) * t);
                for (int dx = -r; dx <= r; dx++)
                {
                    float u = (dx + r) / (float)Math.Max(1, 2 * r);
                    Color c = u < 0.3f ? hi : u < 0.65f ? mid : lo;
                    if (dx == -r || dx == r)
                        c = Ink;
                    Plot(d, w, cx + dx, cy, c);
                }
            }
        }

        static void Band(Color[] d, int w, int x, int y, int bw, int bh, Color hi, Color mid, Color lo)
        {
            for (int yy = 0; yy < bh; yy++)
            {
                for (int xx = 0; xx < bw; xx++)
                {
                    float u = xx / (float)Math.Max(1, bw - 1);
                    Color c = u < 0.3f ? hi : u < 0.65f ? mid : lo;
                    if (xx == 0 || yy == 0 || xx == bw - 1 || yy == bh - 1)
                        c = Ink;
                    Plot(d, w, x + xx, y + yy, c);
                }
            }
        }

        static void Fill(Color[] d, int w, int x0, int y0, int bw, int bh, Color c)
        {
            for (int y = 0; y < bh; y++)
            {
                for (int x = 0; x < bw; x++)
                    Plot(d, w, x0 + x, y0 + y, c);
            }
        }

        static void OutlineRect(Color[] d, int w, int x0, int y0, int bw, int bh)
        {
            for (int x = 0; x < bw; x++)
            {
                Plot(d, w, x0 + x, y0, Ink);
                Plot(d, w, x0 + x, y0 + bh - 1, Ink);
            }
            for (int y = 0; y < bh; y++)
            {
                Plot(d, w, x0, y0 + y, Ink);
                Plot(d, w, x0 + bw - 1, y0 + y, Ink);
            }
        }

        static Color Mix(Color a, Color b, int bAmt)
        {
            int aAmt = 100 - bAmt;
            return new Color(
                (a.R * aAmt + b.R * bAmt) / 100,
                (a.G * aAmt + b.G * bAmt) / 100,
                (a.B * aAmt + b.B * bAmt) / 100);
        }

        static Texture2D Build(GraphicsDevice gd, Action<Color[], int> paint)
        {
            return Build(gd, Src, Src, (d, w, h) => paint(d, w));
        }

        static Texture2D Build(GraphicsDevice gd, int w, int h, Action<Color[], int, int> paint)
        {
            Color[] data = new Color[w * h];
            paint(data, w, h);
            return TileGen.Scale2(gd, data, w, h);
        }

        static void Plot(Color[] d, int w, int x, int y, Color c)
        {
            int h = d.Length / w;
            if (x < 0 || y < 0 || x >= w || y >= h)
                return;
            d[y * w + x] = c;
        }
    }
}
