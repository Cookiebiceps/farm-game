namespace HarvestHollow
{
    public enum ItemKind
    {
        Tool,
        Seed,
        Produce,
        Resource,
        Placeable,
        Food
    }

    public sealed class ItemDef
    {
        public string Id;
        public string Name;
        public ItemKind Kind;
        public ToolId Tool;
        public string CropId;
        public bool Stackable;
        public int MaxStack;
        public int Sell;
        public int Restore;

        public ItemDef(string id, string name, ItemKind kind, ToolId tool, string cropId, bool stackable, int maxStack, int sell)
            : this(id, name, kind, tool, cropId, stackable, maxStack, sell, 0)
        {
        }

        public ItemDef(string id, string name, ItemKind kind, ToolId tool, string cropId, bool stackable, int maxStack, int sell, int restore)
        {
            Id = id;
            Name = name;
            Kind = kind;
            Tool = tool;
            CropId = cropId;
            Stackable = stackable;
            MaxStack = maxStack;
            Sell = sell;
            Restore = restore;
        }
    }

    public sealed class InvSlot
    {
        public string Id;
        public int Count;

        public bool Empty
        {
            get { return string.IsNullOrEmpty(Id) || Count <= 0; }
        }

        public void Clear()
        {
            Id = null;
            Count = 0;
        }

        public void Set(string id, int count)
        {
            Id = id;
            Count = count;
            if (Count <= 0)
                Clear();
        }
    }

    public struct SlotLoc
    {
        public bool Valid;
        public bool Bar;
        public int Index;

        public static SlotLoc None
        {
            get { return new SlotLoc(); }
        }

        public static SlotLoc PackAt(int i)
        {
            SlotLoc s = new SlotLoc();
            s.Valid = true;
            s.Bar = false;
            s.Index = i;
            return s;
        }

        public static SlotLoc BarAt(int i)
        {
            SlotLoc s = new SlotLoc();
            s.Valid = true;
            s.Bar = true;
            s.Index = i;
            return s;
        }

        public bool Same(SlotLoc other)
        {
            return Valid && other.Valid && Bar == other.Bar && Index == other.Index;
        }
    }

    public static class ItemCatalog
    {
        public static readonly ItemDef Hoe = Tool("hoe", "Hoe", ToolId.Hoe);
        public static readonly ItemDef Can = Tool("can", "Watering can", ToolId.Can);
        public static readonly ItemDef Scythe = Tool("scythe", "Scythe", ToolId.Scythe);
        public static readonly ItemDef Axe = Tool("axe", "Axe", ToolId.Axe);
        public static readonly ItemDef Pickaxe = Tool("pickaxe", "Pickaxe", ToolId.Pickaxe);
        public static readonly ItemDef Sword = Tool("sword", "Sword", ToolId.Sword);
        public static readonly ItemDef Rod = Tool("rod", "Fishing pole", ToolId.Rod);
        public static readonly ItemDef MilkPail = Tool("pail", "Milk pail", ToolId.MilkPail);
        public static readonly ItemDef Shears = Tool("shears", "Shears", ToolId.Shears);
        public const int PlanksPerPail = 4;
        public const int PlanksPerShears = 3;
        public const int ShearsCost = 150;
        public static readonly ItemDef Wood = new ItemDef("wood", "Wood", ItemKind.Resource, ToolId.Hoe, null, true, 999, 8);
        public static readonly ItemDef Stone = new ItemDef("stone", "Stone", ItemKind.Resource, ToolId.Hoe, null, true, 999, 6);
        public static readonly ItemDef Fiber = new ItemDef("fiber", "Fiber", ItemKind.Resource, ToolId.Hoe, null, true, 999, 2);
        public static readonly ItemDef Fence = new ItemDef("fence", "Fence", ItemKind.Placeable, ToolId.Hoe, null, true, 999, 4);
        public static readonly ItemDef Plank = new ItemDef("plank", "Wooden plank", ItemKind.Resource, ToolId.Hoe, null, true, 999, 12);
        public static readonly ItemDef Hay = new ItemDef("hay", "Hay", ItemKind.Resource, ToolId.Hoe, null, true, 999, 2);
        public static readonly ItemDef Milk = new ItemDef("milk", "Milk", ItemKind.Produce, ToolId.Hoe, null, true, 999, 90);
        public static readonly ItemDef Wool = new ItemDef("wool", "Wool", ItemKind.Produce, ToolId.Hoe, null, true, 999, 48);
        public const int WoodPerPlank = 10;
        public static readonly ItemDef Chicken = new ItemDef("animal.chicken", "Chicken", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 40);
        public static readonly ItemDef Rabbit = new ItemDef("animal.rabbit", "Rabbit", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 50);
        public static readonly ItemDef Sheep = new ItemDef("animal.sheep", "Sheep", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 120);
        public static readonly ItemDef Pig = new ItemDef("animal.pig", "Pig", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 150);
        public static readonly ItemDef Cow = new ItemDef("animal.cow", "Cow", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 200);
        public static readonly ItemDef Horse = new ItemDef("animal.horse", "Horse", ItemKind.Placeable, ToolId.Hoe, null, true, 99, 275);
        public static readonly ItemDef[] Livestock = { Chicken, Rabbit, Sheep, Pig, Cow, Horse };
        public static readonly ItemDef GoldOre = new ItemDef("ore.gold", "Gold ore", ItemKind.Resource, ToolId.Hoe, null, true, 999, 22);
        public static readonly ItemDef SilverOre = new ItemDef("ore.silver", "Silver ore", ItemKind.Resource, ToolId.Hoe, null, true, 999, 14);
        public static readonly ItemDef Geode = new ItemDef("geode", "Geode", ItemKind.Resource, ToolId.Hoe, null, true, 999, 10);
        public static readonly ItemDef Diamond = new ItemDef("gem.diamond", "Diamond", ItemKind.Resource, ToolId.Hoe, null, true, 99, 280);
        public static readonly ItemDef Emerald = new ItemDef("gem.emerald", "Emerald", ItemKind.Resource, ToolId.Hoe, null, true, 99, 220);
        public static readonly ItemDef Sapphire = new ItemDef("gem.sapphire", "Sapphire", ItemKind.Resource, ToolId.Hoe, null, true, 99, 200);
        public static readonly ItemDef Jade = new ItemDef("gem.jade", "Jade", ItemKind.Resource, ToolId.Hoe, null, true, 99, 180);
        public static readonly ItemDef Cockle = new ItemDef("shell.cockle", "Cockle", ItemKind.Resource, ToolId.Hoe, null, true, 999, 8);
        public static readonly ItemDef Scallop = new ItemDef("shell.scallop", "Scallop", ItemKind.Resource, ToolId.Hoe, null, true, 999, 14);
        public static readonly ItemDef Whelk = new ItemDef("shell.whelk", "Whelk", ItemKind.Resource, ToolId.Hoe, null, true, 999, 16);
        public static readonly ItemDef SandDollar = new ItemDef("shell.sanddollar", "Sand dollar", ItemKind.Resource, ToolId.Hoe, null, true, 999, 20);
        public static readonly ItemDef Conch = new ItemDef("shell.conch", "Conch", ItemKind.Resource, ToolId.Hoe, null, true, 999, 32);
        public static readonly ItemDef Seaweed = new ItemDef("seaweed", "Seaweed", ItemKind.Resource, ToolId.Hoe, null, true, 999, 6);
        public static readonly ItemDef[] BeachFinds = { Cockle, Scallop, Whelk, SandDollar, Conch, Seaweed };

        public static readonly ItemDef Bread = new ItemDef("food.bread", "Hearth bread", ItemKind.Food, ToolId.Hoe, null, true, 99, 8, 25);
        public static readonly ItemDef Stew = new ItemDef("food.stew", "Hearty stew", ItemKind.Food, ToolId.Hoe, null, true, 99, 12, 50);
        public static readonly ItemDef Pie = new ItemDef("food.pie", "Harvest pie", ItemKind.Food, ToolId.Hoe, null, true, 99, 20, 100);
        public static readonly ItemDef Cider = new ItemDef("food.cider", "Hearth cider", ItemKind.Food, ToolId.Hoe, null, true, 99, 10, 20);
        public static readonly ItemDef Tea = new ItemDef("food.tea", "Willow tea", ItemKind.Food, ToolId.Hoe, null, true, 99, 6, 15);
        public static readonly ItemDef Ale = new ItemDef("food.ale", "Valley ale", ItemKind.Food, ToolId.Hoe, null, true, 99, 12, 30);
        public static readonly ItemDef Cocoa = new ItemDef("food.cocoa", "Evening cocoa", ItemKind.Food, ToolId.Hoe, null, true, 99, 10, 25);

        public static readonly ItemDef[] Foods = { Bread, Stew, Pie };
        public static readonly ItemDef[] Drinks = { Cider, Tea, Ale, Cocoa };
        public static readonly ItemDef[] Minerals = { GoldOre, SilverOre, Geode, Diamond, Emerald, Sapphire, Jade };
        public static readonly int[] PackUpgradePrices = { 200, 400, 700, 1100, 1600 };

        public static readonly ItemDef[] All;

        static ItemCatalog()
        {
            ItemDef[] list = new ItemDef[9 + 8 + Livestock.Length + Minerals.Length + BeachFinds.Length + Foods.Length + Drinks.Length + CropCatalog.All.Length * 2 + FishCatalog.Saltwater.Length];
            int n = 0;
            list[n++] = Hoe;
            list[n++] = Can;
            list[n++] = Scythe;
            list[n++] = Axe;
            list[n++] = Pickaxe;
            list[n++] = Sword;
            list[n++] = Rod;
            list[n++] = MilkPail;
            list[n++] = Shears;
            list[n++] = Wood;
            list[n++] = Stone;
            list[n++] = Fiber;
            list[n++] = Fence;
            list[n++] = Plank;
            list[n++] = Hay;
            list[n++] = Milk;
            list[n++] = Wool;
            for (int i = 0; i < Livestock.Length; i++)
                list[n++] = Livestock[i];
            for (int i = 0; i < Minerals.Length; i++)
                list[n++] = Minerals[i];
            for (int i = 0; i < BeachFinds.Length; i++)
                list[n++] = BeachFinds[i];
            list[n++] = Bread;
            list[n++] = Stew;
            list[n++] = Pie;
            list[n++] = Cider;
            list[n++] = Tea;
            list[n++] = Ale;
            list[n++] = Cocoa;
            for (int i = 0; i < CropCatalog.All.Length; i++)
            {
                CropDef c = CropCatalog.All[i];
                ToolId tool = ToolId.Turnip;
                if (c.Id == "potato") tool = ToolId.Potato;
                else if (c.Id == "cabbage") tool = ToolId.Cabbage;
                else if (c.Id == "melon") tool = ToolId.Melon;
                else if (c.Id == "pumpkin") tool = ToolId.Pumpkin;
                list[n++] = new ItemDef("seed." + c.Id, c.SeedName, ItemKind.Seed, tool, c.Id, true, 999, 0);
                list[n++] = new ItemDef(c.Id, c.Name, ItemKind.Produce, ToolId.Hoe, c.Id, true, 999, c.Sell);
            }
            for (int i = 0; i < FishCatalog.Saltwater.Length; i++)
            {
                FishDef f = FishCatalog.Saltwater[i];
                list[n++] = new ItemDef(FishCatalog.ItemId(f.Id), f.Name, ItemKind.Produce, ToolId.Hoe, null, true, 999, f.Sell);
            }
            All = list;
        }

        static ItemDef Tool(string id, string name, ToolId tool)
        {
            return new ItemDef(id, name, ItemKind.Tool, tool, null, false, 1, 0);
        }

        public static ItemDef Find(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;
            for (int i = 0; i < All.Length; i++)
            {
                if (All[i].Id == id)
                    return All[i];
            }
            return null;
        }

        public static bool IsDrink(string id)
        {
            if (string.IsNullOrEmpty(id))
                return false;
            for (int i = 0; i < Drinks.Length; i++)
            {
                if (Drinks[i].Id == id)
                    return true;
            }
            return false;
        }

        public static string SeedId(string cropId)
        {
            return "seed." + cropId;
        }

        public static void RollVein(System.Random rng, int miningLevel, out string id, out int count)
        {
            int gemChance = 5 + miningLevel / 2;
            if (rng.Next(100) < gemChance)
            {
                string[] gems = { "gem.diamond", "gem.emerald", "gem.sapphire", "gem.jade" };
                id = gems[rng.Next(gems.Length)];
                count = 1;
                return;
            }
            string[] ores = { "ore.gold", "ore.silver", "geode" };
            id = ores[rng.Next(ores.Length)];
            count = 1 + rng.Next(10);
        }
    }
}
