using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    public sealed class FarmerPeer
    {
        public bool Used;
        public string Name = "Farmer";
        public Vector2 Pos;
        public int Dir;
        public bool Moving;
        public float Anim;
        public int Gold = 500;
        public int Energy = GameConst.MaxEnergy;
        public int CanWater = GameConst.CanCapacity;
        public int Selected;
        public int PackUpgrades;
        public int ShippedTonight;
        public int FaceX;
        public int FaceY;
        public float SwingT;
        public float SwingDur;
        public string SwingAct = "";
        public float ActionLock;
        public string ZoneName = "Harvest Hollow";
        public string OutdoorZone = "Harvest Hollow";
        public Vector2 OutdoorPos;
        public string InsideId = "";
        public int InsideFloor;
        public string PendingFish = "";
        public string HeldId = "";
        public FarmerLook Look = FarmerLook.Classic;
        public readonly SkillSet Skills = new SkillSet();
        public readonly InvSlot[] Bar = new InvSlot[GameConst.BarSlots];
        public readonly InvSlot[] Pack = new InvSlot[GameConst.PackMaxSlots];

        public FarmerPeer()
        {
            for (int i = 0; i < Bar.Length; i++)
                Bar[i] = new InvSlot();
            for (int i = 0; i < Pack.Length; i++)
                Pack[i] = new InvSlot();
        }

        public void Write(BinaryWriter w, bool inventory)
        {
            w.Write(Used);
            w.Write(Name ?? "");
            w.Write(Pos.X);
            w.Write(Pos.Y);
            w.Write(Dir);
            w.Write(Moving);
            w.Write(Anim);
            w.Write(FaceX);
            w.Write(FaceY);
            w.Write(SwingT);
            w.Write(SwingDur);
            w.Write(SwingAct ?? "");
            w.Write(ZoneName ?? "");
            w.Write(OutdoorZone ?? "");
            w.Write(OutdoorPos.X);
            w.Write(OutdoorPos.Y);
            w.Write(InsideId ?? "");
            w.Write(InsideFloor);
            w.Write(HeldId ?? "");
            Look.Write(w);
            if (!inventory)
                return;
            w.Write(Gold);
            w.Write(Energy);
            w.Write(CanWater);
            w.Write(Selected);
            w.Write(PackUpgrades);
            w.Write(ShippedTonight);
            w.Write(PendingFish ?? "");
            WriteSlots(w, Bar);
            WriteSlots(w, Pack);
            Skills.Write(w);
        }

        public void Read(BinaryReader r, bool inventory)
        {
            Used = r.ReadBoolean();
            Name = r.ReadString();
            Pos = new Vector2(r.ReadSingle(), r.ReadSingle());
            Dir = r.ReadInt32();
            Moving = r.ReadBoolean();
            Anim = r.ReadSingle();
            FaceX = r.ReadInt32();
            FaceY = r.ReadInt32();
            SwingT = r.ReadSingle();
            SwingDur = r.ReadSingle();
            SwingAct = r.ReadString();
            ZoneName = r.ReadString();
            OutdoorZone = r.ReadString();
            OutdoorPos = new Vector2(r.ReadSingle(), r.ReadSingle());
            InsideId = r.ReadString();
            InsideFloor = r.ReadInt32();
            HeldId = r.ReadString();
            Look = FarmerLook.ReadFrom(r);
            if (!inventory)
                return;
            Gold = r.ReadInt32();
            Energy = r.ReadInt32();
            CanWater = r.ReadInt32();
            Selected = r.ReadInt32();
            PackUpgrades = r.ReadInt32();
            ShippedTonight = r.ReadInt32();
            PendingFish = r.ReadString();
            ReadSlots(r, Bar);
            ReadSlots(r, Pack);
            Skills.Read(r);
        }

        static void WriteSlots(BinaryWriter w, InvSlot[] slots)
        {
            w.Write(slots.Length);
            for (int i = 0; i < slots.Length; i++)
            {
                w.Write(slots[i].Id ?? "");
                w.Write(slots[i].Count);
            }
        }

        static void ReadSlots(BinaryReader r, InvSlot[] slots)
        {
            int n = r.ReadInt32();
            for (int i = 0; i < n; i++)
            {
                string id = r.ReadString();
                int c = r.ReadInt32();
                if (i < slots.Length)
                    slots[i].Set(string.IsNullOrEmpty(id) ? null : id, c);
            }
        }
    }

    public sealed class NetSession
    {
        public const byte MsgWelcome = 1;
        public const byte MsgReject = 2;
        public const byte MsgInput = 3;
        public const byte MsgSnap = 4;
        public const byte MsgAction = 5;
        public const byte MsgJoin = 6;

        public const byte ActUse = 1;
        public const byte ActInteract = 2;
        public const byte ActBuySeed = 3;
        public const byte ActBuyFood = 4;
        public const byte ActUpgrade = 5;
        public const byte ActSellFish = 6;
        public const byte ActShip = 7;
        public const byte ActSleep = 8;
        public const byte ActMoveItem = 9;
        public const byte ActCraft = 10;
        public const byte ActSpendSkill = 11;
        public const byte ActBuyDrink = 12;
        public const byte ActCraftPlank = 13;
        public const byte ActBuyAnimal = 14;
        public const byte ActMoveBuilding = 15;
        public const byte ActCraftPail = 16;
        public const byte ActCraftShears = 17;

        public bool IsHost;
        public bool IsClient;
        public bool Active { get { return IsHost || IsClient; } }
        public int LocalSlot;
        public string Status = "";
        public string HostAddress = "";
        public readonly FarmerPeer[] Peers = new FarmerPeer[GameConst.MaxPlayers];
        public int PlayerCount
        {
            get
            {
                int n = 0;
                for (int i = 0; i < Peers.Length; i++)
                {
                    if (Peers[i] != null && Peers[i].Used)
                        n++;
                }
                return n;
            }
        }

        World _world;
        public void AttachWorld(World world)
        {
            if (world != null)
                _world = world;
        }
        readonly object _lock = new object();
        readonly Queue<Action> _main = new Queue<Action>();
        TcpListener _listen;
        Thread _accept;
        volatile bool _run;
        readonly TcpClient[] _clients = new TcpClient[GameConst.MaxPlayers];
        TcpClient _server;
        NetworkStream _serverStream;
        float _snapTimer;
        FarmerPeer _hostScratch = new FarmerPeer();

        public NetSession(World world)
        {
            _world = world;
            for (int i = 0; i < Peers.Length; i++)
                Peers[i] = new FarmerPeer();
        }

        public static Color Tint(int slot)
        {
            if (slot == 1) return new Color(176, 208, 255);
            if (slot == 2) return new Color(255, 186, 176);
            if (slot == 3) return new Color(186, 232, 176);
            if (slot == 4) return new Color(218, 186, 255);
            if (slot == 5) return new Color(255, 214, 148);
            return Color.White;
        }

        public static string LanIp()
        {
            try
            {
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.OperationalStatus != OperationalStatus.Up)
                        continue;
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                        continue;
                    foreach (UnicastIPAddressInformation addr in nic.GetIPProperties().UnicastAddresses)
                    {
                        if (addr.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            string s = addr.Address.ToString();
                            if (!s.StartsWith("127."))
                                return s;
                        }
                    }
                }
            }
            catch
            {
            }
            return "127.0.0.1";
        }

        public void Host()
        {
            Stop();
            IsHost = true;
            IsClient = false;
            LocalSlot = 0;
            Peers[0].Used = true;
            Peers[0].Name = "Host";
            _world.CapturePeer(Peers[0]);
            HostAddress = LanIp();
            Status = "Hosting on " + HostAddress + ":" + GameConst.NetPort.ToString();
            _world.ShareWorldView = true;
            _run = true;
            _listen = new TcpListener(IPAddress.Any, GameConst.NetPort);
            _listen.Start();
            _accept = new Thread(AcceptLoop);
            _accept.IsBackground = true;
            _accept.Start();
        }

        public void Join(string ip)
        {
            Stop();
            IsClient = true;
            IsHost = false;
            Status = "Connecting to " + ip + "...";
            _run = true;
            Thread t = new Thread(() => ConnectLoop(ip));
            t.IsBackground = true;
            t.Start();
        }

        public void Stop()
        {
            _run = false;
            try
            {
                if (_listen != null)
                    _listen.Stop();
            }
            catch
            {
            }
            _listen = null;
            try
            {
                if (_server != null)
                    _server.Close();
            }
            catch
            {
            }
            _server = null;
            _serverStream = null;
            for (int i = 0; i < _clients.Length; i++)
            {
                try
                {
                    if (_clients[i] != null)
                        _clients[i].Close();
                }
                catch
                {
                }
                _clients[i] = null;
            }
            IsHost = false;
            IsClient = false;
            _world.ShareWorldView = false;
            for (int i = 0; i < Peers.Length; i++)
                Peers[i].Used = i == 0;
            LocalSlot = 0;
        }

        void AcceptLoop()
        {
            while (_run)
            {
                try
                {
                    TcpClient c = _listen.AcceptTcpClient();
                    Enqueue(() => OnAccept(c));
                }
                catch
                {
                    return;
                }
            }
        }

        void OnAccept(TcpClient c)
        {
            int slot = -1;
            for (int i = 1; i < Peers.Length; i++)
            {
                if (!Peers[i].Used)
                {
                    slot = i;
                    break;
                }
            }
            if (slot < 0)
            {
                SendRaw(c.GetStream(), MsgReject, w => w.Write("The farm is full (6 farmers)."));
                try { c.Close(); } catch { }
                return;
            }
            _world.CapturePeer(Peers[0]);
            Peers[0].Used = true;
            Peers[slot].Used = true;
            Peers[slot].Name = "Farmer " + (slot + 1).ToString();
            Peers[slot].Look = FarmerLook.Classic;
            _world.FillDefaultInventory();
            _world.PlayerPos = _world.SlotSpawn(slot);
            _world.Dir = 0;
            _world.Inside = null;
            _world.OutdoorZone = "Harvest Hollow";
            _world.ZoneName = "Harvest Hollow";
            _world.CapturePeer(Peers[slot]);
            Peers[slot].Look = FarmerLook.Classic;
            _world.ApplyPeer(Peers[0]);
            _clients[slot] = c;
            try { c.NoDelay = true; } catch { }
            Status = PlayerCount.ToString() + "/" + GameConst.MaxPlayers.ToString() + " farmers. " + HostAddress;
            NetworkStream ns = c.GetStream();
            SendRaw(ns, MsgWelcome, w =>
            {
                w.Write((byte)slot);
                w.Write(Peers[slot].Name);
            });
            BroadcastSnap();
            int captured = slot;
            Thread t = new Thread(() => ReadLoop(c, captured));
            t.IsBackground = true;
            t.Start();
        }

        void ConnectLoop(string ip)
        {
            try
            {
                TcpClient c = new TcpClient();
                c.Connect(ip, GameConst.NetPort);
                try { c.NoDelay = true; } catch { }
                _server = c;
                _serverStream = c.GetStream();
                SendRaw(_serverStream, MsgJoin, w =>
                {
                    w.Write("Farmer");
                    _world.Look.Write(w);
                });
                Enqueue(() => { Status = "Waiting for the host..."; });
                ReadLoop(c, -1);
            }
            catch (Exception ex)
            {
                Enqueue(() =>
                {
                    Status = "Could not join: " + ex.Message;
                    IsClient = false;
                });
            }
        }

        void ReadLoop(TcpClient c, int hostSlot)
        {
            NetworkStream ns;
            try { ns = c.GetStream(); }
            catch { return; }
            byte[] header = new byte[5];
            while (_run)
            {
                try
                {
                    if (!ReadExact(ns, header, 5))
                        break;
                    int len = BitConverter.ToInt32(header, 0);
                    byte type = header[4];
                    if (len < 0 || len > 4_000_000)
                        break;
                    byte[] body = new byte[len];
                    if (len > 0 && !ReadExact(ns, body, len))
                        break;
                    byte[] copy = body;
                    byte t = type;
                    int slot = hostSlot;
                    Enqueue(() => Handle(t, copy, slot));
                }
                catch
                {
                    break;
                }
            }
            Enqueue(() => OnDrop(hostSlot));
        }

        void OnDrop(int hostSlot)
        {
            if (IsHost && hostSlot > 0)
            {
                Peers[hostSlot].Used = false;
                _clients[hostSlot] = null;
                Status = PlayerCount.ToString() + "/" + GameConst.MaxPlayers.ToString() + " farmers.";
                _world.ShowToast(Peers[hostSlot].Name + " left the valley.");
            }
            else if (IsClient)
            {
                Status = "Disconnected from host.";
                IsClient = false;
                _world.ShowToast("Lost the host connection.");
            }
        }

        static bool ReadExact(NetworkStream ns, byte[] buf, int n)
        {
            int o = 0;
            while (o < n)
            {
                int r = ns.Read(buf, o, n - o);
                if (r <= 0)
                    return false;
                o += r;
            }
            return true;
        }

        static void SendRaw(NetworkStream ns, byte type, Action<BinaryWriter> body)
        {
            if (ns == null)
                return;
            MemoryStream ms = new MemoryStream();
            BinaryWriter w = new BinaryWriter(ms);
            body(w);
            w.Flush();
            byte[] data = ms.ToArray();
            byte[] packet = new byte[5 + data.Length];
            BitConverter.GetBytes(data.Length).CopyTo(packet, 0);
            packet[4] = type;
            Buffer.BlockCopy(data, 0, packet, 5, data.Length);
            lock (ns)
            {
                try { ns.Write(packet, 0, packet.Length); }
                catch { }
            }
        }

        void Handle(byte type, byte[] body, int fromSlot)
        {
            BinaryReader r = new BinaryReader(new MemoryStream(body));
            if (type == MsgWelcome && IsClient)
            {
                LocalSlot = r.ReadByte();
                Peers[LocalSlot].Name = r.ReadString();
                Peers[LocalSlot].Used = true;
                Status = "Joined as " + Peers[LocalSlot].Name;
            }
            else if (type == MsgReject)
            {
                Status = r.ReadString();
                IsClient = false;
            }
            else if (type == MsgJoin && IsHost)
            {
                string name = r.ReadString();
                FarmerLook look = FarmerLook.ReadFrom(r);
                if (fromSlot > 0)
                {
                    if (!string.IsNullOrEmpty(name))
                        Peers[fromSlot].Name = name;
                    Peers[fromSlot].Look = look;
                    BroadcastSnap();
                }
            }
            else if (type == MsgInput && IsHost && fromSlot > 0)
            {
                FarmerPeer p = Peers[fromSlot];
                p.Pos = new Vector2(r.ReadSingle(), r.ReadSingle());
                p.Dir = r.ReadInt32();
                p.Moving = r.ReadBoolean();
                p.Anim = r.ReadSingle();
                p.FaceX = r.ReadInt32();
                p.FaceY = r.ReadInt32();
                p.Selected = r.ReadInt32();
                p.SwingT = r.ReadSingle();
                p.SwingDur = r.ReadSingle();
                p.SwingAct = r.ReadString();
            }
            else if (type == MsgAction && IsHost && fromSlot > 0)
            {
                byte act = r.ReadByte();
                RunAs(fromSlot, () => DoAction(act, r));
            }
            else if (type == MsgSnap && IsClient)
            {
                _world.ReadWorldBody(r, SaveGame.Version);
                _world.ReadAnimals(r);
                _world.ReadFarmSites(r);
                if (r.BaseStream.Position < r.BaseStream.Length)
                {
                    _world.HayInSilo = r.ReadInt32();
                    if (_world.HayInSilo < 0)
                        _world.HayInSilo = 0;
                    if (_world.HayInSilo > GameConst.SiloCapacity)
                        _world.HayInSilo = GameConst.SiloCapacity;
                }
                int n = r.ReadInt32();
                for (int i = 0; i < n && i < Peers.Length; i++)
                {
                    bool used = r.ReadBoolean();
                    Peers[i].Used = used;
                    if (!used)
                        continue;
                    bool mine = i == LocalSlot;
                    Peers[i].Read(r, mine);
                }
                if (Peers[LocalSlot].Used)
                {
                    if (_world.Screen == Screen.Title || _world.Screen == Screen.Join)
                        _world.ApplyVisualPeer(Peers[LocalSlot]);
                    _world.ApplyInventoryFromPeer(Peers[LocalSlot]);
                }
                _world.ShareWorldView = true;
                if (_world.Screen == Screen.Title || _world.Screen == Screen.Join)
                    _world.Screen = Screen.Play;
            }
        }

        void DoAction(byte act, BinaryReader r)
        {
            if (act == ActUse)
            {
                int tx = r.ReadInt32();
                int ty = r.ReadInt32();
                string a = _world.UseTool(tx, ty);
                _world.BeginSwing(a);
            }
            else if (act == ActInteract)
            {
                int tx = r.ReadInt32();
                int ty = r.ReadInt32();
                _world.Interact(tx, ty);
            }
            else if (act == ActBuySeed)
            {
                int i = r.ReadInt32();
                if (i >= 0 && i < CropCatalog.All.Length)
                    _world.Buy(CropCatalog.All[i]);
            }
            else if (act == ActBuyFood)
            {
                int i = r.ReadInt32();
                if (i >= 0 && i < ItemCatalog.Foods.Length)
                    _world.BuyFood(ItemCatalog.Foods[i]);
            }
            else if (act == ActBuyDrink)
            {
                int i = r.ReadInt32();
                _world.BuyDrink(i);
            }
            else if (act == ActUpgrade)
                _world.BuyPackUpgrade();
            else if (act == ActSellFish)
                _world.SellAllFish();
            else if (act == ActShip)
                _world.ShipAll();
            else if (act == ActSleep)
            {
                _world.AdvanceDay(false);
                SaveGame.Write(_world);
                RestEveryone();
                _hostScratch.Energy = GameConst.MaxEnergy;
                if (_hostScratch.ShippedTonight > 0)
                {
                    _hostScratch.Gold += _hostScratch.ShippedTonight;
                    _hostScratch.ShippedTonight = 0;
                }
            }
            else if (act == ActMoveItem)
            {
                bool fb = r.ReadBoolean();
                int fi = r.ReadInt32();
                bool tb = r.ReadBoolean();
                int ti = r.ReadInt32();
                SlotLoc from = fb ? SlotLoc.BarAt(fi) : SlotLoc.PackAt(fi);
                SlotLoc to = tb ? SlotLoc.BarAt(ti) : SlotLoc.PackAt(ti);
                _world.MoveItem(from, to);
            }
            else if (act == ActCraft)
                _world.CraftFence();
            else if (act == ActCraftPlank)
                _world.CraftPlank();
            else if (act == ActCraftPail)
                _world.CraftMilkPail();
            else if (act == ActCraftShears)
                _world.CraftShears();
            else if (act == ActBuyAnimal)
            {
                int i = r.ReadInt32();
                _world.BuyAnimal(i);
            }
            else if (act == ActMoveBuilding)
            {
                string id = r.ReadString();
                int x = r.ReadInt32();
                int y = r.ReadInt32();
                Building house = _world.FindBuilding(id);
                _world.MoveFarmBuilding(house, x, y);
            }
            else if (act == ActSpendSkill)
                _world.SpendSkillPoint(r.ReadInt32());
        }

        public void FillCaveGuests()
        {
            _world.CaveGuests.Clear();
            if (!IsHost)
                return;
            for (int i = 1; i < Peers.Length; i++)
            {
                FarmerPeer p = Peers[i];
                if (p == null || !p.Used)
                    continue;
                if (p.InsideId != "ridge-cave")
                    continue;
                int slot = i;
                CaveGuest g = new CaveGuest();
                g.Pos = p.Pos;
                g.Hurt = dmg =>
                {
                    if (_world.InfiniteEnergy)
                        Peers[slot].Energy = GameConst.MaxEnergy;
                    else
                        Peers[slot].Energy = Math.Max(0, Peers[slot].Energy - dmg);
                };
                _world.CaveGuests.Add(g);
            }
        }

        public void RestEveryone()
        {
            for (int i = 1; i < Peers.Length; i++)
            {
                if (!Peers[i].Used)
                    continue;
                Peers[i].Energy = GameConst.MaxEnergy;
                if (Peers[i].ShippedTonight > 0)
                {
                    Peers[i].Gold += Peers[i].ShippedTonight;
                    Peers[i].ShippedTonight = 0;
                }
            }
        }

        void RunAs(int slot, Action fn)
        {
            Screen saved = _world.Screen;
            string toast = _world.Toast;
            float toastT = _world.ToastTimer;
            _world.CapturePeer(_hostScratch);
            _hostScratch.Name = Peers[0].Name;
            _world.ApplyPeer(Peers[slot]);
            fn();
            _world.SyncDoorsSilent();
            _world.CapturePeer(Peers[slot]);
            _world.ApplyPeer(_hostScratch);
            _world.Screen = saved;
            _world.Toast = toast;
            _world.ToastTimer = toastT;
        }

        public void Pump()
        {
            lock (_lock)
            {
                while (_main.Count > 0)
                    _main.Dequeue()();
            }
        }

        void Enqueue(Action a)
        {
            lock (_lock)
                _main.Enqueue(a);
        }

        public void Tick(float dt)
        {
            Pump();
            if (!IsHost)
                return;
            _world.CapturePeer(Peers[0]);
            Peers[0].Used = true;
            Peers[0].Name = "Host";
            for (int i = 1; i < Peers.Length; i++)
            {
                if (Peers[i].Used)
                    RunAs(i, () => _world.SyncDoorsSilent());
            }
            _snapTimer += dt;
            if (_snapTimer >= 0.10f)
            {
                _snapTimer = 0f;
                BroadcastSnap();
            }
        }

        void BroadcastSnap()
        {
            _world.CapturePeer(Peers[0]);
            for (int i = 1; i < Peers.Length; i++)
            {
                if (_clients[i] == null || !Peers[i].Used)
                    continue;
                int slot = i;
                NetworkStream ns;
                try { ns = _clients[i].GetStream(); }
                catch { continue; }
                SendRaw(ns, MsgSnap, w =>
                {
                    _world.WriteWorldBody(w);
                    _world.WriteAnimals(w);
                    _world.WriteFarmSites(w);
                    w.Write(_world.HayInSilo);
                    w.Write(Peers.Length);
                    for (int p = 0; p < Peers.Length; p++)
                    {
                        w.Write(Peers[p].Used);
                        if (!Peers[p].Used)
                            continue;
                        Peers[p].Write(w, p == slot);
                    }
                });
            }
        }

        public void SendInput(World world)
        {
            if (!IsClient || _serverStream == null)
                return;
            SendRaw(_serverStream, MsgInput, w =>
            {
                w.Write(world.PlayerPos.X);
                w.Write(world.PlayerPos.Y);
                w.Write(world.Dir);
                w.Write(world.Moving);
                w.Write(world.Anim);
                w.Write(world.Face.X);
                w.Write(world.Face.Y);
                w.Write(world.Selected);
                w.Write(world.SwingT);
                w.Write(world.SwingDur);
                w.Write(world.SwingAct ?? "");
            });
        }

        public void SendAction(byte act, Action<BinaryWriter> body)
        {
            if (!IsClient || _serverStream == null)
                return;
            SendRaw(_serverStream, MsgAction, w =>
            {
                w.Write(act);
                if (body != null)
                    body(w);
            });
        }
    }
}
