using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// Tiny 5x7 bitmap font drawn with SpriteBatch (XNA 4.0 pattern).
    /// </summary>
    public sealed class PixelFont
    {
        private readonly Texture2D _pixel;
        private readonly Dictionary<char, string[]> _glyphs = new Dictionary<char, string[]>();

        public PixelFont(Texture2D pixel)
        {
            _pixel = pixel;
            Add(' ', new[] { ".....", ".....", ".....", ".....", ".....", ".....", "....." });
            Add('0', new[] { ".XXX.", "X...X", "X..XX", "X.X.X", "XX..X", "X...X", ".XXX." });
            Add('1', new[] { "..X..", ".XX..", "..X..", "..X..", "..X..", "..X..", ".XXX." });
            Add('2', new[] { ".XXX.", "X...X", "....X", "..XX.", ".X...", "X....", "XXXXX" });
            Add('3', new[] { ".XXX.", "X...X", "....X", "..XX.", "....X", "X...X", ".XXX." });
            Add('4', new[] { "...X.", "..XX.", ".X.X.", "X..X.", "XXXXX", "...X.", "...X." });
            Add('5', new[] { "XXXXX", "X....", "XXXX.", "....X", "....X", "X...X", ".XXX." });
            Add('6', new[] { ".XXX.", "X....", "X....", "XXXX.", "X...X", "X...X", ".XXX." });
            Add('7', new[] { "XXXXX", "....X", "...X.", "..X..", ".X...", ".X...", ".X..." });
            Add('8', new[] { ".XXX.", "X...X", "X...X", ".XXX.", "X...X", "X...X", ".XXX." });
            Add('9', new[] { ".XXX.", "X...X", "X...X", ".XXXX", "....X", "....X", ".XXX." });
            Add('A', new[] { ".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X" });
            Add('B', new[] { "XXXX.", "X...X", "X...X", "XXXX.", "X...X", "X...X", "XXXX." });
            Add('C', new[] { ".XXX.", "X...X", "X....", "X....", "X....", "X...X", ".XXX." });
            Add('D', new[] { "XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX." });
            Add('E', new[] { "XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX" });
            Add('F', new[] { "XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "X...." });
            Add('G', new[] { ".XXX.", "X...X", "X....", "X.XXX", "X...X", "X...X", ".XXX." });
            Add('H', new[] { "X...X", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X" });
            Add('I', new[] { ".XXX.", "..X..", "..X..", "..X..", "..X..", "..X..", ".XXX." });
            Add('J', new[] { "....X", "....X", "....X", "....X", "X...X", "X...X", ".XXX." });
            Add('K', new[] { "X...X", "X..X.", "X.X..", "XX...", "X.X..", "X..X.", "X...X" });
            Add('L', new[] { "X....", "X....", "X....", "X....", "X....", "X....", "XXXXX" });
            Add('M', new[] { "X...X", "XX.XX", "X.X.X", "X.X.X", "X...X", "X...X", "X...X" });
            Add('N', new[] { "X...X", "XX..X", "X.X.X", "X.X.X", "X..XX", "X...X", "X...X" });
            Add('O', new[] { ".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX." });
            Add('P', new[] { "XXXX.", "X...X", "X...X", "XXXX.", "X....", "X....", "X...." });
            Add('Q', new[] { ".XXX.", "X...X", "X...X", "X...X", "X.X.X", "X..X.", ".XX.X" });
            Add('R', new[] { "XXXX.", "X...X", "X...X", "XXXX.", "X.X..", "X..X.", "X...X" });
            Add('S', new[] { ".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX." });
            Add('T', new[] { "XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.." });
            Add('U', new[] { "X...X", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX." });
            Add('V', new[] { "X...X", "X...X", "X...X", "X...X", "X...X", ".X.X.", "..X.." });
            Add('W', new[] { "X...X", "X...X", "X...X", "X.X.X", "X.X.X", "XX.XX", "X...X" });
            Add('X', new[] { "X...X", "X...X", ".X.X.", "..X..", ".X.X.", "X...X", "X...X" });
            Add('Y', new[] { "X...X", "X...X", ".X.X.", "..X..", "..X..", "..X..", "..X.." });
            Add('Z', new[] { "XXXXX", "....X", "...X.", "..X..", ".X...", "X....", "XXXXX" });
            Add('.', new[] { ".....", ".....", ".....", ".....", ".....", ".....", ".X..." });
            Add(',', new[] { ".....", ".....", ".....", ".....", ".....", ".X...", "X...." });
            Add(':', new[] { ".....", "..X..", ".....", ".....", "..X..", ".....", "....." });
            Add('!', new[] { "..X..", "..X..", "..X..", "..X..", "..X..", ".....", "..X.." });
            Add('?', new[] { ".XXX.", "X...X", "....X", "...X.", "..X..", ".....", "..X.." });
            Add('-', new[] { ".....", ".....", ".....", "XXXXX", ".....", ".....", "....." });
            Add('+', new[] { ".....", "..X..", "..X..", "XXXXX", "..X..", "..X..", "....." });
            Add('\'', new[] { "..X..", "..X..", ".X...", ".....", ".....", ".....", "....." });
            Add('/', new[] { "....X", "...X.", "..X..", ".X...", "X....", "X....", "....." });
            Add('(', new[] { "..XX.", ".X...", "X....", "X....", "X....", ".X...", "..XX." });
            Add(')', new[] { ".XX..", "...X.", "....X", "....X", "....X", "...X.", ".XX.." });
            Add('[', new[] { ".XXX.", ".X...", ".X...", ".X...", ".X...", ".X...", ".XXX." });
            Add(']', new[] { ".XXX.", "...X.", "...X.", "...X.", "...X.", "...X.", ".XXX." });
        }

        private void Add(char c, string[] rows)
        {
            _glyphs[c] = rows;
            _glyphs[char.ToLowerInvariant(c)] = rows;
        }

        public int Measure(string text, int scale)
        {
            return text.Length * 6 * scale;
        }

        public void Draw(SpriteBatch batch, string text, int x, int y, Color color, int scale)
        {
            if (text == null)
                return;
            int cx = x;
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (ch == '\n')
                {
                    cx = x;
                    y += 8 * scale;
                    continue;
                }
                string[] g;
                if (!_glyphs.TryGetValue(ch, out g))
                    g = _glyphs['?'];
                for (int row = 0; row < 7; row++)
                {
                    for (int col = 0; col < 5; col++)
                    {
                        if (g[row][col] == 'X')
                        {
                            batch.Draw(_pixel, new Rectangle(cx + col * scale, y + row * scale, scale, scale), color);
                        }
                    }
                }
                cx += 6 * scale;
            }
        }
    }
}
