using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// PNG tile pack: 32×32 Wang sets plus optional object sprites.
    /// Missing files fall back to procedural TileGen in Assets.
    /// </summary>
    public sealed class PackAtlas
    {
        public bool Ready;
        readonly Dictionary<string, WangSet> _sets = new Dictionary<string, WangSet>();
        readonly Dictionary<string, Texture2D> _objects = new Dictionary<string, Texture2D>();
        readonly Dictionary<string, Texture2D> _fills = new Dictionary<string, Texture2D>();

        public void Load(GraphicsDevice device)
        {
            string root = FindRoot();
            if (root == null)
                return;

            LoadSet(device, root, "grass_path");
            LoadSet(device, root, "grass_water");
            LoadSet(device, root, "grass_soil");
            LoadSet(device, root, "grass_cobble");
            LoadSet(device, root, "woods_path");
            LoadSet(device, root, "water_sand");

            string fillDir = Path.Combine(root, "tiles");
            TryFill(device, fillDir, "fill_path");
            TryFill(device, fillDir, "fill_water");
            TryFill(device, fillDir, "fill_soil");
            TryFill(device, fillDir, "fill_sand");
            TryFill(device, fillDir, "fill_tilled");
            TryFill(device, fillDir, "fill_wet");
            TryFill(device, fillDir, "fill_cobble");
            TryFill(device, fillDir, "fill_mountain");

            string objDir = Path.Combine(root, "objects");
            if (Directory.Exists(objDir))
            {
                string[] files = Directory.GetFiles(objDir, "*.png");
                for (int i = 0; i < files.Length; i++)
                {
                    Texture2D tex = LoadPng(device, files[i]);
                    if (tex != null)
                        _objects[Path.GetFileNameWithoutExtension(files[i])] = tex;
                }
            }

            OverlayFill("grass_path", false, "fill_path");
            OverlayFill("woods_path", false, "fill_path");
            OverlayFill("grass_water", false, "fill_water");
            OverlayFill("grass_soil", false, "fill_soil");
            OverlayFill("water_sand", false, "fill_water");
            OverlayFill("water_sand", true, "fill_sand");
            OverlayFill("grass_cobble", false, "fill_cobble");

            Ready = _sets.Count > 0 || _objects.Count > 0 || _fills.Count > 0;
        }

        public bool HasSet(string name)
        {
            return _sets.ContainsKey(name);
        }

        public Texture2D FillOf(string setName, bool upper)
        {
            WangSet set;
            if (!_sets.TryGetValue(setName, out set))
                return null;
            return upper ? set.Upper : set.Lower;
        }

        public Texture2D ExtraFill(string name)
        {
            Texture2D tex;
            return _fills.TryGetValue(name, out tex) ? tex : null;
        }

        public void SetExtraFill(string name, Texture2D tex)
        {
            if (name == null || tex == null)
                return;
            _fills[name] = tex;
        }

        public void SetFill(string setName, bool upper, Texture2D tex)
        {
            if (tex == null)
                return;
            WangSet set;
            if (!_sets.TryGetValue(setName, out set))
                return;
            int key = upper ? 15 : 0;
            set.ByKey[key] = tex;
            if (upper)
                set.Upper = tex;
            else
                set.Lower = tex;
        }

        public Texture2D Object(string name)
        {
            Texture2D tex;
            return _objects.TryGetValue(name, out tex) ? tex : null;
        }

        public Texture2D Tree(TreeKind kind)
        {
            switch (kind)
            {
                case TreeKind.Pine:
                    return Object("tree_pine") ?? Object("tree_oak");
                case TreeKind.Spruce:
                    return Object("tree_pine") ?? Object("tree_oak");
                case TreeKind.Willow:
                    return Object("tree_willow") ?? Object("tree_oak");
                case TreeKind.Blossom:
                    return Object("tree_blossom") ?? Object("tree_oak");
                case TreeKind.Birch:
                    return Object("tree_birch") ?? Object("tree_oak");
                case TreeKind.Palm:
                    return Object("tree_palm") ?? Object("tree_oak");
                case TreeKind.Dead:
                    return Object("tree_dead") ?? Object("tree_oak");
                case TreeKind.Autumn:
                    return Object("tree_oak");
                case TreeKind.DarkOak:
                    return Object("tree_oak");
                case TreeKind.Oak:
                    return Object("tree_oak");
                default:
                    return Object("tree_oak") ?? Object("tree_blossom");
            }
        }

        public Texture2D Ground(World world, TileType t, int tx, int ty)
        {
            if (world == null || world.Inside != null)
                return null;

            // Dirt roads stay a flat packed-earth fill. The grass_path / woods_path
            // Wang sheets use a raised cliff lip that reads as mountains along every
            // roadside; those rims belong on water and mountain edges only.
            if (t == TileType.Path || t == TileType.Bin || t == TileType.Door)
            {
                if (GameConst.InDeepForest(tx, ty))
                    return FillOf("woods_path", false) ?? ExtraFill("fill_path");
                return ExtraFill("fill_path") ?? FillOf("grass_path", false);
            }
            if (t == TileType.Water)
            {
                // Always use animated stream / coast / ocean tiles. Wang water_sand
                // on the water cell froze a pond fill along the shore and broke the
                // river-to-sea blend. Sand tiles still use that set for wet edges.
                return null;
            }
            if (t == TileType.Sand || t == TileType.Shell || t == TileType.Seaweed)
            {
                if (Touches(world, tx, ty, TileType.Water)
                    || Touches(world, tx, ty, TileType.Dock)
                    || Touches(world, tx, ty, TileType.Bridge))
                    return null;
                return ExtraFill("fill_sand");
            }
            if (t == TileType.FarmSoil || t == TileType.Weed)
                return ExtraFill("fill_soil") ?? FillOf("grass_soil", false);
            if (t == TileType.Tilled)
                return ExtraFill("fill_tilled") ?? ExtraFill("fill_soil");
            if (t == TileType.Wet)
                return ExtraFill("fill_wet") ?? ExtraFill("fill_soil");
            if (t == TileType.Cobble)
                return ExtraFill("fill_cobble") ?? FillOf("grass_cobble", false);
            if (t == TileType.Mountain)
                return null;
            if (t == TileType.Cliff)
                return null;
            if (t == TileType.Dock)
                return null;

            if (IsRaised(t))
            {
                string set = RaisedSet(world, tx, ty);
                if (set != null)
                {
                    Texture2D wang = Pick(set, world, tx, ty);
                    if (wang != null)
                        return wang;
                }
                if (GameConst.InDeepForest(tx, ty))
                    return FillOf("woods_path", true);
                if (ty >= GameConst.VillageH && ty < GameConst.FarmOy)
                    return null;
                if (ty >= GameConst.BeachOy)
                    return ExtraFill("fill_sand");
                return FillOf("grass_path", true);
            }
            return null;
        }

        public bool UsesWangEdges(World world, int tx, int ty)
        {
            if (world == null || world.Inside != null || !Ready)
                return false;
            TileType t = world.TileAt(tx, ty);
            if (!IsRaised(t))
                return false;
            string set = RaisedSet(world, tx, ty);
            return set != null && HasSet(set);
        }

        string RaisedSet(World world, int tx, int ty)
        {
            // Wang lips read as cliffs along water. Keep them off the beach and
            // off the river so animated stream tiles can meet the sand.
            if (ty >= GameConst.VillageH && ty < GameConst.FarmOy)
                return null;
            if (ty >= GameConst.BeachOy)
                return null;

            bool sand = false;
            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    if (dx == 0 && dy == 0)
                        continue;
                    TileType n = world.TileAt(tx + dx, ty + dy);
                    if (n == TileType.Sand || n == TileType.Shell || n == TileType.Seaweed)
                        sand = true;
                }
            }
            if (sand && HasSet("water_sand"))
                return "water_sand";
            return null;
        }

        static bool Touches(World world, int tx, int ty, TileType want)
        {
            int[] dx = { 0, 0, -1, 1 };
            int[] dy = { -1, 1, 0, 0 };
            for (int i = 0; i < 4; i++)
            {
                if (world.TileAt(tx + dx[i], ty + dy[i]) == want)
                    return true;
            }
            return false;
        }

        Texture2D Pick(string setName, World world, int tx, int ty)
        {
            WangSet set;
            if (setName == null || !_sets.TryGetValue(setName, out set))
                return null;
            bool nw = VertexUpper(world, tx, ty, setName);
            bool ne = VertexUpper(world, tx + 1, ty, setName);
            bool sw = VertexUpper(world, tx, ty + 1, setName);
            bool se = VertexUpper(world, tx + 1, ty + 1, setName);
            int key = (nw ? 8 : 0) | (ne ? 4 : 0) | (sw ? 2 : 0) | (se ? 1 : 0);
            Texture2D tex;
            if (set.ByKey.TryGetValue(key, out tex))
                return tex;
            return (nw || ne || sw || se) ? set.Upper : set.Lower;
        }

        bool VertexUpper(World world, int vx, int vy, string setName)
        {
            int raised = 0;
            int total = 0;
            for (int dy = -1; dy <= 0; dy++)
            {
                for (int dx = -1; dx <= 0; dx++)
                {
                    int x = vx + dx;
                    int y = vy + dy;
                    TileType t;
                    if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                        t = GuessOob(vy, vx);
                    else
                        t = world.TileAt(x, y);
                    total++;
                    if (IsUpperFor(setName, t, x, y))
                        raised++;
                }
            }
            return raised >= 2;
        }

        static TileType GuessOob(int vy, int vx)
        {
            if (vy < GameConst.VillageH)
                return TileType.Grass;
            if (vy < GameConst.FarmOy)
                return TileType.Mountain;
            if (vy >= GameConst.BeachOy)
                return TileType.Sand;
            return TileType.Grass;
        }

        static bool IsUpperFor(string setName, TileType t, int x, int y)
        {
            if (setName == "water_sand")
            {
                if (t == TileType.Water || t == TileType.Bridge)
                    return false;
                return t == TileType.Sand || t == TileType.Shell || t == TileType.Seaweed || IsRaised(t);
            }
            if (setName == "mountain_water")
            {
                if (t == TileType.Water || t == TileType.Bridge)
                    return false;
                return t == TileType.Mountain || t == TileType.Cliff || IsRaised(t);
            }
            if (t == TileType.Water || t == TileType.Bridge || t == TileType.Path
                || t == TileType.Bin || t == TileType.Door || t == TileType.Dock
                || t == TileType.FarmSoil || t == TileType.Tilled || t == TileType.Wet
                || t == TileType.Weed || t == TileType.Cobble || t == TileType.Sand
                || t == TileType.Shell || t == TileType.Seaweed
                || t == TileType.Fence)
                return false;
            return IsRaised(t);
        }

        public static bool IsRaised(TileType t)
        {
            return t == TileType.Grass || t == TileType.WoodsGrass || t == TileType.Tree
                || t == TileType.Flower || t == TileType.Stump || t == TileType.Dummy
                || t == TileType.Mountain || t == TileType.Rock || t == TileType.Mineral
                || t == TileType.Hay || t == TileType.HayCut;
        }

        void CopyLower(string fromName, string toName)
        {
            WangSet from;
            WangSet to;
            if (!_sets.TryGetValue(fromName, out from) || !_sets.TryGetValue(toName, out to))
                return;
            if (from.Lower == null)
                return;
            to.ByKey[0] = from.Lower;
            to.Lower = from.Lower;
        }

        void OverlayFill(string setName, bool upper, string fillName)
        {
            WangSet set;
            Texture2D fill;
            if (!_sets.TryGetValue(setName, out set) || !_fills.TryGetValue(fillName, out fill))
                return;
            int key = upper ? 15 : 0;
            set.ByKey[key] = fill;
            if (upper)
                set.Upper = fill;
            else
                set.Lower = fill;
        }

        void LoadSet(GraphicsDevice device, string root, string name)
        {
            string dir = Path.Combine(root, "tiles", name);
            if (!Directory.Exists(dir))
                return;
            WangSet set = new WangSet();
            string[] files = Directory.GetFiles(dir, "*.png");
            for (int i = 0; i < files.Length; i++)
            {
                string file = Path.GetFileNameWithoutExtension(files[i]);
                int us = file.IndexOf('_');
                string code = us >= 0 && us + 4 < file.Length ? file.Substring(us + 1, 4) : file;
                if (code.Length != 4)
                    continue;
                if (code.IndexOf('T') >= 0 || code.IndexOf('t') >= 0)
                    continue;
                int key = 0;
                for (int c = 0; c < 4; c++)
                {
                    char ch = code[c];
                    if (ch == 'U' || ch == 'u')
                        key |= 8 >> c;
                }
                Texture2D tex = LoadPng(device, files[i]);
                if (tex == null)
                    continue;
                set.ByKey[key] = tex;
                if (key == 15)
                    set.Upper = tex;
                if (key == 0)
                    set.Lower = tex;
            }
            if (set.ByKey.Count == 0)
                return;
            if (set.Upper == null)
            {
                foreach (KeyValuePair<int, Texture2D> kv in set.ByKey)
                {
                    set.Upper = kv.Value;
                    break;
                }
            }
            if (set.Lower == null)
                set.Lower = set.Upper;
            _sets[name] = set;
        }

        void TryFill(GraphicsDevice device, string dir, string name)
        {
            string path = Path.Combine(dir, name + ".png");
            Texture2D tex = LoadPng(device, path);
            if (tex != null)
                _fills[name] = tex;
        }

        static Texture2D LoadPng(GraphicsDevice device, string path)
        {
            if (!File.Exists(path))
                return null;
            Texture2D tex;
            using (FileStream fs = File.OpenRead(path))
                tex = Texture2D.FromStream(device, fs);
            Premultiply(tex);
            return tex;
        }

        static void Premultiply(Texture2D tex)
        {
            int n = tex.Width * tex.Height;
            Color[] data = new Color[n];
            tex.GetData(data);
            for (int i = 0; i < n; i++)
            {
                Color c = data[i];
                if (c.A == 255)
                    continue;
                data[i] = Color.FromNonPremultiplied(c.R, c.G, c.B, c.A);
            }
            tex.SetData(data);
        }

        public static string PackRoot()
        {
            return FindRoot();
        }

        static string FindRoot()
        {
            string[] guesses =
            {
                Path.Combine(AppContext.BaseDirectory, "Content", "pack"),
                Path.Combine(Directory.GetCurrentDirectory(), "Content", "pack"),
                Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "Content", "pack")
            };
            for (int i = 0; i < guesses.Length; i++)
            {
                if (Directory.Exists(guesses[i]))
                    return Path.GetFullPath(guesses[i]);
            }
            return null;
        }

        sealed class WangSet
        {
            public readonly Dictionary<int, Texture2D> ByKey = new Dictionary<int, Texture2D>();
            public Texture2D Upper;
            public Texture2D Lower;
        }
    }
}
