# Art pack

Original 32×32 top-down village tiles generated for Harvest Hollow (not the paid Cainos itch.io pack).

- `tiles/<set>/*.png` — Wang autotiles. Filename `NN_NW NESW SE.png` with `U` = raised terrain, `L` = lower terrain.
- `objects/*.png` — trees and props with transparent backgrounds.
- `objects/farm_cottage.png` — Kenmi Cute Fantasy free house (`House_1_Wood_Base_Blue.png`), blitted at 32px/tile for Your Cottage.
- `objects/farm_barn.png` — Kenmi Cute Fantasy barn (red gable, double doors), blitted at 32px/tile. Recovered from the pack's outdoor house previews when the upload was empty.
- `objects/ash_forge.png` — Kenmi Cute Fantasy wood-and-stone forge house, blitted at 32px/tile for Ash's Forge.
- `objects/farm_greenhouse.png` — Kenmi Cute Fantasy glasshouse (teal frame), blitted at 32px/tile. Free-pack license: non-commercial use, modifications allowed, do not redistribute the pack.

The game loads these at runtime (`Texture2D.FromStream`) and falls back to procedural `TileGen` if a file is missing.
