using System;
using System.Globalization;
using System.IO;
using Microsoft.Xna.Framework.Input;

namespace HarvestHollow
{
    public enum SettingsTab
    {
        Graphics,
        Audio,
        Controls
    }

    public enum BindId
    {
        MoveUp,
        MoveDown,
        MoveLeft,
        MoveRight,
        Interact,
        Use,
        Bag,
        Help,
        Settings,
        Mute
    }

    public sealed class GameSettings
    {
        public int Zoom = 2;
        public bool Fullscreen;
        public bool Vsync = true;
        public bool Shake = true;
        public int Rain = 2;
        public int Music = 70;
        public int Sfx = 80;
        public bool Mute;
        public Keys MoveUp = Keys.W;
        public Keys MoveDown = Keys.S;
        public Keys MoveLeft = Keys.A;
        public Keys MoveRight = Keys.D;
        public Keys Interact = Keys.E;
        public Keys Use = Keys.Space;
        public Keys Bag = Keys.I;
        public Keys Help = Keys.H;
        public Keys SettingsKey = Keys.Escape;
        public Keys MuteKey = Keys.M;

        public static string FilePath()
        {
            try
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HarvestHollow");
                Directory.CreateDirectory(dir);
                return Path.Combine(dir, "settings.cfg");
            }
            catch
            {
                return "harvest-settings.cfg";
            }
        }

        public static GameSettings Load()
        {
            GameSettings s = new GameSettings();
            string path = FilePath();
            if (!File.Exists(path))
                return s;
            try
            {
                string[] lines = File.ReadAllLines(path);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    int eq = line.IndexOf('=');
                    if (eq <= 0)
                        continue;
                    string key = line.Substring(0, eq).Trim();
                    string val = line.Substring(eq + 1).Trim();
                    s.Apply(key, val);
                }
            }
            catch
            {
            }
            s.Clamp();
            return s;
        }

        public void Save()
        {
            Clamp();
            try
            {
                string[] lines =
                {
                    "zoom=" + Zoom.ToString(CultureInfo.InvariantCulture),
                    "fullscreen=" + (Fullscreen ? "1" : "0"),
                    "vsync=" + (Vsync ? "1" : "0"),
                    "shake=" + (Shake ? "1" : "0"),
                    "rain=" + Rain.ToString(CultureInfo.InvariantCulture),
                    "music=" + Music.ToString(CultureInfo.InvariantCulture),
                    "sfx=" + Sfx.ToString(CultureInfo.InvariantCulture),
                    "mute=" + (Mute ? "1" : "0"),
                    "MoveUp=" + MoveUp,
                    "MoveDown=" + MoveDown,
                    "MoveLeft=" + MoveLeft,
                    "MoveRight=" + MoveRight,
                    "Interact=" + Interact,
                    "Use=" + Use,
                    "Bag=" + Bag,
                    "Help=" + Help,
                    "Settings=" + SettingsKey,
                    "MuteKey=" + MuteKey
                };
                File.WriteAllLines(FilePath(), lines);
            }
            catch
            {
            }
        }

        public void Reset()
        {
            GameSettings d = new GameSettings();
            Zoom = d.Zoom;
            Fullscreen = d.Fullscreen;
            Vsync = d.Vsync;
            Shake = d.Shake;
            Rain = d.Rain;
            Music = d.Music;
            Sfx = d.Sfx;
            Mute = d.Mute;
            MoveUp = d.MoveUp;
            MoveDown = d.MoveDown;
            MoveLeft = d.MoveLeft;
            MoveRight = d.MoveRight;
            Interact = d.Interact;
            Use = d.Use;
            Bag = d.Bag;
            Help = d.Help;
            SettingsKey = d.SettingsKey;
            MuteKey = d.MuteKey;
        }

        public void Clamp()
        {
            if (Zoom < 2) Zoom = 2;
            if (Zoom > 4) Zoom = 4;
            if (Rain < 0) Rain = 0;
            if (Rain > 2) Rain = 2;
            if (Music < 0) Music = 0;
            if (Music > 100) Music = 100;
            if (Sfx < 0) Sfx = 0;
            if (Sfx > 100) Sfx = 100;
        }

        public Keys GetBind(BindId id)
        {
            switch (id)
            {
                case BindId.MoveUp: return MoveUp;
                case BindId.MoveDown: return MoveDown;
                case BindId.MoveLeft: return MoveLeft;
                case BindId.MoveRight: return MoveRight;
                case BindId.Interact: return Interact;
                case BindId.Use: return Use;
                case BindId.Bag: return Bag;
                case BindId.Help: return Help;
                case BindId.Settings: return SettingsKey;
                default: return MuteKey;
            }
        }

        public void SetBind(BindId id, Keys key)
        {
            switch (id)
            {
                case BindId.MoveUp: MoveUp = key; break;
                case BindId.MoveDown: MoveDown = key; break;
                case BindId.MoveLeft: MoveLeft = key; break;
                case BindId.MoveRight: MoveRight = key; break;
                case BindId.Interact: Interact = key; break;
                case BindId.Use: Use = key; break;
                case BindId.Bag: Bag = key; break;
                case BindId.Help: Help = key; break;
                case BindId.Settings: SettingsKey = key; break;
                default: MuteKey = key; break;
            }
        }

        public bool BindTaken(BindId skip, Keys key)
        {
            for (int i = 0; i <= (int)BindId.Mute; i++)
            {
                BindId id = (BindId)i;
                if (id == skip)
                    continue;
                if (GetBind(id) == key)
                    return true;
            }
            return false;
        }

        public static string BindLabel(BindId id)
        {
            switch (id)
            {
                case BindId.MoveUp: return "Walk north";
                case BindId.MoveDown: return "Walk south";
                case BindId.MoveLeft: return "Walk west";
                case BindId.MoveRight: return "Walk east";
                case BindId.Interact: return "Interact";
                case BindId.Use: return "Use tool";
                case BindId.Bag: return "Satchel";
                case BindId.Help: return "Handbook";
                case BindId.Settings: return "Settings";
                default: return "Mute music";
            }
        }

        public static string KeyName(Keys key)
        {
            if (key >= Keys.D0 && key <= Keys.D9)
                return ((char)('0' + (key - Keys.D0))).ToString();
            if (key == Keys.OemQuestion) return "?";
            if (key == Keys.OemComma) return ",";
            if (key == Keys.OemPeriod) return ".";
            if (key == Keys.LeftShift) return "L-SHIFT";
            if (key == Keys.RightShift) return "R-SHIFT";
            if (key == Keys.LeftControl) return "L-CTRL";
            if (key == Keys.RightControl) return "R-CTRL";
            if (key == Keys.LeftAlt) return "L-ALT";
            if (key == Keys.RightAlt) return "R-ALT";
            string n = key.ToString();
            return n.ToUpperInvariant();
        }

        void Apply(string key, string val)
        {
            int n;
            int.TryParse(val, NumberStyles.Integer, CultureInfo.InvariantCulture, out n);
            bool on = val == "1" || val.Equals("true", StringComparison.OrdinalIgnoreCase);
            Keys parsed;
            bool isKey = Enum.TryParse(val, true, out parsed);
            if (key == "zoom") Zoom = n;
            else if (key == "fullscreen") Fullscreen = on;
            else if (key == "vsync") Vsync = on;
            else if (key == "shake") Shake = on;
            else if (key == "rain") Rain = n;
            else if (key == "music") Music = n;
            else if (key == "sfx") Sfx = n;
            else if (key == "mute") Mute = on;
            else if (isKey && key == "MoveUp") MoveUp = parsed;
            else if (isKey && key == "MoveDown") MoveDown = parsed;
            else if (isKey && key == "MoveLeft") MoveLeft = parsed;
            else if (isKey && key == "MoveRight") MoveRight = parsed;
            else if (isKey && key == "Interact") Interact = parsed;
            else if (isKey && key == "Use") Use = parsed;
            else if (isKey && key == "Bag") Bag = parsed;
            else if (isKey && key == "Help") Help = parsed;
            else if (isKey && key == "Settings") SettingsKey = parsed;
            else if (isKey && key == "MuteKey") MuteKey = parsed;
        }
    }
}
