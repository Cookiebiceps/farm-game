using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    /// <summary>
    /// Admin map editor: tile paint, object move, and invisible walls.
    /// World mutation lives here so HarvestHollowGame can stay a thin input/draw layer.
    /// </summary>
    public static class MapEdit
    {
        public static readonly TileType[] Palette =
        {
            TileType.Grass, TileType.WoodsGrass, TileType.FarmSoil, TileType.Tilled,
            TileType.Path, TileType.Cobble, TileType.Water, TileType.Sand,
            TileType.Mountain, TileType.Dock, TileType.HouseFloor, TileType.HouseWall,
            TileType.Flower, TileType.Hay
        };

        public static string ToolName(MapEditTool tool)
        {
            if (tool == MapEditTool.Move)
                return "Select/Move";
            if (tool == MapEditTool.Paint)
                return "Paint";
            if (tool == MapEditTool.Erase)
                return "Erase";
            if (tool == MapEditTool.Wall)
                return "Invisible wall";
            if (tool == MapEditTool.Place)
                return "Place";
            return "Eyedropper";
        }

        static MapStamp[] _catalog;

        public static MapStamp[] Catalog
        {
            get
            {
                if (_catalog == null)
                    _catalog = BuildCatalog();
                return _catalog;
            }
        }

        static MapStamp TileStamp(string name, TileType t)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Tile;
            s.Name = name;
            s.Tile = t;
            return s;
        }

        static MapStamp HouseStamp(string name, string prefix, int w, int h, int doorDx, int style, BuildingKind kind)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Building;
            s.Name = name;
            s.HouseName = name;
            s.HousePrefix = prefix;
            s.W = w;
            s.H = h;
            s.DoorDx = doorDx;
            s.Style = style;
            s.HouseKind = kind;
            return s;
        }

        static MapStamp DecoStamp(string name, int kind)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Deco;
            s.Name = name;
            s.Deco = kind;
            return s;
        }

        static MapStamp AnimalStamp(AnimalKind kind)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Animal;
            s.Name = AnimalCatalog.Name(kind);
            s.Animal = kind;
            return s;
        }

        static MapStamp CropStamp(CropDef def)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Crop;
            s.Name = def.Name;
            s.CropId = def.Id;
            return s;
        }

        static MapStamp GateStamp(string dest, int dir)
        {
            MapStamp s = new MapStamp();
            s.Kind = MapStampKind.Gate;
            s.Name = "Sign to " + dest;
            s.GateDest = dest;
            s.GateDir = dir;
            return s;
        }

        static MapStamp[] BuildCatalog()
        {
            List<MapStamp> list = new List<MapStamp>();
            list.Add(TileStamp("Oak tree", TileType.Tree));
            list.Add(TileStamp("Stump", TileType.Stump));
            list.Add(TileStamp("Rock", TileType.Rock));
            list.Add(TileStamp("Mineral vein", TileType.Mineral));
            list.Add(TileStamp("Fence", TileType.Fence));
            list.Add(TileStamp("Flower", TileType.Flower));
            list.Add(TileStamp("Weed", TileType.Weed));
            list.Add(TileStamp("Hay", TileType.Hay));
            list.Add(TileStamp("Hay stubble", TileType.HayCut));
            list.Add(TileStamp("Shipping bin", TileType.Bin));
            list.Add(TileStamp("Training dummy", TileType.Dummy));
            list.Add(TileStamp("Chest", TileType.Chest));
            list.Add(TileStamp("Wood dock", TileType.Dock));
            list.Add(TileStamp("Water", TileType.Water));
            list.Add(TileStamp("Shell", TileType.Shell));
            list.Add(TileStamp("Seaweed", TileType.Seaweed));
            list.Add(HouseStamp("Cottage", "stamp-cottage-", 7, 5, 3, 0, BuildingKind.Cottage));
            list.Add(HouseStamp("Barn", "stamp-barn-", 8, 6, 3, 8, BuildingKind.Barn));
            list.Add(HouseStamp("Greenhouse", "stamp-greenhouse-", 7, 5, 3, 9, BuildingKind.Greenhouse));
            list.Add(HouseStamp("Chicken coop", "stamp-coop-", 6, 4, 2, 10, BuildingKind.Coop));
            list.Add(HouseStamp("Silo", "stamp-silo-", 2, 3, 0, 11, BuildingKind.Silo));
            list.Add(HouseStamp("Ash's forge", "stamp-ash-", 7, 5, 1, 4, BuildingKind.Carpenter));
            list.Add(HouseStamp("Rowan's shop", "stamp-rowan-", 6, 5, 2, 1, BuildingKind.Shop));
            list.Add(HouseStamp("Village house", "stamp-home-", 6, 5, 2, 2, BuildingKind.Home));
            list.Add(HouseStamp("Hearth Inn", "stamp-inn-", 9, 6, 4, 3, BuildingKind.Inn));
            list.Add(HouseStamp("Bess's stockyard", "stamp-bess-", 7, 5, 3, 1, BuildingKind.AnimalShop));
            list.Add(HouseStamp("Piper's market", "stamp-piper-", 8, 6, 3, 1, BuildingKind.GeneralStore));
            list.Add(HouseStamp("Finn's dock house", "stamp-finn-", 6, 4, 2, 1, BuildingKind.FishMarket));
            list.Add(DecoStamp("Barrel", DecoKind.Barrel));
            list.Add(DecoStamp("Crate", DecoKind.Crate));
            list.Add(DecoStamp("Picnic", DecoKind.Picnic));
            list.Add(DecoStamp("Bush", DecoKind.Bush));
            list.Add(DecoStamp("Fish crate", DecoKind.FishCrate));
            list.Add(DecoStamp("Drying rack", DecoKind.FishRack));
            list.Add(DecoStamp("Shark", DecoKind.Shark));
            list.Add(DecoStamp("Sack", DecoKind.Sack));
            list.Add(DecoStamp("Rowboat", DecoKind.Rowboat));
            list.Add(DecoStamp("Blue sailboat", DecoKind.SailBlue));
            list.Add(DecoStamp("Brown sailboat", DecoKind.SailBrown));
            list.Add(DecoStamp("Log slice", DecoKind.LogSlice));
            for (int i = 0; i < AnimalCatalog.Count; i++)
                list.Add(AnimalStamp((AnimalKind)i));
            for (int i = 0; i < CropCatalog.All.Length; i++)
                list.Add(CropStamp(CropCatalog.All[i]));
            list.Add(GateStamp("Harvest Hollow", 0));
            list.Add(GateStamp("Forbidden Woods", 1));
            list.Add(GateStamp("Moonveil Grove", 1));
            list.Add(GateStamp("Mountain Path", 3));
            list.Add(GateStamp("Hearth Village", 3));
            list.Add(GateStamp("Ridge Summit", 1));
            list.Add(GateStamp("Meadow Road", 0));
            list.Add(GateStamp("Saltwind Beach", 0));
            return list.ToArray();
        }

        public static void StampFoot(MapStamp s, int rot, out int w, out int h)
        {
            w = 1;
            h = 1;
            if (s == null)
                return;
            if (s.Kind == MapStampKind.Building)
            {
                w = Building.FootWFor(rot, s.W, s.H);
                h = Building.FootHFor(rot, s.W, s.H);
            }
        }

        public static string TileName(TileType t)
        {
            switch (t)
            {
                case TileType.Grass: return "Grass";
                case TileType.FarmSoil: return "Dirt";
                case TileType.Tilled: return "Tillable";
                case TileType.Wet: return "Wet soil";
                case TileType.Water: return "Water";
                case TileType.Path: return "Path";
                case TileType.Fence: return "Fence";
                case TileType.HouseWall: return "Wall";
                case TileType.HouseFloor: return "Floor";
                case TileType.Tree: return "Tree";
                case TileType.Rock: return "Rock";
                case TileType.Bin: return "Shipping bin";
                case TileType.Bed: return "Bed";
                case TileType.Counter: return "Counter";
                case TileType.Flower: return "Flower";
                case TileType.Weed: return "Weed";
                case TileType.Door: return "Door";
                case TileType.WoodsGrass: return "Woods grass";
                case TileType.Stump: return "Stump";
                case TileType.Roof: return "Roof";
                case TileType.Cliff: return "Cliff";
                case TileType.Mountain: return "Mountain";
                case TileType.Cobble: return "Cobble";
                case TileType.Sand: return "Sand";
                case TileType.HouseWindow: return "Window";
                case TileType.Dock: return "Wood dock";
                case TileType.Dummy: return "Training dummy";
                case TileType.Mineral: return "Mineral vein";
                case TileType.Bridge: return "Bridge";
                case TileType.Stairs: return "Stairs";
                case TileType.Chest: return "Chest";
                case TileType.Shell: return "Shell";
                case TileType.Seaweed: return "Seaweed";
                case TileType.Hay: return "Hay";
                case TileType.HayCut: return "Hay stubble";
                case TileType.InvisibleWall: return "Invisible wall";
                default: return t.ToString();
            }
        }

        public static bool IsBuildingShell(TileType t)
        {
            return t == TileType.Roof || t == TileType.HouseWall || t == TileType.Door
                || t == TileType.HouseWindow;
        }

        public static bool IsMovableTile(TileType t)
        {
            return t == TileType.Tree || t == TileType.Stump || t == TileType.Rock
                || t == TileType.Mineral || t == TileType.Dummy || t == TileType.Flower
                || t == TileType.Weed || t == TileType.Fence || t == TileType.Bin
                || t == TileType.Shell || t == TileType.Seaweed || t == TileType.Hay
                || t == TileType.HayCut || t == TileType.Dock || t == TileType.Bridge
                || t == TileType.Chest || t == TileType.Water;
        }

        public static string DecoName(int kind)
        {
            if (kind == DecoKind.Barrel) return "Barrel";
            if (kind == DecoKind.Crate) return "Crate";
            if (kind == DecoKind.Picnic) return "Picnic";
            if (kind == DecoKind.Bush) return "Bush";
            if (kind == DecoKind.FishCrate) return "Fish crate";
            if (kind == DecoKind.FishRack) return "Drying rack";
            if (kind == DecoKind.Shark) return "Shark";
            if (kind == DecoKind.Sack) return "Sack";
            if (kind == DecoKind.Rowboat) return "Rowboat";
            if (kind == DecoKind.SailBlue) return "Blue sailboat";
            if (kind == DecoKind.SailBrown) return "Brown sailboat";
            if (kind == DecoKind.LogSlice) return "Log slice";
            return "Prop";
        }
    }

    public sealed class MapUndo
    {
        public readonly List<Point> Cells = new List<Point>();
        public readonly List<TileType> Tiles = new List<TileType>();
        public readonly List<bool> Walls = new List<bool>();
        public MapEditPick Moved;
        public int MovedToX;
        public int MovedToY;
        public MapStamp Stamp;
        public int StampX;
        public int StampY;
        public int StampRot;
        public string StampBuildingId = "";
    }

    public sealed partial class World
    {
        public int NpcTileX(int i)
        {
            if (NpcTx == null || i < 0 || i >= NpcTx.Length)
                return VillageFolk.Outdoor[i].Tx;
            return NpcTx[i];
        }

        public int NpcTileY(int i)
        {
            if (NpcTy == null || i < 0 || i >= NpcTy.Length)
                return VillageFolk.Outdoor[i].Ty;
            return NpcTy[i];
        }

        public void SetNpcTile(int i, int x, int y)
        {
            if (NpcTx == null || NpcTy == null)
                return;
            if (i < 0 || i >= NpcTx.Length)
                return;
            NpcTx[i] = x;
            NpcTy[i] = y;
        }

        public TileType NaturalGround(int tx, int ty)
        {
            return SoftAfterMine(tx, ty);
        }

        public bool BuildingOccupies(int tx, int ty)
        {
            for (int i = 0; i < Buildings.Count; i++)
            {
                if (Buildings[i].ContainsTile(tx, ty))
                    return true;
            }
            return false;
        }

        public Building EditorBuildingAt(int tx, int ty)
        {
            Building best = null;
            int bestD = int.MaxValue;
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                int y0 = b.Y - 2;
                if (tx < b.X || tx >= b.X + b.FootW || ty < y0 || ty >= b.Y + b.FootH)
                    continue;
                int cy = b.Y + b.FootH / 2;
                int cx = b.X + b.FootW / 2;
                int d = Math.Abs(tx - cx) + Math.Abs(ty - cy);
                if (d < bestD)
                {
                    bestD = d;
                    best = b;
                }
            }
            return best;
        }

        public MapEditPick EditorHit(int tx, int ty)
        {
            MapEditPick pick = new MapEditPick();
            pick.Kind = MapEditKind.None;
            pick.X = tx;
            pick.Y = ty;
            pick.W = 1;
            pick.H = 1;
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
            {
                pick.Name = "Off the map";
                return pick;
            }
            Building house = EditorBuildingAt(tx, ty);
            if (house != null)
            {
                pick.Kind = MapEditKind.Building;
                pick.House = house;
                pick.Name = string.IsNullOrEmpty(house.RepairName) ? house.Name : house.RepairName;
                pick.X = house.X;
                pick.Y = house.Y;
                pick.W = house.FootW;
                pick.H = house.FootH;
                return pick;
            }
            for (int i = 0; i < VillageFolk.Outdoor.Length; i++)
            {
                if (Math.Abs(NpcTileX(i) - tx) <= 1 && Math.Abs(NpcTileY(i) - ty) <= 1)
                {
                    NpcDef n = VillageFolk.Outdoor[i];
                    pick.Kind = MapEditKind.Npc;
                    pick.Index = i;
                    pick.Name = n.Name;
                    pick.NpcId = n.Id;
                    pick.NpcName = n.Name;
                    pick.NpcLine = n.Line;
                    pick.X = NpcTileX(i);
                    pick.Y = NpcTileY(i);
                    return pick;
                }
            }
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                int ax = (int)Math.Floor(a.Pos.X / GameConst.Tile);
                int ay = (int)Math.Floor(a.Pos.Y / GameConst.Tile);
                if (ax == tx && ay == ty)
                {
                    pick.Kind = MapEditKind.Animal;
                    pick.Index = i;
                    pick.Name = AnimalCatalog.Name(a.Kind);
                    pick.AnimalKind = a.Kind;
                    pick.AnimalPos = a.Pos;
                    pick.AnimalDir = a.Dir;
                    pick.X = ax;
                    pick.Y = ay;
                    return pick;
                }
            }
            for (int i = 0; i < Decos.Count; i++)
            {
                if (Decos[i].X == tx && Decos[i].Y == ty)
                {
                    pick.Kind = MapEditKind.Deco;
                    pick.Index = i;
                    pick.Name = MapEdit.DecoName(Decos[i].Kind);
                    pick.DecoCopy = new Deco();
                    pick.DecoCopy.X = Decos[i].X;
                    pick.DecoCopy.Y = Decos[i].Y;
                    pick.DecoCopy.Kind = Decos[i].Kind;
                    pick.X = tx;
                    pick.Y = ty;
                    return pick;
                }
            }
            for (int i = 0; i < Gates.Count; i++)
            {
                if (Math.Abs(Gates[i].X - tx) <= 1 && Math.Abs(Gates[i].Y - ty) <= 1)
                {
                    pick.Kind = MapEditKind.Gate;
                    pick.Index = i;
                    pick.Name = "Sign to " + Gates[i].Dest;
                    pick.GateCopy = new GateSign();
                    pick.GateCopy.X = Gates[i].X;
                    pick.GateCopy.Y = Gates[i].Y;
                    pick.GateCopy.Dest = Gates[i].Dest;
                    pick.GateCopy.Dir = Gates[i].Dir;
                    pick.X = Gates[i].X;
                    pick.Y = Gates[i].Y;
                    return pick;
                }
            }
            for (int i = 0; i < Bridges.Count; i++)
            {
                StoneBridge b = Bridges[i];
                if (tx >= b.X && tx < b.X + b.W && ty >= b.Y && ty < b.Y + b.H)
                {
                    pick.Kind = MapEditKind.Bridge;
                    pick.Index = i;
                    pick.Name = "Stone bridge";
                    pick.BridgeCopy = new StoneBridge();
                    pick.BridgeCopy.X = b.X;
                    pick.BridgeCopy.Y = b.Y;
                    pick.BridgeCopy.W = b.W;
                    pick.BridgeCopy.H = b.H;
                    pick.BridgeCopy.NorthSouth = b.NorthSouth;
                    pick.X = b.X;
                    pick.Y = b.Y;
                    pick.W = b.W;
                    pick.H = b.H;
                    return pick;
                }
            }
            TileType t = TileAt(tx, ty);
            if (MapEdit.IsMovableTile(t) && !MapEdit.IsBuildingShell(t))
            {
                pick.Kind = MapEditKind.Tile;
                pick.Tile = t;
                pick.Name = MapEdit.TileName(t);
                Crop crop;
                if (Crops.TryGetValue(CropKey(tx, ty), out crop))
                    pick.Crop = crop;
                return pick;
            }
            Crop planted;
            if (Crops.TryGetValue(CropKey(tx, ty), out planted))
            {
                pick.Kind = MapEditKind.Tile;
                pick.Tile = t;
                pick.Crop = planted;
                CropDef def = CropCatalog.Find(planted.Id);
                pick.Name = def != null ? def.Name : "Crop";
                return pick;
            }
            pick.Name = "";
            return pick;
        }

        public string EditorHoverName(int tx, int ty)
        {
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return "Off the map";
            MapEditPick hit = EditorHit(tx, ty);
            if (hit.Kind != MapEditKind.None)
                return hit.Name;
            TileType t = TileAt(tx, ty);
            string name = MapEdit.TileName(t);
            if (HasHiddenWall(tx, ty))
                name += " + wall";
            return name;
        }

        public bool EditorPaintCell(int tx, int ty, TileType paint, bool erase, bool allowBuilding)
        {
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return false;
            if (Inside != null)
                return false;
            TileType now = Tiles[tx, ty];
            if (!allowBuilding && (MapEdit.IsBuildingShell(now) || BuildingOccupies(tx, ty)))
                return false;
            TileType next = erase ? NaturalGround(tx, ty) : paint;
            if (now == next)
                return false;
            Tiles[tx, ty] = next;
            if (next != TileType.Tilled && next != TileType.Wet)
                Crops.Remove(CropKey(tx, ty));
            if (now == TileType.Tree)
                TreeHits.Remove(CropKey(tx, ty));
            if (now == TileType.Rock || now == TileType.Mineral)
                RockHits.Remove(CropKey(tx, ty));
            return true;
        }

        public bool EditorSetWallCell(int tx, int ty, bool on)
        {
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return false;
            if (HasHiddenWall(tx, ty) == on)
                return false;
            SetHiddenWall(tx, ty, on);
            return true;
        }

        public bool CanPlaceEditorBuilding(Building b, int x, int y)
        {
            if (b == null)
                return false;
            if (x < 0 || y < 0)
                return false;
            if (x + b.FootW > GameConst.MapW || y + b.FootH > GameConst.MapH)
                return false;
            int lx, ly;
            Building.DoorLocal(b.W, b.H, b.DoorDx, b.Rot, out lx, out ly);
            int doorX = x + lx;
            int doorY = y + ly;
            int pathX, pathY;
            b.ApproachAt(x, y, b.Rot, out pathX, out pathY);
            if (doorX < 0 || doorX >= GameConst.MapW || doorY < 0 || doorY >= GameConst.MapH)
                return false;
            if (pathX < 0 || pathX >= GameConst.MapW || pathY < 0 || pathY >= GameConst.MapH)
                return false;
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building other = Buildings[i];
                if (other == b)
                    continue;
                if (other.HitsRect(x, y, b.FootW, b.FootH))
                    return false;
            }
            for (int dy = 0; dy < b.FootH; dy++)
            {
                for (int dx = 0; dx < b.FootW; dx++)
                {
                    int tx = x + dx;
                    int ty = y + dy;
                    if (b.ContainsTile(tx, ty))
                        continue;
                    TileType t = Tiles[tx, ty];
                    if (MapEdit.IsBuildingShell(t))
                        return false;
                    if (t == TileType.Tree || t == TileType.Rock || t == TileType.Mineral
                        || t == TileType.Bin || t == TileType.Dummy || t == TileType.Chest)
                        return false;
                    if (t == TileType.Water && b.Kind != BuildingKind.FishMarket)
                        return false;
                    if (t == TileType.Cliff && b.Kind != BuildingKind.Cave)
                        return false;
                }
            }
            return true;
        }

        public bool MoveEditorBuilding(Building b, int x, int y)
        {
            if (b == null)
                return false;
            if (b.X == x && b.Y == y)
                return true;
            if (!CanPlaceEditorBuilding(b, x, y))
                return false;
            UnstampEditorBuilding(b);
            b.X = x;
            b.Y = y;
            MapGen.StampBuilding(Tiles, b);
            if (Inside == b)
                OutdoorPos = b.OutdoorExit;
            return true;
        }

        public bool RotateEditorBuilding(Building b)
        {
            if (b == null)
                return false;
            int oldRot = b.Rot;
            int oldX = b.X;
            int oldY = b.Y;
            int oldFw = b.FootW;
            int oldFh = b.FootH;
            UnstampEditorBuilding(b);
            b.Rot = (b.Rot + 1) & 3;
            int nx = oldX + (oldFw - b.FootW) / 2;
            int ny = oldY + (oldFh - b.FootH) / 2;
            if (!CanPlaceEditorBuilding(b, nx, ny))
            {
                nx = oldX;
                ny = oldY;
            }
            if (!CanPlaceEditorBuilding(b, nx, ny))
            {
                b.Rot = oldRot;
                MapGen.StampBuilding(Tiles, b);
                return false;
            }
            b.X = nx;
            b.Y = ny;
            MapGen.StampBuilding(Tiles, b);
            if (Inside == b)
                OutdoorPos = b.OutdoorExit;
            return true;
        }

        void UnstampEditorBuilding(Building b)
        {
            if (b == null || Tiles == null)
                return;
            if (b.Kind == BuildingKind.Cave)
            {
                for (int dy = 0; dy < b.H; dy++)
                {
                    for (int dx = 0; dx < b.W; dx++)
                    {
                        int tx = b.X + dx;
                        int ty = b.Y + dy;
                        if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                            continue;
                        TileType t = Tiles[tx, ty];
                        if (t == TileType.Cliff || t == TileType.Door)
                            Tiles[tx, ty] = TileType.Mountain;
                    }
                }
                int ax = b.ApproachX;
                int ay = b.ApproachY;
                if (ax >= 0 && ay >= 0 && ax < GameConst.MapW && ay < GameConst.MapH)
                {
                    if (Tiles[ax, ay] == TileType.Path)
                        Tiles[ax, ay] = TileType.Mountain;
                }
                return;
            }
            UnstampFarmBuilding(b);
            for (int dy = 0; dy < b.FootH; dy++)
            {
                for (int dx = 0; dx < b.FootW; dx++)
                {
                    int tx = b.X + dx;
                    int ty = b.Y + dy;
                    if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                        continue;
                    if (Tiles[tx, ty] == TileType.Grass)
                        Tiles[tx, ty] = NaturalGround(tx, ty);
                }
            }
        }

        public bool CanPlaceEditorTile(MapEditPick pick, int x, int y)
        {
            if (pick == null || pick.Kind == MapEditKind.None)
                return false;
            if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                return false;
            if (pick.Kind == MapEditKind.Building)
                return CanPlaceEditorBuilding(pick.House, x, y);
            if (pick.Kind == MapEditKind.Bridge)
            {
                int w = pick.W < 1 ? 1 : pick.W;
                int h = pick.H < 1 ? 1 : pick.H;
                if (x + w > GameConst.MapW || y + h > GameConst.MapH)
                    return false;
                return true;
            }
            if (BuildingOccupies(x, y) && pick.Kind != MapEditKind.Npc)
                return false;
            TileType t = Tiles[x, y];
            if (pick.Kind == MapEditKind.Tile)
            {
                if (pick.X == x && pick.Y == y)
                    return true;
                if (MapEdit.IsBuildingShell(t))
                    return false;
                if (t == TileType.Tree || t == TileType.Rock || t == TileType.Mineral
                    || t == TileType.Bin || t == TileType.Dummy || t == TileType.Chest)
                    return false;
                if (t == TileType.Water && pick.Tile != TileType.Water && pick.Tile != TileType.Dock
                    && pick.Tile != TileType.Bridge)
                    return false;
                return true;
            }
            if (pick.Kind == MapEditKind.Deco || pick.Kind == MapEditKind.Gate
                || pick.Kind == MapEditKind.Animal || pick.Kind == MapEditKind.Npc)
            {
                if (IsSolid(t) && t != TileType.Tree)
                    return false;
                return true;
            }
            return false;
        }

        public bool MoveEditorPick(MapEditPick pick, int x, int y)
        {
            if (pick == null)
                return false;
            if (pick.X == x && pick.Y == y)
                return true;
            if (!CanPlaceEditorTile(pick, x, y))
                return false;
            if (pick.Kind == MapEditKind.Building)
                return MoveEditorBuilding(pick.House, x, y);
            if (pick.Kind == MapEditKind.Tile)
            {
                TileType here = Tiles[pick.X, pick.Y];
                if (here == pick.Tile || (pick.Crop != null && Crops.ContainsKey(CropKey(pick.X, pick.Y))))
                    Tiles[pick.X, pick.Y] = NaturalGround(pick.X, pick.Y);
                Crop crop;
                string fromKey = CropKey(pick.X, pick.Y);
                if (Crops.TryGetValue(fromKey, out crop))
                    Crops.Remove(fromKey);
                Tiles[x, y] = pick.Tile;
                if (crop != null)
                    Crops[CropKey(x, y)] = crop;
                else if (pick.Crop != null)
                    Crops[CropKey(x, y)] = pick.Crop;
                pick.X = x;
                pick.Y = y;
                return true;
            }
            if (pick.Kind == MapEditKind.Deco && pick.Index >= 0 && pick.Index < Decos.Count)
            {
                Decos[pick.Index].X = x;
                Decos[pick.Index].Y = y;
                pick.X = x;
                pick.Y = y;
                return true;
            }
            if (pick.Kind == MapEditKind.Gate && pick.Index >= 0 && pick.Index < Gates.Count)
            {
                Gates[pick.Index].X = x;
                Gates[pick.Index].Y = y;
                pick.X = x;
                pick.Y = y;
                return true;
            }
            if (pick.Kind == MapEditKind.Animal && pick.Index >= 0 && pick.Index < Animals.Count)
            {
                Animals[pick.Index].Pos = new Vector2((x + 0.5f) * GameConst.Tile, (y + 0.5f) * GameConst.Tile);
                pick.X = x;
                pick.Y = y;
                return true;
            }
            if (pick.Kind == MapEditKind.Npc && pick.Index >= 0)
            {
                SetNpcTile(pick.Index, x, y);
                pick.X = x;
                pick.Y = y;
                return true;
            }
            if (pick.Kind == MapEditKind.Bridge && pick.Index >= 0 && pick.Index < Bridges.Count)
            {
                StoneBridge b = Bridges[pick.Index];
                b.X = x;
                b.Y = y;
                pick.X = x;
                pick.Y = y;
                return true;
            }
            return false;
        }

        public void BeginMapEdit()
        {
            if (Inside != null)
            {
                OutdoorPos = Inside.OutdoorExit;
                PlayerPos = OutdoorPos;
                Inside = null;
                InsideFloor = 0;
                DoorSwing = null;
                DoorOpenU = 0f;
                DoorForced = false;
                int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
                int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
                OutdoorZone = ZoneAt(tx, ty);
            }
            ShareWorldView = true;
            ZoneName = "Map editor";
            Screen = Screen.MapEdit;
            ShowToast("Map editor. Esc returns to admin.");
        }

        public void EndMapEdit()
        {
            ShareWorldView = false;
            Screen = Screen.Admin;
            int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
            int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
            OutdoorZone = ZoneAt(tx, ty);
            ZoneName = OutdoorZone;
            ShowToast("Closed the map editor.");
        }

        public string NextStampId(string prefix)
        {
            if (string.IsNullOrEmpty(prefix))
                prefix = "stamp-";
            int n = 1;
            while (FindBuilding(prefix + n.ToString()) != null)
            {
                n++;
                if (n > 512)
                    break;
            }
            return prefix + n.ToString();
        }

        public bool CanStampEditor(MapStamp s, int x, int y, int rot)
        {
            if (s == null)
                return false;
            if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                return false;
            if (Inside != null)
                return false;
            if (s.Kind == MapStampKind.Building)
            {
                Building proto = new Building();
                proto.Id = "_proto";
                proto.X = x;
                proto.Y = y;
                proto.W = s.W;
                proto.H = s.H;
                proto.DoorDx = s.DoorDx;
                proto.Rot = rot & 3;
                proto.Kind = s.HouseKind;
                if (!CanPlaceEditorBuilding(proto, x, y))
                    return false;
                int fw = proto.FootW;
                int fh = proto.FootH;
                for (int dy = 0; dy < fh; dy++)
                {
                    for (int dx = 0; dx < fw; dx++)
                    {
                        int tx = x + dx;
                        int ty = y + dy;
                        TileType t = Tiles[tx, ty];
                        if (t == TileType.Tree || t == TileType.Rock || t == TileType.Mineral
                            || t == TileType.Bin || t == TileType.Dummy || t == TileType.Chest
                            || t == TileType.Fence || MapEdit.IsBuildingShell(t))
                            return false;
                    }
                }
                return true;
            }
            MapEditPick pick = new MapEditPick();
            pick.X = -1;
            pick.Y = -1;
            if (s.Kind == MapStampKind.Tile)
            {
                pick.Kind = MapEditKind.Tile;
                pick.Tile = s.Tile;
                return CanPlaceEditorTile(pick, x, y);
            }
            if (s.Kind == MapStampKind.Deco || s.Kind == MapStampKind.Gate)
            {
                pick.Kind = s.Kind == MapStampKind.Deco ? MapEditKind.Deco : MapEditKind.Gate;
                return CanPlaceEditorTile(pick, x, y);
            }
            if (s.Kind == MapStampKind.Animal)
            {
                if (Animals.Count >= AnimalCatalog.MaxOnFarm)
                    return false;
                if (AnimalOnTile(x, y))
                    return false;
                pick.Kind = MapEditKind.Animal;
                return CanPlaceEditorTile(pick, x, y);
            }
            if (s.Kind == MapStampKind.Crop)
            {
                if (Crops.ContainsKey(CropKey(x, y)))
                    return false;
                if (BuildingOccupies(x, y))
                    return false;
                TileType t = Tiles[x, y];
                if (MapEdit.IsBuildingShell(t))
                    return false;
                return t == TileType.Grass || t == TileType.FarmSoil || t == TileType.Tilled
                    || t == TileType.Wet || t == TileType.Flower || t == TileType.Weed
                    || t == TileType.WoodsGrass || t == TileType.Hay || t == TileType.HayCut;
            }
            return false;
        }

        public bool StampEditor(MapStamp s, int x, int y, int rot, out string placedId)
        {
            placedId = "";
            if (!CanStampEditor(s, x, y, rot))
                return false;
            if (s.Kind == MapStampKind.Tile)
                return EditorPaintCell(x, y, s.Tile, false, false);
            if (s.Kind == MapStampKind.Building)
            {
                if (Buildings.Count >= 256)
                    return false;
                string id = NextStampId(s.HousePrefix);
                Building b = Building.Make(id, s.HouseName, x, y, s.W, s.H, s.DoorDx, s.Style, s.HouseKind);
                b.Rot = rot & 3;
                b.Repaired = true;
                if (b.IsFarmOutbuilding)
                {
                    b.Name = b.RepairName;
                    b.RebuildInterior();
                }
                if (!CanPlaceEditorBuilding(b, x, y))
                    return false;
                Buildings.Add(b);
                MapGen.StampBuilding(Tiles, b);
                placedId = id;
                return true;
            }
            if (s.Kind == MapStampKind.Deco)
            {
                if (Decos.Count >= 4096)
                    return false;
                Deco d = new Deco();
                d.X = x;
                d.Y = y;
                d.Kind = s.Deco;
                Decos.Add(d);
                return true;
            }
            if (s.Kind == MapStampKind.Gate)
            {
                if (Gates.Count >= 256)
                    return false;
                GateSign g = new GateSign();
                g.X = x;
                g.Y = y;
                g.Dest = s.GateDest ?? "";
                g.Dir = s.GateDir;
                Gates.Add(g);
                return true;
            }
            if (s.Kind == MapStampKind.Animal)
            {
                FarmAnimal a = new FarmAnimal();
                a.Kind = s.Animal;
                a.Pos = new Vector2((x + 0.5f) * GameConst.Tile, (y + 0.5f) * GameConst.Tile);
                a.Wander = a.Pos;
                a.Dir = 0;
                a.WanderT = 0.4f;
                if (s.Animal == AnimalKind.Sheep)
                    a.HasWool = true;
                Animals.Add(a);
                return true;
            }
            if (s.Kind == MapStampKind.Crop)
            {
                CropDef def = CropCatalog.Find(s.CropId);
                if (def == null)
                    return false;
                Crop crop = new Crop();
                crop.Id = def.Id;
                crop.Stage = def.Days;
                crop.Watered = false;
                Tiles[x, y] = TileType.Tilled;
                Crops[CropKey(x, y)] = crop;
                return true;
            }
            return false;
        }

        public bool UnstampEditor(MapStamp s, int x, int y, string buildingId)
        {
            if (s == null)
                return false;
            if (s.Kind == MapStampKind.Tile)
                return EditorPaintCell(x, y, TileType.Grass, true, false);
            if (s.Kind == MapStampKind.Building)
            {
                Building b = FindBuilding(buildingId);
                if (b == null)
                    return false;
                UnstampEditorBuilding(b);
                Buildings.Remove(b);
                return true;
            }
            if (s.Kind == MapStampKind.Deco)
            {
                for (int i = Decos.Count - 1; i >= 0; i--)
                {
                    if (Decos[i].X == x && Decos[i].Y == y && Decos[i].Kind == s.Deco)
                    {
                        Decos.RemoveAt(i);
                        return true;
                    }
                }
                return false;
            }
            if (s.Kind == MapStampKind.Gate)
            {
                for (int i = Gates.Count - 1; i >= 0; i--)
                {
                    if (Gates[i].X == x && Gates[i].Y == y)
                    {
                        Gates.RemoveAt(i);
                        return true;
                    }
                }
                return false;
            }
            if (s.Kind == MapStampKind.Animal)
            {
                FarmAnimal a = AnimalAtTile(x, y);
                if (a == null)
                    return false;
                Animals.Remove(a);
                return true;
            }
            if (s.Kind == MapStampKind.Crop)
            {
                Crops.Remove(CropKey(x, y));
                if (x >= 0 && y >= 0 && x < GameConst.MapW && y < GameConst.MapH)
                {
                    if (Tiles[x, y] == TileType.Tilled || Tiles[x, y] == TileType.Wet)
                        Tiles[x, y] = NaturalGround(x, y);
                }
                return true;
            }
            return false;
        }

        void WriteMapExtras(System.IO.BinaryWriter w)
        {
            w.Write(Decos.Count);
            for (int i = 0; i < Decos.Count; i++)
            {
                w.Write(Decos[i].X);
                w.Write(Decos[i].Y);
                w.Write(Decos[i].Kind);
            }
            w.Write(Gates.Count);
            for (int i = 0; i < Gates.Count; i++)
            {
                w.Write(Gates[i].X);
                w.Write(Gates[i].Y);
                w.Write(Gates[i].Dest ?? "");
                w.Write(Gates[i].Dir);
            }
            int n = VillageFolk.Outdoor.Length;
            w.Write(n);
            for (int i = 0; i < n; i++)
            {
                w.Write(NpcTileX(i));
                w.Write(NpcTileY(i));
            }
        }

        void ReadMapExtras(System.IO.BinaryReader r)
        {
            Decos.Clear();
            int dc = r.ReadInt32();
            if (dc < 0)
                dc = 0;
            if (dc > 4096)
                dc = 4096;
            for (int i = 0; i < dc; i++)
            {
                Deco d = new Deco();
                d.X = r.ReadInt32();
                d.Y = r.ReadInt32();
                d.Kind = r.ReadInt32();
                Decos.Add(d);
            }
            Gates.Clear();
            int gc = r.ReadInt32();
            if (gc < 0)
                gc = 0;
            if (gc > 256)
                gc = 256;
            for (int i = 0; i < gc; i++)
            {
                GateSign g = new GateSign();
                g.X = r.ReadInt32();
                g.Y = r.ReadInt32();
                g.Dest = r.ReadString();
                g.Dir = r.ReadInt32();
                Gates.Add(g);
            }
            int n = r.ReadInt32();
            if (n < 0)
                n = 0;
            if (n > 32)
                n = 32;
            for (int i = 0; i < n; i++)
            {
                int x = r.ReadInt32();
                int y = r.ReadInt32();
                if (i < NpcTx.Length)
                {
                    NpcTx[i] = x;
                    NpcTy[i] = y;
                }
            }
        }
    }
}
