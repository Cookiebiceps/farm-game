using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace HarvestHollow
{
    /// <summary>
    /// XNA 4.0 Game subclass: Initialize / LoadContent / Update / Draw.
    /// </summary>
    public sealed class HarvestHollowGame : Game
    {
        private readonly GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Assets _assets;
        private PixelFont _font;
        private World _world;
        private NetSession _net;
        private int _titleRow;
        private string _joinIp = "127.0.0.1";
        private int _createRow;
        private int _createNext;
        private FarmerLook _createLook = FarmerLook.Classic;
        private float _createAnim;
        private int _createDir;
        private int _skillRow;
        private readonly List<ItemDef> _adminItems = new List<ItemDef>();
        private string _adminFilter = "";
        private int _adminSel;
        private int _adminScroll;
        private int _adminQty = 1;
        private Building _planPick;
        private MapEditTool _editTool;
        private MapEditPick _editPick;
        private TileType _editPaint = TileType.Grass;
        private int _editBrush = 1;
        private bool _editGrid = true;
        private Vector2 _editCam;
        private bool _editPainting;
        private readonly List<MapUndo> _editUndo = new List<MapUndo>();
        private MapUndo _editStroke;
        private int _editStamp;
        private int _editStampRot;
        private int _editStampScroll;
        private float _saveAcc;
        private bool _saveLoaded;
        private float _inputSend;
        private KeyboardState _prevKeys;
        private MouseState _prevMouse;
        private Vector2 _cam;
        private GameSettings _cfg;
        private SettingsTab _setTab;
        private int _setRow;
        private bool _rebinding;
        private Screen _settingsBack = Screen.Title;
        private float Scale
        {
            get
            {
                if (_world != null && _world.Screen == Screen.Plan)
                    return PlanScale;
                int z = _cfg != null ? _cfg.Zoom : 2;
                if (z < 2) z = 2;
                if (z > 4) z = 4;
                if (z == 2) return 1.55f;
                if (z == 3) return 2.30f;
                return 3.02f;
            }
        }

        private float PlanScale
        {
            get
            {
                int vw = GraphicsDevice != null ? GraphicsDevice.Viewport.Width : 1280;
                int vh = GraphicsDevice != null ? GraphicsDevice.Viewport.Height : 720;
                if (vw < 8) vw = 1280;
                if (vh < 8) vh = 720;
                float farmW = (GameConst.MapW - GameConst.FarmOx) * GameConst.Tile + GameConst.Tile * 2f;
                float farmH = GameConst.FarmH * GameConst.Tile + GameConst.Tile * 2f;
                float sx = vw / farmW;
                float sy = vh / farmH;
                float s = sx < sy ? sx : sy;
                if (s < 0.28f) s = 0.28f;
                if (s > 0.72f) s = 0.72f;
                return s;
            }
        }
        private int RainCount
        {
            get
            {
                if (_cfg == null || _cfg.Rain >= 2) return 340;
                if (_cfg.Rain == 1) return 220;
                return 120;
            }
        }
        private readonly Random _rng = new Random();
        private RainDrop[] _rain;
        private RainSplash[] _splashes;
        private int _splashAt;
        private float _windTime;
        private readonly Dictionary<Texture2D, int> _treeRootH = new Dictionary<Texture2D, int>();
        private PianoTheme _music;
        private SoundEffect _thunder;
        private SoundEffect _pickup;
        private float _flash;
        private float _thunderIn;
        private float _nextBolt = 4f;
        private float _camShake;
        private readonly LightningBolt[] _bolts = new LightningBolt[4];
        private int _boltAt;
        private SlotLoc _dragFrom;
        private bool _dragging;
        private bool _dragMoved;
        private Point _dragStart;
        private const int HudSlot = 50;
        private const int HudGap = 52;
        private const int HudBarX = 12;
        private const int PackSlot = 56;
        private const int PackGap = 8;
        private float _prevSwingU;
        private readonly ToolSpark[] _sparks = new ToolSpark[64];
        private int _sparkAt;
        private readonly FallingLeaf[] _leaves = new FallingLeaf[80];
        private int _leafAt;
        private float _leafSpawn;
        private readonly Firefly[] _flies = new Firefly[40];
        private int _flyAt;

        public HarvestHollowGame()
        {
            _graphics = new GraphicsDeviceManager(this);
            _cfg = GameSettings.Load();
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.SynchronizeWithVerticalRetrace = _cfg.Vsync;
            _graphics.IsFullScreen = _cfg.Fullscreen;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            Window.Title = "Harvest Hollow";
            Window.AllowUserResizing = true;
        }

        protected override void Initialize()
        {
            _world = new World();
            _net = new NetSession(_world);
            _saveLoaded = SaveGame.Read(_world);
            _world.Screen = Screen.Title;
            _rain = new RainDrop[340];
            _splashes = new RainSplash[96];
            for (int i = 0; i < _rain.Length; i++)
                ResetDrop(ref _rain[i], true);
            ApplyGraphics();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _assets = new Assets();
            _assets.Load(GraphicsDevice);
            _font = new PixelFont(_assets.Pixel);
            _music = new PianoTheme();
            _music.Load();
            ApplyAudio();
            _thunder = BakeThunder();
            _pickup = BakePickup();
        }

        protected override void UnloadContent()
        {
            if (_music != null)
            {
                _music.Dispose();
                _music = null;
            }
            if (_thunder != null)
            {
                _thunder.Dispose();
                _thunder = null;
            }
            if (_pickup != null)
            {
                _pickup.Dispose();
                _pickup = null;
            }
            if (_net != null)
                _net.Stop();
            TrySaveValley();
            base.UnloadContent();
        }

        protected override void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
            _windTime += dt;
            if (_flash > 0f)
                _flash = Math.Max(0f, _flash - dt * 4.2f);
            if (_camShake > 0f)
                _camShake = Math.Max(0f, _camShake - dt * 2.8f);
            KeyboardState keys = Keyboard.GetState();
            MouseState mouse = Mouse.GetState();
            if (_net != null)
                _net.Tick(dt);

            if (_world.Screen != Screen.Loading && _world.ArriveBannerTimer > 0)
                _world.ArriveBannerTimer = Math.Max(0, _world.ArriveBannerTimer - dt);

            if (Pressed(keys, _cfg.MuteKey) && !_rebinding && _music != null)
            {
                _cfg.Mute = !_cfg.Mute;
                ApplyAudio();
                _cfg.Save();
                if (_world.Screen != Screen.Title)
                    _world.ShowToast(_cfg.Mute ? "Piano muted." : "Piano theme on.");
            }

            if (_rebinding && _world.Screen == Screen.Settings)
            {
                Keys captured = FirstPressedKey(keys);
                if (captured == Keys.Escape)
                    _rebinding = false;
                else if (captured != Keys.None)
                    FinishRebind(captured);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (Pressed(keys, Keys.Escape) || Pressed(keys, _cfg.SettingsKey))
            {
                if (_world.Screen == Screen.Settings)
                    CloseSettings();
                else if (_world.Screen == Screen.Create)
                    _world.Screen = Screen.Title;
                else if (_world.Screen == Screen.Skills)
                    _world.Screen = Screen.Play;
                else if (_world.Screen == Screen.Plan)
                {
                    // FinishFarmPlan runs in UpdateFarmPlan so Shop does not eat the same Esc.
                }
                else if (_world.Screen == Screen.MapEdit)
                {
                    // EndMapEdit runs in UpdateMapEdit so Admin does not eat the same Esc.
                }
                else if (_world.Screen == Screen.Play || _world.Screen == Screen.Title || _world.Screen == Screen.Help)
                    OpenSettings(_world.Screen);
                else if (_world.Screen != Screen.Loading && _world.Screen != Screen.Title)
                    _world.Screen = Screen.Play;
            }

            if (_world.Screen == Screen.Loading)
            {
                _world.TickLoading(dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Join)
            {
                UpdateJoin(keys, mouse, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Create)
            {
                UpdateCreate(keys, mouse, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Title)
            {
                int rows = TitleRows();
                if (_titleRow >= rows)
                    _titleRow = 0;
                if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                    _titleRow = (_titleRow + 1) % rows;
                if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                    _titleRow = (_titleRow + rows - 1) % rows;
                if (Pressed(keys, Keys.Enter) || Pressed(keys, _cfg.Use))
                    ChooseTitle();
                if (Clicked(mouse))
                {
                    if (TitleSettingsHit(mouse.X, mouse.Y, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height))
                        OpenSettings(Screen.Title);
                    else
                        ChooseTitle();
                }
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Sleep)
            {
                if (Pressed(keys, Keys.Enter) || Pressed(keys, _cfg.Interact))
                {
                    if (_net != null && _net.IsClient)
                        _net.SendAction(NetSession.ActSleep, null);
                    else
                    {
                        _world.AdvanceDay(false);
                        if (_net != null && _net.IsHost)
                            _net.RestEveryone();
                        TrySaveValley();
                    }
                    _world.WakeInCottage();
                    _world.Screen = Screen.Play;
                    _world.ShowToast("A new morning in Harvest Hollow.");
                }
                if (Pressed(keys, Keys.Escape) || Pressed(keys, Keys.N) || Pressed(keys, _cfg.SettingsKey))
                    _world.Screen = Screen.Play;
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Shop)
            {
                bool fishShop = _world.Inside != null && _world.Inside.Kind == BuildingKind.FishMarket;
                bool general = _world.Inside != null && _world.Inside.Kind == BuildingKind.GeneralStore;
                bool innBar = _world.Inside != null && _world.Inside.Kind == BuildingKind.Inn;
                bool carpenter = _world.Inside != null && _world.Inside.Kind == BuildingKind.Carpenter;
                bool animals = _world.Inside != null && _world.Inside.Kind == BuildingKind.AnimalShop;
                if (fishShop)
                {
                    if (Pressed(keys, Keys.Enter) || Pressed(keys, Keys.Space) || Pressed(keys, _cfg.Use))
                    {
                        if (_net != null && _net.IsClient)
                            _net.SendAction(NetSession.ActSellFish, null);
                        else
                            _world.SellAllFish();
                    }
                }
                else if (innBar)
                {
                    if (Pressed(keys, Keys.D1)) NetBuyDrink(0);
                    if (Pressed(keys, Keys.D2)) NetBuyDrink(1);
                    if (Pressed(keys, Keys.D3)) NetBuyDrink(2);
                    if (Pressed(keys, Keys.D4)) NetBuyDrink(3);
                }
                else if (carpenter)
                {
                    if (Pressed(keys, Keys.D1) || Pressed(keys, Keys.Enter) || Pressed(keys, _cfg.Use))
                        NetCraftPlank();
                    if (Pressed(keys, Keys.D2))
                        BeginFarmPlanFromAsh();
                    if (Pressed(keys, Keys.D3))
                        NetCraftMilkPail();
                    if (Pressed(keys, Keys.D4))
                        NetCraftShears();
                }
                else if (animals)
                {
                    if (Pressed(keys, Keys.D1)) NetBuyAnimal(0);
                    if (Pressed(keys, Keys.D2)) NetBuyAnimal(1);
                    if (Pressed(keys, Keys.D3)) NetBuyAnimal(2);
                    if (Pressed(keys, Keys.D4)) NetBuyAnimal(3);
                    if (Pressed(keys, Keys.D5)) NetBuyAnimal(4);
                    if (Pressed(keys, Keys.D6)) NetBuyAnimal(5);
                }
                else
                {
                    if (Pressed(keys, Keys.D1)) NetBuySeed(0);
                    if (Pressed(keys, Keys.D2)) NetBuySeed(1);
                    if (Pressed(keys, Keys.D3)) NetBuySeed(2);
                    if (Pressed(keys, Keys.D4)) NetBuySeed(3);
                    if (Pressed(keys, Keys.D5)) NetBuySeed(4);
                    if (general)
                    {
                        if (Pressed(keys, Keys.D6)) NetBuyFood(0);
                        if (Pressed(keys, Keys.D7)) NetBuyFood(1);
                        if (Pressed(keys, Keys.D8)) NetBuyFood(2);
                        if (Pressed(keys, Keys.D9))
                        {
                            if (_net != null && _net.IsClient)
                                _net.SendAction(NetSession.ActUpgrade, null);
                            else
                                _world.BuyPackUpgrade();
                        }
                    }
                }
                if (Pressed(keys, Keys.Escape) || Pressed(keys, _cfg.Interact) || Pressed(keys, _cfg.SettingsKey))
                    _world.Screen = Screen.Play;
                _prevKeys = keys;
                _prevMouse = mouse;
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Plan)
            {
                UpdateFarmPlan(keys, mouse, dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.MapEdit)
            {
                UpdateMapEdit(keys, mouse, dt, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                _prevKeys = keys;
                _prevMouse = mouse;
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                base.Update(gameTime);
                return;
            }

            if (Pressed(keys, Keys.F4)
                && _world.Screen != Screen.Title
                && _world.Screen != Screen.Create
                && _world.Screen != Screen.Join
                && _world.Screen != Screen.Loading
                && _world.Screen != Screen.Settings)
            {
                if (_world.Screen == Screen.Admin)
                    _world.Screen = Screen.Play;
                else
                    OpenAdmin();
            }
            if (_world.Screen == Screen.Admin)
            {
                UpdateAdmin(keys, mouse, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (Pressed(keys, _cfg.Bag))
            {
                if (_world.Screen == Screen.Bag)
                    _world.Screen = Screen.Play;
                else if (_world.Screen == Screen.Play || _world.Screen == Screen.Help || _world.Screen == Screen.Skills)
                    _world.Screen = Screen.Bag;
                CancelDrag();
            }
            if (Pressed(keys, Keys.K))
            {
                if (_world.Screen == Screen.Skills)
                    _world.Screen = Screen.Play;
                else if (_world.Screen == Screen.Play || _world.Screen == Screen.Help || _world.Screen == Screen.Bag)
                    _world.Screen = Screen.Skills;
            }
            if (Pressed(keys, _cfg.Help) || Pressed(keys, Keys.OemQuestion) || Pressed(keys, Keys.F1))
                _world.Screen = _world.Screen == Screen.Help ? Screen.Play : Screen.Help;
            if (Pressed(keys, Keys.F3)
                && _world.Screen != Screen.Title
                && _world.Screen != Screen.Create
                && _world.Screen != Screen.Join
                && _world.Screen != Screen.Loading)
            {
                _world.InfiniteEnergy = !_world.InfiniteEnergy;
                if (_world.InfiniteEnergy)
                    _world.Energy = GameConst.MaxEnergy;
                _world.ShowToast(_world.InfiniteEnergy ? "Infinite energy on." : "Infinite energy off.");
            }

            if (_world.Screen == Screen.Help)
            {
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Settings)
            {
                UpdateSettings(keys, mouse, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            int vw = GraphicsDevice.Viewport.Width;
            int vh = GraphicsDevice.Viewport.Height;
            bool overUi = HandleInventoryMouse(mouse, vw, vh);
            if (Clicked(mouse) && HudMenuHit(mouse.X, mouse.Y, vw, vh))
            {
                OpenSettings(Screen.Play);
                overUi = true;
            }

            for (int i = 0; i < _world.Bar.Length; i++)
            {
                Keys digit = Keys.D1 + i;
                if (Pressed(keys, digit))
                    _world.Selected = i;
            }

            if (_world.Screen == Screen.Skills)
            {
                if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                    _skillRow = (_skillRow + 1) % SkillSet.Count;
                if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                    _skillRow = (_skillRow + 2) % SkillSet.Count;
                if (Pressed(keys, Keys.Enter) || Pressed(keys, _cfg.Use))
                    NetSpendSkill(_skillRow);
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            if (_world.Screen == Screen.Bag)
            {
                if (Pressed(keys, Keys.C))
                {
                    if (keys.IsKeyDown(Keys.LeftShift) || keys.IsKeyDown(Keys.RightShift))
                        NetCraftPlank();
                    else
                        NetCraftFence();
                }
                if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                    _skillRow = (_skillRow + 1) % SkillSet.Count;
                if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                    _skillRow = (_skillRow + 2) % SkillSet.Count;
                if (Pressed(keys, Keys.Enter))
                    NetSpendSkill(_skillRow);
                if (!_dragging && Clicked(mouse))
                {
                    int hit = HitBagSkill(mouse.X, mouse.Y, vw, vh);
                    if (hit >= 0)
                    {
                        _skillRow = hit;
                        NetSpendSkill(hit);
                    }
                }
                _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
                _prevKeys = keys;
                _prevMouse = mouse;
                base.Update(gameTime);
                return;
            }

            Vector2 move = Vector2.Zero;
            if (keys.IsKeyDown(_cfg.MoveLeft) || keys.IsKeyDown(Keys.Left)) move.X -= 1;
            if (keys.IsKeyDown(_cfg.MoveRight) || keys.IsKeyDown(Keys.Right)) move.X += 1;
            if (keys.IsKeyDown(_cfg.MoveUp) || keys.IsKeyDown(Keys.Up)) move.Y -= 1;
            if (keys.IsKeyDown(_cfg.MoveDown) || keys.IsKeyDown(Keys.Down)) move.Y += 1;
            if (move.LengthSquared() > 0 && !_dragging)
            {
                move.Normalize();
                if (Math.Abs(move.X) > Math.Abs(move.Y))
                    _world.Dir = move.X < 0 ? 1 : 2;
                else
                    _world.Dir = move.Y < 0 ? 3 : 0;
                Vector2 next = _world.PlayerPos + move * GameConst.PlayerSpeed * dt;
                if (!_world.Blocked(next.X, _world.PlayerPos.Y))
                    _world.PlayerPos.X = next.X;
                if (!_world.Blocked(_world.PlayerPos.X, next.Y))
                    _world.PlayerPos.Y = next.Y;
                _world.Moving = true;
                _world.Anim += dt;
            }
            else
                _world.Moving = false;

            _world.UpdateZone();
            _world.CheckDoors(dt);

            Point hover = ScreenToTile(mouse.X, mouse.Y);
            float dist = Math.Abs(hover.X - _world.PlayerPos.X / GameConst.Tile) + Math.Abs(hover.Y - _world.PlayerPos.Y / GameConst.Tile);
            if (dist <= 2.5f)
                _world.Face = hover;
            else
                _world.Face = FacingTile();

            _world.Hint = HintFor(_world.Face.X, _world.Face.Y);

            if (Pressed(keys, Keys.C))
            {
                if (keys.IsKeyDown(Keys.LeftShift) || keys.IsKeyDown(Keys.RightShift))
                    NetCraftPlank();
                else
                    NetCraftFence();
            }

            if (Pressed(keys, _cfg.Interact))
            {
                TileType it = _world.TileAt(_world.Face.X, _world.Face.Y);
                if (_net != null && _net.IsClient)
                {
                    if (it == TileType.Bin)
                        _net.SendAction(NetSession.ActShip, null);
                    else if (it == TileType.Fence)
                    {
                        _net.SendAction(NetSession.ActInteract, w =>
                        {
                            w.Write(_world.Face.X);
                            w.Write(_world.Face.Y);
                        });
                    }
                    else
                    {
                        _net.SendAction(NetSession.ActInteract, w =>
                        {
                            w.Write(_world.Face.X);
                            w.Write(_world.Face.Y);
                        });
                        if (it != TileType.Bin)
                            _world.Interact(_world.Face.X, _world.Face.Y);
                    }
                }
                else
                    _world.Interact(_world.Face.X, _world.Face.Y);
            }

            bool use = !overUi && !_dragging && (Pressed(keys, _cfg.Use) || (Clicked(mouse) && dist <= 2.5f));
            if (use && _world.ActionLock <= 0)
            {
                if (_net != null && _net.IsClient)
                {
                    _net.SendAction(NetSession.ActUse, w =>
                    {
                        w.Write(_world.Face.X);
                        w.Write(_world.Face.Y);
                    });
                    ItemDef held = _world.HeldItem();
                    string kind = "hoe";
                    if (held != null && held.Kind == ItemKind.Seed) kind = "plant";
                    else if (held != null && held.Tool == ToolId.Can) kind = "water";
                    else if (held != null && held.Tool == ToolId.Axe) kind = "chop";
                    else if (held != null && held.Tool == ToolId.Pickaxe) kind = "pick";
                    else if (held != null && held.Tool == ToolId.Sword) kind = "slash";
                    else if (held != null && held.Tool == ToolId.Scythe) kind = "scythe";
                    else if (held != null && held.Tool == ToolId.Rod) kind = "fish";
                    else if (held != null && held.Tool == ToolId.MilkPail) kind = "milk";
                    else if (held != null && held.Tool == ToolId.Shears) kind = "shear";
                    else if (held != null && held.Kind == ItemKind.Food) kind = "eat";
                    else if (held != null && held.Kind == ItemKind.Placeable) kind = "plant";
                    _world.BeginSwing(kind);
                    _world.ActionLock = _world.Swinging ? _world.SwingDur : 0.12f;
                }
                else
                {
                    string act = _world.UseTool(_world.Face.X, _world.Face.Y);
                    _world.BeginSwing(act);
                    _world.ActionLock = _world.Swinging ? _world.SwingDur : 0.12f;
                }
            }
            _world.ActionLock = Math.Max(0, _world.ActionLock - dt);
            _world.TickSwing(dt);
            TickToolFx(dt);
            TickLeaves(dt);
            TickFallingTrees(dt);
            if (_net == null || !_net.IsClient)
            {
                if (_net != null && _net.IsHost)
                    _net.FillCaveGuests();
                else
                    _world.CaveGuests.Clear();
                int day = _world.Day;
                _world.TickTime(dt);
                if (_net != null && _net.IsHost && _world.Day != day)
                    _net.RestEveryone();
                if (_world.Day != day)
                    TrySaveValley();
            }
            if (_world.Screen == Screen.Play && (_net == null || !_net.IsClient))
            {
                _saveAcc += dt;
                if (_saveAcc >= 20f)
                {
                    _saveAcc = 0f;
                    TrySaveValley();
                }
            }
            _world.ToastTimer = Math.Max(0, _world.ToastTimer - dt);
            if (_world.PickupCue)
            {
                _world.PickupCue = false;
                PlayPickup();
            }

            if (_net != null && _net.IsClient)
            {
                _inputSend += dt;
                if (_inputSend >= 0.05f)
                {
                    _inputSend = 0f;
                    _net.SendInput(_world);
                }
            }

            UpdateRain(dt);
            UpdateStorm(dt);

            _prevKeys = keys;
            _prevMouse = mouse;
            base.Update(gameTime);
        }

        private bool HandleInventoryMouse(MouseState mouse, int vw, int vh)
        {
            bool bag = _world.Screen == Screen.Bag;
            SlotLoc over = HitSlot(mouse.X, mouse.Y, vw, vh, bag);
            bool onUi = over.Valid || bag;
            if (Clicked(mouse))
            {
                if (over.Valid)
                {
                    InvSlot slot = _world.SlotAt(over);
                    if (over.Bar)
                        _world.Selected = over.Index;
                    if (slot != null && !slot.Empty)
                    {
                        _dragFrom = over;
                        _dragging = true;
                        _dragMoved = false;
                        _dragStart = new Point(mouse.X, mouse.Y);
                    }
                    return true;
                }
                if (bag)
                    return true;
            }

            if (_dragging)
            {
                int dx = mouse.X - _dragStart.X;
                int dy = mouse.Y - _dragStart.Y;
                if (dx * dx + dy * dy > 36)
                    _dragMoved = true;
                if (mouse.LeftButton == ButtonState.Released && _prevMouse.LeftButton == ButtonState.Pressed)
                {
                    if (_dragMoved && over.Valid)
                    {
                        _world.MoveItem(_dragFrom, over);
                        if (_net != null && _net.IsClient)
                        {
                            SlotLoc a = _dragFrom;
                            SlotLoc b = over;
                            _net.SendAction(NetSession.ActMoveItem, w =>
                            {
                                w.Write(a.Bar);
                                w.Write(a.Index);
                                w.Write(b.Bar);
                                w.Write(b.Index);
                            });
                        }
                        if (over.Bar)
                            _world.Selected = over.Index;
                    }
                    CancelDrag();
                    return true;
                }
                return true;
            }

            return onUi && mouse.LeftButton == ButtonState.Pressed;
        }

        private void CancelDrag()
        {
            _dragging = false;
            _dragMoved = false;
            _dragFrom = SlotLoc.None;
        }

        private SlotLoc HitSlot(int mx, int my, int vw, int vh, bool includePack)
        {
            int barY = vh - 70;
            for (int i = 0; i < _world.Bar.Length; i++)
            {
                int sx = HudBarX + i * HudGap;
                if (mx >= sx && mx < sx + HudSlot && my >= barY && my < barY + HudSlot)
                    return SlotLoc.BarAt(i);
            }
            if (!includePack)
                return SlotLoc.None;
            int gridX, gridY;
            PackOrigin(vw, vh, out gridX, out gridY);
            int step = PackSlot + PackGap;
            for (int i = 0; i < _world.PackOpen; i++)
            {
                int col = i % GameConst.PackCols;
                int row = i / GameConst.PackCols;
                int sx = gridX + col * step;
                int sy = gridY + row * step;
                if (mx >= sx && mx < sx + PackSlot && my >= sy && my < sy + PackSlot)
                    return SlotLoc.PackAt(i);
            }
            return SlotLoc.None;
        }

        private void PackOrigin(int vw, int vh, out int gridX, out int gridY)
        {
            int panelX, panelY, panelW, panelH;
            BagLayout(vw, vh, out panelX, out panelY, out panelW, out panelH, out gridX, out gridY);
        }

        private void BagLayout(int vw, int vh, out int panelX, out int panelY, out int panelW, out int panelH, out int gridX, out int gridY)
        {
            int rows = _world.PackRowsOpen;
            int gridW = GameConst.PackCols * PackSlot + (GameConst.PackCols - 1) * PackGap;
            int gridH = rows * PackSlot + (rows - 1) * PackGap;
            panelW = 300;
            panelH = gridH + 118;
            if (panelH < 430)
                panelH = 430;
            int gap = 16;
            int satchelW = gridW + 48;
            int total = panelW + gap + satchelW;
            int left = (vw - total) / 2;
            if (left < 12)
                left = 12;
            panelX = left;
            gridX = left + panelW + gap + 24;
            gridY = vh / 2 - gridH / 2 - 24;
            panelY = gridY - 72;
            if (panelY + panelH > vh - 86)
                panelY = vh - 86 - panelH;
            if (panelY < 8)
                panelY = 8;
        }

        private int HitBagSkill(int mx, int my, int vw, int vh)
        {
            int panelX, panelY, panelW, panelH, gridX, gridY;
            BagLayout(vw, vh, out panelX, out panelY, out panelW, out panelH, out gridX, out gridY);
            int y0 = panelY + 236;
            for (int i = 0; i < SkillSet.Count; i++)
            {
                int y = y0 + i * 48;
                if (mx >= panelX + 12 && mx < panelX + panelW - 12 && my >= y && my < y + 44)
                    return i;
            }
            return -1;
        }

        private void DrawItemInSlot(InvSlot slot, int sx, int sy, int size, bool dim)
        {
            if (slot == null || slot.Empty)
                return;
            Texture2D icon = _assets.ItemIcon(slot.Id);
            int pad = size / 5;
            Color tint = dim ? new Color(255, 255, 255, 90) : Color.White;
            _spriteBatch.Draw(icon, new Rectangle(sx + pad, sy + pad, size - pad * 2, size - pad * 2), tint);
            ItemDef def = ItemCatalog.Find(slot.Id);
            string qty = "";
            if (def != null && def.Id == "can")
                qty = _world.CanWater.ToString();
            else if (def != null && def.Stackable && slot.Count > 0)
                qty = slot.Count.ToString();
            if (qty.Length > 0)
                _font.Draw(_spriteBatch, qty, sx + size - 4 - _font.Measure(qty, 1), sy + size - 12, Color.White, 1);
        }

        private bool Pressed(KeyboardState keys, Keys key)
        {
            return keys.IsKeyDown(key) && _prevKeys.IsKeyUp(key);
        }

        private void OpenSettings(Screen from)
        {
            _settingsBack = from == Screen.Settings ? Screen.Play : from;
            _world.Screen = Screen.Settings;
            _setRow = 0;
            _rebinding = false;
        }

        private void CloseSettings()
        {
            _rebinding = false;
            _cfg.Save();
            if (_settingsBack == Screen.Title)
                TrySaveValley();
            _world.Screen = _settingsBack == Screen.Title ? Screen.Title : Screen.Play;
        }

        private bool SettingsShowsMenuExit()
        {
            return _settingsBack != Screen.Title;
        }

        private void SettingsPanel(int vw, int vh, out int px, out int py, out int panelW, out int panelH)
        {
            panelW = 920;
            panelH = SettingsShowsMenuExit() ? 600 : 540;
            px = vw / 2 - panelW / 2;
            py = vh / 2 - panelH / 2;
        }

        private bool IsMenuExitRow(int row)
        {
            return SettingsShowsMenuExit() && row == SettingsRowCount() - 1;
        }

        private void ReturnToMainMenu()
        {
            _rebinding = false;
            _cfg.Save();
            TrySaveValley();
            if (_net != null)
                _net.Stop();
            _world.Screen = Screen.Title;
            _settingsBack = Screen.Title;
            _titleRow = 0;
        }

        private void ApplyGraphics()
        {
            try
            {
                _graphics.SynchronizeWithVerticalRetrace = _cfg.Vsync;
                _graphics.IsFullScreen = _cfg.Fullscreen;
                _graphics.ApplyChanges();
            }
            catch
            {
                _cfg.Fullscreen = false;
            }
        }

        private void ApplyAudio()
        {
            if (_music == null)
                return;
            _music.SetUserVolume(_cfg.Music / 100f);
            _music.SetMuted(_cfg.Mute);
        }

        private int SettingsRowCount()
        {
            int extra = SettingsShowsMenuExit() ? 1 : 0;
            if (_setTab == SettingsTab.Graphics) return 6 + extra;
            if (_setTab == SettingsTab.Audio) return 4 + extra;
            return 11 + extra;
        }

        private void UpdateSettings(KeyboardState keys, MouseState mouse, int vw, int vh)
        {
            if (Pressed(keys, Keys.Tab))
            {
                int t = (int)_setTab;
                if (keys.IsKeyDown(Keys.LeftShift) || keys.IsKeyDown(Keys.RightShift))
                    t = (t + 2) % 3;
                else
                    t = (t + 1) % 3;
                _setTab = (SettingsTab)t;
                _setRow = 0;
            }
            if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                _setRow = (_setRow + SettingsRowCount() - 1) % SettingsRowCount();
            if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                _setRow = (_setRow + 1) % SettingsRowCount();
            if (Pressed(keys, Keys.Left) || Pressed(keys, Keys.A))
                NudgeSetting(-1);
            if (Pressed(keys, Keys.Right) || Pressed(keys, Keys.D))
                NudgeSetting(1);
            if (Pressed(keys, Keys.Enter) || Pressed(keys, Keys.Space))
                ActivateSetting(1);

            if (Clicked(mouse))
                ClickSettings(mouse.X, mouse.Y, vw, vh);
        }

        private void ClickSettings(int mx, int my, int vw, int vh)
        {
            int panelW, panelH, px, py;
            SettingsPanel(vw, vh, out px, out py, out panelW, out panelH);
            int tabY = py + 70;
            for (int i = 0; i < 3; i++)
            {
                int tx = px + 40 + i * 220;
                if (mx >= tx && mx < tx + 200 && my >= tabY && my < tabY + 36)
                {
                    _setTab = (SettingsTab)i;
                    _setRow = 0;
                    return;
                }
            }

            int row0 = py + 130;
            int rows = SettingsRowCount();
            for (int i = 0; i < rows; i++)
            {
                int ry = row0 + i * 34;
                if (my < ry || my >= ry + 32)
                    continue;
                _setRow = i;
                if (_setTab == SettingsTab.Audio && (i == 0 || i == 1))
                {
                    int barX = px + 420;
                    int barW = 280;
                    if (mx >= barX && mx <= barX + barW)
                    {
                        int val = (int)((mx - barX) / (float)barW * 100f);
                        if (val < 0) val = 0;
                        if (val > 100) val = 100;
                        if (i == 0) _cfg.Music = val;
                        else _cfg.Sfx = val;
                        ApplyAudio();
                        _cfg.Save();
                    }
                    else
                        NudgeSetting(1);
                    return;
                }
                ActivateSetting(1);
                return;
            }
        }

        private void NudgeSetting(int dir)
        {
            if (IsMenuExitRow(_setRow))
            {
                ReturnToMainMenu();
                return;
            }
            if (_setTab == SettingsTab.Graphics)
            {
                if (_setRow == 0)
                {
                    _cfg.Zoom += dir;
                    if (_cfg.Zoom < 2) _cfg.Zoom = 4;
                    if (_cfg.Zoom > 4) _cfg.Zoom = 2;
                }
                else if (_setRow == 1)
                    _cfg.Fullscreen = !_cfg.Fullscreen;
                else if (_setRow == 2)
                    _cfg.Vsync = !_cfg.Vsync;
                else if (_setRow == 3)
                    _cfg.Shake = !_cfg.Shake;
                else if (_setRow == 4)
                {
                    _cfg.Rain += dir;
                    if (_cfg.Rain < 0) _cfg.Rain = 2;
                    if (_cfg.Rain > 2) _cfg.Rain = 0;
                }
                else
                    _cfg.Reset();
                if (_setRow == 1 || _setRow == 2 || _setRow == 5)
                    ApplyGraphics();
                ApplyAudio();
                _cfg.Save();
                return;
            }
            if (_setTab == SettingsTab.Audio)
            {
                if (_setRow == 0)
                    _cfg.Music = Math.Max(0, Math.Min(100, _cfg.Music + dir * 5));
                else if (_setRow == 1)
                    _cfg.Sfx = Math.Max(0, Math.Min(100, _cfg.Sfx + dir * 5));
                else if (_setRow == 2)
                    _cfg.Mute = !_cfg.Mute;
                else
                    _cfg.Reset();
                ApplyAudio();
                _cfg.Save();
                return;
            }
            if (_setRow >= 10)
            {
                _cfg.Reset();
                ApplyGraphics();
                ApplyAudio();
                _cfg.Save();
                return;
            }
            _rebinding = true;
        }

        private void ActivateSetting(int dir)
        {
            if (IsMenuExitRow(_setRow))
            {
                ReturnToMainMenu();
                return;
            }
            if (_setTab == SettingsTab.Controls && _setRow < 10)
            {
                _rebinding = true;
                return;
            }
            NudgeSetting(dir);
        }

        private void FinishRebind(Keys key)
        {
            BindId id = (BindId)_setRow;
            if (_cfg.BindTaken(id, key))
            {
                _world.ShowToast("That key is already bound.");
                _rebinding = false;
                return;
            }
            _cfg.SetBind(id, key);
            _rebinding = false;
            _cfg.Save();
        }

        private Keys FirstPressedKey(KeyboardState keys)
        {
            Array values = Enum.GetValues(typeof(Keys));
            for (int i = 0; i < values.Length; i++)
            {
                Keys key = (Keys)values.GetValue(i);
                if (key == Keys.None || key == Keys.LeftWindows || key == Keys.RightWindows)
                    continue;
                if (Pressed(keys, key))
                    return key;
            }
            return Keys.None;
        }

        private bool TitleSettingsHit(int mx, int my, int vw, int vh)
        {
            string line = "ESC SETTINGS";
            int w = _font.Measure(line, 3);
            int x = vw / 2 - w / 2;
            int y = vh / 2 + 28;
            return mx >= x - 12 && mx < x + w + 12 && my >= y - 4 && my < y + 28;
        }

        private void DrawSettings(int vw, int vh)
        {
            int panelW, panelH, px, py;
            SettingsPanel(vw, vh, out px, out py, out panelW, out panelH);
            Fill(0, 0, vw, vh, new Color(10, 8, 14, 150));
            Panel(px, py, panelW, panelH);
            string title = "SETTINGS";
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, py + 24, new Color(232, 197, 71), 3);
            string[] tabs = { "GRAPHICS", "AUDIO", "CONTROLS" };
            int tabY = py + 70;
            for (int i = 0; i < 3; i++)
            {
                int tx = px + 40 + i * 220;
                bool on = (int)_setTab == i;
                Fill(tx, tabY, 200, 36, on ? new Color(61, 42, 31) : new Color(32, 24, 20));
                DrawRect(tx, tabY, 200, 36, on ? new Color(232, 197, 71) : new Color(139, 94, 60));
                int tw = _font.Measure(tabs[i], 2);
                _font.Draw(_spriteBatch, tabs[i], tx + 100 - tw / 2, tabY + 10, on ? new Color(244, 228, 166) : Color.White, 2);
            }

            int row0 = py + 130;
            int rows = SettingsRowCount();
            for (int i = 0; i < rows; i++)
            {
                int ry = row0 + i * 34;
                bool sel = i == _setRow;
                if (IsMenuExitRow(i))
                {
                    int bx = px + 220;
                    int bw = panelW - 440;
                    Fill(bx, ry - 4, bw, 32, sel ? new Color(72, 48, 34) : new Color(42, 32, 28));
                    DrawRect(bx, ry - 4, bw, 32, sel ? new Color(232, 197, 71) : new Color(139, 94, 60));
                    string menu = "BACK TO MAIN MENU";
                    _font.Draw(_spriteBatch, menu, vw / 2 - _font.Measure(menu, 2) / 2, ry + 4, sel ? new Color(244, 228, 166) : Color.White, 2);
                    continue;
                }
                if (sel)
                    Fill(px + 28, ry - 4, panelW - 56, 32, new Color(61, 42, 31, 180));
                string left;
                string right;
                SettingRowText(i, out left, out right);
                _font.Draw(_spriteBatch, left, px + 48, ry + 4, sel ? new Color(244, 228, 166) : Color.White, 2);
                if (_setTab == SettingsTab.Audio && (i == 0 || i == 1))
                {
                    int val = i == 0 ? _cfg.Music : _cfg.Sfx;
                    int barX = px + 420;
                    int barW = 280;
                    Fill(barX, ry + 8, barW, 12, new Color(61, 42, 31));
                    Fill(barX, ry + 8, barW * val / 100, 12, new Color(126, 192, 106));
                    DrawRect(barX, ry + 8, barW, 12, new Color(196, 165, 116));
                    _font.Draw(_spriteBatch, val.ToString() + "%", barX + barW + 16, ry + 4, Color.White, 2);
                }
                else
                {
                    Color rc = (_rebinding && sel) ? new Color(232, 197, 71) : new Color(196, 165, 116);
                    _font.Draw(_spriteBatch, right, px + 420, ry + 4, rc, 2);
                }
            }

            string foot = _rebinding
                ? "Press a key to bind. ESC cancels."
                : (SettingsShowsMenuExit()
                    ? "ARROWS move   ENTER/CLICK change   TAB tabs   ESC resume"
                    : "ARROWS move   ENTER/CLICK change   TAB tabs   ESC back");
            _font.Draw(_spriteBatch, foot, vw / 2 - _font.Measure(foot, 2) / 2, py + panelH - 40, new Color(196, 165, 116), 2);
        }

        private void SettingRowText(int row, out string left, out string right)
        {
            left = "";
            right = "";
            if (IsMenuExitRow(row))
            {
                left = "Back to main menu";
                right = "";
                return;
            }
            if (_setTab == SettingsTab.Graphics)
            {
                if (row == 0) { left = "Zoom"; right = _cfg.Zoom.ToString() + "x"; }
                else if (row == 1) { left = "Fullscreen"; right = _cfg.Fullscreen ? "ON" : "OFF"; }
                else if (row == 2) { left = "Vertical sync"; right = _cfg.Vsync ? "ON" : "OFF"; }
                else if (row == 3) { left = "Camera shake"; right = _cfg.Shake ? "ON" : "OFF"; }
                else if (row == 4)
                {
                    left = "Rain detail";
                    right = _cfg.Rain <= 0 ? "LOW" : (_cfg.Rain == 1 ? "MEDIUM" : "HIGH");
                }
                else { left = "Restore defaults"; right = ""; }
                return;
            }
            if (_setTab == SettingsTab.Audio)
            {
                if (row == 0) { left = "Music"; right = ""; }
                else if (row == 1) { left = "Sound"; right = ""; }
                else if (row == 2) { left = "Mute music"; right = _cfg.Mute ? "ON" : "OFF"; }
                else { left = "Restore defaults"; right = ""; }
                return;
            }
            if (row >= 10)
            {
                left = "Restore defaults";
                right = "";
                return;
            }
            BindId id = (BindId)row;
            left = GameSettings.BindLabel(id);
            if (_rebinding && row == _setRow)
                right = "PRESS A KEY";
            else
            {
                right = GameSettings.KeyName(_cfg.GetBind(id));
                if (id == BindId.MoveUp || id == BindId.MoveDown || id == BindId.MoveLeft || id == BindId.MoveRight)
                    right += "  (ARROWS TOO)";
            }
        }

        private bool Clicked(MouseState mouse)
        {
            return mouse.LeftButton == ButtonState.Pressed && _prevMouse.LeftButton == ButtonState.Released;
        }

        private Point FacingTile()
        {
            int ox = 0, oy = 0;
            if (_world.Dir == 0) oy = 1;
            if (_world.Dir == 1) ox = -1;
            if (_world.Dir == 2) ox = 1;
            if (_world.Dir == 3) oy = -1;
            return new Point(
                (int)Math.Floor((_world.PlayerPos.X + ox * 20) / GameConst.Tile),
                (int)Math.Floor((_world.PlayerPos.Y + oy * 20) / GameConst.Tile));
        }

        private Point ScreenToTile(int mx, int my)
        {
            float wx = mx / (float)Scale + _cam.X;
            float wy = my / (float)Scale + _cam.Y;
            return new Point((int)Math.Floor(wx / GameConst.Tile), (int)Math.Floor(wy / GameConst.Tile));
        }

        private string HintFor(int tx, int ty)
        {
            if (!_world.ZoneLit(tx, ty))
                return "The next place is dark until you walk in.";
            string road = _world.RoadHint(tx, ty);
            if (road != null)
                return road;
            TileType t = _world.TileAt(tx, ty);
            if (t == TileType.Tree)
                return TreeSpecies.Hint(TreeSpecies.KindAt(tx, ty));
            if (t == TileType.Stump)
                return "A stump. The tree fell here.";
            if (t == TileType.Rock)
            {
                ItemDef held = _world.HeldItem();
                if (held != null && held.Tool == ToolId.Pickaxe)
                    return "Space - Mine stone";
                return "Stone. Mine it with a pickaxe.";
            }
            if (t == TileType.Shell)
                return "E - Pick up the " + BeachForage.ShellNameAt(tx, ty).ToLowerInvariant();
            if (t == TileType.Seaweed)
                return "E - Pick up the seaweed";
            if (t == TileType.Bridge)
                return "A small wooden bridge.";
            if (t == TileType.Cliff)
                return "A stone drop. The lip hangs over the face.";
            if (t == TileType.Mineral)
            {
                ItemDef held = _world.HeldItem();
                if (held != null && held.Tool == ToolId.Pickaxe)
                    return "Space - Mine the mineral vein";
                return "A mineral vein. Mine it with a pickaxe.";
            }
            if (t == TileType.Dummy)
                return "Space - Train Attack on the dummy";
            if (t == TileType.Hay)
            {
                ItemDef heldHay = _world.HeldItem();
                if (heldHay != null && heldHay.Tool == ToolId.Scythe)
                    return "Space - Cut hay";
                return "A hayfield. Cut it with the scythe, then store it in the silo.";
            }
            if (t == TileType.HayCut)
                return "Hay stubble. It grows back with time.";
            if (_world.Inside == null)
            {
                Building silo = _world.SiloAt(tx, ty);
                if (silo != null)
                    return "E - Store hay or take hay (" + _world.HayInSilo.ToString()
                        + "/" + GameConst.SiloCapacity.ToString() + ")";
            }
            if (t == TileType.Door)
            {
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Cave)
                {
                    if (_world.Inside.IsCaveDeepDoor(_world.InsideFloor, tx, ty))
                    {
                        if (_world.InsideFloor >= CaveGen.Levels - 1)
                            return "The last door. The hollow goes no deeper.";
                        return "E - Descend to depth " + (_world.InsideFloor + 2).ToString();
                    }
                    if (_world.InsideFloor <= 0)
                        return "E - Leave the cave";
                    return "E - Climb toward the mouth";
                }
                Building doorB = _world.HouseAtDoor(tx, ty);
                if (_world.Inside != null)
                    return "E - Leave";
                if (doorB != null && doorB.Kind == BuildingKind.Cave)
                    return "E - Enter the cave";
                if (doorB != null && doorB.Kind == BuildingKind.Silo)
                    return "E - Store hay or take hay (" + _world.HayInSilo.ToString()
                        + "/" + GameConst.SiloCapacity.ToString() + ")";
                if (doorB != null && doorB.NeedsRepair)
                {
                    return "E - Repair with " + doorB.RepairPlanks.ToString() + " planks (have "
                        + _world.CountItem("plank").ToString() + ")";
                }
                return "E - Walk inside";
            }
            if (t == TileType.Chest)
                return _world.CaveChestLooted(tx, ty) ? "An empty stone chest." : "E - Open the chest";
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Cave)
            {
                CaveTroll near = _world.TrollNear(_world.PlayerPos, 56f);
                if (near != null)
                {
                    string who = CaveMobCatalog.Name(near.Kind);
                    ItemDef heldSword = _world.HeldItem();
                    if (heldSword != null && heldSword.Tool == ToolId.Sword)
                        return "Space - Strike the " + who;
                    return "A " + who + ". Equip the sword from your satchel.";
                }
            }
            if (t == TileType.Bed) return "E - Sleep until morning";
            if (t == TileType.Stairs)
                return _world.InsideFloor == 0 ? "E - Go upstairs" : "E - Go downstairs";
            if (t == TileType.Counter)
            {
                if (_world.Inside != null && _world.Inside.IsResidence)
                    return "A kitchen counter.";
                if (_world.Inside != null && _world.Inside.FurnishAt(tx, ty) == FurnishKind.Stove)
                    return "A wood stove.";
                if (_world.Inside != null && _world.Inside.FurnishAt(tx, ty) == FurnishKind.Keg)
                    return "A tapped keg. The cedar still smells.";
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Inn)
                    return "E - Mira's bar (drinks)";
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.FishMarket)
                    return "E - Sell fish to Finn";
                if (_world.Inside != null && _world.Inside.FurnishAt(tx, ty) == FurnishKind.Fridge)
                    return "A cold case. You can see the stock through the glass.";
                if (_world.Inside != null && _world.Inside.FurnishAt(tx, ty) == FurnishKind.Shelf)
                    return "An aisle of jars, cans, and seed packets.";
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Carpenter)
                    return "E - Ash mills planks, crafts a milk pail or shears, or marks a new site for farm buildings";
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.AnimalShop)
                    return "E - Bess sells livestock";
                if (_world.Inside != null && _world.Inside.Kind == BuildingKind.GeneralStore)
                    return "E - Piper's counter (food, seeds, satchel)";
                return "E - Rowan the seed merchant";
            }
            if (t == TileType.Bin) return "E - Ship crops overnight";
            if (t == TileType.Fence)
            {
                ItemDef held = _world.HeldItem();
                if (held != null && held.Id == "fence")
                    return "Space - Place another fence beside it";
                return "E - Pack up the fence";
            }
            if (_world.Inside == null)
            {
                FarmAnimal stock = _world.AnimalAtTile(tx, ty);
                if (stock != null)
                {
                    ItemDef heldStock = _world.HeldItem();
                    if (stock.Kind == AnimalKind.Cow)
                    {
                        if (heldStock != null && AnimalCatalog.IsLivestock(heldStock.Id))
                            return "E - Call the cow back into the bag";
                        if (!_world.HasMilkPail())
                            return "Need a milk pail.";
                        if (stock.MilkedToday)
                            return "Already milked today.";
                        return "E  milk";
                    }
                    if (stock.Kind == AnimalKind.Sheep)
                    {
                        if (heldStock != null && AnimalCatalog.IsLivestock(heldStock.Id))
                            return "E - Call the sheep back into the bag";
                        if (!_world.HasShears())
                            return "Need shears.";
                        if (!stock.HasWool)
                            return "Wool growing back.";
                        return "E  shear";
                    }
                    return "E - Call the " + AnimalCatalog.Name(stock.Kind).ToLowerInvariant() + " back into the bag";
                }
            }
            ItemDef animalHand = _world.HeldItem();
            if (animalHand != null && AnimalCatalog.IsLivestock(animalHand.Id))
                return "Space - Set the " + animalHand.Name.ToLowerInvariant() + " on the pasture";
            if (t == TileType.Dock)
                return "Weathered planks over the tide. Cast from the edge.";
            if (t == TileType.Water)
            {
                ItemDef held = _world.HeldItem();
                if (held != null && held.Tool == ToolId.Rod)
                    return _world.OutdoorZone == "Saltwind Beach" ? "Space - Cast into the sea" : "Only the sea holds saltwater fish";
                if (GameConst.InMoonveil(tx, ty))
                    return "A still pool. Moonlight lives in it. E - Fill watering can";
                return "E - Fill watering can";
            }
            Crop crop;
            if (_world.Crops.TryGetValue(_world.CropKey(tx, ty), out crop))
            {
                CropDef def = CropCatalog.Find(crop.Id);
                string name = def != null ? def.Name : crop.Id;
                return name + "  stage " + crop.Stage + (crop.Watered ? "  watered" : "  thirsty");
            }
            ItemDef hand = _world.HeldItem();
            if (hand != null && hand.Id == "fence")
                return "Space - Plant a fence";
            if (hand != null && hand.Id == "plank")
                return "E a ruined farm building to spend planks on repairs";
            if (hand != null && hand.Id == "wood")
                return "C - Fence (1 wood)   Shift+C - Plank (10 wood)";
            return "";
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(_world.Inside != null ? InteriorClear(_world.Inside) : Color.Black);
            int vw = GraphicsDevice.Viewport.Width;
            int vh = GraphicsDevice.Viewport.Height;

            if (_world.Screen == Screen.Join)
            {
                DrawJoin(vw, vh);
                base.Draw(gameTime);
                return;
            }

            if (_world.Screen == Screen.Create)
            {
                DrawCreate(vw, vh);
                base.Draw(gameTime);
                return;
            }

            if (_world.Screen == Screen.Title || (_world.Screen == Screen.Settings && _settingsBack == Screen.Title))
            {
                DrawTitle(vw, vh);
                if (_world.Screen == Screen.Settings)
                {
                    _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
                    DrawSettings(vw, vh);
                    _spriteBatch.End();
                }
                base.Draw(gameTime);
                return;
            }

            float targetX = _world.PlayerPos.X - vw / (float)Scale / 2f;
            float targetY = _world.PlayerPos.Y - vh / (float)Scale / 2f;
            if (_world.Screen == Screen.Plan)
            {
                float farmPx = GameConst.FarmOx * GameConst.Tile;
                float farmPy = GameConst.FarmOy * GameConst.Tile;
                float farmW = (GameConst.MapW - GameConst.FarmOx) * GameConst.Tile;
                float farmH = GameConst.FarmH * GameConst.Tile;
                targetX = farmPx + farmW * 0.5f - vw / (float)Scale / 2f;
                targetY = farmPy + farmH * 0.5f - vh / (float)Scale / 2f;
            }
            else if (_world.Screen == Screen.MapEdit)
            {
                targetX = _editCam.X;
                targetY = _editCam.Y;
            }
            bool snapCam = Math.Abs(targetX - _cam.X) > 120 || Math.Abs(targetY - _cam.Y) > 120
                || (_world.Screen == Screen.Loading && _world.LoadApplied);
            if (snapCam)
            {
                _cam.X = targetX;
                _cam.Y = targetY;
            }
            else
            {
                _cam.X += (targetX - _cam.X) * 0.18f;
                _cam.Y += (targetY - _cam.Y) * 0.18f;
            }

            float shakeX = 0f, shakeY = 0f;
            if (_camShake > 0.01f && _cfg.Shake)
            {
                shakeX = (float)(_rng.NextDouble() * 2.0 - 1.0) * _camShake * 2.4f;
                shakeY = (float)(_rng.NextDouble() * 2.0 - 1.0) * _camShake * 1.8f;
            }
            Matrix cam = Matrix.CreateTranslation(-(int)(_cam.X + shakeX), -(int)(_cam.Y + shakeY), 0) * Matrix.CreateScale(Scale);
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, null, null, null, cam);

            int cols = _world.PlayCols;
            int rows = _world.PlayRows;
            int t0x = Math.Max(0, (int)_cam.X / GameConst.Tile - 1);
            int t0y = Math.Max(0, (int)_cam.Y / GameConst.Tile - 1);
            int t1x = Math.Min(cols, (int)(_cam.X + vw / Scale) / GameConst.Tile + 2);
            int t1y = Math.Min(rows, (int)(_cam.Y + vh / Scale) / GameConst.Tile + 2);

            for (int ty = t0y; ty < t1y; ty++)
            {
                for (int tx = t0x; tx < t1x; tx++)
                    DrawTile(tx, ty, _world.Minutes);
            }

            for (int ty = t0y; ty < t1y; ty++)
            {
                for (int tx = t0x; tx < t1x; tx++)
                    DrawOverlay(tx, ty);
            }

            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Greenhouse)
                DrawGreenhouseInsideBack();

            int frame = Characters.Pose(_world.Moving, _world.Anim, _world.Swinging, _world.SwingU);
            float playerSort = _world.PlayerPos.Y;
            if (_world.Inside == null)
            {
                DrawTrees(true, playerSort, t0x, t0y, t1x, t1y);
                DrawHouses(true, playerSort);
                DrawBridges(true, playerSort);
                DrawGates(true, playerSort);
                DrawDecos(true, playerSort);
                DrawTownsfolk(true, playerSort);
            }
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Shop)
                DrawPerson(_assets.Rowan, _world.Inside.Iw / 2, 3, true, playerSort);
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Inn && _world.InsideFloor == 0)
                DrawPerson(_assets.Mira, 5, 2, true, playerSort);
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.FishMarket)
                DrawPerson(_assets.Finn, _world.Inside.Iw / 2, 3, true, playerSort);
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.GeneralStore)
                DrawPerson(_assets.Piper, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, true, playerSort);
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Carpenter)
                DrawPerson(_assets.Ash, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, true, playerSort);
            else if (_world.Inside != null && _world.Inside.Kind == BuildingKind.AnimalShop)
                DrawPerson(_assets.Bess, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, true, playerSort);
            DrawTrolls(true, playerSort);
            DrawAnimals(true, playerSort);
            DrawPeers(true, playerSort);
            if (_world.Screen != Screen.Plan && _world.Screen != Screen.MapEdit)
                DrawFarmer(frame, NetSession.Tint(_net != null ? _net.LocalSlot : 0));
            if (_world.Inside == null)
            {
                DrawHouses(false, playerSort);
                DrawBridges(false, playerSort);
                DrawGates(false, playerSort);
                DrawDecos(false, playerSort);
                DrawTrees(false, playerSort, t0x, t0y, t1x, t1y);
                DrawTownsfolk(false, playerSort);
            }
            else if (_world.Inside.Kind == BuildingKind.Shop)
                DrawPerson(_assets.Rowan, _world.Inside.Iw / 2, 3, false, playerSort);
            else if (_world.Inside.Kind == BuildingKind.Inn && _world.InsideFloor == 0)
                DrawPerson(_assets.Mira, 5, 2, false, playerSort);
            else if (_world.Inside.Kind == BuildingKind.FishMarket)
                DrawPerson(_assets.Finn, _world.Inside.Iw / 2, 3, false, playerSort);
            else if (_world.Inside.Kind == BuildingKind.GeneralStore)
                DrawPerson(_assets.Piper, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, false, playerSort);
            else if (_world.Inside.Kind == BuildingKind.Carpenter)
                DrawPerson(_assets.Ash, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, false, playerSort);
            else if (_world.Inside.Kind == BuildingKind.AnimalShop)
                DrawPerson(_assets.Bess, _world.Inside.NpcX >= 0 ? _world.Inside.NpcX : _world.Inside.Iw / 2,
                    _world.Inside.NpcY >= 0 ? _world.Inside.NpcY : 3, false, playerSort);
            DrawTrolls(false, playerSort);
            DrawAnimals(false, playerSort);
            DrawPeers(false, playerSort);

            if (_world.Screen == Screen.Plan)
                DrawFarmPlanGhost();
            else if (_world.Screen == Screen.MapEdit)
                DrawMapEditWorld(t0x, t0y, t1x, t1y);
            else if (_world.ZoneLit(_world.Face.X, _world.Face.Y))
            {
                DrawRect(_world.Face.X * GameConst.Tile, _world.Face.Y * GameConst.Tile, GameConst.Tile, 1, new Color(255, 244, 180, 200));
                DrawRect(_world.Face.X * GameConst.Tile, _world.Face.Y * GameConst.Tile + GameConst.Tile - 1, GameConst.Tile, 1, new Color(255, 244, 180, 200));
                DrawRect(_world.Face.X * GameConst.Tile, _world.Face.Y * GameConst.Tile, 1, GameConst.Tile, new Color(255, 244, 180, 200));
                DrawRect(_world.Face.X * GameConst.Tile + GameConst.Tile - 1, _world.Face.Y * GameConst.Tile, 1, GameConst.Tile, new Color(255, 244, 180, 200));
            }

            DrawToolFx();
            DrawLeaves();
            DrawLightning();
            DrawDayOverlay();
            DrawRain();
            DrawStormFlash();
            _spriteBatch.End();

            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
            DrawHud(vw, vh);
            if (_world.Screen == Screen.Shop) DrawShop(vw, vh);
            if (_world.Screen == Screen.Sleep) DrawSleep(vw, vh);
            if (_world.Screen == Screen.Help) DrawHelp(vw, vh);
            if (_world.Screen == Screen.Bag) DrawBag(vw, vh);
            if (_world.Screen == Screen.Skills) DrawSkills(vw, vh);
            if (_world.Screen == Screen.Settings) DrawSettings(vw, vh);
            if (_world.Screen == Screen.Admin) DrawAdmin(vw, vh);
            if (_world.Screen == Screen.MapEdit) DrawMapEditHud(vw, vh);
            DrawDragGhost();
            DrawToast(vw, vh);
            if (_world.Screen == Screen.Loading)
                DrawLoadFade(vw, vh);
            _spriteBatch.End();

            base.Draw(gameTime);
        }

        private void DrawTile(int tx, int ty, float minutes)
        {
            int x = tx * GameConst.Tile;
            int y = ty * GameConst.Tile;
            if (!_world.ZoneLit(tx, ty))
            {
                Fill(x, y, GameConst.Tile, GameConst.Tile, Color.Black);
                return;
            }
            TileType t = _world.TileAt(tx, ty);
            if (t == TileType.InvisibleWall)
                t = TileType.Grass;
            if (t == TileType.Path || t == TileType.Bin || (t == TileType.Door && _world.Inside == null)
                || t == TileType.Fence || t == TileType.Dock || t == TileType.Bridge)
                _spriteBatch.Draw(t == TileType.Bridge
                    ? _assets.WaterAt(tx, ty, minutes)
                    : _assets.Underlay(tx, ty), new Vector2(x, y), Color.White);
            if (t == TileType.Bridge)
                _spriteBatch.Draw(_assets.BridgeTile(_world, tx, ty), new Vector2(x, y), Color.White);
            else
            {
                if (t == TileType.Counter && _world.Inside != null
                    && _world.Inside.FurnishAt(tx, ty) == FurnishKind.Fridge)
                    _spriteBatch.Draw(_assets.Ground(TileType.HouseFloor, tx, ty, minutes, _world.Inside, _world),
                        new Vector2(x, y), Color.White);
                Texture2D ground = _assets.Ground(t, tx, ty, minutes, _world.Inside, _world);
                if (t == TileType.Door && _world.InteriorDoorOpen)
                    ground = _world.Inside != null
                        ? _assets.InteriorDoorOf(_world.Inside, true)
                        : _assets.DoorOpen;
                _spriteBatch.Draw(ground, new Vector2(x, y), Color.White);
            }
        }

        private static bool IsRaisedGround(TileType t)
        {
            return t == TileType.Grass || t == TileType.WoodsGrass || t == TileType.Tree
                || t == TileType.Flower || t == TileType.Weed || t == TileType.Stump
                || t == TileType.Dummy || t == TileType.Mountain
                || t == TileType.Hay || t == TileType.HayCut;
        }

        private static bool IsLowGround(TileType t)
        {
            return t == TileType.Path || t == TileType.Cobble || t == TileType.FarmSoil
                || t == TileType.Tilled || t == TileType.Wet || t == TileType.Sand
                || t == TileType.Shell || t == TileType.Seaweed
                || t == TileType.Water || t == TileType.Dock || t == TileType.Bridge
                || t == TileType.Bin;
        }

        private void DrawGroundEdges(int tx, int ty, TileType t)
        {
            if (_world.Inside != null)
                return;
            if (t == TileType.Mountain)
            {
                DrawMountainLips(tx, ty);
                return;
            }
            if (!IsRaisedGround(t))
                return;
            if (_assets.Pack.UsesWangEdges(_world, tx, ty))
                return;
            int x = tx * GameConst.Tile;
            int y = ty * GameConst.Tile;
            Texture2D[] edge = _assets.GrassEdge;
            if (WantsGroundEdge(_world.TileAt(tx, ty - 1)))
                _spriteBatch.Draw(edge[0], new Vector2(x, y), Color.White);
            if (WantsGroundEdge(_world.TileAt(tx + 1, ty)))
                _spriteBatch.Draw(edge[1], new Vector2(x, y), Color.White);
            if (WantsGroundEdge(_world.TileAt(tx, ty + 1)))
                _spriteBatch.Draw(edge[2], new Vector2(x, y), Color.White);
            if (WantsGroundEdge(_world.TileAt(tx - 1, ty)))
                _spriteBatch.Draw(edge[3], new Vector2(x, y), Color.White);
        }

        // Stone lips hang off the plateau onto roads, lawns, water, and cliff faces.
        // Lawn-to-path still uses a thin GrassEdge, not Wang cliff autotiles.
        private static bool WantsGroundEdge(TileType n)
        {
            return IsLowGround(n);
        }

        private static bool IsMountainDrop(TileType n)
        {
            return n == TileType.Path || n == TileType.Grass || n == TileType.WoodsGrass
                || n == TileType.Sand || n == TileType.Water || n == TileType.Bridge
                || n == TileType.Cliff || n == TileType.Cobble || n == TileType.FarmSoil
                || n == TileType.Tilled || n == TileType.Wet || n == TileType.Dock
                || n == TileType.Bin || n == TileType.Flower || n == TileType.Weed
                || n == TileType.Dummy || n == TileType.Stump;
        }

        private void DrawMountainLips(int tx, int ty)
        {
            int x = tx * GameConst.Tile;
            int y = ty * GameConst.Tile;
            int v = (tx * 5 + ty * 3) & 3;
            const int rim = 6;
            const int sideRim = 5;
            if (IsMountainDrop(_world.TileAt(tx, ty - 1)))
            {
                Texture2D n = _assets.MountainNorthDrop[v];
                _spriteBatch.Draw(n, new Vector2(x, y - (n.Height - rim)), Color.White);
            }
            if (IsMountainDrop(_world.TileAt(tx - 1, ty)))
            {
                Texture2D w = _assets.MountainWestDrop[v];
                _spriteBatch.Draw(w, new Vector2(x - (w.Width - sideRim), y), Color.White);
            }
            if (IsMountainDrop(_world.TileAt(tx + 1, ty)))
            {
                Texture2D e = _assets.MountainEastDrop[v];
                _spriteBatch.Draw(e, new Vector2(x + GameConst.Tile - sideRim, y), Color.White);
            }
            if (IsMountainDrop(_world.TileAt(tx, ty + 1)))
            {
                Texture2D s = _assets.MountainSouthDrop[v];
                _spriteBatch.Draw(s, new Vector2(x, y + GameConst.Tile - rim), Color.White);
            }
        }

        private void DrawOverlay(int tx, int ty)
        {
            if (!_world.ZoneLit(tx, ty))
                return;
            int x = tx * GameConst.Tile;
            int y = ty * GameConst.Tile;
            TileType t = _world.TileAt(tx, ty);
            DrawGroundEdges(tx, ty, t);
            if (t == TileType.Stump)
                _spriteBatch.Draw(_assets.Stump, new Vector2(x, y), Color.White);
            if (t == TileType.Rock)
                _spriteBatch.Draw(_assets.Rock, new Vector2(x, y), Color.White);
            if (t == TileType.Mineral)
                _spriteBatch.Draw(_assets.Mineral, new Vector2(x, y), Color.White);
            if ((t == TileType.Cliff || t == TileType.Mountain) && _world.TileAt(tx, ty + 1) == TileType.Water)
                _spriteBatch.Draw(_assets.CliffFoam, new Vector2(x, y + GameConst.Tile - _assets.CliffFoam.Height), Color.White);
            if (t == TileType.Water && GameConst.InMoonveil(tx, ty))
            {
                float glow = 0.40f + 0.22f * (float)Math.Sin(_world.Minutes * 0.11f + tx * 0.7f + ty);
                Fill(x + 3, y + 3, 26, 26, new Color(168, 198, 255, (int)(glow * 88)));
                Fill(x + 10, y + 10, 12, 12, new Color(220, 232, 255, (int)(glow * 50)));
            }
            if (t == TileType.Rock && GameConst.InMoonveil(tx, ty))
            {
                float halo = 0.30f + 0.18f * (float)Math.Sin(_world.Minutes * 0.09f + tx + ty);
                Fill(x + 8, y + 6, 16, 10, new Color(186, 204, 255, (int)(halo * 55)));
            }
            if (t == TileType.Water && ty >= GameConst.BeachOy)
            {
                Color foam = new Color(220, 242, 246, 180);
                if (IsBeachShore(_world.TileAt(tx, ty - 1)))
                    Fill(x, y, GameConst.Tile, 5, foam);
                if (IsBeachShore(_world.TileAt(tx, ty + 1)))
                    Fill(x, y + GameConst.Tile - 4, GameConst.Tile, 4, foam);
                if (IsBeachShore(_world.TileAt(tx - 1, ty)))
                    Fill(x, y, 4, GameConst.Tile, foam);
                if (IsBeachShore(_world.TileAt(tx + 1, ty)))
                    Fill(x + GameConst.Tile - 4, y, 4, GameConst.Tile, foam);
            }
            if (t == TileType.Dummy)
                _spriteBatch.Draw(_assets.Dummy, new Vector2(x, y), Color.White);
            if (t == TileType.Dock)
                DrawDockPilings(tx, ty, x, y);
            if (t == TileType.Flower)
            {
                if (_world.Inside != null && _world.Inside.Kind != BuildingKind.Cave)
                    _spriteBatch.Draw(_assets.IndoorPlant, new Vector2(x, y), Color.White);
                else
                {
                    bool woods = GameConst.InDeepForest(tx, ty);
                    Texture2D fl = woods ? _assets.Mushroom : _assets.Flower;
                    float phase = tx * 0.91f + ty * 1.37f;
                    DrawSwaying(fl, x, y + 4, 1f, 1f, phase, woods ? 0.22f : 1f);
                    if (GameConst.InMoonveil(tx, ty) && t == TileType.Flower)
                    {
                        float glow = 0.45f + 0.25f * (float)Math.Sin(_world.Minutes * 0.08f + phase);
                        Fill(x + 10, y + 12, 6, 6, new Color(186, 214, 255, (int)(glow * 70)));
                    }
                }
            }
            if (t == TileType.Shell)
            {
                Texture2D sh = _assets.Shells[BeachForage.ShellKindAt(tx, ty)];
                _spriteBatch.Draw(sh, new Vector2(x, y + 6), Color.White);
            }
            if (t == TileType.Seaweed)
            {
                float phase = tx * 0.6f + ty * 1.1f;
                DrawSwaying(_assets.Seaweed, x, y + 4, 1f, 1f, phase, 0.55f);
            }
            if (t == TileType.Weed)
                _spriteBatch.Draw(_assets.Weed, new Vector2(x, y + 4), Color.White);
            if (t == TileType.Hay)
            {
                Texture2D hay = _assets.HayReady[(tx * 3 + ty * 5) & 3];
                float phase = tx * 0.73f + ty * 1.11f;
                DrawSwaying(hay, x, y + 2, 1f, 1f, phase, 0.7f);
            }
            if (t == TileType.HayCut)
            {
                Texture2D stub = _assets.HayStubble[(tx + ty) & 1];
                _spriteBatch.Draw(stub, new Vector2(x, y + 6), Color.White);
            }
            if (t == TileType.Bed
                && _world.TileAt(tx - 1, ty) != TileType.Bed
                && _world.TileAt(tx, ty - 1) != TileType.Bed)
                _spriteBatch.Draw(_assets.Bed, new Vector2(x, y), Color.White);
            if (_world.Inside != null && _world.InsideFloor == 0)
            {
                FurnishKind fk = _world.Inside.FurnishAt(tx, ty);
                if (fk == FurnishKind.Table)
                    _spriteBatch.Draw(_assets.Table, new Vector2(x, y), Color.White);
            }
            if (t == TileType.Bin && _world.TileAt(tx - 1, ty) != TileType.Bin)
                _spriteBatch.Draw(_assets.Bin, new Vector2(x - 2, y - 16), Color.White);
            if (t == TileType.Chest)
            {
                Texture2D chest = _world.CaveChestLooted(tx, ty) ? _assets.ChestOpen : _assets.Chest;
                _spriteBatch.Draw(chest, new Vector2(x, y + GameConst.Tile - chest.Height), Color.White);
            }

            Crop crop;
            if (_world.Crops.TryGetValue(_world.CropKey(tx, ty), out crop))
            {
                CropDef def = CropCatalog.Find(crop.Id);
                Texture2D[] frames;
                if (def != null && _assets.CropFrames.TryGetValue(crop.Id, out frames))
                {
                    int fi = crop.Stage <= 1 ? 0 : (crop.Stage < def.Days ? 1 : 2);
                    _spriteBatch.Draw(frames[fi], new Vector2(x, y), Color.White);
                    if (crop.Stage >= def.Days)
                        Fill(x + 4, y + 4, 24, 24, new Color(255, 220, 80, 70));
                }
            }
        }

        private void DrawDockPilings(int tx, int ty, int x, int y)
        {
            Texture2D p = _assets.DockPiling;
            int tw = GameConst.Tile;
            bool south = _world.TileAt(tx, ty + 1) == TileType.Water;
            bool east = _world.TileAt(tx + 1, ty) == TileType.Water;
            bool west = _world.TileAt(tx - 1, ty) == TileType.Water;
            bool corner = (south && (east || west)) || (east && west);
            if (south && (corner || (tx & 1) == 0))
                _spriteBatch.Draw(p, new Vector2(x + (tw - p.Width) / 2, y + tw - 3), Color.White);
            if (east && (corner || (ty & 1) == 0))
                _spriteBatch.Draw(p, new Vector2(x + tw - p.Width + 1, y + 8), Color.White);
            if (west && (corner || (ty & 1) == 1))
                _spriteBatch.Draw(p, new Vector2(x - 1, y + 8), Color.White);
        }

        private static bool IsBeachShore(TileType t)
        {
            return t == TileType.Sand || t == TileType.Path || t == TileType.Flower
                || t == TileType.Rock || t == TileType.Stump || t == TileType.Shell
                || t == TileType.Seaweed || t == TileType.Dock;
        }

        private void DrawDayOverlay()
        {
            float m = _world.Minutes;
            float shade = 0;
            if (m < 6 * 60) shade = 0.45f;
            else if (m < 8 * 60) shade = 0.2f * (1f - (m - 360f) / 120f);
            else if (m > 20 * 60) shade = Math.Min(0.5f, (m - 1200f) / 240f);
            if (_world.Raining) shade += 0.10f;
            if (_world.Storming) shade += 0.16f;
            int ptx = (int)Math.Floor(_world.PlayerPos.X / GameConst.Tile);
            int pty = (int)Math.Floor(_world.PlayerPos.Y / GameConst.Tile);
            if (_world.Inside != null)
                shade = _world.Storming ? 0.18f : 0.12f;
            else
            {
                if (GameConst.InMoonveil(ptx, pty))
                    shade += 0.34f;
                else if (InWoods(ptx, pty)) shade += 0.22f;
                else if (GameConst.InSummit(ptx, pty)) shade += 0.10f;
            }
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Cave)
                shade = 0.38f;
            int ox = (int)_cam.X;
            int oy = (int)_cam.Y;
            int ow = (int)(GraphicsDevice.Viewport.Width / Scale) + 8;
            int oh = (int)(GraphicsDevice.Viewport.Height / Scale) + 8;
            if (shade > 0)
            {
                Color dusk = GameConst.InMoonveil(ptx, pty) && _world.Inside == null
                    ? new Color(28, 36, 62, (int)(shade * 255))
                    : new Color(48, 42, 40, (int)(shade * 255));
                Fill(ox, oy, ow, oh, dusk);
            }
            DrawFireflies();
            if (_world.Raining && _world.Inside == null)
                Fill(ox, oy, ow, oh, new Color(56, 62, 72, _world.Storming ? 64 : 40));
        }

        private void DrawFireflies()
        {
            if (_world.Inside != null)
                return;
            int ptx = (int)Math.Floor(_world.PlayerPos.X / GameConst.Tile);
            int pty = (int)Math.Floor(_world.PlayerPos.Y / GameConst.Tile);
            if (!GameConst.InMoonveil(ptx, pty) || !_world.ZoneLit(ptx, pty))
                return;
            float dt = 0.016f;
            if (_rng.NextDouble() < 0.35)
            {
                Firefly f = _flies[_flyAt];
                f.Pos = _world.PlayerPos + new Vector2(_rng.Next(220) - 110, _rng.Next(140) - 90);
                f.Phase = (float)_rng.NextDouble() * 6.2f;
                f.Max = 1.8f + (float)_rng.NextDouble() * 2.2f;
                f.Life = f.Max;
                f.Alive = true;
                _flies[_flyAt] = f;
                _flyAt = (_flyAt + 1) % _flies.Length;
            }
            for (int i = 0; i < _flies.Length; i++)
            {
                if (!_flies[i].Alive)
                    continue;
                _flies[i].Life -= dt;
                if (_flies[i].Life <= 0f)
                {
                    _flies[i].Alive = false;
                    continue;
                }
                _flies[i].Phase += dt * 2.4f;
                _flies[i].Pos.X += (float)Math.Sin(_flies[i].Phase) * 12f * dt;
                _flies[i].Pos.Y += (float)Math.Cos(_flies[i].Phase * 1.3f) * 8f * dt;
                float u = _flies[i].Life / _flies[i].Max;
                float pulse = 0.45f + 0.55f * (0.5f + 0.5f * (float)Math.Sin(_flies[i].Phase * 3f));
                int a = (int)(u * pulse * 220);
                Color c = (_rng.Next(3) == 0)
                    ? new Color(210, 236, 255, a)
                    : new Color(232, 214, 120, a);
                _spriteBatch.Draw(_assets.Pixel, _flies[i].Pos, null, c, 0f, Vector2.Zero, 2.2f, SpriteEffects.None, 0f);
            }
        }

        private void RainView(out float x, out float y, out float w, out float h)
        {
            w = GraphicsDevice.Viewport.Width / (float)Scale + 96f;
            h = GraphicsDevice.Viewport.Height / (float)Scale + 96f;
            x = _world.PlayerPos.X - w * 0.5f;
            y = _world.PlayerPos.Y - h * 0.5f;
        }

        private void ResetDrop(ref RainDrop d, bool scatter)
        {
            float vx, vy, vw, vh;
            RainView(out vx, out vy, out vw, out vh);
            d.Speed = 280f + _rng.Next(220);
            d.Wind = -78f - _rng.Next(70);
            d.Length = 8f + _rng.Next(12);
            d.Alpha = (byte)(72 + _rng.Next(140));
            d.Width = _rng.NextDouble() < 0.22 ? 2f : 1.1f;
            if (_world.Storming)
            {
                d.Speed += 90f + _rng.Next(80);
                d.Wind -= 30f + _rng.Next(40);
                d.Length += 3 + _rng.Next(6);
                d.Alpha = (byte)Math.Min(255, d.Alpha + 40);
                d.Width = _rng.NextDouble() < 0.4 ? 2.2f : 1.3f;
            }
            d.Pos.X = vx + (float)_rng.NextDouble() * vw;
            if (scatter)
                d.Pos.Y = vy + (float)_rng.NextDouble() * vh;
            else
                d.Pos.Y = vy - d.Length - _rng.Next(40);
            d.HitY = d.Pos.Y + 28f + _rng.Next(Math.Max(40, (int)vh));
        }

        private void SpawnSplash(float x, float y)
        {
            _splashes[_splashAt].Pos = new Vector2(x, y);
            _splashes[_splashAt].Age = 0f;
            _splashes[_splashAt].Life = 0.10f + (float)_rng.NextDouble() * 0.12f;
            _splashes[_splashAt].Alive = true;
            _splashAt = (_splashAt + 1) % _splashes.Length;
        }

        private void UpdateRain(float dt)
        {
            if (!_world.Raining)
                return;

            float vx, vy, vw, vh;
            RainView(out vx, out vy, out vw, out vh);
            float gust = RainGust();
            float mapW = GameConst.MapW * GameConst.Tile;
            float mapH = GameConst.MapH * GameConst.Tile;
            for (int i = 0; i < RainCount; i++)
            {
                _rain[i].Pos.X += _rain[i].Wind * gust * dt;
                _rain[i].Pos.Y += _rain[i].Speed * dt;
                bool hit = _rain[i].Pos.Y >= _rain[i].HitY;
                bool off = _rain[i].Pos.Y > vy + vh || _rain[i].Pos.X < vx - 12f || _rain[i].Pos.X > vx + vw + 12f;
                if (hit)
                {
                    if (_rain[i].Pos.X >= 0 && _rain[i].Pos.X < mapW && _rain[i].HitY >= 0 && _rain[i].HitY < mapH)
                        SpawnSplash(_rain[i].Pos.X, _rain[i].HitY);
                    ResetDrop(ref _rain[i], false);
                }
                else if (off)
                    ResetDrop(ref _rain[i], true);
            }

            for (int i = 0; i < _splashes.Length; i++)
            {
                if (!_splashes[i].Alive)
                    continue;
                _splashes[i].Age += dt;
                if (_splashes[i].Age >= _splashes[i].Life)
                    _splashes[i].Alive = false;
            }
        }

        private float RainGust()
        {
            float g = 1f + 0.22f * (float)Math.Sin(_windTime * 1.35f);
            if (_world.Storming)
                g += 0.28f + 0.22f * (float)Math.Sin(_windTime * 3.4f);
            return g;
        }

        private float WindStrength()
        {
            if (_world.Inside != null)
                return 0.12f;
            if (_world.Storming)
                return 1.55f;
            return _world.Raining ? 1f : 0.34f;
        }

        /// <summary>
        /// Westward rain wind (same sign as RainDrop.Wind). Positive rotation is clockwise.
        /// </summary>
        private float WindDirSign()
        {
            return -1f;
        }

        private void DrawSwaying(Texture2D tex, float left, float top, float scaleX, float scaleY, float phase, float ampMul)
        {
            DrawSwaying(tex, new Rectangle(0, 0, tex.Width, tex.Height), left, top, scaleX, scaleY, phase, ampMul, Color.White);
        }

        private void DrawSwaying(Texture2D tex, Rectangle src, float left, float top, float scaleX, float scaleY, float phase, float ampMul)
        {
            DrawSwaying(tex, src, left, top, scaleX, scaleY, phase, ampMul, Color.White);
        }

        private void DrawSwaying(Texture2D tex, Rectangle src, float left, float top, float scaleX, float scaleY, float phase, float ampMul, Color tint)
        {
            float wind = WindStrength();
            float wave = (float)Math.Sin(_windTime * 1.85f + phase);
            float gust = (float)Math.Sin(_windTime * 3.1f + phase * 0.5f);
            float rest = _world.Raining && _world.Inside == null ? 0.35f : 0f;
            float amp = (0.05f + 0.11f * wind) * ampMul;
            float rot = WindDirSign() * amp * (rest + wave * 0.75f + gust * 0.25f);
            Vector2 origin = new Vector2(src.Width * 0.5f, src.Height);
            Vector2 pos = new Vector2(left + src.Width * 0.5f * scaleX, top + src.Height * scaleY);
            _spriteBatch.Draw(tex, pos, src, tint, rot, origin, new Vector2(scaleX, scaleY), SpriteEffects.None, 0f);
        }

        private void DrawRain()
        {
            if (!_world.Raining || _world.Inside != null)
                return;

            float gust = RainGust();
            for (int i = 0; i < RainCount; i++)
            {
                int rtx = (int)_rain[i].Pos.X / GameConst.Tile;
                int rty = (int)_rain[i].Pos.Y / GameConst.Tile;
                if (!_world.ZoneLit(rtx, rty))
                    continue;
                float angle = (float)Math.Atan2(_rain[i].Wind * gust, _rain[i].Speed);
                float tailX = _rain[i].Pos.X + (float)Math.Sin(angle) * _rain[i].Length;
                float tailY = _rain[i].Pos.Y + (float)Math.Cos(angle) * _rain[i].Length;
                if (!_world.ZoneLit((int)tailX / GameConst.Tile, (int)tailY / GameConst.Tile))
                    continue;
                Color streak = Premul(new Color(188, 216, 255, (int)_rain[i].Alpha));
                float width = _rain[i].Width > 0.5f ? _rain[i].Width : 1.15f;
                _spriteBatch.Draw(_assets.Pixel, _rain[i].Pos, null, streak, angle, new Vector2(0.5f, 0f),
                    new Vector2(width, _rain[i].Length), SpriteEffects.None, 0f);
            }

            for (int i = 0; i < _splashes.Length; i++)
            {
                if (!_splashes[i].Alive)
                    continue;
                int stx = (int)_splashes[i].Pos.X / GameConst.Tile;
                int sty = (int)_splashes[i].Pos.Y / GameConst.Tile;
                if (!_world.ZoneLit(stx, sty))
                    continue;
                float t = _splashes[i].Age / _splashes[i].Life;
                int alpha = (int)((1f - t) * 190);
                int w = 2 + (int)(t * 7);
                int h = t < 0.35f ? 2 : 1;
                Fill((int)_splashes[i].Pos.X - w / 2, (int)_splashes[i].Pos.Y, w, h, new Color(198, 224, 255, alpha));
                if (t < 0.45f)
                    Fill((int)_splashes[i].Pos.X, (int)_splashes[i].Pos.Y - 1, 1, 2, new Color(224, 238, 255, alpha));
            }
        }

        private void UpdateStorm(float dt)
        {
            for (int i = 0; i < _bolts.Length; i++)
            {
                if (_bolts[i].Life > 0f)
                    _bolts[i].Life -= dt;
            }

            if (_thunderIn > 0f)
            {
                _thunderIn -= dt;
                if (_thunderIn <= 0f)
                    PlayThunder();
            }

            if (!_world.Raining || _world.Screen == Screen.Title)
                return;

            _nextBolt -= dt;
            if (_world.Storming && _nextBolt <= 0f)
            {
                StrikeLightning();
                _nextBolt = 3.2f + (float)_rng.NextDouble() * 8.5f;
            }
        }

        private void StrikeLightning()
        {
            _flash = _world.Inside != null ? 0.45f : 1f;
            _thunderIn = 0.12f + (float)_rng.NextDouble() * 0.95f;
            if (_world.Inside != null)
                return;

            float vx, vy, vw, vh;
            RainView(out vx, out vy, out vw, out vh);
            Vector2 start = new Vector2(vx + vw * (0.12f + (float)_rng.NextDouble() * 0.76f), vy - 8f);
            Vector2 end = new Vector2(
                start.X + ((float)_rng.NextDouble() - 0.5f) * 90f,
                vy + vh * (0.42f + (float)_rng.NextDouble() * 0.4f));
            _boltAt = (_boltAt + 1) % _bolts.Length;
            _bolts[_boltAt].Pts = ForkBolt(start, end, 9 + _rng.Next(6), 18f);
            _bolts[_boltAt].Life = 0.16f + (float)_rng.NextDouble() * 0.10f;
            _bolts[_boltAt].Max = _bolts[_boltAt].Life;

            if (_rng.NextDouble() < 0.55 && _bolts[_boltAt].Pts.Length > 4)
            {
                int mid = 2 + _rng.Next(_bolts[_boltAt].Pts.Length - 3);
                Vector2 b0 = _bolts[_boltAt].Pts[mid];
                Vector2 b1 = b0 + new Vector2(((float)_rng.NextDouble() - 0.5f) * 70f, 24f + _rng.Next(50));
                int other = (_boltAt + 1) % _bolts.Length;
                _bolts[other].Pts = ForkBolt(b0, b1, 5 + _rng.Next(4), 12f);
                _bolts[other].Life = _bolts[_boltAt].Life * 0.75f;
                _bolts[other].Max = _bolts[other].Life;
            }
        }

        private Vector2[] ForkBolt(Vector2 a, Vector2 b, int segs, float jag)
        {
            Vector2[] pts = new Vector2[segs + 1];
            pts[0] = a;
            pts[segs] = b;
            Vector2 n = b - a;
            float len = n.Length();
            if (len < 1f)
                len = 1f;
            n /= len;
            Vector2 perp = new Vector2(-n.Y, n.X);
            for (int i = 1; i < segs; i++)
            {
                float t = i / (float)segs;
                float fade = 1f - Math.Abs(t * 2f - 1f);
                float j = ((float)_rng.NextDouble() - 0.5f) * jag * (0.35f + fade);
                pts[i] = a + (b - a) * t + perp * j;
            }
            return pts;
        }

        private void DrawLightning()
        {
            if (_world.Inside != null)
                return;
            for (int b = 0; b < _bolts.Length; b++)
            {
                if (_bolts[b].Life <= 0f || _bolts[b].Pts == null || _bolts[b].Pts.Length < 2)
                    continue;
                float u = Math.Max(0f, _bolts[b].Life / Math.Max(0.001f, _bolts[b].Max));
                int alpha = (int)(255 * u);
                Color core = new Color(244, 248, 255, alpha);
                Color glow = new Color(170, 200, 255, (int)(140 * u));
                Vector2[] pts = _bolts[b].Pts;
                for (int i = 0; i < pts.Length - 1; i++)
                {
                    DrawBoltSeg(pts[i], pts[i + 1], glow, 2.2f);
                    DrawBoltSeg(pts[i], pts[i + 1], core, 1.1f);
                }
            }
        }

        private void DrawBoltSeg(Vector2 a, Vector2 b, Color c, float width)
        {
            Vector2 d = b - a;
            float len = d.Length();
            if (len < 0.4f)
                return;
            float ang = (float)Math.Atan2(d.Y, d.X);
            _spriteBatch.Draw(_assets.Pixel, a, null, Premul(c), ang, new Vector2(0f, 0.5f), new Vector2(len, width), SpriteEffects.None, 0f);
        }

        private void DrawStormFlash()
        {
            if (_flash <= 0.01f)
                return;
            int ox = (int)_cam.X;
            int oy = (int)_cam.Y;
            int ow = (int)(GraphicsDevice.Viewport.Width / Scale) + 8;
            int oh = (int)(GraphicsDevice.Viewport.Height / Scale) + 8;
            float a = Math.Clamp(_flash * (_world.Inside != null ? 0.35f : 0.55f), 0f, 1f);
            Fill(ox, oy, ow, oh, new Color(220, 232, 255, (int)(a * 70)));
        }

        private void PlayThunder()
        {
            if (_thunder == null || _cfg.Mute || _cfg.Sfx <= 0)
                return;
            if (_cfg.Shake)
                _camShake = 0.55f + (float)_rng.NextDouble() * 0.55f;
            try
            {
                float vol = (0.38f + (float)_rng.NextDouble() * 0.22f) * (_cfg.Sfx / 100f);
                float pitch = (float)(_rng.NextDouble() * 0.5 - 0.35);
                _thunder.Play(vol, pitch, (float)(_rng.NextDouble() * 0.5 - 0.25));
            }
            catch
            {
            }
        }

        private SoundEffect BakeThunder()
        {
            try
            {
                const int rate = 22050;
                int n = (int)(rate * 1.35);
                byte[] pcm = new byte[n * 4];
                float brown = 0f;
                for (int i = 0; i < n; i++)
                {
                    float t = i / (float)rate;
                    float crack = t < 0.08f ? (float)Math.Sin(t / 0.08f * Math.PI) : 0f;
                    float boom = t < 0.12f ? 0f : (float)Math.Exp(-(t - 0.12f) * 2.4);
                    float env = crack * 0.85f + boom * 0.7f;
                    float white = (float)_rng.NextDouble() * 2f - 1f;
                    brown = brown * 0.985f + white * 0.015f;
                    float rumble = (float)Math.Sin(t * 38f) * 0.12f * boom;
                    float s = Math.Max(-1f, Math.Min(1f, (brown * 3.2f + rumble) * env));
                    short v = (short)(s * 22000);
                    int o = i * 4;
                    pcm[o] = (byte)(v & 0xff);
                    pcm[o + 1] = (byte)((v >> 8) & 0xff);
                    short r = (short)(v * 0.92f);
                    if (i > 180)
                    {
                        int d = (i - 180) * 4;
                        r = (short)((short)(pcm[d] | (pcm[d + 1] << 8)) * 0.85f);
                    }
                    pcm[o + 2] = (byte)(r & 0xff);
                    pcm[o + 3] = (byte)((r >> 8) & 0xff);
                }
                return new SoundEffect(pcm, rate, AudioChannels.Stereo);
            }
            catch
            {
                return null;
            }
        }

        private void PlayPickup()
        {
            if (_pickup == null || _cfg.Mute || _cfg.Sfx <= 0)
                return;
            try
            {
                float vol = 0.42f * (_cfg.Sfx / 100f);
                _pickup.Play(vol, 0.15f, 0f);
            }
            catch
            {
            }
        }

        private SoundEffect BakePickup()
        {
            try
            {
                const int rate = 22050;
                int n = (int)(rate * 0.16);
                byte[] pcm = new byte[n * 4];
                for (int i = 0; i < n; i++)
                {
                    float t = i / (float)rate;
                    float env = (float)Math.Exp(-t * 18f);
                    float s = (float)(Math.Sin(t * 2 * Math.PI * 880) * 0.45
                        + Math.Sin(t * 2 * Math.PI * 1320) * 0.22) * env;
                    short v = (short)(Math.Max(-1f, Math.Min(1f, s)) * 18000);
                    int o = i * 4;
                    pcm[o] = (byte)(v & 0xff);
                    pcm[o + 1] = (byte)((v >> 8) & 0xff);
                    pcm[o + 2] = pcm[o];
                    pcm[o + 3] = pcm[o + 1];
                }
                return new SoundEffect(pcm, rate, AudioChannels.Stereo);
            }
            catch
            {
                return null;
            }
        }

        private string WeatherTag()
        {
            if (_world.Storming)
                return "  STORM";
            if (_world.Raining)
                return "  RAIN";
            return "";
        }

        private void DrawHud(int vw, int vh)
        {
            if (_world.Screen == Screen.Plan)
            {
                DrawFarmPlanHud(vw, vh);
                return;
            }
            if (_world.Screen == Screen.MapEdit)
                return;
            Panel(12, 12, 280, 78);
            _font.Draw(_spriteBatch, "SPRING  DAY " + _world.Day, 24, 22, new Color(196, 165, 116), 2);
            _font.Draw(_spriteBatch, ClockLabel(_world.Minutes) + WeatherTag(), 24, 42, Color.White, 2);
            _font.Draw(_spriteBatch, _world.ZoneName.ToUpperInvariant(), 24, 62, ZoneColor(_world.ZoneName), 2);

            int menuX, menuY, menuW, menuH;
            HudMenuRect(vw, vh, out menuX, out menuY, out menuW, out menuH);
            MouseState ms = Mouse.GetState();
            bool menuHot = ms.X >= menuX && ms.X < menuX + menuW && ms.Y >= menuY && ms.Y < menuY + menuH;
            Fill(menuX, menuY, menuW, menuH, menuHot ? new Color(72, 48, 34) : new Color(42, 32, 28));
            DrawRect(menuX, menuY, menuW, menuH, menuHot ? new Color(232, 197, 71) : new Color(139, 94, 60));
            string menu = "MENU";
            _font.Draw(_spriteBatch, menu, menuX + menuW / 2 - _font.Measure(menu, 2) / 2, menuY + 8, menuHot ? new Color(244, 228, 166) : Color.White, 2);

            Panel(vw - 292, 12, 280, 102);
            _font.Draw(_spriteBatch, _world.Gold.ToString() + "G", vw - 276, 22, new Color(232, 197, 71), 2);
            _font.Draw(_spriteBatch, _world.InfiniteEnergy ? "ENERGY  INF" : "ENERGY", vw - 276, 44, new Color(196, 165, 116), 2);
            Fill(vw - 276, 62, 248, 14, new Color(61, 42, 31));
            int ew = _world.InfiniteEnergy ? 244 : (int)(244f * _world.Energy / GameConst.MaxEnergy);
            Fill(vw - 274, 64, Math.Max(0, ew), 10, _world.InfiniteEnergy ? new Color(232, 197, 71) : new Color(126, 192, 106));
            string sk = "ATK " + _world.Skills.Level[0].ToString()
                + "  WOOD " + _world.Skills.Level[1].ToString()
                + "  MINE " + _world.Skills.Level[2].ToString();
            _font.Draw(_spriteBatch, sk, vw - 276, 84, new Color(176, 208, 255), 2);

            int barY = vh - 70;
            int slot = HudSlot;
            int gap = HudGap;
            SlotLoc hover = HitSlot(Mouse.GetState().X, Mouse.GetState().Y, vw, vh, _world.Screen == Screen.Bag);
            for (int i = 0; i < _world.Bar.Length; i++)
            {
                int sx = HudBarX + i * gap;
                bool selected = i == _world.Selected;
                bool drop = _dragging && hover.Valid && hover.Bar && hover.Index == i;
                Color border = drop ? new Color(244, 228, 166) : (selected ? new Color(232, 197, 71) : new Color(139, 94, 60));
                Fill(sx, barY, slot, slot, new Color(26, 21, 32, 220));
                DrawRect(sx, barY, slot, slot, border);
                bool dim = _dragging && _dragFrom.Bar && _dragFrom.Index == i;
                DrawItemInSlot(_world.Bar[i], sx, barY, slot, dim);
                _font.Draw(_spriteBatch, (i + 1).ToString(), sx + 4, barY + 4, new Color(196, 165, 116), 1);
            }

            Panel(vw - 360, vh - 56, 348, 40);
            _font.Draw(_spriteBatch, "ESC MENU  I BAG  K SKILLS  H HELP", vw - 344, vh - 42, Color.White, 2);

            if (_net != null && _net.Active)
            {
                string lan = _net.IsHost
                    ? "LAN HOST  " + _net.PlayerCount.ToString() + "/" + GameConst.MaxPlayers.ToString() + "  " + _net.HostAddress
                    : "LAN GUEST  " + _net.PlayerCount.ToString() + "/" + GameConst.MaxPlayers.ToString();
                int lw = _font.Measure(lan, 2) + 24;
                Panel(12, 96, lw, 28);
                _font.Draw(_spriteBatch, lan, 24, 102, new Color(176, 208, 255), 2);
            }

            if (_world.Hint.Length > 0)
            {
                int w = _font.Measure(_world.Hint, 2) + 24;
                int hx = (vw - w) / 2;
                Panel(hx, vh - 120, w, 32);
                _font.Draw(_spriteBatch, _world.Hint, hx + 12, vh - 112, new Color(244, 228, 166), 2);
            }

            if (_world.ArriveBannerTimer > 0 && _world.ArriveBanner.Length > 0)
            {
                string now = "NOW ENTERING";
                string name = _world.ArriveBanner.ToUpperInvariant();
                int nw = _font.Measure(now, 2);
                int bw = _font.Measure(name, 4);
                int boxW = Math.Max(nw, bw) + 48;
                int bx = (vw - boxW) / 2;
                int by = vh / 5;
                Panel(bx, by, boxW, 78);
                _font.Draw(_spriteBatch, now, vw / 2 - nw / 2, by + 12, new Color(196, 165, 116), 2);
                _font.Draw(_spriteBatch, name, vw / 2 - bw / 2, by + 36, ZoneColor(_world.ArriveBanner), 4);
            }
        }

        private void DrawToast(int vw, int vh)
        {
            if (_world.ToastTimer <= 0 || _world.Toast.Length == 0)
                return;
            int w = Math.Min(vw - 40, _font.Measure(_world.Toast, 2) + 24);
            int hx = (vw - w) / 2;
            Panel(hx, 100, w, 32);
            _font.Draw(_spriteBatch, _world.Toast, hx + 12, 108, Color.White, 2);
        }

        private void HudMenuRect(int vw, int vh, out int x, out int y, out int w, out int h)
        {
            w = 108;
            h = 32;
            x = 304;
            y = 12;
        }

        private bool HudMenuHit(int mx, int my, int vw, int vh)
        {
            int x, y, w, h;
            HudMenuRect(vw, vh, out x, out y, out w, out h);
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }

        private void DrawTitle(int vw, int vh)
        {
            GraphicsDevice.Clear(new Color(148, 168, 168));
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
            int groundY = vh * 2 / 3;
            int ts = GameConst.Tile * 2;
            for (int y = groundY; y < vh; y += ts)
            {
                for (int x = 0; x < vw; x += ts)
                    _spriteBatch.Draw(_assets.Grass[(x / ts + y / ts) & 3], new Rectangle(x, y, ts, ts), Color.White);
            }
            for (int x = vw / 2; x < vw; x += ts)
                _spriteBatch.Draw(_assets.Water[0], new Rectangle(x, vh - ts, ts, ts), Color.White);
            float trunkH = _assets.PineTrunk[0].Height * 2;
            float pineH = _assets.PineNeedles[1].Height * 1.5f;
            float pineW = _assets.PineNeedles[1].Width * 1.5f;
            _spriteBatch.Draw(_assets.PineTrunk[1], new Rectangle(88, groundY - (int)trunkH + 12, _assets.PineTrunk[1].Width * 2, (int)trunkH), Color.White);
            DrawSwaying(_assets.PineNeedles[1], 88 + 28 - pineW / 2f, groundY - (int)trunkH + 12 - pineH + 48, 1.5f, 1.5f, 0.2f, 0.2f);
            float appleH = _assets.FarmCanopy[0].Height * 1.5f;
            float appleW = _assets.FarmCanopy[0].Width * 1.5f;
            float appleTrunkH = _assets.FarmTrunk[2].Height * 2;
            _spriteBatch.Draw(_assets.FarmTrunk[2], new Rectangle(vw - 210, groundY - (int)appleTrunkH + 8, _assets.FarmTrunk[2].Width * 2, (int)appleTrunkH), Color.White);
            DrawSwaying(_assets.FarmCanopy[0], vw - 210 + 36 - appleW / 2f, groundY - (int)appleTrunkH + 8 - appleH + 40, 1.5f, 1.5f, 1.1f, 0.7f);
            Texture2D farmer = _assets.PlayerFrame(_world.Look, 0, 0);
            int fw = (int)(farmer.Width * GameConst.CharScale * 2.4f);
            int fh = (int)(farmer.Height * GameConst.CharScale * 2.4f);
            _spriteBatch.Draw(farmer, new Rectangle(vw / 2 - fw / 2, groundY - fh + 16, fw, fh), Color.White);
            DrawSwaying(_assets.Flower, 220, groundY - 20, 48f / _assets.Flower.Width, 36f / _assets.Flower.Height, 0.4f, 1f);
            _font.Draw(_spriteBatch, "HARVEST HOLLOW", vw / 2 - _font.Measure("HARVEST HOLLOW", 5) / 2, vh / 5, new Color(244, 228, 166), 5);
            _font.Draw(_spriteBatch, "A quiet valley farm in the XNA 4.0 tradition", vw / 2 - _font.Measure("A quiet valley farm in the XNA 4.0 tradition", 2) / 2, vh / 5 + 56, Color.White, 2);
            _font.Draw(_spriteBatch, "PRESS ENTER", vw / 2 - _font.Measure("PRESS ENTER", 3) / 2, vh / 2 - 36, new Color(232, 197, 71), 3);
            int opt = 0;
            int oy = vh / 2 + 8;
            if (SaveGame.Exists())
            {
                DrawTitleOption(vw, oy, "CONTINUE FARM", opt);
                opt++;
                oy += 24;
            }
            DrawTitleOption(vw, oy, "SOLO VALLEY", opt);
            DrawTitleOption(vw, oy + 24, "HOST LAN FARM  (UP TO 6)", opt + 1);
            DrawTitleOption(vw, oy + 48, "JOIN LAN FARM", opt + 2);
            _font.Draw(_spriteBatch, "ESC SETTINGS", vw / 2 - _font.Measure("ESC SETTINGS", 3) / 2, oy + 84, new Color(244, 228, 166), 3);
            _font.Draw(_spriteBatch, "WASD MOVE   1-9 TOOLS   CLICK/SPACE USE   E INTERACT", vw / 2 - _font.Measure("WASD MOVE   1-9 TOOLS   CLICK/SPACE USE   E INTERACT", 2) / 2, vh - 48, Color.White, 2);
            _spriteBatch.End();
        }

        private void DrawTitleOption(int vw, int y, string text, int row)
        {
            Color c = _titleRow == row ? new Color(232, 197, 71) : Color.White;
            string line = (_titleRow == row ? "> " : "  ") + text;
            _font.Draw(_spriteBatch, line, vw / 2 - _font.Measure(line, 2) / 2, y, c, 2);
        }

        private void DrawJoin(int vw, int vh)
        {
            GraphicsDevice.Clear(new Color(36, 32, 40));
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
            string t = "JOIN LAN FARM";
            _font.Draw(_spriteBatch, t, vw / 2 - _font.Measure(t, 4) / 2, vh / 5, new Color(244, 228, 166), 4);
            string sub = "Type the host's local IP. ENTER connects.";
            _font.Draw(_spriteBatch, sub, vw / 2 - _font.Measure(sub, 2) / 2, vh / 5 + 48, Color.White, 2);
            string ip = _joinIp + (_joinIp.Length < 15 ? "_" : "");
            int boxW = Math.Max(280, _font.Measure(ip, 3) + 32);
            Panel(vw / 2 - boxW / 2, vh / 2 - 24, boxW, 48);
            _font.Draw(_spriteBatch, ip, vw / 2 - _font.Measure(ip, 3) / 2, vh / 2 - 8, new Color(232, 197, 71), 3);
            string st = _net != null ? _net.Status : "";
            if (st.Length > 0)
                _font.Draw(_spriteBatch, st, vw / 2 - _font.Measure(st, 2) / 2, vh / 2 + 48, new Color(176, 208, 255), 2);
            DrawMainMenuButton(vw, vh - 48, MainMenuButtonHit(Mouse.GetState().X, Mouse.GetState().Y, vw, vh, vh - 48));
            _spriteBatch.End();
        }

        private int TitleRows()
        {
            return SaveGame.Exists() ? 4 : 3;
        }

        private void ChooseTitle()
        {
            int row = _titleRow;
            bool haveSave = SaveGame.Exists();
            if (haveSave && row == 0)
            {
                ContinueFarm();
                return;
            }
            int mode = haveSave ? row - 1 : row;
            _createLook = _world.Look;
            _createRow = 0;
            _createDir = 0;
            if (mode <= 0)
            {
                if (_net != null)
                    _net.Stop();
                _createNext = 0;
            }
            else if (mode == 1)
                _createNext = 1;
            else
                _createNext = 2;
            _world.Screen = Screen.Create;
        }

        private void ContinueFarm()
        {
            if (_net != null)
                _net.Stop();
            if (!_saveLoaded)
                _saveLoaded = SaveGame.Read(_world);
            if (!_saveLoaded)
            {
                _world.ShowToast("Could not load the farm save.");
                return;
            }
            _world.Screen = Screen.Play;
            _world.ShowToast("Welcome back.");
        }

        private void BeginNewValley()
        {
            if (_net != null)
                _net.Stop();
            _world = new World();
            if (_net != null)
                _net.AttachWorld(_world);
            else
                _net = new NetSession(_world);
            _saveLoaded = false;
            _saveAcc = 0f;
        }

        private void TrySaveValley()
        {
            if (_world == null)
                return;
            if (_net != null && _net.IsClient)
                return;
            Screen s = _world.Screen;
            if (s == Screen.Create || s == Screen.Join || s == Screen.Loading)
                return;
            if (!_saveLoaded && s != Screen.Play && s != Screen.Sleep)
                return;
            if (SaveGame.Write(_world))
                _saveLoaded = true;
        }

        private void FinishCreate()
        {
            _createLook.Clamp();
            if (_createNext == 2)
            {
                _world.Look = _createLook;
                _world.Screen = Screen.Join;
                return;
            }
            BeginNewValley();
            _world.Look = _createLook;
            if (_createNext == 0)
            {
                _world.Screen = Screen.Play;
                TrySaveValley();
                _world.ShowToast("Farm saved. You can continue later.");
            }
            else
            {
                _net.Host();
                _world.Screen = Screen.Play;
                TrySaveValley();
                _world.ShowToast(_net.Status);
            }
        }

        private void UpdateCreate(KeyboardState keys, MouseState mouse, int vw, int vh, float dt)
        {
            _createAnim += dt;
            if (Pressed(keys, Keys.Q))
                _createDir = (_createDir + 3) % 4;
            if (Pressed(keys, Keys.E))
                _createDir = (_createDir + 1) % 4;
            if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                _createRow = (_createRow + 1) % 7;
            if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                _createRow = (_createRow + 6) % 7;
            if (_createRow < 6)
            {
                if (Pressed(keys, Keys.Left) || Pressed(keys, Keys.A))
                    _createLook.Cycle(_createRow, -1);
                if (Pressed(keys, Keys.Right) || Pressed(keys, Keys.D))
                    _createLook.Cycle(_createRow, 1);
            }
            if (Pressed(keys, Keys.Enter) || Pressed(keys, _cfg.Use))
            {
                if (_createRow >= 6)
                    FinishCreate();
                else
                    _createLook.Cycle(_createRow, 1);
            }
            if (Clicked(mouse))
            {
                if (MainMenuButtonHit(mouse.X, mouse.Y, vw, vh, vh - 48))
                {
                    if (_net != null)
                        _net.Stop();
                    _world.Screen = Screen.Title;
                    return;
                }
                int panelX = vw / 2 + 20;
                int panelY = vh / 5 + 70;
                int startY = panelY + 6 * 36 + 16;
                for (int i = 0; i < 6; i++)
                {
                    int y = panelY + i * 36;
                    if (mouse.X >= panelX && mouse.X < panelX + 420 && mouse.Y >= y && mouse.Y < y + 32)
                    {
                        _createRow = i;
                        _createLook.Cycle(i, mouse.X < panelX + 210 ? -1 : 1);
                        break;
                    }
                }
                if (mouse.X >= panelX && mouse.X < panelX + 420 && mouse.Y >= startY && mouse.Y < startY + 36)
                {
                    _createRow = 6;
                    FinishCreate();
                }
            }
        }

        private void DrawCreate(int vw, int vh)
        {
            GraphicsDevice.Clear(new Color(48, 42, 50));
            _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);
            string t = "MAKE YOUR FARMER";
            _font.Draw(_spriteBatch, t, vw / 2 - _font.Measure(t, 4) / 2, 28, new Color(244, 228, 166), 4);
            string sub = "A new valley starts with a face you'll keep.";
            _font.Draw(_spriteBatch, sub, vw / 2 - _font.Measure(sub, 2) / 2, 72, Color.White, 2);

            int stageX = vw / 2 - 430;
            int stageY = 110;
            Panel(stageX, stageY, 300, 420);
            int frame = Characters.Pose(true, _createAnim, false, 0f);
            Texture2D farmer = _assets.PlayerFrame(_createLook, _createDir, frame);
            float scale = 4.2f;
            int fw = (int)(farmer.Width * scale);
            int fh = (int)(farmer.Height * scale);
            _spriteBatch.Draw(_assets.CharShadow, new Rectangle(stageX + 150 - 40, stageY + 340, 80, 28), Color.White);
            _spriteBatch.Draw(farmer, new Rectangle(stageX + 150 - fw / 2, stageY + 360 - fh, fw, fh), Color.White);
            string turn = "Q / E turn";
            _font.Draw(_spriteBatch, turn, stageX + 150 - _font.Measure(turn, 2) / 2, stageY + 380, new Color(196, 165, 116), 2);

            int panelX = vw / 2 + 20;
            int panelY = vh / 5 + 70;
            Panel(panelX - 16, panelY - 16, 452, 7 * 36 + 48);
            for (int i = 0; i < 7; i++)
            {
                int y = i < 6 ? panelY + i * 36 : panelY + 6 * 36 + 16;
                bool on = _createRow == i;
                Color c = on ? new Color(232, 197, 71) : Color.White;
                string line;
                if (i < 6)
                    line = (on ? "> " : "  ") + FarmerLook.PartName(i) + "   < " + _createLook.PartValue(i) + " >";
                else
                    line = (on ? "> " : "  ") + "WALK INTO THE VALLEY";
                _font.Draw(_spriteBatch, line, panelX, y + 8, c, 2);
            }
            string hint = "ARROWS change the look. ENTER starts.";
            _font.Draw(_spriteBatch, hint, vw / 2 - _font.Measure(hint, 2) / 2, vh - 78, new Color(196, 165, 116), 2);
            DrawMainMenuButton(vw, vh - 48, MainMenuButtonHit(Mouse.GetState().X, Mouse.GetState().Y, vw, vh, vh - 48));
            _spriteBatch.End();
        }

        private void DrawMainMenuButton(int vw, int y, bool selected)
        {
            string t = "BACK TO MAIN MENU";
            int tw = _font.Measure(t, 2);
            int bw = tw + 36;
            int bh = 32;
            int bx = vw / 2 - bw / 2;
            Fill(bx, y - 6, bw, bh, selected ? new Color(72, 48, 34) : new Color(42, 32, 28));
            DrawRect(bx, y - 6, bw, bh, selected ? new Color(232, 197, 71) : new Color(139, 94, 60));
            _font.Draw(_spriteBatch, t, vw / 2 - tw / 2, y, selected ? new Color(244, 228, 166) : Color.White, 2);
        }

        private bool MainMenuButtonHit(int mx, int my, int vw, int vh, int y)
        {
            string t = "BACK TO MAIN MENU";
            int tw = _font.Measure(t, 2);
            int bw = tw + 36;
            int bh = 32;
            int bx = vw / 2 - bw / 2;
            return mx >= bx && mx < bx + bw && my >= y - 6 && my < y - 6 + bh;
        }

        private void UpdateJoin(KeyboardState keys, MouseState mouse, int vw, int vh)
        {
            if (Pressed(keys, Keys.Escape))
            {
                if (_net != null)
                    _net.Stop();
                _world.Screen = Screen.Title;
                return;
            }
            if (Clicked(mouse) && MainMenuButtonHit(mouse.X, mouse.Y, vw, vh, vh - 48))
            {
                if (_net != null)
                    _net.Stop();
                _world.Screen = Screen.Title;
                return;
            }
            if (Pressed(keys, Keys.Enter))
            {
                string ip = _joinIp.Trim();
                if (ip.Length == 0)
                    ip = "127.0.0.1";
                _net.Join(ip);
                return;
            }
            if (Pressed(keys, Keys.Back) && _joinIp.Length > 0)
                _joinIp = _joinIp.Substring(0, _joinIp.Length - 1);
            for (int i = 0; i < 10; i++)
            {
                if (Pressed(keys, Keys.D0 + i) || Pressed(keys, Keys.NumPad0 + i))
                    _joinIp += i.ToString();
            }
            if (Pressed(keys, Keys.OemPeriod) || Pressed(keys, Keys.Decimal))
                _joinIp += ".";
        }

        private void NetBuySeed(int i)
        {
            if (i < 0 || i >= CropCatalog.All.Length)
                return;
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActBuySeed, w => w.Write(i));
            else
                _world.Buy(CropCatalog.All[i]);
        }

        private void NetBuyDrink(int i)
        {
            if (i < 0 || i >= ItemCatalog.Drinks.Length)
                return;
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActBuyDrink, w => w.Write(i));
            else
                _world.BuyDrink(i);
        }

        private void NetBuyFood(int i)
        {
            if (i < 0 || i >= ItemCatalog.Foods.Length)
                return;
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActBuyFood, w => w.Write(i));
            else
                _world.BuyFood(ItemCatalog.Foods[i]);
        }

        private void NetCraftFence()
        {
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActCraft, null);
            else
                _world.CraftFence();
        }

        private void NetCraftPlank()
        {
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActCraftPlank, null);
            else
                _world.CraftPlank();
        }

        private void NetCraftMilkPail()
        {
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActCraftPail, null);
            else
                _world.CraftMilkPail();
        }

        private void NetCraftShears()
        {
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActCraftShears, null);
            else
                _world.CraftShears();
        }

        private void NetBuyAnimal(int i)
        {
            if (i < 0 || i >= ItemCatalog.Livestock.Length)
                return;
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActBuyAnimal, w => w.Write(i));
            else
                _world.BuyAnimal(i);
        }

        private void NetSpendSkill(int skill)
        {
            if (_net != null && _net.IsClient)
                _net.SendAction(NetSession.ActSpendSkill, w => w.Write(skill));
            else
                _world.SpendSkillPoint(skill);
        }

        private void BeginFarmPlanFromAsh()
        {
            if (_net != null && _net.IsClient)
            {
                _world.ShowToast("The host has to mark the stakes.");
                return;
            }
            _planPick = null;
            _world.BeginFarmPlan();
        }

        private void FinishFarmPlan()
        {
            _planPick = null;
            _world.EndFarmPlan(_net != null && _net.Active);
        }

        private bool RightClicked(MouseState mouse)
        {
            return mouse.RightButton == ButtonState.Pressed && _prevMouse.RightButton == ButtonState.Released;
        }

        private void UpdateFarmPlan(KeyboardState keys, MouseState mouse, float dt)
        {
            if (Pressed(keys, Keys.Escape) || Pressed(keys, _cfg.SettingsKey) || Pressed(keys, _cfg.Interact))
            {
                FinishFarmPlan();
                return;
            }
            if (RightClicked(mouse))
            {
                _planPick = null;
                _world.ShowToast("Pick another building, or ESC when the stakes are in.");
            }
            Point tile = ScreenToTile(mouse.X, mouse.Y);
            Building hover = _world.FarmBuildingAt(tile.X, tile.Y);
            if (Pressed(keys, Keys.R))
            {
                Building turn = _planPick != null ? _planPick : hover;
                if (turn == null)
                    _world.ShowToast("Click a building, then press R to turn it.");
                else if (_world.RotateFarmBuilding(turn))
                    _world.ShowToast(turn.RepairName + " faces a new wall.");
                else
                    _world.ShowToast("No room to turn " + turn.RepairName + " here.");
                return;
            }
            if (_planPick == null)
            {
                if (_world.MovableFarmBuildingCount() <= 0)
                    _world.Hint = "No farm buildings to move. ESC returns to Ash.";
                else if (hover != null)
                    _world.Hint = "Click to lift " + hover.RepairName;
                else
                    _world.Hint = "Click a farm building, then a patch of pasture. R turns it. ESC done.";
            }
            else if (hover != null && hover != _planPick)
                _world.Hint = "Click to lift " + hover.RepairName + " instead";
            else if (_world.CanPlaceFarmBuilding(_planPick, tile.X, tile.Y))
                _world.Hint = "Click to set " + _planPick.RepairName + " here. R turns it.";
            else
                _world.Hint = "That ground isn't clear.";

            if (!(Clicked(mouse) || Pressed(keys, Keys.Space) || Pressed(keys, _cfg.Use)))
                return;
            if (_planPick == null)
            {
                if (hover != null)
                {
                    _planPick = hover;
                    _world.ShowToast("Got " + hover.RepairName + ". Click the pasture.");
                }
                else
                    _world.ShowToast("Click a building on the farm.");
                return;
            }
            if (hover != null && hover != _planPick)
            {
                _planPick = hover;
                _world.ShowToast("Got " + hover.RepairName + ". Click the pasture.");
                return;
            }
            if (_planPick.X == tile.X && _planPick.Y == tile.Y)
            {
                _planPick = null;
                return;
            }
            if (_world.MoveFarmBuilding(_planPick, tile.X, tile.Y))
            {
                _world.ShowToast(_planPick.RepairName + " sits here now.");
                _planPick = null;
            }
            else
                _world.ShowToast("That ground isn't clear.");
        }

        private void DrawFarmPlanGhost()
        {
            MouseState mouse = Mouse.GetState();
            Point tile = ScreenToTile(mouse.X, mouse.Y);
            if (_planPick != null)
            {
                DrawPlanFootprint(_planPick.X, _planPick.Y, _planPick.FootW, _planPick.FootH, new Color(232, 197, 71, 90));
                DrawPlanDoorMark(_planPick.X, _planPick.Y, _planPick);
                bool ok = _world.CanPlaceFarmBuilding(_planPick, tile.X, tile.Y);
                Color ghost = ok ? new Color(90, 196, 110, 110) : new Color(196, 72, 64, 110);
                DrawPlanFootprint(tile.X, tile.Y, _planPick.FootW, _planPick.FootH, ghost);
                DrawPlanDoorMark(tile.X, tile.Y, _planPick);
            }
            else
            {
                Building hover = _world.FarmBuildingAt(tile.X, tile.Y);
                if (hover != null)
                {
                    DrawPlanFootprint(hover.X, hover.Y, hover.FootW, hover.FootH, new Color(244, 228, 166, 80));
                    DrawPlanDoorMark(hover.X, hover.Y, hover);
                }
            }
        }

        private void DrawPlanDoorMark(int x, int y, Building b)
        {
            int lx, ly;
            Building.DoorLocal(b.W, b.H, b.DoorDx, b.Rot, out lx, out ly);
            int t = GameConst.Tile;
            Fill((x + lx) * t, (y + ly) * t, t, t, new Color(48, 36, 28, 200));
        }

        private void DrawPlanFootprint(int x, int y, int w, int h, Color c)
        {
            int t = GameConst.Tile;
            Fill(x * t, y * t, w * t, h * t, c);
            DrawRect(x * t, y * t, w * t, h * t, new Color(c.R, c.G, c.B, (byte)220));
        }

        private void DrawFarmPlanHud(int vw, int vh)
        {
            string title = "ASH'S SITE PLAN";
            string sub = _planPick == null
                ? "Click a farm building. R turns it. Click pasture to set it down."
                : "Moving  " + _planPick.RepairName + ".  R rotates.  Right-click cancels.";
            string esc = "ESC returns to the forge";
            int boxW = Math.Max(_font.Measure(title, 3), Math.Max(_font.Measure(sub, 2), _font.Measure(esc, 2))) + 40;
            int bx = (vw - boxW) / 2;
            Panel(bx, 16, boxW, 86);
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, 26, new Color(232, 197, 71), 3);
            _font.Draw(_spriteBatch, sub, vw / 2 - _font.Measure(sub, 2) / 2, 54, Color.White, 2);
            _font.Draw(_spriteBatch, esc, vw / 2 - _font.Measure(esc, 2) / 2, 74, new Color(196, 165, 116), 2);

            if (_world.Hint.Length > 0)
            {
                int w = _font.Measure(_world.Hint, 2) + 24;
                int hx = (vw - w) / 2;
                Panel(hx, vh - 56, w, 32);
                _font.Draw(_spriteBatch, _world.Hint, hx + 12, vh - 48, new Color(244, 228, 166), 2);
            }
        }

        private static int EditToolCount()
        {
            return 6;
        }

        private void EditPaletteRect(int vw, int vh, out int x, out int y, out int w, out int h)
        {
            x = 12;
            y = 110;
            w = 168;
            h = 6 * 28 + 16;
        }

        private void EditPaintRow(int vw, int vh, out int x, out int y, out int w, out int h)
        {
            int n = MapEdit.Palette.Length;
            w = n * 28 + 16;
            h = 40;
            x = 188;
            y = vh - 92;
        }

        private bool EditUiHit(int mx, int my, int vw, int vh)
        {
            int x, y, w, h;
            EditPaletteRect(vw, vh, out x, out y, out w, out h);
            if (mx >= x && mx < x + w && my >= y && my < y + h)
                return true;
            if (_editTool == MapEditTool.Paint || _editTool == MapEditTool.Dropper)
            {
                EditPaintRow(vw, vh, out x, out y, out w, out h);
                if (mx >= x && mx < x + w && my >= y && my < y + h)
                    return true;
            }
            if (_editTool == MapEditTool.Place)
            {
                EditStampRect(vw, vh, out x, out y, out w, out h);
                if (mx >= x && mx < x + w && my >= y && my < y + h)
                    return true;
            }
            return false;
        }

        private void EditStampRect(int vw, int vh, out int x, out int y, out int w, out int h)
        {
            x = vw - 228;
            y = 110;
            w = 216;
            h = vh - 196;
        }

        private int EditStampVisible(int h)
        {
            int n = (h - 16) / 18;
            if (n < 4)
                n = 4;
            return n;
        }

        private MapStamp CurrentStamp()
        {
            MapStamp[] all = MapEdit.Catalog;
            if (all.Length == 0)
                return null;
            if (_editStamp < 0)
                _editStamp = 0;
            if (_editStamp >= all.Length)
                _editStamp = all.Length - 1;
            return all[_editStamp];
        }

        private void KeepStampVisible(int vh)
        {
            int x, y, w, h;
            EditStampRect(1280, vh, out x, out y, out w, out h);
            int vis = EditStampVisible(h);
            if (_editStamp < _editStampScroll)
                _editStampScroll = _editStamp;
            if (_editStamp >= _editStampScroll + vis)
                _editStampScroll = _editStamp - vis + 1;
            if (_editStampScroll < 0)
                _editStampScroll = 0;
        }

        private void CycleStamp(int delta, int vh)
        {
            MapStamp[] all = MapEdit.Catalog;
            if (all.Length == 0)
                return;
            _editStamp += delta;
            while (_editStamp < 0)
                _editStamp += all.Length;
            while (_editStamp >= all.Length)
                _editStamp -= all.Length;
            _editStampRot = 0;
            KeepStampVisible(vh);
            _world.ShowToast("Place: " + all[_editStamp].Name);
        }

        private void PushEditUndo(MapUndo u)
        {
            if (u == null)
                return;
            if (u.Moved == null && u.Cells.Count == 0 && u.Stamp == null)
                return;
            _editUndo.Add(u);
            if (_editUndo.Count > 32)
                _editUndo.RemoveAt(0);
        }

        private void RecordCell(MapUndo u, int tx, int ty)
        {
            if (u == null)
                return;
            for (int i = 0; i < u.Cells.Count; i++)
            {
                if (u.Cells[i].X == tx && u.Cells[i].Y == ty)
                    return;
            }
            u.Cells.Add(new Point(tx, ty));
            u.Tiles.Add(_world.TileAt(tx, ty));
            u.Walls.Add(_world.HasHiddenWall(tx, ty));
        }

        private void UndoEdit()
        {
            if (_editPick != null)
            {
                _editPick = null;
                _world.ShowToast("Cancelled.");
                return;
            }
            if (_editUndo.Count == 0)
            {
                _world.ShowToast("Nothing to undo.");
                return;
            }
            MapUndo u = _editUndo[_editUndo.Count - 1];
            _editUndo.RemoveAt(_editUndo.Count - 1);
            if (u.Moved != null)
            {
                MapEditPick back = ClonePick(u.Moved);
                back.X = u.MovedToX;
                back.Y = u.MovedToY;
                if (back.House != null)
                    _world.MoveEditorBuilding(back.House, u.Moved.X, u.Moved.Y);
                else
                    _world.MoveEditorPick(back, u.Moved.X, u.Moved.Y);
                _world.ShowToast("Moved " + u.Moved.Name + " back.");
                return;
            }
            if (u.Stamp != null)
            {
                _world.UnstampEditor(u.Stamp, u.StampX, u.StampY, u.StampBuildingId);
                _world.ShowToast("Removed " + u.Stamp.Name + ".");
                return;
            }
            for (int i = 0; i < u.Cells.Count; i++)
            {
                int tx = u.Cells[i].X;
                int ty = u.Cells[i].Y;
                if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                    continue;
                _world.Tiles[tx, ty] = u.Tiles[i];
                _world.SetHiddenWall(tx, ty, u.Walls[i]);
            }
            _world.ShowToast("Undid last edit.");
        }

        private void BrushAt(int cx, int cy, Action<int, int> fn)
        {
            int r = _editBrush <= 1 ? 0 : 1;
            for (int dy = -r; dy <= r; dy++)
            {
                for (int dx = -r; dx <= r; dx++)
                    fn(cx + dx, cy + dy);
            }
        }

        private void UpdateMapEdit(KeyboardState keys, MouseState mouse, float dt, int vw, int vh)
        {
            if (Pressed(keys, Keys.Escape) || Pressed(keys, _cfg.SettingsKey) || Pressed(keys, Keys.F4))
            {
                if (_editPick != null)
                {
                    _editPick = null;
                    _world.ShowToast("Cancelled.");
                    return;
                }
                _world.EndMapEdit();
                OpenAdmin();
                return;
            }
            float pan = 340f * dt;
            if (keys.IsKeyDown(Keys.A) || keys.IsKeyDown(Keys.Left))
                _editCam.X -= pan;
            if (keys.IsKeyDown(Keys.D) || keys.IsKeyDown(Keys.Right))
                _editCam.X += pan;
            if (keys.IsKeyDown(Keys.W) || keys.IsKeyDown(Keys.Up))
                _editCam.Y -= pan;
            if (keys.IsKeyDown(Keys.S) || keys.IsKeyDown(Keys.Down))
                _editCam.Y += pan;
            ClampEditCam(vw, vh);

            if (Pressed(keys, Keys.D1)) _editTool = MapEditTool.Move;
            if (Pressed(keys, Keys.D2)) _editTool = MapEditTool.Paint;
            if (Pressed(keys, Keys.D3)) _editTool = MapEditTool.Erase;
            if (Pressed(keys, Keys.D4)) _editTool = MapEditTool.Wall;
            if (Pressed(keys, Keys.D5)) _editTool = MapEditTool.Dropper;
            if (Pressed(keys, Keys.D6)) _editTool = MapEditTool.Place;
            int wheel = mouse.ScrollWheelValue - _prevMouse.ScrollWheelValue;
            if (_editTool == MapEditTool.Place)
            {
                if (Pressed(keys, Keys.OemOpenBrackets) || Pressed(keys, Keys.OemComma))
                    CycleStamp(-1, vh);
                if (Pressed(keys, Keys.OemCloseBrackets) || Pressed(keys, Keys.OemPeriod))
                    CycleStamp(1, vh);
                if (wheel > 0)
                    CycleStamp(-1, vh);
                else if (wheel < 0)
                    CycleStamp(1, vh);
            }
            else
            {
                if (Pressed(keys, Keys.OemOpenBrackets) || Pressed(keys, Keys.OemComma))
                    _editBrush = 1;
                if (Pressed(keys, Keys.OemCloseBrackets) || Pressed(keys, Keys.OemPeriod))
                    _editBrush = 3;
            }
            if (Pressed(keys, Keys.G))
                _editGrid = !_editGrid;
            if (Pressed(keys, Keys.Z))
            {
                UndoEdit();
                return;
            }

            Point tile = ScreenToTile(mouse.X, mouse.Y);
            bool overUi = EditUiHit(mouse.X, mouse.Y, vw, vh);
            MapEditPick hover = overUi ? new MapEditPick() : _world.EditorHit(tile.X, tile.Y);

            if (Pressed(keys, Keys.R))
            {
                MapStamp stampTurn = CurrentStamp();
                if (_editTool == MapEditTool.Place && stampTurn != null && stampTurn.Kind == MapStampKind.Building)
                {
                    _editStampRot = (_editStampRot + 1) & 3;
                    _world.ShowToast(stampTurn.Name + " faces a new wall.");
                    return;
                }
                Building turn = _editPick != null && _editPick.House != null ? _editPick.House : hover.House;
                if (turn == null)
                    _world.ShowToast("Click a building, then press R to turn it.");
                else if (_world.RotateEditorBuilding(turn))
                    _world.ShowToast(turn.RepairName + " faces a new wall.");
                else
                    _world.ShowToast("Can't place here.");
                return;
            }

            if (RightClicked(mouse))
            {
                if (_editPick != null)
                {
                    _editPick = null;
                    _world.ShowToast("Cancelled.");
                    return;
                }
                if (!overUi && (_editTool == MapEditTool.Paint || _editTool == MapEditTool.Dropper || _editTool == MapEditTool.Erase))
                {
                    SampleEditTile(tile.X, tile.Y);
                    return;
                }
                if (!overUi && _editTool == MapEditTool.Wall)
                {
                    BeginEditStroke();
                    BrushAt(tile.X, tile.Y, (x, y) =>
                    {
                        RecordCell(_editStroke, x, y);
                        _world.EditorSetWallCell(x, y, false);
                    });
                    PushEditUndo(_editStroke);
                    _editStroke = null;
                    return;
                }
            }

            if (Clicked(mouse) && overUi)
            {
                HandleEditUiClick(mouse.X, mouse.Y, vw, vh);
                return;
            }

            if (_editTool == MapEditTool.Move)
            {
                if (_editPick == null)
                {
                    if (hover.Kind != MapEditKind.None)
                        _world.Hint = "Click to lift " + hover.Name;
                    else
                        _world.Hint = "nothing under cursor";
                }
                else if (_world.CanPlaceEditorTile(_editPick, tile.X, tile.Y))
                    _world.Hint = "Click to set " + _editPick.Name + " here. R turns buildings.";
                else
                    _world.Hint = "can't place here";

                if (Clicked(mouse) && !overUi)
                {
                    if (_editPick == null)
                    {
                        if (hover.Kind == MapEditKind.None)
                            _world.ShowToast("nothing under cursor");
                        else
                        {
                            _editPick = hover;
                            _world.ShowToast("Got " + hover.Name + ". Click to place.");
                        }
                    }
                    else if (hover.Kind != MapEditKind.None && hover.Kind != MapEditKind.Tile
                        && !(hover.Kind == _editPick.Kind && hover.X == _editPick.X && hover.Y == _editPick.Y))
                    {
                        _editPick = hover;
                        _world.ShowToast("Got " + hover.Name + ". Click to place.");
                    }
                    else if (_world.CanPlaceEditorTile(_editPick, tile.X, tile.Y))
                    {
                        MapUndo u = new MapUndo();
                        u.Moved = ClonePick(_editPick);
                        u.MovedToX = tile.X;
                        u.MovedToY = tile.Y;
                        if (_world.MoveEditorPick(_editPick, tile.X, tile.Y))
                        {
                            PushEditUndo(u);
                            _world.ShowToast(_editPick.Name + " sits here now.");
                            _editPick = null;
                        }
                        else
                            _world.ShowToast("can't place here");
                    }
                    else
                        _world.ShowToast("can't place here");
                }
                return;
            }

            if (_editTool == MapEditTool.Dropper)
            {
                _world.Hint = "Click a tile to sample it.";
                if (Clicked(mouse) && !overUi)
                    SampleEditTile(tile.X, tile.Y);
                return;
            }

            if (_editTool == MapEditTool.Place)
            {
                MapStamp stamp = CurrentStamp();
                string stampName = stamp != null ? stamp.Name : "nothing";
                bool ok = stamp != null && _world.CanStampEditor(stamp, tile.X, tile.Y, _editStampRot);
                if (ok)
                    _world.Hint = "Click to stamp " + stampName + ". R turns buildings.";
                else
                    _world.Hint = "can't place here";
                if (Clicked(mouse) && !overUi)
                {
                    if (!ok)
                        _world.ShowToast("can't place here");
                    else
                    {
                        MapUndo u = new MapUndo();
                        if (stamp.Kind == MapStampKind.Tile || stamp.Kind == MapStampKind.Crop)
                            RecordCell(u, tile.X, tile.Y);
                        string placedId;
                        if (_world.StampEditor(stamp, tile.X, tile.Y, _editStampRot, out placedId))
                        {
                            u.Stamp = stamp;
                            u.StampX = tile.X;
                            u.StampY = tile.Y;
                            u.StampRot = _editStampRot;
                            u.StampBuildingId = placedId ?? "";
                            PushEditUndo(u);
                            _world.ShowToast("Placed " + stampName + ".");
                        }
                        else
                            _world.ShowToast("can't place here");
                    }
                }
                return;
            }

            bool paintDown = mouse.LeftButton == ButtonState.Pressed && !overUi;
            if (paintDown && !_editPainting)
            {
                _editPainting = true;
                BeginEditStroke();
            }
            if (!paintDown && _editPainting)
            {
                _editPainting = false;
                PushEditUndo(_editStroke);
                _editStroke = null;
            }
            if (paintDown)
            {
                if (_editTool == MapEditTool.Wall)
                {
                    _world.Hint = "LMB place wall  RMB erase wall";
                    BrushAt(tile.X, tile.Y, (x, y) =>
                    {
                        RecordCell(_editStroke, x, y);
                        _world.EditorSetWallCell(x, y, true);
                    });
                }
                else if (_editTool == MapEditTool.Erase)
                {
                    _world.Hint = "Erasing tiles under the brush.";
                    BrushAt(tile.X, tile.Y, (x, y) =>
                    {
                        RecordCell(_editStroke, x, y);
                        _world.EditorPaintCell(x, y, TileType.Grass, true, false);
                    });
                }
                else
                {
                    _world.Hint = "Painting " + MapEdit.TileName(_editPaint) + ".";
                    BrushAt(tile.X, tile.Y, (x, y) =>
                    {
                        RecordCell(_editStroke, x, y);
                        _world.EditorPaintCell(x, y, _editPaint, false, false);
                    });
                }
            }
            else if (_editTool == MapEditTool.Wall)
                _world.Hint = "LMB place invisible wall  RMB erase";
            else if (_editTool == MapEditTool.Erase)
                _world.Hint = "LMB erase tiles. Buildings stay unless you move them.";
            else
                _world.Hint = "LMB paints " + MapEdit.TileName(_editPaint) + ". RMB samples.";
        }

        private static MapEditPick ClonePick(MapEditPick src)
        {
            if (src == null)
                return null;
            MapEditPick p = new MapEditPick();
            p.Kind = src.Kind;
            p.Name = src.Name;
            p.X = src.X;
            p.Y = src.Y;
            p.W = src.W;
            p.H = src.H;
            p.House = src.House;
            p.Index = src.Index;
            p.Tile = src.Tile;
            p.Crop = src.Crop;
            p.DecoCopy = src.DecoCopy;
            p.GateCopy = src.GateCopy;
            p.BridgeCopy = src.BridgeCopy;
            p.AnimalKind = src.AnimalKind;
            p.NpcId = src.NpcId;
            return p;
        }

        private void BeginEditStroke()
        {
            _editStroke = new MapUndo();
        }

        private void SampleEditTile(int tx, int ty)
        {
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
            {
                _world.ShowToast("nothing under cursor");
                return;
            }
            TileType t = _world.TileAt(tx, ty);
            if (t == TileType.InvisibleWall)
                t = TileType.Grass;
            _editPaint = t;
            _editTool = MapEditTool.Paint;
            _world.ShowToast("Sampled " + MapEdit.TileName(t) + ".");
        }

        private void HandleEditUiClick(int mx, int my, int vw, int vh)
        {
            int x, y, w, h;
            EditPaletteRect(vw, vh, out x, out y, out w, out h);
            if (mx >= x && mx < x + w && my >= y && my < y + h)
            {
                int row = (my - y - 8) / 28;
                if (row >= 0 && row < EditToolCount())
                    _editTool = (MapEditTool)row;
                return;
            }
            EditPaintRow(vw, vh, out x, out y, out w, out h);
            if (mx >= x && mx < x + w && my >= y && my < y + h)
            {
                int i = (mx - x - 8) / 28;
                if (i >= 0 && i < MapEdit.Palette.Length)
                {
                    _editPaint = MapEdit.Palette[i];
                    _editTool = MapEditTool.Paint;
                }
                return;
            }
            if (_editTool == MapEditTool.Place)
            {
                EditStampRect(vw, vh, out x, out y, out w, out h);
                if (mx >= x && mx < x + w && my >= y && my < y + h)
                {
                    int vis = EditStampVisible(h);
                    int row = (my - y - 8) / 18;
                    int idx = _editStampScroll + row;
                    if (row >= 0 && row < vis && idx >= 0 && idx < MapEdit.Catalog.Length)
                    {
                        _editStamp = idx;
                        _editStampRot = 0;
                        _world.ShowToast("Place: " + MapEdit.Catalog[idx].Name);
                    }
                }
            }
        }

        private void DrawMapEditWorld(int t0x, int t0y, int t1x, int t1y)
        {
            if (_editGrid)
            {
                Color line = new Color(244, 228, 166, 40);
                for (int tx = t0x; tx <= t1x; tx++)
                    Fill(tx * GameConst.Tile, t0y * GameConst.Tile, 1, (t1y - t0y) * GameConst.Tile, line);
                for (int ty = t0y; ty <= t1y; ty++)
                    Fill(t0x * GameConst.Tile, ty * GameConst.Tile, (t1x - t0x) * GameConst.Tile, 1, line);
            }
            for (int ty = t0y; ty < t1y; ty++)
            {
                for (int tx = t0x; tx < t1x; tx++)
                {
                    if (!_world.HasHiddenWall(tx, ty))
                        continue;
                    int x = tx * GameConst.Tile;
                    int y = ty * GameConst.Tile;
                    Color hash = new Color(232, 90, 70, 90);
                    for (int i = 0; i < GameConst.Tile; i += 4)
                    {
                        Fill(x + i, y, 2, GameConst.Tile, hash);
                        Fill(x, y + i, GameConst.Tile, 2, hash);
                    }
                    DrawRect(x, y, GameConst.Tile, GameConst.Tile, new Color(232, 90, 70, 180));
                    _font.Draw(_spriteBatch, "W", x + 10, y + 12, new Color(255, 220, 210, 220), 1);
                }
            }
            MouseState mouse = Mouse.GetState();
            Point tile = ScreenToTile(mouse.X, mouse.Y);
            int t = GameConst.Tile;
            if (_editPick != null)
            {
                DrawPlanFootprint(_editPick.X, _editPick.Y, _editPick.W, _editPick.H, new Color(232, 197, 71, 80));
                bool ok = _world.CanPlaceEditorTile(_editPick, tile.X, tile.Y);
                Color ghost = ok ? new Color(90, 196, 110, 110) : new Color(196, 72, 64, 110);
                DrawPlanFootprint(tile.X, tile.Y, _editPick.W, _editPick.H, ghost);
            }
            else if (_editTool == MapEditTool.Place)
            {
                MapStamp ghostStamp = CurrentStamp();
                int gw, gh;
                MapEdit.StampFoot(ghostStamp, _editStampRot, out gw, out gh);
                bool ok = ghostStamp != null && _world.CanStampEditor(ghostStamp, tile.X, tile.Y, _editStampRot);
                Color ghost = ok ? new Color(90, 196, 110, 110) : new Color(196, 72, 64, 110);
                DrawPlanFootprint(tile.X, tile.Y, gw, gh, ghost);
            }
            else
            {
                MapEditPick hover = _world.EditorHit(tile.X, tile.Y);
                if (hover.Kind != MapEditKind.None)
                    DrawPlanFootprint(hover.X, hover.Y, hover.W, hover.H, new Color(244, 228, 166, 70));
                else
                    DrawRect(tile.X * t, tile.Y * t, t, t, new Color(255, 244, 180, 180));
            }
            if (_editTool == MapEditTool.Paint || _editTool == MapEditTool.Erase || _editTool == MapEditTool.Wall)
            {
                int r = _editBrush <= 1 ? 0 : 1;
                Color c = _editTool == MapEditTool.Wall ? new Color(232, 90, 70, 80)
                    : (_editTool == MapEditTool.Erase ? new Color(196, 72, 64, 70) : new Color(90, 196, 110, 70));
                DrawPlanFootprint(tile.X - r, tile.Y - r, r * 2 + 1, r * 2 + 1, c);
            }
        }

        private void DrawMapEditHud(int vw, int vh)
        {
            string title = "MAP EDITOR";
            Point tile = ScreenToTile(Mouse.GetState().X, Mouse.GetState().Y);
            string hover = _world.EditorHoverName(tile.X, tile.Y);
            string sub;
            if (_editTool == MapEditTool.Place)
            {
                MapStamp cur = CurrentStamp();
                string placeName = cur != null ? cur.Name : "nothing";
                sub = "Place: " + placeName + "  -  " + hover;
            }
            else
            {
                sub = MapEdit.ToolName(_editTool) + "  -  "
                    + MapEdit.TileName(_editPaint) + "  -  brush " + _editBrush.ToString()
                    + "  -  " + hover;
            }
            int boxW = Math.Max(_font.Measure(title, 3), _font.Measure(sub, 2)) + 40;
            if (boxW < 520) boxW = 520;
            int bx = (vw - boxW) / 2;
            Panel(bx, 12, boxW, 70);
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, 20, new Color(232, 197, 71), 3);
            _font.Draw(_spriteBatch, sub, vw / 2 - _font.Measure(sub, 2) / 2, 50, Color.White, 2);

            int px, py, pw, ph;
            EditPaletteRect(vw, vh, out px, out py, out pw, out ph);
            Panel(px, py, pw, ph);
            string[] tools = { "1 Move", "2 Paint", "3 Erase", "4 Wall", "5 Dropper", "6 Place" };
            for (int i = 0; i < tools.Length; i++)
            {
                int y = py + 8 + i * 28;
                bool on = (int)_editTool == i;
                if (on)
                    Fill(px + 6, y - 2, pw - 12, 24, new Color(61, 42, 31, 180));
                Color c = on ? new Color(232, 197, 71) : Color.White;
                _font.Draw(_spriteBatch, tools[i], px + 12, y + 4, c, 2);
            }

            if (_editTool == MapEditTool.Paint || _editTool == MapEditTool.Dropper)
            {
                int rx, ry, rw, rh;
                EditPaintRow(vw, vh, out rx, out ry, out rw, out rh);
                Panel(rx, ry, rw, rh);
                for (int i = 0; i < MapEdit.Palette.Length; i++)
                {
                    int sx = rx + 8 + i * 28;
                    int sy = ry + 8;
                    bool on = MapEdit.Palette[i] == _editPaint;
                    Fill(sx, sy, 24, 24, TileSwatch(MapEdit.Palette[i]));
                    DrawRect(sx, sy, 24, 24, on ? new Color(232, 197, 71) : new Color(139, 94, 60));
                }
            }

            if (_editTool == MapEditTool.Place)
            {
                int sx, sy, sw, sh;
                EditStampRect(vw, vh, out sx, out sy, out sw, out sh);
                Panel(sx, sy, sw, sh);
                MapStamp[] all = MapEdit.Catalog;
                int vis = EditStampVisible(sh);
                KeepStampVisible(vh);
                for (int i = 0; i < vis; i++)
                {
                    int idx = _editStampScroll + i;
                    if (idx >= all.Length)
                        break;
                    int rowY = sy + 8 + i * 18;
                    bool on = idx == _editStamp;
                    if (on)
                        Fill(sx + 6, rowY - 2, sw - 12, 18, new Color(61, 42, 31, 180));
                    Color c = on ? new Color(232, 197, 71) : Color.White;
                    _font.Draw(_spriteBatch, all[idx].Name, sx + 12, rowY + 2, c, 2);
                }
            }

            string help = _editTool == MapEditTool.Place
                ? "LMB stamp  [ ] or wheel cycle  R rotate  G grid  Z undo  WASD pan  Esc back to admin"
                : "LMB paint/place  RMB sample/cancel  [ ] brush  G grid  Z undo  WASD pan  Esc back to admin";
            int hw = _font.Measure(help, 2) + 24;
            Panel((vw - hw) / 2, vh - 40, hw, 28);
            _font.Draw(_spriteBatch, help, (vw - hw) / 2 + 12, vh - 32, new Color(244, 228, 166), 2);

            if (_world.Hint.Length > 0)
            {
                int w = _font.Measure(_world.Hint, 2) + 24;
                int hx = (vw - w) / 2;
                Panel(hx, vh - 76, w, 28);
                _font.Draw(_spriteBatch, _world.Hint, hx + 12, vh - 68, new Color(244, 228, 166), 2);
            }
        }

        private static Color TileSwatch(TileType t)
        {
            switch (t)
            {
                case TileType.Grass: return new Color(106, 168, 79);
                case TileType.WoodsGrass: return new Color(62, 110, 58);
                case TileType.FarmSoil: return new Color(139, 94, 60);
                case TileType.Tilled: return new Color(120, 78, 48);
                case TileType.Path: return new Color(186, 154, 106);
                case TileType.Cobble: return new Color(148, 148, 148);
                case TileType.Water: return new Color(64, 118, 176);
                case TileType.Sand: return new Color(224, 196, 138);
                case TileType.Mountain: return new Color(128, 128, 132);
                case TileType.Dock: return new Color(156, 108, 64);
                case TileType.HouseFloor: return new Color(196, 168, 120);
                case TileType.HouseWall: return new Color(176, 148, 96);
                case TileType.Flower: return new Color(214, 96, 138);
                case TileType.Hay: return new Color(214, 176, 72);
                default: return new Color(90, 90, 90);
            }
        }

        private void DrawPeers(bool behindPlayer, float playerSort)
        {
            if (_net == null || !_net.Active)
                return;
            string localInside = _world.Inside != null ? _world.Inside.Id : "";
            for (int i = 0; i < _net.Peers.Length; i++)
            {
                if (i == _net.LocalSlot)
                    continue;
                FarmerPeer p = _net.Peers[i];
                if (p == null || !p.Used)
                    continue;
                string pin = p.InsideId ?? "";
                if (localInside != pin)
                    continue;
                if (localInside == "inn" && p.InsideFloor != _world.InsideFloor)
                    continue;
                if (localInside.Length == 0)
                {
                    int tx = (int)Math.Floor(p.Pos.X / GameConst.Tile);
                    int ty = (int)Math.Floor(p.Pos.Y / GameConst.Tile);
                    if (!_world.ZoneLit(tx, ty))
                        continue;
                }
                float bottom = p.Pos.Y;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                int frame = Characters.Pose(p.Moving, p.Anim, p.SwingT > 0f, p.SwingDur > 0.0001f ? 1f - p.SwingT / p.SwingDur : 0f);
                DrawFarmerAt(p.Pos, p.Dir, frame, p.Moving, p.Anim, p.SwingT, p.SwingDur, p.SwingAct, p.HeldId, p.Look, NetSession.Tint(i), p.Name);
            }
        }

        private void DrawTrolls(bool behindPlayer, float playerSort)
        {
            if (_world.Inside == null || _world.Inside.Kind != BuildingKind.Cave)
                return;
            for (int i = 0; i < _world.Trolls.Count; i++)
            {
                CaveTroll t = _world.Trolls[i];
                if (!t.Alive)
                    continue;
                bool behind = t.Pos.Y <= playerSort;
                if (behind != behindPlayer)
                    continue;
                int frame = t.Moving ? ((int)(t.Anim * 8) % 2) : 0;
                int dir = t.Dir;
                if (dir < 0 || dir > 3)
                    dir = 0;
                int kind = CaveMobCatalog.Clamp(t.Kind);
                Texture2D tex = _assets.CaveMobs[kind][dir][frame];
                float cs = CaveMobCatalog.Scale(kind);
                float fw = tex.Width * cs;
                float fh = tex.Height * cs;
                Vector2 feet = t.Pos;
                Color tint = t.HurtT > 0f ? new Color(255, 140, 140) : Color.White;
                _spriteBatch.Draw(_assets.CharShadow,
                    new Vector2(feet.X - _assets.CharShadow.Width * cs / 2f, feet.Y - 5),
                    null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
                _spriteBatch.Draw(tex, new Vector2(feet.X - fw / 2f, feet.Y - fh + 2),
                    null, tint, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
                int barW = 22;
                int hx = (int)(feet.X - barW / 2f);
                int hy = (int)(feet.Y - fh - 4);
                Fill(hx, hy, barW, 3, new Color(40, 20, 20, 200));
                int hpW = (int)(barW * Math.Max(0f, t.Hp / (float)Math.Max(1, t.MaxHp)));
                Fill(hx, hy, hpW, 3, new Color(186, 72, 58));
            }
        }

        private void DrawAnimals(bool behindPlayer, float playerSort)
        {
            if (_world.Inside != null)
                return;
            for (int i = 0; i < _world.Animals.Count; i++)
            {
                FarmAnimal a = _world.Animals[i];
                int tx = (int)Math.Floor(a.Pos.X / GameConst.Tile);
                int ty = (int)Math.Floor(a.Pos.Y / GameConst.Tile);
                if (!_world.ZoneLit(tx, ty))
                    continue;
                bool behind = a.Pos.Y <= playerSort;
                if (behind != behindPlayer)
                    continue;
                int kind = (int)a.Kind;
                if (kind < 0 || kind >= _assets.Livestock.Length)
                    kind = 0;
                int dir = a.Dir;
                if (dir < 0 || dir > 3)
                    dir = 0;
                int frame = a.Moving ? ((int)(a.Anim * 8) % 2) : 0;
                Texture2D tex = _assets.Livestock[kind][dir][frame];
                if (a.Kind == AnimalKind.Sheep && !a.HasWool
                    && _assets.SheepShorn[dir] != null && _assets.SheepShorn[dir][frame] != null)
                    tex = _assets.SheepShorn[dir][frame];
                float cs = AnimalCatalog.Scale(a.Kind);
                float fw = tex.Width * cs;
                float fh = tex.Height * cs;
                Vector2 feet = a.Pos;
                _spriteBatch.Draw(_assets.CharShadow,
                    new Vector2(feet.X - _assets.CharShadow.Width * cs / 2f, feet.Y - 4),
                    null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
                _spriteBatch.Draw(tex, new Vector2(feet.X - fw / 2f, feet.Y - fh + 2),
                    null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
            }
        }

        private void DrawLoadFade(int vw, int vh)
        {
            float black = _world.LoadFadeAlpha();
            if (black > 0f)
                Fill(0, 0, vw, vh, new Color(0, 0, 0, (int)(black * 255f)));

            float title = _world.LoadTitleAlpha();
            if (title <= 0f)
                return;

            string zone = _world.LoadingZone;
            if (string.IsNullOrEmpty(zone))
                zone = _world.ZoneName;
            string now = "NOW ENTERING";
            string name = zone.ToUpperInvariant();
            Color label = new Color(196, 165, 116) * title;
            Color zoneCol = ZoneColor(zone) * title;
            _font.Draw(_spriteBatch, now, vw / 2 - _font.Measure(now, 2) / 2, vh / 5, label, 2);
            _font.Draw(_spriteBatch, name, vw / 2 - _font.Measure(name, 4) / 2, vh / 5 + 36, zoneCol, 4);
            string flavor = ZoneFlavor(zone);
            if (flavor.Length > 0)
                _font.Draw(_spriteBatch, flavor, vw / 2 - _font.Measure(flavor, 2) / 2, vh / 5 + 84, label, 2);
        }

        private static string ZoneFlavor(string zone)
        {
            if (zone == "Forbidden Woods") return "The canopy swallows the sun.";
            if (zone == "Moonveil Grove") return "Pines and dark oak hold a light that is not the sun.";
            if (zone == "Mountain Path") return "The Hollow River runs beside the road.";
            if (zone == "Ridge Summit") return "Thin air, pine, and a cave in the rock.";
            if (zone == "Hearth Inn") return "A taproom, a fire, and stairs to the guest rooms.";
            if (zone == "Inn Rooms") return "Two quiet bedrooms above the bar.";
            if (zone.IndexOf("Workshop", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Forge", StringComparison.Ordinal) >= 0) return "A packed Cute Fantasy wood-and-stone forge with a red gable. Ash mills a plank if you bring wood.";
            if (zone == "Harvest Hollow") return "Your valley farm. The river cuts east of the spine.";
            if (zone == "Your Cottage") return "A packed Cute Fantasy wood cottage with a blue gable, and a path to the field.";
            if (zone.IndexOf("Barn", StringComparison.Ordinal) >= 0) return "A packed Cute Fantasy wood barn. The double doors slide open when you walk up.";
            if (zone.IndexOf("Greenhouse", StringComparison.Ordinal) >= 0) return "A packed Cute Fantasy glasshouse with a teal frame.";
            if (zone.IndexOf("Coop", StringComparison.Ordinal) >= 0) return "Nests wait for hens.";
            if (zone == "Meadow Road") return "A long lane of fences and wildflowers. The sea is still ahead.";
            if (zone == "Saltwind Beach") return "The river meets the tide. Finn's dock house keeps the catch.";
            return "";
        }

        private void DrawShop(int vw, int vh)
        {
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.FishMarket)
            {
                Modal(vw, vh, "FINN'S DOCK HOUSE", "Saltwater only. ENTER sells every fish you hold. E to leave.");
                int y = vh / 2 - 72;
                for (int i = 0; i < FishCatalog.Saltwater.Length; i++)
                {
                    FishDef d = FishCatalog.Saltwater[i];
                    int col = i / 8;
                    int row = i % 8;
                    string line = d.Name + "  " + d.Sell.ToString() + "G";
                    _font.Draw(_spriteBatch, line, vw / 2 - 280 + col * 280, y + row * 18, Color.White, 2);
                }
                return;
            }
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Inn)
            {
                Modal(vw, vh, "MIRA'S BAR", "Keys 1-4 to buy a drink. E to leave. Drink from the hotbar.");
                int y = vh / 2 - 72;
                for (int i = 0; i < ItemCatalog.Drinks.Length; i++)
                {
                    ItemDef d = ItemCatalog.Drinks[i];
                    string line = (i + 1).ToString() + "  " + d.Name + "  " + World.FoodCost(d).ToString() + "G  +" + d.Restore.ToString() + " energy";
                    _font.Draw(_spriteBatch, line, vw / 2 - 280, y + i * 22, Color.White, 2);
                }
                return;
            }
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.Carpenter)
            {
                Modal(vw, vh, "ASH'S FORGE", "Anvil, coals, and square boards. 1 mills a plank. 2 moves farm buildings. 3 crafts a milk pail. 4 crafts shears. E to leave.");
                int y = vh / 2 - 64;
                int wood = _world.CountItem("wood");
                int planks = _world.CountItem("plank");
                string line = "1  Mill 1 wooden plank  " + ItemCatalog.WoodPerPlank.ToString() + " wood";
                _font.Draw(_spriteBatch, line, vw / 2 - 280, y, Color.White, 2);
                _font.Draw(_spriteBatch, "2  Move and rotate farm buildings  (overhead site plan)", vw / 2 - 280, y + 24, Color.White, 2);
                _font.Draw(_spriteBatch, "3  Craft a milk pail  " + ItemCatalog.PlanksPerPail.ToString() + " planks", vw / 2 - 280, y + 48, Color.White, 2);
                _font.Draw(_spriteBatch, "4  Craft shears  " + ItemCatalog.PlanksPerShears.ToString() + " planks", vw / 2 - 280, y + 72, Color.White, 2);
                string have = "You have  " + wood.ToString() + " wood,  " + planks.ToString() + " planks";
                _font.Draw(_spriteBatch, have, vw / 2 - 280, y + 100, new Color(232, 197, 71), 2);
                _font.Draw(_spriteBatch, "Ash will lift a house. R rotates 90. Click pasture to set it down.", vw / 2 - 280, y + 128, new Color(196, 165, 116), 2);
                return;
            }
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.AnimalShop)
            {
                Modal(vw, vh, "BESS'S STOCKYARD", "Keys 1-6 buy a crate. Set livestock on the farm with Space.");
                int y = vh / 2 - 80;
                for (int i = 0; i < ItemCatalog.Livestock.Length; i++)
                {
                    ItemDef d = ItemCatalog.Livestock[i];
                    string line = (i + 1).ToString() + "  " + d.Name + "  " + AnimalCatalog.Prices[i].ToString() + "G";
                    _font.Draw(_spriteBatch, line, vw / 2 - 280, y + i * 22, Color.White, 2);
                }
                _font.Draw(_spriteBatch, "E milks a cow (need a milk pail). E shears a sheep (need shears). Hold a crate and E to pack a cow or sheep.", vw / 2 - 280, y + ItemCatalog.Livestock.Length * 22 + 8, new Color(196, 165, 116), 2);
                return;
            }
            if (_world.Inside != null && _world.Inside.Kind == BuildingKind.GeneralStore)
            {
                Modal(vw, vh, "PIPER'S MARKET", "Keys 1-9 to buy. E to leave. Eat food from the hotbar.");
                int y = vh / 2 - 88;
                for (int i = 0; i < CropCatalog.All.Length; i++)
                {
                    CropDef d = CropCatalog.All[i];
                    string line = (i + 1).ToString() + "  " + d.SeedName + "  " + d.SeedCost.ToString() + "G";
                    _font.Draw(_spriteBatch, line, vw / 2 - 280, y + i * 18, Color.White, 2);
                }
                y += CropCatalog.All.Length * 18 + 8;
                for (int i = 0; i < ItemCatalog.Foods.Length; i++)
                {
                    ItemDef f = ItemCatalog.Foods[i];
                    string line = (i + 6).ToString() + "  " + f.Name + "  " + World.FoodCost(f).ToString() + "G  +" + f.Restore.ToString() + " energy";
                    _font.Draw(_spriteBatch, line, vw / 2 - 280, y + i * 18, Color.White, 2);
                }
                y += ItemCatalog.Foods.Length * 18 + 8;
                string up;
                if (_world.PackUpgrades >= GameConst.PackUpgradeMax)
                    up = "9  Satchel full  (" + _world.PackOpen.ToString() + " slots)";
                else
                    up = "9  Satchel +5 slots  " + ItemCatalog.PackUpgradePrices[_world.PackUpgrades].ToString() + "G  (" + _world.PackOpen.ToString() + "/" + GameConst.PackMaxSlots.ToString() + ")";
                _font.Draw(_spriteBatch, up, vw / 2 - 280, y, new Color(232, 197, 71), 2);
                return;
            }
            Modal(vw, vh, "ROWAN'S SHOP", "Seeds are hope you can hold. Keys 1-5 to buy. E to leave.");
            int sy = vh / 2 - 40;
            for (int i = 0; i < CropCatalog.All.Length; i++)
            {
                CropDef d = CropCatalog.All[i];
                string line = (i + 1).ToString() + "  " + d.SeedName + "  " + d.SeedCost.ToString() + "G  " + d.Days.ToString() + " DAYS  SELLS " + d.Sell.ToString() + "G";
                _font.Draw(_spriteBatch, line, vw / 2 - 280, sy + i * 22, Color.White, 2);
            }
        }

        private void DrawSleep(int vw, int vh)
        {
            Modal(vw, vh, "TURN IN FOR THE NIGHT?", "ENTER sleep   N stay up");
            _font.Draw(_spriteBatch, "Watered crops grow. Shipping gold arrives at dawn.", vw / 2 - 280, vh / 2, Color.White, 2);
        }

        private void DrawHelp(int vw, int vh)
        {
            Modal(vw, vh, "FARM HANDBOOK", "ESC to close");
            string[] lines =
            {
                "Walk into a door (or press E) and it swings open before the rooms load.",
                "Harvest glowing crops with the scythe or by using the tile.",
                "I opens the satchel: character sheet on the left, items on the right.",
                "Follow the signed roads to each zone mouth. The next land stays black until you walk in.",
                "South of the timber farmhouse a lane runs to a broken barn, greenhouse, coop, and a concrete silo. Mill planks and press E to repair the ruins. Cut hayfields with the scythe and store hay in the silo.",
                "The barn is a packed Cute Fantasy wood barn with a red gable. Walk up and the double doors slide open to the sides. Repair it with 16 planks. The silo beside it holds hay.",
                "West: woods, then Moonveil Grove. South: a long Meadow Road walk to the beach. North: mountain path beside the Hollow River, then village.",
                "Continue Farm loads your last character. The valley writes to AppData/HarvestHollow/valley.sav.",
                "Host LAN farm from the title (up to 6). Make your farmer first. Guests type the host IP.",
                "Village: willow park, north square, Piper's market, Ash's packed Cute Fantasy forge (mill planks, or move and rotate farm buildings), Bess's stockyard, south gardens. Talk to Mira, Cob, Lila, Bram, and Nell.",
                "Hearth Inn has a taproom downstairs. Mira sells cider, tea, ale, and cocoa. Stairs lead to two guest rooms.",
                "Piper's market is a full shop: glass coolers, stocked aisles, and a counter she stands behind.",
                "Piper sells seeds, bread, stew, pie, and satchel upgrades (+5 slots, five times). Eat food from the hotbar.",
                "The fishing pole is hotbar 9. Cast from Finn's dock or the shoreline into the sea only.",
                "Finn buys saltwater fish in the dock house. River and pond water are not the sea.",
                "Saltwind Beach is a long shore of wind-rippled sand. E picks up cockles, scallops, whelks, sand dollars, conches, and seaweed. Ship them from the bin.",
                "Walk west through the Forbidden Woods into Moonveil Grove: dark oak, pine, a moonlit pool, and fireflies.",
                "Shift+C mills 1 wooden plank from 10 wood, or ask Ash at the village forge. Press 2 at his bench for an overhead of Harvest Hollow to move cottages and outbuildings. R rotates a building 90. Right-click cancels a pick. E a ruined building to spend planks (coop 6, greenhouse 10, barn 16). A satchel starts with 100 planks for testing.",
                "The greenhouse is a packed Cute Fantasy glasshouse outside. Inside it is 24 tiles long, with brick walls, a glass roof, and two soil beds.",
                "Hayfields on Harvest Hollow grow tall gold grass. The scythe cuts hay. E the silo to store it (240) or take it back.",
                "Bess sells chickens, rabbits, sheep, pigs, cows, and horses. Place them on the farm from the hotbar. E packs one back up. Two cows and two sheep graze by the barn.",
                "Hold a milk pail (one starts in the satchel, or craft one at Ash from 4 planks) and press E on a cow to milk. One bottle a day; ship it from the bin (90g). Already milked cows wait until morning. E still packs other stock; hold a livestock crate and E to pack a cow.",
                "Hold shears (one starts in the satchel, or craft them at Ash from 3 planks, key 4) and press E on a woolly sheep. Wool grows back the next morning and ships for 48g. Hold a crate and E to pack a sheep.",
                "Chop trees for wood. They fall, and a stump stays. C crafts 1 fence from 1 wood. Place it from the hotbar. E picks it up.",
                "Pickaxe is in the satchel. Mine roadside stone. Sparkling veins on Ridge Summit and in Ridge Hollow drop ore.",
                "Ridge Hollow is a 100-floor labyrinth. Bats, slimes, and spiders join the trolls as you go deeper. Vaults stay quiet.",
                "Veins give 1-10 gold ore, silver ore, or geodes, with a rare chance of diamond, emerald, sapphire, or jade.",
                "Hit the dummy by the cottage to train Attack. A sword is in the satchel for cave bats, slimes, spiders, and trolls.",
                "K opens skills. Wood, stone, and cave beasts grant XP. Level-ups award a skill point to spend.",
                "The farmer walks on a four-step cycle. Space or click winds up, then strikes, with the tool in the swinging hand.",
                "F4 opens the admin spawn menu (testing). Type to filter, ENTER puts the selected item in your bag. Click MAP EDITOR to paint the valley, move or stamp trees, buildings, and placeables, and place invisible walls.",
                "ESC opens settings. H handbook. F3 infinite energy (testing). F4 admin spawn. 1 hoe  2 can  3 scythe  4 axe  5-8 seeds  9 pole   I bag   K skills"
            };
            for (int i = 0; i < lines.Length; i++)
                _font.Draw(_spriteBatch, lines[i], vw / 2 - 360, vh / 2 - 44 + i * 20, Color.White, 2);
        }

        private void OpenAdmin()
        {
            _world.Screen = Screen.Admin;
            _adminFilter = "";
            _adminSel = 0;
            _adminScroll = 0;
            _adminQty = 1;
            RebuildAdminList();
        }

        private void RebuildAdminList()
        {
            _adminItems.Clear();
            ItemDef[] all = ItemCatalog.All;
            if (all == null)
                return;
            string f = _adminFilter ?? "";
            f = f.ToLowerInvariant();
            for (int i = 0; i < all.Length; i++)
            {
                ItemDef d = all[i];
                if (d == null || string.IsNullOrEmpty(d.Id))
                    continue;
                if (f.Length > 0)
                {
                    string name = d.Name ?? "";
                    if (name.ToLowerInvariant().IndexOf(f) < 0 && d.Id.ToLowerInvariant().IndexOf(f) < 0)
                        continue;
                }
                _adminItems.Add(d);
            }
            if (_adminSel >= _adminItems.Count)
                _adminSel = _adminItems.Count - 1;
            if (_adminSel < 0)
                _adminSel = 0;
        }

        private static int AdminVisibleRows()
        {
            return 16;
        }

        private void AdminKeepVisible()
        {
            int vis = AdminVisibleRows();
            if (_adminSel < _adminScroll)
                _adminScroll = _adminSel;
            if (_adminSel >= _adminScroll + vis)
                _adminScroll = _adminSel - vis + 1;
            if (_adminScroll < 0)
                _adminScroll = 0;
        }

        private void AdminMove(int delta)
        {
            if (_adminItems.Count == 0)
                return;
            _adminSel += delta;
            if (_adminSel < 0)
                _adminSel = 0;
            if (_adminSel >= _adminItems.Count)
                _adminSel = _adminItems.Count - 1;
            AdminKeepVisible();
        }

        private void AdminSpawn(KeyboardState keys)
        {
            if (_adminItems.Count == 0 || _adminSel < 0 || _adminSel >= _adminItems.Count)
                return;
            ItemDef d = _adminItems[_adminSel];
            if (d == null || string.IsNullOrEmpty(d.Id))
                return;
            int n = _adminQty;
            if (keys.IsKeyDown(Keys.LeftShift) || keys.IsKeyDown(Keys.RightShift))
                n = 10;
            if (n < 1)
                n = 1;
            int before = _world.CountItem(d.Id);
            _world.AddItem(d.Id, n);
            int after = _world.CountItem(d.Id);
            if (after > before)
            {
                string name = string.IsNullOrEmpty(d.Name) ? d.Id : d.Name;
                _world.ShowToast("Spawned " + name + ".");
            }
        }

        private static char AdminTypeChar(Keys key)
        {
            if (key >= Keys.A && key <= Keys.Z)
            {
                if (key == Keys.W || key == Keys.S)
                    return '\0';
                return (char)('a' + (key - Keys.A));
            }
            if (key >= Keys.D0 && key <= Keys.D9)
                return (char)('0' + (key - Keys.D0));
            if (key >= Keys.NumPad0 && key <= Keys.NumPad9)
                return (char)('0' + (key - Keys.NumPad0));
            if (key == Keys.OemPeriod || key == Keys.Decimal)
                return '.';
            if (key == Keys.Space)
                return ' ';
            return '\0';
        }

        private char ReadAdminFilterChar(KeyboardState keys)
        {
            for (int i = 0; i < 26; i++)
            {
                char ch = AdminTypeChar(Keys.A + i);
                if (ch != '\0' && Pressed(keys, Keys.A + i))
                    return ch;
            }
            for (int i = 0; i < 10; i++)
            {
                if (Pressed(keys, Keys.D0 + i) || Pressed(keys, Keys.NumPad0 + i))
                    return (char)('0' + i);
            }
            if (Pressed(keys, Keys.OemPeriod) || Pressed(keys, Keys.Decimal))
                return '.';
            if (Pressed(keys, Keys.Space))
                return ' ';
            return '\0';
        }

        private void AdminLayout(int vw, int vh, out int bx, out int by, out int boxW, out int boxH, out int listY)
        {
            boxW = 920;
            boxH = 560;
            bx = (vw - boxW) / 2;
            by = (vh - boxH) / 2;
            listY = by + 118;
        }

        private void AdminEditorBtn(int bx, int by, out int x, out int y, out int w, out int h)
        {
            x = bx + 24;
            y = by + 42;
            w = 196;
            h = 26;
        }

        private bool AdminEditorHit(int mx, int my, int bx, int by)
        {
            int x, y, w, h;
            AdminEditorBtn(bx, by, out x, out y, out w, out h);
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }

        private void OpenMapEditor()
        {
            if (_net != null && _net.IsClient)
            {
                _world.ShowToast("The host has to open the map editor.");
                return;
            }
            _editPick = null;
            _editTool = MapEditTool.Move;
            _editBrush = 1;
            _editPaint = TileType.Grass;
            _editPainting = false;
            _editStroke = null;
            _editUndo.Clear();
            _editStamp = 0;
            _editStampRot = 0;
            _editStampScroll = 0;
            int vw = GraphicsDevice.Viewport.Width;
            int vh = GraphicsDevice.Viewport.Height;
            _editCam.X = _world.PlayerPos.X - vw / (float)Scale / 2f;
            _editCam.Y = _world.PlayerPos.Y - vh / (float)Scale / 2f;
            ClampEditCam(vw, vh);
            _world.BeginMapEdit();
        }

        private void ClampEditCam(int vw, int vh)
        {
            float viewW = vw / Scale;
            float viewH = vh / Scale;
            float maxX = GameConst.MapW * GameConst.Tile - viewW;
            float maxY = GameConst.MapH * GameConst.Tile - viewH;
            if (maxX < 0) maxX = 0;
            if (maxY < 0) maxY = 0;
            if (_editCam.X < 0) _editCam.X = 0;
            if (_editCam.Y < 0) _editCam.Y = 0;
            if (_editCam.X > maxX) _editCam.X = maxX;
            if (_editCam.Y > maxY) _editCam.Y = maxY;
        }

        private void UpdateAdmin(KeyboardState keys, MouseState mouse, int vw, int vh)
        {
            int vis = AdminVisibleRows();
            if (Pressed(keys, Keys.Down) || Pressed(keys, Keys.S))
                AdminMove(1);
            if (Pressed(keys, Keys.Up) || Pressed(keys, Keys.W))
                AdminMove(-1);
            if (Pressed(keys, Keys.PageDown))
                AdminMove(vis);
            if (Pressed(keys, Keys.PageUp))
                AdminMove(-vis);
            if (Pressed(keys, Keys.Home))
            {
                _adminSel = 0;
                AdminKeepVisible();
            }
            if (Pressed(keys, Keys.End) && _adminItems.Count > 0)
            {
                _adminSel = _adminItems.Count - 1;
                AdminKeepVisible();
            }
            int wheel = mouse.ScrollWheelValue - _prevMouse.ScrollWheelValue;
            if (wheel > 0)
                AdminMove(-1);
            else if (wheel < 0)
                AdminMove(1);
            if (Pressed(keys, Keys.Left))
            {
                _adminQty--;
                if (_adminQty < 1)
                    _adminQty = 1;
            }
            if (Pressed(keys, Keys.Right))
            {
                _adminQty++;
                if (_adminQty > 99)
                    _adminQty = 99;
            }
            if (Pressed(keys, Keys.Back) && _adminFilter.Length > 0)
            {
                _adminFilter = _adminFilter.Substring(0, _adminFilter.Length - 1);
                RebuildAdminList();
                AdminKeepVisible();
            }
            char ch = ReadAdminFilterChar(keys);
            if (ch != '\0')
            {
                if (_adminFilter.Length < 24)
                    _adminFilter += ch;
                RebuildAdminList();
                AdminKeepVisible();
            }
            if (Pressed(keys, Keys.Enter))
                AdminSpawn(keys);

            int bx, by, boxW, boxH, listY;
            AdminLayout(vw, vh, out bx, out by, out boxW, out boxH, out listY);
            int rowH = 22;
            if (Clicked(mouse))
            {
                int mx = mouse.X;
                int my = mouse.Y;
                if (AdminEditorHit(mx, my, bx, by))
                {
                    OpenMapEditor();
                    return;
                }
                if (mx >= bx + 24 && mx < bx + boxW - 24 && my >= listY && my < listY + vis * rowH)
                {
                    int hit = (my - listY) / rowH + _adminScroll;
                    if (hit >= 0 && hit < _adminItems.Count)
                    {
                        _adminSel = hit;
                        AdminKeepVisible();
                        AdminSpawn(keys);
                    }
                }
            }
        }

        private void DrawAdmin(int vw, int vh)
        {
            Fill(0, 0, vw, vh, new Color(10, 8, 14, 150));
            int bx, by, boxW, boxH, listY;
            AdminLayout(vw, vh, out bx, out by, out boxW, out boxH, out listY);
            Panel(bx, by, boxW, boxH);
            string title = "ADMIN SPAWN";
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, by + 16, new Color(232, 197, 71), 3);
            int ebx, eby, ebw, ebh;
            AdminEditorBtn(bx, by, out ebx, out eby, out ebw, out ebh);
            MouseState ms = Mouse.GetState();
            bool ehot = AdminEditorHit(ms.X, ms.Y, bx, by);
            Fill(ebx, eby, ebw, ebh, ehot ? new Color(72, 48, 34) : new Color(42, 32, 28));
            DrawRect(ebx, eby, ebw, ebh, ehot ? new Color(232, 197, 71) : new Color(176, 148, 96));
            string ebtn = "MAP EDITOR";
            _font.Draw(_spriteBatch, ebtn, ebx + ebw / 2 - _font.Measure(ebtn, 2) / 2, eby + 6, ehot ? new Color(244, 228, 166) : Color.White, 2);
            string sub = "TESTING";
            _font.Draw(_spriteBatch, sub, bx + boxW - 28 - _font.Measure(sub, 2), eby + 6, new Color(196, 165, 116), 2);

            string find = _adminFilter.Length == 0 ? "FIND  (type to filter)" : "FIND  " + _adminFilter;
            _font.Draw(_spriteBatch, find, bx + 28, by + 72, Color.White, 2);
            string qty = "COUNT  " + _adminQty.ToString() + "   SHIFT spawns 10";
            _font.Draw(_spriteBatch, qty, bx + boxW - 28 - _font.Measure(qty, 2), by + 72, new Color(196, 165, 116), 2);

            int rowH = 22;
            int vis = AdminVisibleRows();
            if (_adminItems.Count == 0)
            {
                ItemDef[] all = ItemCatalog.All;
                string empty = (all == null || all.Length == 0) ? "No items in the catalog." : "No items match.";
                _font.Draw(_spriteBatch, empty, vw / 2 - _font.Measure(empty, 2) / 2, listY + 48, new Color(196, 165, 116), 2);
            }
            else
            {
                int n = _adminItems.Count < _adminScroll + vis ? _adminItems.Count : _adminScroll + vis;
                for (int i = _adminScroll; i < n; i++)
                {
                    ItemDef d = _adminItems[i];
                    int y = listY + (i - _adminScroll) * rowH;
                    bool on = i == _adminSel;
                    if (on)
                        Fill(bx + 20, y - 2, boxW - 40, rowH, new Color(61, 42, 31, 180));
                    string name = d != null && !string.IsNullOrEmpty(d.Name) ? d.Name : "(unnamed)";
                    string id = d != null && !string.IsNullOrEmpty(d.Id) ? d.Id : "";
                    string line = (on ? "> " : "  ") + name;
                    Color c = on ? new Color(232, 197, 71) : Color.White;
                    _font.Draw(_spriteBatch, line, bx + 28, y, c, 2);
                    if (id.Length > 0)
                        _font.Draw(_spriteBatch, id, bx + boxW - 28 - _font.Measure(id, 2), y, new Color(196, 165, 116), 2);
                }
            }

            string foot = "MAP EDITOR button   WS/ARROWS move   ENTER spawn   F4/ESC close";
            _font.Draw(_spriteBatch, foot, vw / 2 - _font.Measure(foot, 2) / 2, by + boxH - 32, new Color(196, 165, 116), 2);
        }

        private void DrawSkills(int vw, int vh)
        {
            Fill(0, 0, vw, vh, new Color(10, 8, 14, 150));
            int boxW = 520;
            int boxH = 280;
            int bx = (vw - boxW) / 2;
            int by = (vh - boxH) / 2 - 20;
            Panel(bx, by, boxW, boxH);
            string title = "SKILLS";
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, by + 18, new Color(232, 197, 71), 3);
            string pts = _world.Skills.Points.ToString() + " skill point" + (_world.Skills.Points == 1 ? "" : "s") + " to spend";
            _font.Draw(_spriteBatch, pts, vw / 2 - _font.Measure(pts, 2) / 2, by + 48, new Color(176, 208, 255), 2);
            for (int i = 0; i < SkillSet.Count; i++)
            {
                int y = by + 84 + i * 52;
                bool on = _skillRow == i;
                Color c = on ? new Color(232, 197, 71) : Color.White;
                string name = (on ? "> " : "  ") + SkillSet.Names[i] + "  Lv " + _world.Skills.Level[i].ToString();
                _font.Draw(_spriteBatch, name, bx + 28, y, c, 2);
                int need = _world.Skills.Need(i);
                int xp = _world.Skills.Xp[i];
                Fill(bx + 28, y + 22, 360, 12, new Color(61, 42, 31));
                int fill = need <= 0 ? 360 : (int)(360f * xp / need);
                if (fill > 360) fill = 360;
                Fill(bx + 30, y + 24, Math.Max(0, fill - 4), 8, new Color(126, 192, 106));
                string bar = need <= 0 ? "MAX" : xp.ToString() + " / " + need.ToString() + " xp";
                _font.Draw(_spriteBatch, bar, bx + 400, y + 20, new Color(196, 165, 116), 1);
            }
            string hint = "ENTER spends a point. Chop wood, mine stone, or hit the dummy for XP. K closes.";
            _font.Draw(_spriteBatch, hint, vw / 2 - _font.Measure(hint, 2) / 2, by + boxH - 32, new Color(196, 165, 116), 2);
        }

        private void DrawBagCharacter(int x, int y, int w, int h)
        {
            Panel(x, y, w, h);
            string title = "FARMER";
            _font.Draw(_spriteBatch, title, x + w / 2 - _font.Measure(title, 3) / 2, y + 12, new Color(232, 197, 71), 3);

            string name = "You";
            if (_net != null && _net.Active)
            {
                FarmerPeer me = _net.Peers[_net.LocalSlot];
                if (me != null && !string.IsNullOrEmpty(me.Name))
                    name = me.Name;
            }
            Texture2D farmer = _assets.PlayerFrame(_world.Look, 0, 0);
            float scale = 2.15f;
            int fw = (int)(farmer.Width * scale);
            int fh = (int)(farmer.Height * scale);
            int px = x + 18;
            int py = y + 44;
            Fill(px, py, 92, 118, new Color(26, 21, 32, 220));
            DrawRect(px, py, 92, 118, new Color(139, 94, 60));
            _spriteBatch.Draw(farmer, new Rectangle(px + 46 - fw / 2, py + 112 - fh, fw, fh), Color.White);

            int tx = px + 104;
            int ty = py + 6;
            _font.Draw(_spriteBatch, name, tx, ty, Color.White, 2);
            _font.Draw(_spriteBatch, _world.Look.Girl ? "Girl" : "Boy", tx, ty + 18, new Color(196, 165, 116), 2);
            _font.Draw(_spriteBatch, _world.Look.PartValue(2), tx, ty + 36, new Color(196, 165, 116), 1);
            _font.Draw(_spriteBatch, _world.Look.PartValue(3), tx, ty + 50, new Color(196, 165, 116), 1);
            _font.Draw(_spriteBatch, _world.Gold.ToString() + "G", tx, ty + 70, new Color(232, 197, 71), 2);
            _font.Draw(_spriteBatch, _world.InfiniteEnergy ? "ENERGY  INF" : "ENERGY", tx, ty + 90, new Color(196, 165, 116), 1);
            Fill(tx, ty + 104, 160, 10, new Color(61, 42, 31));
            int ew = _world.InfiniteEnergy ? 156 : (int)(156f * _world.Energy / GameConst.MaxEnergy);
            Fill(tx + 2, ty + 106, Math.Max(0, ew), 6, _world.InfiniteEnergy ? new Color(232, 197, 71) : new Color(126, 192, 106));

            int infoY = py + 126;
            _font.Draw(_spriteBatch, "Day " + _world.Day.ToString() + "   " + ClockLabel(_world.Minutes), x + 16, infoY, Color.White, 2);
            _font.Draw(_spriteBatch, _world.ZoneName, x + 16, infoY + 18, ZoneColor(_world.ZoneName), 2);

            int skY = y + 236;
            _font.Draw(_spriteBatch, "SKILLS", x + 16, skY - 20, new Color(232, 197, 71), 2);
            string pts = _world.Skills.Points.ToString() + " pt" + (_world.Skills.Points == 1 ? "" : "s");
            _font.Draw(_spriteBatch, pts, x + w - 16 - _font.Measure(pts, 2), skY - 20, new Color(176, 208, 255), 2);
            for (int i = 0; i < SkillSet.Count; i++)
            {
                int rowY = skY + i * 48;
                bool on = _skillRow == i;
                Color c = on ? new Color(232, 197, 71) : Color.White;
                string line = (on ? "> " : "  ") + SkillSet.Names[i] + "  " + _world.Skills.Level[i].ToString();
                _font.Draw(_spriteBatch, line, x + 12, rowY, c, 2);
                int need = _world.Skills.Need(i);
                int xp = _world.Skills.Xp[i];
                int barW = w - 36;
                Fill(x + 16, rowY + 20, barW, 10, new Color(61, 42, 31));
                int fill = need <= 0 ? barW : (int)(barW * (float)xp / need);
                if (fill > barW) fill = barW;
                Fill(x + 18, rowY + 22, Math.Max(0, fill - 4), 6, new Color(126, 192, 106));
                string bar = need <= 0 ? "MAX" : xp.ToString() + "/" + need.ToString();
                _font.Draw(_spriteBatch, bar, x + w - 16 - _font.Measure(bar, 1), rowY + 4, new Color(196, 165, 116), 1);
            }
            string hint = "Click a skill or ENTER to spend a point.";
            _font.Draw(_spriteBatch, hint, x + 14, y + h - 22, new Color(196, 165, 116), 1);
        }

        private void DrawBag(int vw, int vh)
        {
            Fill(0, 0, vw, vh, new Color(10, 8, 14, 150));
            int panelX, panelY, panelW, panelH, gridX, gridY;
            BagLayout(vw, vh, out panelX, out panelY, out panelW, out panelH, out gridX, out gridY);
            DrawBagCharacter(panelX, panelY, panelW, panelH);

            int rows = _world.PackRowsOpen;
            int gridW = GameConst.PackCols * PackSlot + (GameConst.PackCols - 1) * PackGap;
            int gridH = rows * PackSlot + (rows - 1) * PackGap;
            Panel(gridX - 24, gridY - 72, gridW + 48, gridH + 118);
            string title = "SATCHEL";
            int titleX = gridX - 24 + (gridW + 48) / 2;
            _font.Draw(_spriteBatch, title, titleX - _font.Measure(title, 3) / 2, gridY - 56, new Color(232, 197, 71), 3);
            string sub = "Drag to the hotbar. C a fence. Shift+C a plank. I closes.";
            _font.Draw(_spriteBatch, sub, titleX - _font.Measure(sub, 2) / 2, gridY - 28, new Color(196, 165, 116), 2);

            MouseState mouse = Mouse.GetState();
            SlotLoc hover = HitSlot(mouse.X, mouse.Y, vw, vh, true);
            int step = PackSlot + PackGap;
            for (int i = 0; i < _world.PackOpen; i++)
            {
                int col = i % GameConst.PackCols;
                int row = i / GameConst.PackCols;
                int sx = gridX + col * step;
                int sy = gridY + row * step;
                bool drop = _dragging && hover.Valid && !hover.Bar && hover.Index == i;
                Fill(sx, sy, PackSlot, PackSlot, new Color(26, 21, 32, 230));
                DrawRect(sx, sy, PackSlot, PackSlot, drop ? new Color(244, 228, 166) : new Color(139, 94, 60));
                bool dim = _dragging && !_dragFrom.Bar && _dragFrom.Index == i;
                DrawItemInSlot(_world.Pack[i], sx, sy, PackSlot, dim);
            }

            SlotLoc tip = hover;
            if (tip.Valid && !_dragMoved)
            {
                InvSlot slot = _world.SlotAt(tip);
                ItemDef def = slot != null && !slot.Empty ? ItemCatalog.Find(slot.Id) : null;
                if (def != null)
                {
                    string line = def.Name + (slot.Count > 1 ? "  x" + slot.Count.ToString() : "");
                    int tw = _font.Measure(line, 2) + 20;
                    int tx = mouse.X + 16;
                    int ty = mouse.Y + 18;
                    if (tx + tw > vw - 8) tx = vw - tw - 8;
                    Panel(tx, ty, tw, 28);
                    _font.Draw(_spriteBatch, line, tx + 10, ty + 8, Color.White, 2);
                }
            }
        }

        private void DrawDragGhost()
        {
            if (!_dragging || !_dragMoved)
                return;
            InvSlot slot = _world.SlotAt(_dragFrom);
            if (slot == null || slot.Empty)
                return;
            MouseState mouse = Mouse.GetState();
            DrawItemInSlot(slot, mouse.X - 22, mouse.Y - 22, 44, false);
        }

        private void DrawFarmer(int frame, Color tint)
        {
            DrawFarmerAt(_world.PlayerPos, _world.Dir, frame, _world.Moving, _world.Anim,
                _world.SwingT, _world.SwingDur, _world.SwingAct,
                _world.HeldItem() != null && !_world.Bar[_world.Selected].Empty ? _world.HeldItem().Id : "",
                _world.Look, tint, null);
        }

        private void DrawFarmerAt(Vector2 playerPos, int dir, int frame, bool moving, float anim,
            float swingT, float swingDur, string swingAct, string heldId, FarmerLook look, Color tint, string name)
        {
            Texture2D farmer = _assets.PlayerFrame(look, dir, frame);
            Color drawTint = Color.Lerp(Color.White, tint, 0.18f);
            float lungeX = 0f;
            float lungeY = 0f;
            float bob = 0f;
            bool swinging = swingT > 0f && swingDur > 0.0001f;
            if (moving && !swinging)
            {
                int walk = Characters.Pose(true, anim, false, 0f);
                if (walk == Characters.PoseWalk1 || walk == Characters.PoseWalk3)
                    bob = -1.4f;
                else if (walk == Characters.PoseWalk0 || walk == Characters.PoseWalk2)
                    bob = 0.6f;
            }
            if (swinging)
            {
                float u = 1f - swingT / swingDur;
                float reach = u < 0.45f ? u / 0.45f : Math.Max(0f, 1f - (u - 0.45f) / 0.55f);
                float power = 2.2f;
                if (swingAct == "pick" || swingAct == "hoe")
                    power = 2.8f;
                else if (swingAct == "slash" || swingAct == "scythe")
                    power = 3.2f;
                else if (swingAct == "water" || swingAct == "milk")
                    power = 1.2f;
                else if (swingAct == "fish")
                    power = 1.6f;
                reach *= power;
                if (dir == 1) lungeX = -reach;
                else if (dir == 2) lungeX = reach;
                else if (dir == 3) lungeY = -reach * (swingAct == "pick" || swingAct == "hoe" ? 0.4f : 1f);
                else lungeY = reach * (swingAct == "slash" ? 0.45f : 1f);
            }
            Vector2 feet = new Vector2(playerPos.X + lungeX, playerPos.Y + lungeY);
            float cs = GameConst.CharScale;
            float fw = farmer.Width * cs;
            float fh = farmer.Height * cs;
            _spriteBatch.Draw(_assets.CharShadow, new Vector2(feet.X - _assets.CharShadow.Width * cs / 2f, playerPos.Y - 3),
                null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
            Vector2 farmerPos = new Vector2(feet.X - fw / 2f, feet.Y - fh + 2 + bob);
            bool toolBehind = dir == 3;
            if (toolBehind)
                DrawHeldAt(farmerPos, dir, heldId, swinging, moving, anim, swingT, swingDur, swingAct);
            _spriteBatch.Draw(farmer, farmerPos, null, drawTint, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
            if (!toolBehind)
                DrawHeldAt(farmerPos, dir, heldId, swinging, moving, anim, swingT, swingDur, swingAct);
            if (!string.IsNullOrEmpty(name))
            {
                int nw = _font.Measure(name, 1);
                _font.Draw(_spriteBatch, name, (int)(playerPos.X - nw / 2f), (int)(farmerPos.Y - 10), tint, 1);
            }
        }

        private void DrawHeldAt(Vector2 farmerPos, int dir, string heldId, bool swinging, bool moving, float anim,
            float swingT, float swingDur, string swingAct)
        {
            ItemDef held = ItemCatalog.Find(heldId);
            if (held == null)
                return;
            float u = swinging && swingDur > 0.0001f ? 1f - swingT / swingDur : 0f;
            Texture2D model = _assets.HeldToolFrame(held, swinging ? swingAct : "", u);
            if (model == null || model == _assets.Pixel)
                return;
            Vector2 grip = _assets.HeldGrip(held);
            float hx, hy, restAng;
            HandAnchor(dir, held, out hx, out hy, out restAng);
            float wobble = 0f;
            if (!swinging && moving)
                wobble = (float)Math.Sin(anim * 14f) * 0.10f;
            float ang = restAng + wobble;
            float ox = 0f;
            float oy = 0f;
            float scaleMul = 1f;
            if (swinging)
                ToolMotion(held, dir, swingAct, u, out ang, out ox, out oy, out scaleMul);
            float scale = GameConst.ToolScale * scaleMul;
            SpriteEffects flip = dir == 1 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;
            float cs = GameConst.CharScale;
            Vector2 pos = new Vector2(farmerPos.X + (hx + ox) * cs, farmerPos.Y + (hy + oy) * cs);
            _spriteBatch.Draw(model, pos, null, Color.White, ang, grip, scale, flip, 0f);
            Vector2 handOrigin = new Vector2(_assets.HeldHand.Width / 2f, _assets.HeldHand.Height / 2f);
            _spriteBatch.Draw(_assets.HeldHand, pos, null, Color.White, ang * 0.10f, handOrigin, GameConst.HandScale, flip, 0f);
        }

        private void DrawHeldItem(Vector2 farmerPos, Texture2D farmer)
        {
            ItemDef held = _world.HeldItem();
            if (held == null || _world.Bar[_world.Selected].Empty)
                return;
            DrawHeldAt(farmerPos, _world.Dir, held.Id, _world.Swinging, _world.Moving, _world.Anim,
                _world.SwingT, _world.SwingDur, _world.SwingAct);
        }

        private float WalkWobble()
        {
            if (_world.Swinging || !_world.Moving)
                return 0f;
            return (float)Math.Sin(_world.Anim * 14f) * 0.12f;
        }

        private float SwingAngle(ItemDef held)
        {
            float ang, ox, oy, sm;
            ToolMotion(held, _world.Dir, _world.SwingAct, _world.SwingU, out ang, out ox, out oy, out sm);
            return ang;
        }

        static void ToolMotion(ItemDef held, int dir, string act, float u, out float ang, out float ox, out float oy, out float scaleMul)
        {
            float hx, hy, rest;
            HandAnchor(dir, held, out hx, out hy, out rest);
            float side = dir == 1 ? 1f : -1f;
            if (dir == 0)
                side = -1f;
            if (dir == 3)
                side = 1f;
            ox = 0f;
            oy = 0f;
            scaleMul = 1f;
            ang = rest;
            if (act == "water" || act == "milk")
            {
                float pour = (float)Math.Sin(Math.Min(1f, u * 1.2f) * Math.PI);
                ang = rest + side * (0.2f + pour * 1.35f);
                ox = side * -pour * 3f;
                oy = pour * 5f;
                return;
            }
            if (act == "shear")
            {
                float snip = (float)Math.Sin(u * Math.PI * 2.0);
                ang = rest + side * (0.12f + Math.Abs(snip) * 0.55f);
                ox = side * snip * 1.5f;
                oy = 2f * (float)Math.Sin(u * Math.PI);
                scaleMul = 1f + 0.06f * Math.Abs(snip);
                return;
            }
            if (act == "eat")
            {
                ang = rest + (float)Math.Sin(u * 16f) * 0.18f + side * 0.12f * (float)Math.Sin(u * Math.PI);
                oy = -8f * (float)Math.Sin(u * Math.PI);
                return;
            }
            if (act == "plant")
            {
                float dip = (float)Math.Sin(u * Math.PI);
                ang = rest + (float)Math.Sin(u * 22f) * 0.22f + side * 0.18f * dip;
                oy = dip * 6f;
                return;
            }
            if (act == "harvest")
            {
                float pull = SmoothStrike(u);
                ang = rest + side * (-0.25f + 1.15f * pull);
                oy = -2f + pull * 4f;
                return;
            }
            if (act == "fish")
            {
                float lift = u < 0.28f ? u / 0.28f : (u < 0.72f ? 1f : 1f - (u - 0.72f) / 0.28f);
                ang = rest + side * (-0.55f + lift * 1.85f);
                ox = side * (1f - lift) * 4f;
                oy = -lift * 5f;
                return;
            }
            if (act == "pick")
            {
                float arc = SmoothStrike(u);
                ang = rest + side * (-1.35f + 2.55f * arc);
                oy = -4f + arc * 10f;
                ox = side * -arc * 2f;
                return;
            }
            if (act == "hoe")
            {
                float arc = SmoothStrike(u);
                ang = rest + side * (-1.05f + 2.4f * arc);
                oy = -2f + arc * 8f;
                return;
            }
            if (act == "slash")
            {
                float arc = SmoothStrike(u);
                ang = rest + side * (-1.45f + 2.85f * arc);
                ox = side * (-3f + 8f * arc);
                oy = (float)Math.Sin(arc * Math.PI) * 3f;
                return;
            }
            if (act == "scythe")
            {
                float arc = SmoothStrike(u);
                ang = rest + side * (-1.35f + 2.7f * arc);
                ox = side * (-2f + 7f * arc);
                return;
            }
            float chop = SmoothStrike(u);
            ang = rest + side * (-1.15f + 2.35f * chop);
            oy = -3f + chop * 6f;
        }

        static float SmoothStrike(float u)
        {
            if (u <= 0.28f)
                return 0.15f * (u / 0.28f);
            if (u <= 0.48f)
                return 0.15f + 0.85f * ((u - 0.28f) / 0.20f);
            return 1f - 0.35f * ((u - 0.48f) / 0.52f);
        }

        static void HandAnchor(int dir, ItemDef held, out float hx, out float hy, out float rest)
        {
            bool bucket = held != null && held.Kind == ItemKind.Tool
                && (held.Tool == ToolId.Can || held.Tool == ToolId.MilkPail);
            bool rod = held != null && held.Kind == ItemKind.Tool && held.Tool == ToolId.Rod;
            bool shears = held != null && held.Kind == ItemKind.Tool && held.Tool == ToolId.Shears;
            if (dir == 1)
            {
                hx = bucket ? 8f : 7f;
                hy = bucket ? 30f : (rod ? 26f : 28f);
                rest = shears ? 0.25f : 0.42f;
            }
            else if (dir == 2)
            {
                hx = bucket ? 24f : 25f;
                hy = bucket ? 30f : (rod ? 26f : 28f);
                rest = shears ? -0.22f : -0.38f;
            }
            else if (dir == 3)
            {
                hx = 11f;
                hy = rod ? 24f : 26f;
                rest = -0.52f;
            }
            else
            {
                hx = 22f;
                hy = bucket ? 31f : 30f;
                rest = 0.48f;
            }
        }

        private void TickToolFx(float dt)
        {
            float u = _world.Swinging ? _world.SwingU : 0f;
            if (_world.Swinging && _prevSwingU < 0.42f && u >= 0.42f)
                BurstToolFx();
            if (_world.Swinging && (_world.SwingAct == "water" || _world.SwingAct == "milk") && u > 0.22f && u < 0.78f)
                DripWater();
            if (_world.Swinging && _world.SwingAct == "plant" && u > 0.2f && u < 0.7f && (_rng.Next(3) == 0))
                BurstSeeds();
            _prevSwingU = _world.Swinging ? u : 0f;

            for (int i = 0; i < _sparks.Length; i++)
            {
                if (_sparks[i].Life <= 0f)
                    continue;
                _sparks[i].Life -= dt;
                _sparks[i].Pos += _sparks[i].Vel * dt;
                _sparks[i].Vel.Y += 42f * dt;
            }
        }

        private void BurstToolFx()
        {
            float cx = _world.Face.X * GameConst.Tile + GameConst.Tile / 2;
            float cy = _world.Face.Y * GameConst.Tile + 20;
            string act = _world.SwingAct;
            if (act == "hoe")
                Spray(cx, cy, 10, new Color(138, 92, 52), new Color(196, 150, 96), 28f);
            else if (act == "chop")
                Spray(cx, cy - 4, 12, new Color(118, 74, 42), new Color(176, 118, 62), 36f);
            else if (act == "pick")
                Spray(cx, cy - 2, 14, new Color(168, 168, 176), new Color(220, 220, 228), 40f);
            else if (act == "slash")
                Spray(cx, cy - 6, 10, new Color(236, 240, 246), new Color(180, 196, 210), 44f);
            else if (act == "scythe")
                Spray(cx, cy, 8, new Color(236, 232, 210), new Color(180, 210, 120), 40f);
            else if (act == "harvest")
                Spray(cx, cy - 2, 10, new Color(255, 220, 80), new Color(255, 244, 180), 24f);
            else if (act == "fish")
                Spray(cx, cy + 4, 14, new Color(72, 156, 196), new Color(232, 244, 248), 32f);
            else if (act == "milk")
                Spray(cx, cy, 8, new Color(250, 248, 236), new Color(232, 214, 170), 22f);
            else if (act == "shear")
                Spray(cx, cy - 2, 8, new Color(236, 222, 196), new Color(196, 180, 150), 26f);
        }

        private void BurstSeeds()
        {
            float cx = _world.Face.X * GameConst.Tile + GameConst.Tile / 2;
            float cy = _world.Face.Y * GameConst.Tile + 12;
            ItemDef held = _world.HeldItem();
            Color a = new Color(150, 96, 52);
            Color b = new Color(196, 150, 36);
            if (held != null)
            {
                CropDef crop = CropCatalog.Find(held.CropId);
                if (crop != null)
                {
                    a = crop.Fruit;
                    b = crop.Leaf;
                }
            }
            Spray(cx, cy, 2, a, b, 18f);
        }

        private void DripWater()
        {
            float hx, hy, rest;
            ItemDef held = _world.HeldItem();
            if (held == null)
                return;
            Texture2D farmer = _assets.PlayerFrame(_world.Look, _world.Dir, 0);
            HandAnchor(_world.Dir, held, out hx, out hy, out rest);
            float cs = GameConst.CharScale;
            Vector2 farmerPos = new Vector2(
                _world.PlayerPos.X - farmer.Width * cs / 2f,
                _world.PlayerPos.Y - farmer.Height * cs + 3);
            float sx = farmerPos.X + hx * cs;
            float sy = farmerPos.Y + hy * cs + 2;
            float tx = _world.Face.X * GameConst.Tile + GameConst.Tile / 2 - sx;
            float ty = _world.Face.Y * GameConst.Tile + GameConst.Tile / 2 - sy;
            SpawnSpark(sx, sy, tx * 1.6f + (_rng.Next(11) - 5), ty * 1.6f + 12f + _rng.Next(8),
                new Color(72, 156, 210), 1.2f, 0.35f);
        }

        private void Spray(float x, float y, int n, Color a, Color b, float speed)
        {
            for (int i = 0; i < n; i++)
            {
                float ang = (float)(_rng.NextDouble() * Math.PI - Math.PI * 0.5);
                float sp = speed * (0.45f + (float)_rng.NextDouble());
                Color c = (_rng.Next(2) == 0) ? a : b;
                SpawnSpark(x, y, (float)Math.Cos(ang) * sp, (float)Math.Sin(ang) * sp - 8f, c, 1.1f, 0.28f + (float)_rng.NextDouble() * 0.18f);
            }
        }

        private void SpawnSpark(float x, float y, float vx, float vy, Color color, float size, float life)
        {
            _sparkAt = (_sparkAt + 1) % _sparks.Length;
            _sparks[_sparkAt].Pos = new Vector2(x, y);
            _sparks[_sparkAt].Vel = new Vector2(vx, vy);
            _sparks[_sparkAt].Color = color;
            _sparks[_sparkAt].Size = size;
            _sparks[_sparkAt].Life = life;
            _sparks[_sparkAt].Max = life;
        }

        private void DrawToolFx()
        {
            for (int i = 0; i < _sparks.Length; i++)
            {
                if (_sparks[i].Life <= 0f)
                    continue;
                float a = Math.Max(0f, _sparks[i].Life / _sparks[i].Max);
                Color c = _sparks[i].Color * a;
                float s = _sparks[i].Size * (0.7f + 0.6f * a);
                _spriteBatch.Draw(_assets.Pixel, _sparks[i].Pos, null, c, 0f, Vector2.Zero, s, SpriteEffects.None, 0f);
            }
        }

        private void DrawTrees(bool behindPlayer, float playerSort, int t0x, int t0y, int t1x, int t1y)
        {
            int y0 = Math.Max(0, t0y - 8);
            int x0 = Math.Max(0, t0x - 2);
            int x1 = Math.Min(_world.PlayCols, t1x + 2);
            int y1 = Math.Min(_world.PlayRows, t1y + 1);
            for (int ty = y0; ty < y1; ty++)
            {
                for (int tx = x0; tx < x1; tx++)
                {
                    if (_world.TileAt(tx, ty) != TileType.Tree)
                        continue;
                    if (!_world.ZoneLit(tx, ty))
                        continue;
                    float bottom = (ty + 1) * GameConst.Tile;
                    bool behind = bottom <= playerSort;
                    if (behind != behindPlayer)
                        continue;
                    DrawOneTree(tx, ty);
                }
            }
            for (int i = 0; i < _world.FallingTrees.Count; i++)
            {
                FallingTree fall = _world.FallingTrees[i];
                if (fall.Tx < x0 - 2 || fall.Tx >= x1 + 2 || fall.Ty < y0 || fall.Ty >= y1 + 2)
                    continue;
                if (!_world.ZoneLit(fall.Tx, fall.Ty))
                    continue;
                float bottom = (fall.Ty + 1) * GameConst.Tile;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                DrawFallingTree(fall);
            }
        }

        private struct TreeDraw
        {
            public bool Packed;
            public Texture2D PackedTex;
            public Texture2D Trunk;
            public Texture2D Canopy;
            public float PackedX;
            public float PackedY;
            public float TrunkX;
            public float TrunkY;
            public float CanopyX;
            public float CanopyY;
            public float Phase;
            public float Sway;
            public Color TrunkTint;
            public Color LeafTint;
            public float StumpX;
            public float StumpY;
        }

        private TreeDraw MakeTreeDraw(int tx, int ty)
        {
            TreeDraw d = new TreeDraw();
            int v = (tx * 5 + ty * 3) & 3;
            TreeKind kind = TreeSpecies.KindAt(tx, ty);
            d.StumpX = tx * GameConst.Tile + GameConst.Tile / 2f;
            d.StumpY = ty * GameConst.Tile + GameConst.Tile - 2f;
            d.TrunkTint = kind == TreeKind.DarkOak ? new Color(92, 72, 86) : Color.White;
            d.LeafTint = kind == TreeKind.DarkOak ? new Color(108, 88, 142) : Color.White;
            d.Phase = tx * 0.73f + ty * 1.11f;
            Texture2D packedTree = _assets.Pack.Tree(kind);
            if (packedTree != null && kind != TreeKind.DarkOak)
            {
                d.Packed = true;
                d.PackedTex = packedTree;
                d.PackedX = tx * GameConst.Tile + GameConst.Tile / 2f - packedTree.Width / 2f;
                d.PackedY = ty * GameConst.Tile + GameConst.Tile - packedTree.Height + 4;
                d.Sway = 0.5f;
                if (kind == TreeKind.Palm)
                    d.Sway = 0.85f;
                else if (kind == TreeKind.Pine || kind == TreeKind.Spruce)
                    d.Sway = 0.16f;
                return d;
            }
            float overlap = 14f;
            d.Sway = 0.55f;
            switch (kind)
            {
                case TreeKind.Pine:
                    d.Trunk = _assets.PineTrunk[v];
                    d.Canopy = _assets.PineNeedles[v];
                    overlap = 20f;
                    d.Sway = 0.18f;
                    break;
                case TreeKind.Spruce:
                    d.Trunk = _assets.PineTrunk[(v + 1) & 3];
                    d.Canopy = _assets.SpruceNeedles[v];
                    overlap = 22f;
                    d.Sway = 0.14f;
                    break;
                case TreeKind.Willow:
                    d.Trunk = _assets.FarmTrunk[v];
                    d.Canopy = _assets.WillowCanopy[v];
                    overlap = 18f;
                    d.Sway = 0.72f;
                    break;
                case TreeKind.Blossom:
                    d.Trunk = _assets.FarmTrunk[v];
                    d.Canopy = _assets.BlossomCanopy[v];
                    overlap = 14f;
                    d.Sway = 0.5f;
                    break;
                case TreeKind.Birch:
                    d.Trunk = _assets.FarmTrunk[v];
                    d.Canopy = _assets.BirchCanopy[v];
                    overlap = 12f;
                    d.Sway = 0.6f;
                    break;
                case TreeKind.Oak:
                    d.Trunk = _assets.WoodsTrunk[v];
                    d.Canopy = _assets.OakCanopy[v];
                    overlap = 16f;
                    d.Sway = 0.4f;
                    break;
                case TreeKind.Palm:
                    d.Trunk = _assets.PalmTrunk[v];
                    d.Canopy = _assets.PalmFronds[v];
                    overlap = 18f;
                    d.Sway = 0.85f;
                    break;
                case TreeKind.Dead:
                    d.Trunk = _assets.WoodsTrunk[v];
                    d.Canopy = _assets.DeadCrown[v];
                    overlap = 16f;
                    d.Sway = 0.22f;
                    break;
                case TreeKind.Autumn:
                    d.Trunk = _assets.WoodsTrunk[v];
                    d.Canopy = _assets.WoodsCanopy[v];
                    overlap = 14f;
                    d.Sway = 0.42f;
                    break;
                case TreeKind.DarkOak:
                    d.Trunk = _assets.WoodsTrunk[v];
                    d.Canopy = _assets.OakCanopy[v];
                    overlap = 16f;
                    d.Sway = 0.28f;
                    break;
                default:
                    d.Trunk = _assets.FarmTrunk[v];
                    d.Canopy = _assets.FarmCanopy[v];
                    overlap = 14f;
                    d.Sway = 0.55f;
                    break;
            }
            float x = tx * GameConst.Tile;
            float y = ty * GameConst.Tile;
            d.TrunkX = x + GameConst.Tile / 2f - d.Trunk.Width / 2f;
            d.TrunkY = y + GameConst.Tile - d.Trunk.Height + 3;
            d.CanopyX = x + GameConst.Tile / 2f - d.Canopy.Width / 2f;
            d.CanopyY = d.TrunkY - d.Canopy.Height + overlap;
            return d;
        }

        private void DrawOneTree(int tx, int ty)
        {
            TreeDraw d = MakeTreeDraw(tx, ty);
            float x = tx * GameConst.Tile;
            float y = ty * GameConst.Tile;
            _spriteBatch.Draw(_assets.Shadow, new Vector2(x - 4, y + GameConst.Tile - 5), Color.White);
            if (d.Packed)
            {
                DrawPackedTree(d.PackedTex, d.PackedX, d.PackedY, d.Phase, d.Sway);
                return;
            }
            _spriteBatch.Draw(d.Trunk, new Vector2(d.TrunkX, d.TrunkY), d.TrunkTint);
            DrawSwaying(d.Canopy, new Rectangle(0, 0, d.Canopy.Width, d.Canopy.Height),
                d.CanopyX, d.CanopyY, 1f, 1f, d.Phase, d.Sway, d.LeafTint);
        }

        private void DrawFallingTree(FallingTree fall)
        {
            TreeDraw d = MakeTreeDraw(fall.Tx, fall.Ty);
            float u = 1f - fall.Life / fall.Dur;
            if (u < 0f) u = 0f;
            if (u > 1f) u = 1f;
            float ease = u * u * u;
            float ang = fall.Sign * ease * 1.52f;
            float fade = 1f;
            if (u > 0.82f)
                fade = 1f - (u - 0.82f) / 0.18f;
            if (fade < 0f)
                fade = 0f;
            Color trunkTint = d.TrunkTint * fade;
            Color leafTint = d.LeafTint * fade;
            if (d.Packed)
            {
                DrawRotatedSprite(d.PackedTex, d.PackedX, d.PackedY, d.StumpX, d.StumpY, ang, trunkTint);
                return;
            }
            DrawRotatedSprite(d.Trunk, d.TrunkX, d.TrunkY, d.StumpX, d.StumpY, ang, trunkTint);
            DrawRotatedSprite(d.Canopy, d.CanopyX, d.CanopyY, d.StumpX, d.StumpY, ang, leafTint);
        }

        private void DrawRotatedSprite(Texture2D tex, float left, float top, float pivotX, float pivotY, float ang, Color tint)
        {
            if (tex == null)
                return;
            Vector2 origin = new Vector2(pivotX - left, pivotY - top);
            _spriteBatch.Draw(tex, new Vector2(pivotX, pivotY), null, tint, ang, origin, 1f, SpriteEffects.None, 0f);
        }

        private void DrawPackedTree(Texture2D tex, float treeX, float treeY, float phase, float sway)
        {
            int rootH = PackedRootHeight(tex);
            int upperH = tex.Height - rootH;
            if (rootH < 6 || upperH < 16)
            {
                DrawSwaying(tex, treeX, treeY, 1f, 1f, phase, sway);
                return;
            }
            int overlap = 2;
            int rootSrcY = upperH - overlap;
            if (rootSrcY < 0)
                rootSrcY = 0;
            Rectangle rootSrc = new Rectangle(0, rootSrcY, tex.Width, tex.Height - rootSrcY);
            _spriteBatch.Draw(tex, new Vector2(treeX, treeY + rootSrcY), rootSrc, Color.White);
            DrawSwaying(tex, new Rectangle(0, 0, tex.Width, upperH), treeX, treeY, 1f, 1f, phase, sway);
        }

        private int PackedRootHeight(Texture2D tex)
        {
            int cached;
            if (_treeRootH.TryGetValue(tex, out cached))
                return cached;
            Color[] data = new Color[tex.Width * tex.Height];
            tex.GetData(data);
            int bottom = -1;
            int flare = 0;
            for (int y = tex.Height - 1; y >= 0; y--)
            {
                int span = OpaqueSpan(data, tex.Width, y);
                if (span <= 0)
                    continue;
                if (bottom < 0)
                    bottom = y;
                if (span > flare)
                    flare = span;
                if (bottom - y > tex.Height / 3)
                    break;
            }
            int h = Math.Max(8, tex.Height / 10);
            if (bottom >= 0 && flare > 0)
            {
                int cutoff = flare * 62 / 100;
                int run = 0;
                for (int y = bottom; y >= 0 && bottom - y <= tex.Height / 3; y--)
                {
                    int span = OpaqueSpan(data, tex.Width, y);
                    if (span > 0 && span <= cutoff)
                    {
                        run++;
                        if (run >= 2)
                        {
                            h = bottom - y;
                            break;
                        }
                    }
                    else
                        run = 0;
                }
            }
            if (h < 8)
                h = 8;
            if (h > tex.Height / 4)
                h = tex.Height / 4;
            _treeRootH[tex] = h;
            return h;
        }

        static int OpaqueSpan(Color[] data, int w, int y)
        {
            int min = w;
            int max = -1;
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                if (data[row + x].A <= 24)
                    continue;
                if (x < min)
                    min = x;
                if (x > max)
                    max = x;
            }
            return max < 0 ? 0 : max - min + 1;
        }

        private void TickLeaves(float dt)
        {
            float wind = WindStrength();
            if (_world.Inside == null && _world.Screen == Screen.Play)
            {
                _leafSpawn += dt * (1.2f + wind * 1.6f);
                while (_leafSpawn > 0.14f)
                {
                    _leafSpawn -= 0.14f;
                    int tx = (int)(_world.PlayerPos.X / GameConst.Tile) + _rng.Next(19) - 9;
                    int ty = (int)(_world.PlayerPos.Y / GameConst.Tile) + _rng.Next(15) - 7;
                    if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                        continue;
                    if (_world.TileAt(tx, ty) != TileType.Tree || !_world.ZoneLit(tx, ty))
                        continue;
                    TreeKind kind = TreeSpecies.KindAt(tx, ty);
                    if (!TreeSpecies.ShedsLeaves(kind))
                        continue;
                    Color a, b;
                    if (kind == TreeKind.Blossom)
                    {
                        a = new Color(236, 176, 190);
                        b = new Color(248, 214, 220);
                    }
                    else if (kind == TreeKind.Willow)
                    {
                        a = new Color(154, 196, 86);
                        b = new Color(90, 138, 58);
                    }
                    else if (kind == TreeKind.Autumn)
                    {
                        a = new Color(196, 132, 58);
                        b = new Color(148, 88, 40);
                    }
                    else
                    {
                        a = new Color(118, 148, 72);
                        b = new Color(72, 108, 54);
                    }
                    _leaves[_leafAt].Pos = new Vector2(
                        tx * GameConst.Tile + 8 + _rng.Next(16),
                        ty * GameConst.Tile - 36 - _rng.Next(32));
                    _leaves[_leafAt].Vel = new Vector2(-18f - _rng.Next(22), 12f + _rng.Next(16));
                    _leaves[_leafAt].Life = 1.6f + (float)_rng.NextDouble();
                    _leaves[_leafAt].Max = _leaves[_leafAt].Life;
                    _leaves[_leafAt].Rot = (float)_rng.NextDouble() * 6f;
                    _leaves[_leafAt].RotV = (_rng.Next(2) == 0 ? -1f : 1f) * (2.2f + (float)_rng.NextDouble());
                    _leaves[_leafAt].Color = _rng.Next(2) == 0 ? a : b;
                    _leaves[_leafAt].Alive = true;
                    _leafAt = (_leafAt + 1) % _leaves.Length;
                }
            }
            for (int i = 0; i < _leaves.Length; i++)
            {
                if (!_leaves[i].Alive)
                    continue;
                _leaves[i].Life -= dt;
                _leaves[i].Pos += _leaves[i].Vel * dt;
                _leaves[i].Vel.X += WindDirSign() * 8f * dt;
                _leaves[i].Vel.Y += 18f * dt;
                _leaves[i].Rot += _leaves[i].RotV * dt;
                if (_leaves[i].Life <= 0f)
                    _leaves[i].Alive = false;
            }
        }

        private void TickFallingTrees(float dt)
        {
            for (int i = 0; i < _world.FallingTrees.Count; i++)
            {
                FallingTree f = _world.FallingTrees[i];
                if (f.Life >= f.Dur - 0.0001f)
                    BurstFallLeaves(f);
            }
            if (_world.TickFallingTrees(dt))
                _camShake = Math.Max(_camShake, 1.8f);
        }

        private void BurstFallLeaves(FallingTree fall)
        {
            TreeKind kind = TreeSpecies.KindAt(fall.Tx, fall.Ty);
            Color a, b;
            if (kind == TreeKind.Blossom)
            {
                a = new Color(236, 176, 190);
                b = new Color(248, 214, 220);
            }
            else if (kind == TreeKind.Willow)
            {
                a = new Color(154, 196, 86);
                b = new Color(90, 138, 58);
            }
            else if (kind == TreeKind.Autumn)
            {
                a = new Color(196, 132, 58);
                b = new Color(148, 88, 40);
            }
            else if (kind == TreeKind.Pine || kind == TreeKind.Spruce)
            {
                a = new Color(72, 116, 70);
                b = new Color(46, 86, 52);
            }
            else
            {
                a = new Color(118, 148, 72);
                b = new Color(72, 108, 54);
            }
            float cx = fall.Tx * GameConst.Tile + GameConst.Tile / 2f;
            float cy = fall.Ty * GameConst.Tile - 28f;
            for (int n = 0; n < 14; n++)
            {
                _leaves[_leafAt].Pos = new Vector2(cx + _rng.Next(28) - 14, cy - _rng.Next(40));
                _leaves[_leafAt].Vel = new Vector2(fall.Sign * (18f + _rng.Next(40)), 8f + _rng.Next(28));
                _leaves[_leafAt].Life = 0.9f + (float)_rng.NextDouble() * 0.8f;
                _leaves[_leafAt].Max = _leaves[_leafAt].Life;
                _leaves[_leafAt].Rot = (float)_rng.NextDouble() * 6f;
                _leaves[_leafAt].RotV = (_rng.Next(2) == 0 ? -1f : 1f) * (3f + (float)_rng.NextDouble() * 2f);
                _leaves[_leafAt].Color = _rng.Next(2) == 0 ? a : b;
                _leaves[_leafAt].Alive = true;
                _leafAt = (_leafAt + 1) % _leaves.Length;
            }
        }

        private void DrawLeaves()
        {
            for (int i = 0; i < _leaves.Length; i++)
            {
                if (!_leaves[i].Alive)
                    continue;
                float a = Math.Max(0f, _leaves[i].Life / _leaves[i].Max);
                Color c = _leaves[i].Color * a;
                _spriteBatch.Draw(_assets.Pixel, _leaves[i].Pos, null, c, _leaves[i].Rot, new Vector2(0.5f, 0.5f),
                    new Vector2(2.4f, 1.3f), SpriteEffects.None, 0f);
            }
        }

        private void DrawGreenhouseInsideBack()
        {
            Texture2D tex = _assets.GreenhouseInside;
            if (tex == null || _world.Inside == null)
                return;
            int roomW = _world.Inside.Iw * GameConst.Tile;
            float x = (roomW - tex.Width) / 2f;
            float y = GameConst.Tile - tex.Height;
            _spriteBatch.Draw(tex, new Vector2(x, y), Color.White);
        }

        private void DrawHouses(bool behindPlayer, float playerSort)
        {
            for (int i = 0; i < _world.Buildings.Count; i++)
            {
                Building b = _world.Buildings[i];
                float bottom = (b.Y + b.FootH) * GameConst.Tile;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                if (!_world.ZoneLit(b.X, b.Y))
                    continue;
                if (b.Kind == BuildingKind.Barn && DrawBarnDoors(b, bottom))
                    continue;
                Texture2D tex = _assets.HouseSprite(b, _world.DoorLooksOpen(b));
                DrawBuildingSprite(tex, 0, 0, tex.Width, tex.Height, b);
            }
        }

        private bool DrawBarnDoors(Building b, float bottom)
        {
            BarnSprite sheet = b.Repaired ? _assets.BarnOk : _assets.BarnRuin;
            if (sheet == null || sheet.Body == null || sheet.Left == null || sheet.Right == null)
                return false;
            float u = 0f;
            if (_world.DoorSwing == b)
                u = _world.DoorOpenU;
            if (u < 0f)
                u = 0f;
            if (u > 1f)
                u = 1f;
            float ease = u * u * (3f - 2f * u);
            int slide = (int)(ease * sheet.Slide + 0.5f);
            DrawBuildingSprite(sheet.Body, 0, 0, sheet.Body.Width, sheet.Body.Height, b);
            DrawBuildingSprite(sheet.Left, sheet.LeftX - slide, sheet.LeftY, sheet.Body.Width, sheet.Body.Height, b);
            DrawBuildingSprite(sheet.Right, sheet.RightX + slide, sheet.RightY, sheet.Body.Width, sheet.Body.Height, b);
            return true;
        }

        private void DrawBuildingSprite(Texture2D tex, int localX, int localY, int bodyW, int bodyH, Building b)
        {
            if (tex == null)
                return;
            Vector2 pos = BuildingFacadeAnchor(b);
            float ang = (b.Rot & 3) * MathHelper.PiOver2;
            Vector2 origin = new Vector2(bodyW / 2f - localX, bodyH - localY);
            _spriteBatch.Draw(tex, pos, null, Color.White, ang, origin, 1f, SpriteEffects.None, 0f);
        }

        private static Vector2 BuildingFacadeAnchor(Building b)
        {
            float t = GameConst.Tile;
            int r = b.Rot & 3;
            if (r == 0)
                return new Vector2((b.X + b.FootW * 0.5f) * t, (b.Y + b.FootH) * t);
            if (r == 1)
                return new Vector2(b.X * t, (b.Y + b.FootH * 0.5f) * t);
            if (r == 2)
                return new Vector2((b.X + b.FootW * 0.5f) * t, b.Y * t);
            return new Vector2((b.X + b.FootW) * t, (b.Y + b.FootH * 0.5f) * t);
        }

        private void DrawBridges(bool behindPlayer, float playerSort)
        {
            for (int i = 0; i < _world.Bridges.Count; i++)
            {
                StoneBridge b = _world.Bridges[i];
                float bottom = (b.Y + b.H) * GameConst.Tile;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                if (!_world.ZoneLit(b.X, b.Y))
                    continue;
                Texture2D tex = _assets.BridgeSprite(b);
                float x = b.X * GameConst.Tile + (b.W * GameConst.Tile - tex.Width) / 2f;
                float y = bottom - 8;
                _spriteBatch.Draw(tex, new Vector2(x, y), Color.White);
            }
        }

        private void DrawGates(bool behindPlayer, float playerSort)
        {
            for (int i = 0; i < _world.Gates.Count; i++)
            {
                GateSign gs = _world.Gates[i];
                float bottom = (gs.Y + 1) * GameConst.Tile;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                if (!_world.ZoneLit(gs.X, gs.Y))
                    continue;
                int dir = gs.Dir < 0 || gs.Dir > 3 ? 0 : gs.Dir;
                Texture2D tex = _assets.Signpost[dir];
                float x = gs.X * GameConst.Tile;
                float y = bottom - tex.Height;
                _spriteBatch.Draw(tex, new Vector2(x, y), Color.White);
            }
        }

        private void DrawDecos(bool behindPlayer, float playerSort)
        {
            for (int i = 0; i < _world.Decos.Count; i++)
            {
                Deco p = _world.Decos[i];
                float bottom = (p.Y + 1) * GameConst.Tile;
                bool behind = bottom <= playerSort;
                if (behind != behindPlayer)
                    continue;
                if (!_world.ZoneLit(p.X, p.Y))
                    continue;
                Texture2D tex = _assets.Prop(p.Kind);
                float x = p.X * GameConst.Tile + (GameConst.Tile - tex.Width) / 2f;
                float y = bottom - tex.Height;
                _spriteBatch.Draw(_assets.Shadow, new Vector2(p.X * GameConst.Tile + 1, bottom - 5), Color.White);
                _spriteBatch.Draw(tex, new Vector2(x, y), Color.White);
            }
        }

        private void DrawTownsfolk(bool behindPlayer, float playerSort)
        {
            for (int i = 0; i < VillageFolk.Outdoor.Length; i++)
            {
                NpcDef n = VillageFolk.Outdoor[i];
                DrawPerson(_assets.NpcSprite(n.Id), _world.NpcTileX(i), _world.NpcTileY(i), behindPlayer, playerSort);
            }
        }

        private void DrawPerson(Texture2D tex, int tx, int ty, bool behindPlayer, float playerSort)
        {
            if (!_world.ZoneLit(tx, ty))
                return;
            float bottom = (ty + 1) * GameConst.Tile;
            bool behind = bottom <= playerSort;
            if (behind != behindPlayer)
                return;
            float cs = GameConst.CharScale;
            float x = tx * GameConst.Tile + GameConst.Tile / 2f - tex.Width * cs / 2f;
            float y = bottom - tex.Height * cs + 2;
            _spriteBatch.Draw(_assets.CharShadow, new Vector2(tx * GameConst.Tile + GameConst.Tile / 2f - _assets.CharShadow.Width * cs / 2f, bottom - 5),
                null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
            _spriteBatch.Draw(tex, new Vector2(x, y), null, Color.White, 0f, Vector2.Zero, cs, SpriteEffects.None, 0f);
        }

        private static bool InWoods(int tx, int ty)
        {
            return GameConst.InWoods(tx, ty);
        }

        private static Color InteriorClear(Building b)
        {
            if (b.Kind == BuildingKind.Cave)
                return new Color(18, 16, 20);
            if (b.Kind == BuildingKind.Greenhouse)
                return new Color(28, 48, 46);
            if (b.Kind == BuildingKind.Barn)
                return new Color(42, 32, 22);
            if (b.Kind == BuildingKind.Carpenter)
                return new Color(46, 34, 24);
            if (b.Kind == BuildingKind.AnimalShop)
                return new Color(52, 40, 28);
            if (b.Kind == BuildingKind.Coop)
                return new Color(48, 40, 28);
            return new Color(28, 22, 20);
        }

        private static Color ZoneColor(string zone)
        {
            if (zone == "Forbidden Woods")
                return new Color(160, 196, 120);
            if (zone == "Moonveil Grove")
                return new Color(148, 176, 214);
            if (zone == "Mountain Path")
                return new Color(196, 168, 128);
            if (zone == "Ridge Summit")
                return new Color(186, 176, 196);
            if (zone == "Ridge Hollow" || zone.IndexOf("Ridge Hollow", StringComparison.Ordinal) >= 0)
                return new Color(148, 156, 186);
            if (zone == "Hearth Village")
                return new Color(232, 186, 142);
            if (zone == "Meadow Road")
                return new Color(186, 196, 108);
            if (zone == "Saltwind Beach")
                return new Color(232, 196, 138);
            if (zone == "Your Cottage" || zone.IndexOf("Shop", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Inn", StringComparison.Ordinal) >= 0 || zone.IndexOf("Cabin", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Cottage", StringComparison.Ordinal) >= 0 || zone == "Inn Rooms"
                || zone.IndexOf("Barn", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Greenhouse", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Workshop", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Forge", StringComparison.Ordinal) >= 0
                || zone.IndexOf("Stockyard", StringComparison.Ordinal) >= 0)
                return new Color(224, 176, 120);
            return new Color(158, 201, 234);
        }

        private void Modal(int vw, int vh, string title, string sub)
        {
            Fill(0, 0, vw, vh, new Color(10, 8, 14, 140));
            Panel(vw / 2 - 400, vh / 2 - 160, 800, 320);
            _font.Draw(_spriteBatch, title, vw / 2 - _font.Measure(title, 3) / 2, vh / 2 - 140, new Color(232, 197, 71), 3);
            _font.Draw(_spriteBatch, sub, vw / 2 - _font.Measure(sub, 2) / 2, vh / 2 - 100, new Color(196, 165, 116), 2);
        }

        private void Panel(int x, int y, int w, int h)
        {
            Fill(x, y, w, h, new Color(48, 36, 26, 235));
            DrawRect(x, y, w, h, new Color(176, 148, 96));
        }

        /// <summary>
        /// Premultiplies RGB for BlendState.AlphaBlend (SourceBlend=One)
        /// so translucent pixels do not add full-bright color and wash the screen white.
        /// </summary>
        private static Color Premul(Color c)
        {
            if (c.A == 255)
                return c;
            float a = c.A / 255f;
            return new Color((byte)(c.R * a + 0.5f), (byte)(c.G * a + 0.5f), (byte)(c.B * a + 0.5f), c.A);
        }

        private void Fill(int x, int y, int w, int h, Color c)
        {
            _spriteBatch.Draw(_assets.Pixel, new Rectangle(x, y, w, h), Premul(c));
        }

        private void DrawRect(int x, int y, int w, int h, Color c)
        {
            Fill(x, y, w, 2, c);
            Fill(x, y + h - 2, w, 2, c);
            Fill(x, y, 2, h, c);
            Fill(x + w - 2, y, 2, h, c);
        }

        private static string ClockLabel(float minutes)
        {
            int m = (int)minutes;
            int h = m / 60;
            int mm = m % 60;
            bool late = h >= 24;
            if (h >= 24) h -= 24;
            string ampm = h >= 12 ? "PM" : "AM";
            int h12 = h % 12;
            if (h12 == 0) h12 = 12;
            string mins = mm < 10 ? "0" + mm.ToString() : mm.ToString();
            return (late ? "LATE " : "") + h12.ToString() + ":" + mins + " " + ampm;
        }

        private struct FallingLeaf
        {
            public Vector2 Pos;
            public Vector2 Vel;
            public float Life;
            public float Max;
            public float Rot;
            public float RotV;
            public Color Color;
            public bool Alive;
        }

        private struct Firefly
        {
            public Vector2 Pos;
            public float Phase;
            public float Life;
            public float Max;
            public bool Alive;
        }

        private struct RainDrop
        {
            public Vector2 Pos;
            public float Speed;
            public float Wind;
            public float Length;
            public float Width;
            public byte Alpha;
            public float HitY;
        }

        private struct RainSplash
        {
            public Vector2 Pos;
            public float Age;
            public float Life;
            public bool Alive;
        }

        private struct LightningBolt
        {
            public Vector2[] Pts;
            public float Life;
            public float Max;
        }

        private struct ToolSpark
        {
            public Vector2 Pos;
            public Vector2 Vel;
            public Color Color;
            public float Size;
            public float Life;
            public float Max;
        }
    }
}
