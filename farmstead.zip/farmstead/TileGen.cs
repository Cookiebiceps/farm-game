using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// Stardew-like HD pixel pack: painted 32×32 ground, Scale2x sprites.
    /// Light from the upper-left; selective dark-brown outlines.
    /// </summary>
    public static class TileGen
    {
        static readonly Color Ink = new Color(42, 34, 44);
        static readonly Color G0 = new Color(60, 110, 58);
        static readonly Color G1 = new Color(84, 140, 66);
        static readonly Color G2 = new Color(116, 172, 78);
        static readonly Color G3 = new Color(154, 200, 96);
        static readonly Color G4 = new Color(44, 84, 48);
        static readonly Color Gold = new Color(226, 186, 74);
        static readonly Color SoilA = new Color(176, 128, 78);
        static readonly Color SoilB = new Color(146, 100, 60);
        static readonly Color SoilC = new Color(104, 68, 42);
        static readonly Color SoilD = new Color(208, 162, 106);
        static readonly Color TillA = new Color(122, 82, 48);
        static readonly Color TillB = new Color(152, 104, 62);
        static readonly Color TillC = new Color(84, 54, 34);
        static readonly Color TillD = new Color(188, 138, 84);
        static readonly Color WetA = new Color(72, 50, 36);
        static readonly Color WetB = new Color(92, 66, 46);
        static readonly Color WetC = new Color(48, 34, 26);
        static readonly Color WetShine = new Color(138, 180, 116, 160);
        static readonly Color PathA = new Color(208, 170, 116);
        static readonly Color PathB = new Color(180, 140, 92);
        static readonly Color PathC = new Color(232, 200, 148);
        static readonly Color PathD = new Color(140, 102, 64);
        static readonly Color Pebble = new Color(178, 168, 156);
        static readonly Color WaterA = new Color(58, 168, 202);
        static readonly Color WaterB = new Color(92, 204, 228);
        static readonly Color WaterC = new Color(30, 116, 158);
        static readonly Color WaterD = new Color(176, 236, 246);
        static readonly Color Foam = new Color(238, 250, 252);
        static readonly Color WoodA = new Color(178, 120, 68);
        static readonly Color WoodB = new Color(138, 86, 50);
        static readonly Color WoodC = new Color(208, 154, 98);
        static readonly Color WoodD = new Color(88, 54, 34);
        static readonly Color RoofA = new Color(190, 94, 64);
        static readonly Color RoofB = new Color(152, 68, 50);
        static readonly Color RoofC = new Color(216, 128, 86);
        static readonly Color RoofD = new Color(98, 44, 36);
        static readonly Color Plaster = new Color(226, 200, 158);
        static readonly Color PlasterD = new Color(188, 160, 120);
        static readonly Color FloorA = new Color(198, 148, 92);
        static readonly Color FloorB = new Color(168, 122, 74);
        static readonly Color FloorC = new Color(222, 176, 114);

        public static Texture2D WoodsGrass(GraphicsDevice gd, int variant)
        {
            Color w0 = new Color(36, 58, 32);
            Color w1 = new Color(52, 82, 44);
            Color w2 = new Color(74, 108, 52);
            Color w3 = new Color(108, 142, 64);
            Color moss = new Color(86, 128, 48);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                int seed = 4401 + variant * 61;
                PaintClusterBase(d, w, h, seed, w0, w1, w2, w3);
                for (int i = 0; i < 6; i++)
                {
                    int bx = Hash(i, variant, seed) % 28 + 2;
                    int by = Hash(i + 3, variant, seed + 2) % 24 + 5;
                    GrassBlade(d, w, bx, by, w3, moss, w0);
                }
            });
        }

        public static Texture2D Grass(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                int seed = 1103 + variant * 97;
                PaintClusterBase(d, w, h, seed, G0, G1, G2, G3);
                for (int i = 0; i < 7; i++)
                {
                    int bx = (Hash(i, variant, seed) % 28) + 2;
                    int by = (Hash(i + 7, variant, seed) % 24) + 5;
                    GrassBlade(d, w, bx, by, G3, G2, G0);
                }
                if (variant == 2)
                    Flower(d, w, 21, 17, new Color(252, 250, 236), new Color(236, 176, 48));
                if (variant == 3)
                    Flower(d, w, 10, 22, new Color(228, 118, 156), new Color(250, 232, 176));
            });
        }

        /// <summary>
        /// Dark rim drawn just inside a grass tile where it meets lower ground,
        /// giving the raised-terrain edge the top-down village style relies on.
        /// Side: 0 north, 1 east, 2 south, 3 west.
        /// </summary>
        public static Texture2D GrassEdge(GraphicsDevice gd, int side)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int i = 0; i < 32; i++)
                {
                    int depth = 3 + Hash(i / 3, side, 771) % 2;
                    if (side == 2)
                        depth += 2;
                    for (int j = 0; j < depth; j++)
                    {
                        Color c = j == depth - 1 ? G4 : Ink;
                        if (j == 0 && side != 2)
                            c = G0;
                        int x, y;
                        if (side == 0) { x = i; y = j; }
                        else if (side == 1) { x = 31 - j; y = i; }
                        else if (side == 2) { x = i; y = 31 - j; }
                        else { x = j; y = i; }
                        Plot(d, w, x, y, c);
                    }
                }
            });
        }

        public static Texture2D FarmSoil(GraphicsDevice gd)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                PaintClusterBase(d, w, h, 44, SoilC, SoilB, SoilA, SoilD);
                for (int i = 0; i < 18; i++)
                {
                    int x = Hash(i, 1, 44) % 30 + 1;
                    int y = Hash(i, 2, 90) % 30 + 1;
                    Plot(d, w, x, y, SoilC);
                    Plot(d, w, x + 1, y, SoilA);
                }
            });
        }

        public static Texture2D Tilled(GraphicsDevice gd)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    int band = y % 8;
                    Color a = band < 2 ? TillC : band < 4 ? TillA : band < 6 ? TillB : TillD;
                    for (int x = 0; x < w; x++)
                    {
                        Color c = a;
                        if (Hash(x, y, 3) % 17 == 0)
                            c = TillC;
                        Plot(d, w, x, y, c);
                    }
                }
                Plot(d, w, 6, 10, SoilD);
                Plot(d, w, 20, 18, SoilD);
                Plot(d, w, 14, 26, TillD);
            });
        }

        public static Texture2D Wet(GraphicsDevice gd)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    int band = y % 8;
                    Color a = band < 2 ? WetC : band < 5 ? WetA : WetB;
                    for (int x = 0; x < w; x++)
                        Plot(d, w, x, y, a);
                }
                Plot(d, w, 8, 8, WetShine);
                Plot(d, w, 9, 8, WetShine);
                Plot(d, w, 22, 16, WetShine);
                Plot(d, w, 23, 16, Foam);
                Plot(d, w, 4, 24, new Color(80, 140, 70, 140));
                Plot(d, w, 16, 12, new Color(80, 140, 70, 140));
            });
        }

        public static Texture2D Path(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    for (int x = 0; x < w; x++)
                    {
                        int n = Hash(x, y, 9 + variant);
                        Color c = PathA;
                        if (n % 3 == 0) c = PathB;
                        if (n % 5 == 0) c = PathC;
                        if (n % 11 == 0) c = PathD;
                        Plot(d, w, x, y, c);
                    }
                }
                int[,] stones = { { 4, 6, 4, 3 }, { 16, 5, 5, 3 }, { 8, 18, 4, 4 }, { 20, 20, 5, 3 }, { 12, 12, 3, 3 } };
                for (int i = 0; i < stones.GetLength(0); i++)
                {
                    int sx = (stones[i, 0] + variant * 3) % 26;
                    int sy = stones[i, 1];
                    StoneBlob(d, w, sx, sy, stones[i, 2], stones[i, 3],
                        Pebble, new Color(210, 202, 186), new Color(108, 98, 82));
                }
            });
        }

        public static Texture2D Sand(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (d, w, h) => PaintWindSand(d, w, h, variant, false));
        }

        public static Texture2D WetSand(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (d, w, h) => PaintWindSand(d, w, h, variant, true));
        }

        /// <summary>
        /// Seamless 32×32 wind-ripple dunes: stacked S-curves, light crests, darker
        /// lee valleys. Original pixel art (not a stock photo).
        /// </summary>
        public static void PaintWindSand(Color[] d, int w, int h, int variant, bool wet)
        {
            Color valley = wet ? new Color(112, 94, 72) : new Color(168, 124, 76);
            Color shade = wet ? new Color(130, 108, 82) : new Color(196, 150, 96);
            Color mid = wet ? new Color(146, 124, 94) : new Color(218, 176, 118);
            Color crest = wet ? new Color(164, 140, 106) : new Color(238, 206, 146);
            Color hi = wet ? new Color(178, 156, 120) : new Color(252, 228, 172);
            Color spark = wet ? new Color(72, 118, 132) : new Color(255, 246, 214);
            int seed = 8803 + variant * 41;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    double u = x / (double)w;
                    double v = y / (double)h;
                    double warp = Math.Sin((u * 2.0 + 0.18) * Math.PI * 2.0) * 2.6
                        + Math.Sin((u * 4.0 + 0.71) * Math.PI * 2.0) * 1.15
                        + Math.Sin((u + v) * Math.PI * 2.0) * 0.45;
                    double ridge = (y + warp) / 8.0;
                    double wave = ridge - Math.Floor(ridge);
                    double dune;
                    if (wave < 0.20)
                        dune = wave / 0.20 * 0.28;
                    else if (wave < 0.58)
                        dune = 0.28 + (wave - 0.20) / 0.38 * 0.72;
                    else
                        dune = 1.0 - (wave - 0.58) / 0.42 * 0.78;

                    Color col;
                    if (dune < 0.22)
                        col = valley;
                    else if (dune < 0.42)
                        col = shade;
                    else if (dune < 0.68)
                        col = mid;
                    else if (dune < 0.88)
                        col = crest;
                    else
                        col = hi;
                    if (Hash(x, y, seed) % 19 == 0)
                        col = Mix(col, spark, wet ? 35 : 28);
                    Plot(d, w, x, y, col);
                }
            }
        }

        public static Texture2D Water(GraphicsDevice gd, int frame)
        {
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                Color[] band = { WaterC, WaterA, WaterB, WaterA, WaterC, WaterA, WaterB, WaterD };
                for (int y = 0; y < h; y++)
                {
                    for (int x = 0; x < w; x++)
                    {
                        int wave = (int)(Math.Sin((x + frame * 3) * 0.35) * 2.0);
                        int i = (y + wave + frame * 2) & 7;
                        Plot(d, w, x, y, band[i]);
                    }
                }
                int fy = (4 + frame * 6) & 31;
                for (int x = 2; x < 30; x++)
                {
                    if ((x + frame) % 5 == 0)
                        continue;
                    Plot(d, w, x, fy, WaterD);
                    if ((x & 3) == 0)
                        Plot(d, w, x, (fy + 1) & 31, Foam);
                }
                int fy2 = (18 + frame * 4) & 31;
                for (int x = 4; x < 28; x++)
                    Plot(d, w, x, fy2, Mix(WaterB, WaterD, 50));
            });
        }

        /// <summary>
        /// Southward current: chevrons and foam drift +Y (toward the ocean).
        /// Four frames tile vertically so neighboring river cells line up.
        /// </summary>
        public static Texture2D WaterRiver(GraphicsDevice gd, int frame)
        {
            return BuildHi(gd, 32, 32, (d, w, h) => PaintStream(d, w, h, frame, 0));
        }

        /// <summary>
        /// Shallow Saltwind water: same blues as the river, with a softer swell
        /// so the stream can empty into the bay without a material cut.
        /// </summary>
        public static Texture2D WaterCoast(GraphicsDevice gd, int frame)
        {
            return BuildHi(gd, 32, 32, (d, w, h) => PaintStream(d, w, h, frame, 1));
        }

        public static Texture2D WaterOcean(GraphicsDevice gd, int frame)
        {
            return BuildHi(gd, 32, 32, (d, w, h) => PaintStream(d, w, h, frame, 2));
        }

        /// <param name="depth">0 river, 1 coast, 2 ocean.</param>
        static void PaintStream(Color[] d, int w, int h, int frame, int depth)
        {
            Color deep = new Color(24, 92, 142);
            Color mid = new Color(40, 138, 182);
            Color light = new Color(70, 184, 214);
            Color gleam = new Color(164, 226, 238);
            if (depth == 2)
            {
                deep = new Color(22, 88, 138);
                mid = new Color(36, 130, 176);
                light = new Color(64, 176, 210);
                gleam = new Color(158, 224, 236);
            }
            int drift = frame * 2;
            float swellAmp = depth == 0 ? 0f : (depth == 1 ? 0.7f : 1.6f);
            int chevDiv = depth == 0 ? 2 : 3;
            int bandMask = 7;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int chev = Math.Abs((x & 15) - 8) / chevDiv;
                    int swell = swellAmp <= 0.01f ? 0 : (int)(Math.Sin(x * 0.2 + frame * 0.55) * swellAmp);
                    int band = (y - drift - chev + swell) & bandMask;
                    Color c = mid;
                    if (band == 0) c = light;
                    else if (band == 1) c = gleam;
                    else if (band == bandMask - 3) c = Mix(deep, mid, 40);
                    else if (band == bandMask - 2 || band == bandMask - 1) c = deep;
                    if (depth == 0 && ((x + y - drift) & 15) == 4)
                        c = Mix(c, light, 28);
                    if (depth > 0 && ((x + y * 2 - drift) & 19) == 6)
                        c = Mix(c, light, 22);
                    Plot(d, w, x, y, c);
                }
            }
            int foamN = depth == 0 ? 4 : 3;
            for (int k = 0; k < foamN; k++)
            {
                int ax = 5 + k * 7;
                int ay = (6 + k * 9 + drift * 2) & 31;
                Plot(d, w, ax, ay, Foam);
                Plot(d, w, ax - 1, (ay + 31) & 31, gleam);
                Plot(d, w, ax + 1, (ay + 31) & 31, gleam);
                Plot(d, w, ax, (ay + 1) & 31, Mix(Foam, light, 40));
            }
            int fy = (2 + drift * 2) & 31;
            if (depth > 0)
                fy = (8 + drift + (int)(Math.Sin(frame) * 2)) & 31;
            for (int x = 2; x < 30; x += depth == 2 ? 2 : 3)
            {
                if (((x + frame) & 3) == 0)
                    continue;
                Plot(d, w, x, fy, gleam);
                if ((x & 1) == 0)
                    Plot(d, w, x, (fy + 1) & 31, Mix(Foam, gleam, 40));
            }
        }

        public static Texture2D Mountain(GraphicsDevice gd)
        {
            return Mountain(gd, 0);
        }

        public static Texture2D Mountain(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (data, w, h) =>
            {
                PaintMountainFill(data, w, h, variant);
            });
        }

        public static Texture2D MountainEdge(GraphicsDevice gd, int side)
        {
            Color ink = new Color(64, 66, 72);
            Color dark = new Color(92, 96, 102);
            Color mid = new Color(118, 122, 128);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int i = 0; i < 32; i++)
                {
                    int depth = 3 + Hash(i / 3, side, 881) % 2;
                    if (side == 2)
                        depth += 2;
                    for (int j = 0; j < depth; j++)
                    {
                        Color c = j == depth - 1 ? dark : ink;
                        if (j == 0 && side != 2)
                            c = mid;
                        int x, y;
                        if (side == 0) { x = i; y = j; }
                        else if (side == 1) { x = 31 - j; y = i; }
                        else if (side == 2) { x = i; y = 31 - j; }
                        else { x = j; y = i; }
                        Plot(d, w, x, y, c);
                    }
                }
            });
        }

        /// <summary>Light plateau rim, then a vertical stone face that hangs south (+Y).</summary>
        public static Texture2D MountainSouthDrop(GraphicsDevice gd, int variant)
        {
            const int h = 32;
            return BuildHi(gd, 32, h, (d, w, hh) =>
            {
                PaintSouthDrop(d, w, hh, variant);
            });
        }

        /// <summary>North-facing drop: rim on the bottom of the sprite, face hanging up.</summary>
        public static Texture2D MountainNorthDrop(GraphicsDevice gd, int variant)
        {
            const int h = 22;
            return BuildHi(gd, 32, h, (d, w, hh) =>
            {
                PaintNorthDrop(d, w, hh, variant);
            });
        }

        public static Texture2D MountainEastDrop(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 18, 32, (d, w, h) =>
            {
                PaintSideDrop(d, w, h, variant, true);
            });
        }

        public static Texture2D MountainWestDrop(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 18, 32, (d, w, h) =>
            {
                PaintSideDrop(d, w, h, variant, false);
            });
        }

        public static Texture2D Cliff(GraphicsDevice gd, int variant)
        {
            return BuildHi(gd, 32, 32, (data, w, h) =>
            {
                for (int x = 0; x < w; x++)
                {
                    for (int y = 0; y < h; y++)
                    {
                        if (y < 5)
                            Plot(data, w, x, y, PlateauPixel(x, y, variant));
                        else
                            Plot(data, w, x, y, CliffFaceAt(x, y - 5, variant, y == h - 1));
                    }
                }
                PaintUnderLip(data, w, 5, 0, w, variant);
                PaintGrassOverhang(data, w, 5, variant, 0);
                PaintFaceDetails(data, w, 5, 27, variant, false);
            });
        }

        public static Texture2D CliffFoam(GraphicsDevice gd)
        {
            return Build(gd, 16, 6, (data, w, h) =>
            {
                for (int x = 0; x < 16; x++)
                {
                    Plot(data, w, x, 0, Foam);
                    if ((x % 3) != 1)
                        Plot(data, w, x, 1, Mix(Foam, WaterD, 40));
                    if ((x & 1) == 0)
                        Plot(data, w, x, 2, WaterD);
                }
            });
        }

        public static Texture2D BridgeDeck(GraphicsDevice gd, int variant, bool northSouth)
        {
            return WoodBridgeDeck(gd, variant, northSouth, true, true, northSouth, northSouth);
        }

        /// <summary>
        /// Small wooden deck. Planks run along the crossing; rails sit on the
        /// exposed edges so a 2×2 ford reads as one footbridge. Gaps stay
        /// transparent so animated water shows through.
        /// </summary>
        public static Texture2D WoodBridgeDeck(GraphicsDevice gd, int variant, bool northSouth,
            bool railN, bool railS, bool railE, bool railW)
        {
            Color plank = Mix(WoodA, WoodC, 18 + variant * 8);
            Color plankD = WoodB;
            Color gap = Color.Transparent;
            Color nail = new Color(62, 44, 32);
            Color rail = Mix(WoodC, WoodA, 20);
            Color railD = WoodD;
            Color railHi = Mix(WoodC, Foam, 25);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                int plankW = 5;
                if (northSouth)
                {
                    for (int x = 0; x < w; x++)
                    {
                        int col = (x + variant) / plankW;
                        bool seam = ((x + variant) % plankW) == 0;
                        Color row = ((col + variant) & 1) == 0 ? plank : plankD;
                        for (int y = 0; y < h; y++)
                        {
                            if (seam)
                                Plot(d, w, x, y, gap);
                            else
                            {
                                Color c = row;
                                if (y + x < 6) c = Mix(c, WoodC, 30);
                                if (y > 24) c = Mix(c, WoodD, 25);
                                if (((x + y * 3 + variant) % 11) == 0)
                                    c = Mix(c, WoodC, 20);
                                Plot(d, w, x, y, c);
                            }
                        }
                    }
                }
                else
                {
                    for (int y = 0; y < h; y++)
                    {
                        int rowI = (y + variant) / plankW;
                        bool seam = ((y + variant) % plankW) == 0;
                        Color row = ((rowI + variant) & 1) == 0 ? plank : plankD;
                        for (int x = 0; x < w; x++)
                        {
                            if (seam)
                                Plot(d, w, x, y, gap);
                            else
                            {
                                Color c = row;
                                if (x + y < 6) c = Mix(c, WoodC, 30);
                                if (x > 24) c = Mix(c, WoodD, 25);
                                if (((x * 3 + y + variant) % 11) == 0)
                                    c = Mix(c, WoodC, 20);
                                Plot(d, w, x, y, c);
                            }
                        }
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    int nx = 4 + (i * 7 + variant * 3) % 24;
                    int ny = 5 + (i * 5 + variant) % 22;
                    if (d[ny * w + nx].A > 0)
                        Plot(d, w, nx, ny, nail);
                }
                if (railN)
                    WoodRail(d, w, true, true, rail, railD, railHi);
                if (railS)
                    WoodRail(d, w, true, false, rail, railD, railHi);
                if (railE)
                    WoodRail(d, w, false, false, rail, railD, railHi);
                if (railW)
                    WoodRail(d, w, false, true, rail, railD, railHi);
            });
        }

        static void WoodRail(Color[] d, int w, bool horizontal, bool lowEdge, Color rail, Color railD, Color railHi)
        {
            int a = lowEdge ? 0 : 29;
            int b = lowEdge ? 2 : 31;
            if (horizontal)
            {
                for (int x = 0; x < 32; x++)
                {
                    for (int y = a; y <= b; y++)
                    {
                        Color c = y == a || y == b ? railD : rail;
                        if ((x % 8) == 2)
                            c = railD;
                        else if (y == a + 1 && (x & 3) == 1)
                            c = railHi;
                        Plot(d, w, x, y, c);
                    }
                    if ((x % 8) == 2)
                    {
                        Plot(d, w, x, a - (lowEdge ? 0 : 0), railD);
                        Plot(d, w, x + 1, a, Mix(rail, railHi, 40));
                    }
                }
            }
            else
            {
                for (int y = 0; y < 32; y++)
                {
                    for (int x = a; x <= b; x++)
                    {
                        Color c = x == a || x == b ? railD : rail;
                        if ((y % 8) == 2)
                            c = railD;
                        else if (x == a + 1 && (y & 3) == 1)
                            c = railHi;
                        Plot(d, w, x, y, c);
                    }
                }
            }
        }

        public static Texture2D BridgeSpan(GraphicsDevice gd, int tilesW, bool northSouth)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int ph = 28;
            Color s0 = new Color(186, 186, 192);
            Color s1 = new Color(210, 210, 216);
            Color s2 = new Color(148, 150, 160);
            Color s3 = new Color(112, 114, 126);
            Color hi = new Color(232, 232, 236);
            Color ink = new Color(78, 80, 92);
            Color moss = new Color(118, 148, 64);
            return Build(gd, pw, ph, (d, w, h) =>
            {
                int archTop = 8;
                int archBot = ph - 1;
                int cx = pw / 2;
                int rx = pw / 2 - 3;
                int ry = 10;
                for (int y = 0; y < ph; y++)
                {
                    for (int x = 0; x < pw; x++)
                    {
                        int dx = x - cx;
                        int dy = y - (archTop + 8);
                        bool inArch = (dx * dx) * ry * ry + (dy * dy) * rx * rx < rx * rx * ry * ry && y > archTop + 2;
                        if (y < 4)
                            continue;
                        if (inArch)
                            continue;
                        Color c = s0;
                        if ((x / 4 + y / 3) % 2 == 0) c = s1;
                        if (x + y < 10) c = hi;
                        if (x > pw - 4) c = s2;
                        if (y > ph - 5) c = s3;
                        if (x == 0 || x == pw - 1 || y == archBot) c = ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 2; x < pw - 2; x++)
                {
                    int dx = x - cx;
                    int yy = archTop + 3 + (dx * dx) / Math.Max(8, rx);
                    if (yy < ph)
                    {
                        Plot(d, w, x, yy, ink);
                        Plot(d, w, x, yy + 1, s3);
                    }
                }
                for (int x = 0; x < pw; x++)
                {
                    Plot(d, w, x, 3, s3);
                    Plot(d, w, x, 4, s1);
                    Plot(d, w, x, 5, hi);
                    if ((x % 5) == 2)
                        Plot(d, w, x, 2, s2);
                }
                Plot(d, w, 4, 10, moss);
                Plot(d, w, pw - 6, 12, moss);
                if (northSouth)
                {
                    for (int y = 6; y < ph - 2; y++)
                    {
                        Plot(d, w, 0, y, ink);
                        Plot(d, w, 1, y, s2);
                        Plot(d, w, pw - 1, y, ink);
                    }
                }
            });
        }

        public static Texture2D Cobble(GraphicsDevice gd)
        {
            Color grout = new Color(96, 84, 74);
            Color s0 = new Color(178, 166, 148);
            Color s1 = new Color(198, 186, 166);
            Color s2 = new Color(152, 138, 122);
            Color s3 = new Color(216, 204, 182);
            Color hi = new Color(236, 226, 206);
            Color sh = new Color(110, 96, 84);
            return Build(gd, 16, 16, (data, w, h) =>
            {
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                        Plot(data, w, x, y, grout);
                StoneBlob(data, w, 1, 1, 4, 3, s1, hi, sh);
                StoneBlob(data, w, 6, 1, 5, 3, s0, hi, sh);
                StoneBlob(data, w, 12, 1, 3, 3, s2, hi, sh);
                StoneBlob(data, w, 0, 5, 3, 3, s2, hi, sh);
                StoneBlob(data, w, 4, 5, 4, 3, s3, hi, sh);
                StoneBlob(data, w, 9, 5, 4, 3, s1, hi, sh);
                StoneBlob(data, w, 14, 5, 2, 3, s0, hi, sh);
                StoneBlob(data, w, 1, 9, 5, 3, s0, hi, sh);
                StoneBlob(data, w, 7, 9, 4, 3, s2, hi, sh);
                StoneBlob(data, w, 12, 9, 3, 3, s1, hi, sh);
                StoneBlob(data, w, 0, 13, 4, 3, s1, hi, sh);
                StoneBlob(data, w, 5, 13, 5, 3, s3, hi, sh);
                StoneBlob(data, w, 11, 13, 4, 3, s0, hi, sh);
                Plot(data, w, 3, 4, new Color(86, 128, 64));
                Plot(data, w, 8, 8, new Color(86, 128, 64));
                Plot(data, w, 13, 12, new Color(72, 110, 58));
                Plot(data, w, 1, 10, new Color(96, 138, 72));
            });
        }

        public static Texture2D Fence(GraphicsDevice gd)
        {
            Color picket = new Color(232, 214, 176);
            Color picketL = new Color(248, 236, 206);
            Color picketD = new Color(176, 148, 108);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 4; y < 15; y++)
                {
                    Plot(d, w, 3, y, Ink);
                    Plot(d, w, 4, y, picketL);
                    Plot(d, w, 5, y, picket);
                    Plot(d, w, 6, y, picketD);
                    Plot(d, w, 10, y, Ink);
                    Plot(d, w, 11, y, picketL);
                    Plot(d, w, 12, y, picket);
                    Plot(d, w, 13, y, picketD);
                }
                Plot(d, w, 4, 3, picketL);
                Plot(d, w, 5, 2, picket);
                Plot(d, w, 11, 3, picketL);
                Plot(d, w, 12, 2, picket);
                for (int x = 2; x < 15; x++)
                {
                    Plot(d, w, x, 7, picketL);
                    Plot(d, w, x, 8, picket);
                    Plot(d, w, x, 9, picketD);
                }
            });
        }

        public static Texture2D Dock(GraphicsDevice gd)
        {
            Color a = new Color(214, 168, 108);
            Color b = new Color(186, 138, 84);
            Color c = new Color(148, 102, 58);
            Color d = new Color(112, 74, 42);
            Color hi = new Color(236, 196, 132);
            return Build(gd, 16, 16, (data, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    int plank = y / 3;
                    Color row = (plank & 1) == 0 ? a : b;
                    if (y % 3 == 2)
                        row = Mix(row, d, 45);
                    if (y % 3 == 0)
                        row = Mix(row, hi, 22);
                    for (int x = 0; x < w; x++)
                    {
                        Color col = row;
                        if (x == 0)
                            col = hi;
                        if (x == w - 1)
                            col = d;
                        if ((x + plank * 5) % 13 == 0)
                            col = Mix(col, hi, 28);
                        Plot(data, w, x, y, col);
                    }
                }
            });
        }

        public static Texture2D Signpost(GraphicsDevice gd, int dir)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 6; y <= 10; y++)
                    for (int x = 6; x <= 9; x++)
                        Plot(d, w, x, y, (x == 6 || x == 9 || y == 6 || y == 10) ? WoodD : WoodA);
                for (int y = 2; y <= 8; y++)
                {
                    for (int x = 2; x <= 13; x++)
                    {
                        Color c = WoodC;
                        if (x == 2 || x == 13 || y == 2 || y == 8)
                            c = Ink;
                        else if ((x + y) % 5 == 0)
                            c = WoodB;
                        Plot(d, w, x, y, c);
                    }
                }
                Color arrow = new Color(236, 200, 72);
                if (dir == 1)
                {
                    for (int i = 0; i < 6; i++)
                    {
                        Plot(d, w, 10 - i, 5, arrow);
                        Plot(d, w, 10 - i, 6, arrow);
                    }
                    Plot(d, w, 4, 4, arrow);
                    Plot(d, w, 4, 7, arrow);
                }
                else if (dir == 2)
                {
                    for (int i = 0; i < 6; i++)
                    {
                        Plot(d, w, 5 + i, 5, arrow);
                        Plot(d, w, 5 + i, 6, arrow);
                    }
                    Plot(d, w, 11, 4, arrow);
                    Plot(d, w, 11, 7, arrow);
                }
                else if (dir == 3)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Plot(d, w, 7, 7 - i, arrow);
                        Plot(d, w, 8, 7 - i, arrow);
                    }
                    Plot(d, w, 6, 3, arrow);
                    Plot(d, w, 9, 3, arrow);
                }
                else
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Plot(d, w, 7, 3 + i, arrow);
                        Plot(d, w, 8, 3 + i, arrow);
                    }
                    Plot(d, w, 6, 7, arrow);
                    Plot(d, w, 9, 7, arrow);
                }
            });
        }

        public static Texture2D Roof(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    int row = y / 4;
                    int shift = (row % 2) * 3;
                    for (int x = 0; x < w; x++)
                    {
                        int inRow = y % 4;
                        int col = (x + shift) % 6;
                        Color c = RoofA;
                        if (inRow == 0) c = RoofD;
                        else if (inRow == 1) c = RoofC;
                        else if (inRow == 3) c = RoofB;
                        if (col == 0) c = Mix(c, RoofD, 55);
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 0; x < 16; x++)
                    Plot(d, w, x, 0, RoofD);
            });
        }

        /// <summary>
        /// Cottage-core village house: thatch or warm clay roof, cream plaster,
        /// timber posts, climbing roses, and overflowing window boxes.
        /// </summary>
        public static Texture2D House(GraphicsDevice gd, int tilesW, int tilesH, int style, int doorDx)
        {
            return House(gd, tilesW, tilesH, style, doorDx, false);
        }

        public static Texture2D House(GraphicsDevice gd, int tilesW, int tilesH, int style, int doorDx, bool open)
        {
            int pw, ph;
            HouseSize(tilesW, tilesH, out pw, out ph);
            return Build(gd, pw, ph, (d, w, h) => PaintHouse(d, w, tilesW, tilesH, style, doorDx, open));
        }

        public static Texture2D FishShack(GraphicsDevice gd, int tilesW, int tilesH, int doorDx, bool open)
        {
            int pw, ph;
            HouseSize(tilesW, tilesH, out pw, out ph);
            return Build(gd, pw, ph, (d, w, h) => PaintFishShack(d, w, tilesW, tilesH, doorDx, open));
        }

        public static Texture2D Farmhouse(GraphicsDevice gd, int tilesW, int tilesH, int doorDx, bool open)
        {
            _ = tilesW;
            _ = tilesH;
            _ = doorDx;
            _ = open;
            return PackedBuildingTex(gd, CottageAssetPath(), 7, false);
        }

        public static string CottageAssetPath()
        {
            return PackedObjectPath("farm_cottage.png");
        }

        public static string BarnAssetPath()
        {
            return PackedObjectPath("farm_barn.png");
        }

        public static string GreenhouseAssetPath()
        {
            return PackedObjectPath("farm_greenhouse.png");
        }

        public static string ForgeAssetPath()
        {
            return PackedObjectPath("ash_forge.png");
        }

        static string PackedObjectPath(string file)
        {
            string root = PackAtlas.PackRoot();
            if (root == null)
                return null;
            return System.IO.Path.Combine(root, "objects", file);
        }

        /// <summary>
        /// Cute Fantasy House_1_Wood_Base_Blue at 32px/tile (native 16px sprite, nearest-neighbor ×2),
        /// centered on the existing 7-tile cottage lot. Does not restyle the silhouette.
        /// </summary>
        public static bool BlitCottageAsset32(out Color[] dest, out int pw, out int ph)
        {
            return BlitPackedBuilding32(CottageAssetPath(), 7, false, out dest, out pw, out ph);
        }

        /// <summary>
        /// Full Cute Fantasy building sprite at 32px/tile (native 16px art, nearest-neighbor ×2),
        /// centered on the existing lot width. Ruined uses a dim overlay on the same silhouette.
        /// </summary>
        public static bool BlitPackedBuilding32(string path, int tilesW, bool ruined, out Color[] dest, out int pw, out int ph)
        {
            dest = null;
            pw = 0;
            ph = 0;
            Color[] src;
            int sw, sh;
            if (!PngRgba.TryLoad(path, out src, out sw, out sh))
                return false;
            const int scale = 2;
            int dw = sw * scale;
            int dh = sh * scale;
            pw = tilesW * 32;
            ph = dh;
            dest = new Color[pw * ph];
            int ox = (pw - dw) / 2;
            for (int y = 0; y < sh; y++)
            {
                for (int x = 0; x < sw; x++)
                {
                    Color c = src[y * sw + x];
                    if (c.A == 0)
                        continue;
                    if (ruined)
                        c = new Color((byte)(c.R * 168 / 255), (byte)(c.G * 160 / 255), (byte)(c.B * 152 / 255), c.A);
                    int dx0 = ox + x * scale;
                    int dy0 = y * scale;
                    for (int sy = 0; sy < scale; sy++)
                    {
                        int dy = dy0 + sy;
                        if (dy < 0 || dy >= ph)
                            continue;
                        for (int sx = 0; sx < scale; sx++)
                        {
                            int dx = dx0 + sx;
                            if (dx < 0 || dx >= pw)
                                continue;
                            dest[dy * pw + dx] = c;
                        }
                    }
                }
            }
            return true;
        }

        static Texture2D PackedBuildingTex(GraphicsDevice gd, string path, int tilesW, bool ruined)
        {
            Color[] d;
            int pw, ph;
            if (!BlitPackedBuilding32(path, tilesW, ruined, out d, out pw, out ph))
            {
                pw = tilesW * 32;
                ph = 2;
                d = new Color[pw * ph];
            }
            Texture2D tex = new Texture2D(gd, pw, ph);
            tex.SetData(d);
            return tex;
        }

        public const int BarnDoorSrcY0 = 72;
        public const int BarnDoorSrcY1 = 97;
        public const int BarnDoorLeftX0 = 43;
        public const int BarnDoorMidX = 67;
        public const int BarnDoorRightX1 = 91;

        public static void SlideBarnDoors(Color[] dest, int pw, int ph, float openU)
        {
            if (dest == null || pw <= 0 || ph <= 0)
                return;
            if (openU < 0f)
                openU = 0f;
            if (openU > 1f)
                openU = 1f;
            if (openU <= 0.0001f)
                return;
            int scale = 2;
            int srcW = 132;
            int ox = (pw - srcW * scale) / 2;
            int y0 = BarnDoorSrcY0 * scale;
            int y1 = BarnDoorSrcY1 * scale;
            int lx0 = ox + BarnDoorLeftX0 * scale;
            int mid = ox + BarnDoorMidX * scale;
            int rx1 = ox + BarnDoorRightX1 * scale;
            int lh = y1 - y0;
            int lw = mid - lx0;
            int rw = rx1 - mid;
            if (lh <= 0 || lw <= 0 || rw <= 0)
                return;
            Color[] left = CopyDestRect(dest, pw, ph, lx0, y0, lw, lh);
            Color[] right = CopyDestRect(dest, pw, ph, mid, y0, rw, lh);
            FillBarnDoorway(dest, pw, ph, lx0, y0, rx1, y1);
            float ease = openU * openU * (3f - 2f * openU);
            int slide = (int)(ease * GameConst.BarnDoorSlide * scale + 0.5f);
            PasteDestRect(dest, pw, ph, left, lw, lh, lx0 - slide, y0);
            PasteDestRect(dest, pw, ph, right, rw, lh, mid + slide, y0);
        }

        static void FillBarnDoorway(Color[] dest, int pw, int ph, int x0, int y0, int x1, int y1)
        {
            Color hole = new Color(22, 14, 12);
            Color floor = new Color(52, 34, 24);
            int sill = y1 - 6;
            for (int y = y0; y < y1; y++)
            {
                if (y < 0 || y >= ph)
                    continue;
                Color row = y >= sill ? floor : hole;
                for (int x = x0; x < x1; x++)
                {
                    if (x < 0 || x >= pw)
                        continue;
                    dest[y * pw + x] = row;
                }
            }
        }

        static Color[] CopyDestRect(Color[] src, int sw, int sh, int x0, int y0, int rw, int rh)
        {
            Color[] d = new Color[rw * rh];
            for (int y = 0; y < rh; y++)
            {
                int sy = y0 + y;
                for (int x = 0; x < rw; x++)
                {
                    int sx = x0 + x;
                    if (sx >= 0 && sy >= 0 && sx < sw && sy < sh)
                        d[y * rw + x] = src[sy * sw + sx];
                }
            }
            return d;
        }

        static void PasteDestRect(Color[] dest, int dw, int dh, Color[] src, int sw, int sh, int x0, int y0)
        {
            for (int y = 0; y < sh; y++)
            {
                int dy = y0 + y;
                if (dy < 0 || dy >= dh)
                    continue;
                for (int x = 0; x < sw; x++)
                {
                    int dx = x0 + x;
                    if (dx < 0 || dx >= dw)
                        continue;
                    Color c = src[y * sw + x];
                    if (c.A == 0)
                        continue;
                    dest[dy * dw + dx] = c;
                }
            }
        }

        public static BarnSprite MakeBarnSprite(GraphicsDevice gd, bool ruined)
        {
            Color[] d;
            int pw, ph;
            if (!BlitPackedBuilding32(BarnAssetPath(), 8, ruined, out d, out pw, out ph))
                return null;
            int scale = 2;
            int srcW = 132;
            int ox = (pw - srcW * scale) / 2;
            int y0 = BarnDoorSrcY0 * scale;
            int y1 = BarnDoorSrcY1 * scale;
            int lx0 = ox + BarnDoorLeftX0 * scale;
            int mid = ox + BarnDoorMidX * scale;
            int rx1 = ox + BarnDoorRightX1 * scale;
            int lh = y1 - y0;
            int lw = mid - lx0;
            int rw = rx1 - mid;
            if (lh <= 0 || lw <= 0 || rw <= 0)
                return null;
            Color[] left = CopyDestRect(d, pw, ph, lx0, y0, lw, lh);
            Color[] right = CopyDestRect(d, pw, ph, mid, y0, rw, lh);
            FillBarnDoorway(d, pw, ph, lx0, y0, rx1, y1);
            BarnSprite sheet = new BarnSprite();
            sheet.Body = TexFromRgba(gd, d, pw, ph);
            sheet.Left = TexFromRgba(gd, left, lw, lh);
            sheet.Right = TexFromRgba(gd, right, rw, lh);
            sheet.LeftX = lx0;
            sheet.LeftY = y0;
            sheet.RightX = mid;
            sheet.RightY = y0;
            sheet.Slide = (int)(GameConst.BarnDoorSlide * scale + 0.5f);
            return sheet;
        }

        static Texture2D TexFromRgba(GraphicsDevice gd, Color[] d, int w, int h)
        {
            Texture2D tex = new Texture2D(gd, w, h);
            tex.SetData(d);
            return tex;
        }

        public static Texture2D Blacksmith(GraphicsDevice gd, int tilesW, int tilesH, int doorDx, bool open)
        {
            _ = tilesH;
            _ = doorDx;
            _ = open;
            return PackedBuildingTex(gd, ForgeAssetPath(), tilesW, false);
        }

        static void HouseSize(int tilesW, int tilesH, out int pw, out int ph)
        {
            int tw = 16;
            pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            ph = roofH + fasciaH + wallH;
        }

        static void PaintHouse(Color[] d, int w, int tilesW, int tilesH, int style, int doorDx, bool open)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            int doorX0 = doorDx * tw;
            Color r0, r1, r2, r3;
            RoofPalette(style, out r0, out r1, out r2, out r3);
            Color plaster, plasterD, plasterL, beam, beamL, beamH;
            Color stone, stoneL, stoneD, chim, chimL, chimD;
            WallPalette(style, out plaster, out plasterD, out plasterL, out beam, out beamL, out beamH);
            _ = beamH;
            StonePalette(style, out stone, out stoneL, out stoneD, out chim, out chimL, out chimD);

            DrawVillageRoof(d, w, pw, roofH, r0, r1, r2, r3, style);
            DrawVillageFascia(d, w, pw, roofH, fasciaH, r0, r2, r3, style);
            int wallY = roofH + fasciaH;
            DrawVillageWall(d, w, pw, wallY, ph, plaster, plasterD, plasterL, beam, beamL, stone, stoneL, stoneD);
            if (style == 0 || style == 2)
                DrawTimberFrame(d, w, pw, wallY, ph - 3, beam, beamL);
            DrawVillageChimney(d, w, pw, 6, style == 2 ? 8 : pw - 22, chim, chimL, chimD);
            if (style == 3)
                DrawVillageChimney(d, w, pw, 10, 12, chim, chimL, chimD);
            DrawChimneyIvy(d, w, style == 2 ? 8 : pw - 22, 10, style);

            int leftTile = doorDx == 0 ? 1 : 0;
            int rightTile = doorDx == tilesW - 1 ? tilesW - 2 : tilesW - 1;
            DrawVillageWindow(d, w, leftTile * tw + 3, wallY + 5, style);
            DrawVillageWindow(d, w, rightTile * tw + 3, wallY + 5, style);
            if (tilesW >= 8)
            {
                int a = doorDx - 2;
                int b = doorDx + 2;
                if (a > leftTile)
                    DrawVillageWindow(d, w, a * tw + 3, wallY + 5, style);
                if (b < rightTile)
                    DrawVillageWindow(d, w, b * tw + 3, wallY + 5, style);
            }

            DrawHouseDoor(d, w, doorX0, wallY + 3, ph - 2, style, beam, beamL, open);
            DrawVillageStep(d, w, doorX0, ph - 3, ph, stone, stoneL, stoneD);
            DrawClimbingRoses(d, w, 2, wallY - 8, ph - 4, style);
            DrawClimbingRoses(d, w, pw - 16, wallY - 8, ph - 4, style + 3);
            if (style == 0 || style == 2)
                DrawDoorWreath(d, w, doorX0 + 4, wallY + 2);
            if (style == 1 || style == 3)
                DrawAwning(d, w, doorX0 - 4, wallY - 2, 24);
            if (style == 1)
                DrawHangingSign(d, w, Math.Max(2, doorX0 - 14), wallY + 6);
            if (style == 3)
            {
                DrawLantern(d, w, doorX0 - 5, wallY + 9);
                DrawLantern(d, w, doorX0 + 18, wallY + 9);
            }
        }

        static void PaintFishShack(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            Color r0 = new Color(214, 186, 96);
            Color r1 = new Color(236, 210, 124);
            Color r2 = new Color(176, 140, 68);
            Color r3 = new Color(138, 102, 48);
            DrawVillageRoof(d, w, pw, roofH, r0, r1, r2, r3, 0);
            DrawVillageFascia(d, w, pw, roofH, fasciaH, r0, r2, r3, 0);
            int wallY = roofH + fasciaH;
            Color plank = new Color(148, 102, 62);
            Color plankL = new Color(186, 138, 86);
            Color plankD = new Color(96, 62, 36);
            Color beam = new Color(72, 46, 28);
            Color beamL = new Color(108, 72, 42);
            for (int y = wallY; y < ph - 1; y++)
            {
                for (int x = 1; x < pw - 1; x++)
                {
                    int board = x / 2;
                    Color c = (board & 1) == 0 ? plank : Mix(plank, plankD, 28);
                    if (x % 2 == 0)
                        c = plankD;
                    if (y == wallY)
                        c = Mix(c, plankL, 40);
                    Plot(d, w, x, y, c);
                }
            }
            int beamY0 = wallY + 5;
            int beamY1 = ph - 8;
            for (int x = 1; x < pw - 1; x++)
            {
                Plot(d, w, x, beamY0, beam);
                Plot(d, w, x, beamY0 + 1, beamL);
                Plot(d, w, x, beamY1, beamL);
                Plot(d, w, x, beamY1 + 1, beam);
            }
            for (int y = wallY; y < ph - 1; y++)
            {
                Plot(d, w, 0, y, Ink);
                Plot(d, w, pw - 1, y, Ink);
            }
            int doorX0 = doorDx * tw;
            DrawFishDoor(d, w, doorX0, wallY + 10, ph - 2, open);
            DrawFishSign(d, w, doorX0 + 1, wallY + 1);
        }

        static void DrawFishDoor(Color[] d, int w, int doorX0, int y0, int y1, bool open)
        {
            int x0 = doorX0 + 2;
            int x1 = doorX0 + 14;
            Color frame = new Color(56, 34, 20);
            Color frameL = new Color(92, 60, 34);
            Color hole = new Color(16, 10, 12);
            Color holeL = new Color(36, 24, 22);
            for (int y = y0; y < y1; y++)
            {
                for (int x = x0 - 1; x <= x1; x++)
                    Plot(d, w, x, y, x <= x0 || x >= x1 - 1 || y == y0 ? frame : hole);
            }
            for (int x = x0 - 1; x <= x1; x++)
            {
                Plot(d, w, x, y0, frameL);
                Plot(d, w, x, y1 - 1, Mix(frame, Ink, 40));
            }
            for (int y = y0 + 2; y < y1 - 1; y++)
            {
                Plot(d, w, x0 + 1, y, Mix(hole, holeL, 40));
                Plot(d, w, x1 - 2, y, Mix(hole, Ink, 35));
            }
            if (open)
            {
                Color plank = new Color(128, 86, 52);
                for (int y = y0 + 1; y < y1; y++)
                {
                    int lean = (y - y0) / 8;
                    Plot(d, w, x0 - 3 - lean, y, Ink);
                    Plot(d, w, x0 - 2 - lean, y, plank);
                    Plot(d, w, x1 + lean, y, plank);
                    Plot(d, w, x1 + 1 + lean, y, Ink);
                }
            }
        }

        static void DrawFishSign(Color[] d, int w, int x, int y)
        {
            Color board = new Color(62, 132, 72);
            Color boardD = new Color(36, 86, 48);
            Color boardL = new Color(118, 176, 96);
            Color fish = new Color(118, 196, 214);
            Color fishD = new Color(48, 118, 148);
            Color fishL = new Color(186, 232, 236);
            FillRect(d, w, x, y, 14, 10, Ink);
            FillRect(d, w, x + 1, y + 1, 12, 8, board);
            FillRect(d, w, x + 2, y + 2, 10, 6, Mix(board, boardD, 25));
            Plot(d, w, x + 1, y + 1, boardL);
            for (int i = 0; i < 7; i++)
            {
                Plot(d, w, x + 4 + i, y + 4, fish);
                Plot(d, w, x + 4 + i, y + 5, fishD);
            }
            Plot(d, w, x + 3, y + 4, fishD);
            Plot(d, w, x + 11, y + 3, fish);
            Plot(d, w, x + 11, y + 6, fish);
            Plot(d, w, x + 12, y + 4, fishL);
            Plot(d, w, x + 12, y + 5, fish);
            Plot(d, w, x + 6, y + 4, fishL);
        }

        static void PaintFarmhouse(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            int doorX0 = doorDx * tw;
            Color r0 = new Color(206, 92, 48);
            Color r1 = new Color(232, 140, 78);
            Color r2 = new Color(168, 70, 40);
            Color r3 = new Color(108, 48, 32);
            Color plaster = new Color(236, 220, 192);
            Color plasterL = new Color(248, 236, 214);
            Color plasterD = new Color(196, 176, 148);
            Color beam = new Color(62, 38, 22);
            Color beamL = new Color(98, 64, 38);
            Color stone = new Color(92, 88, 84);
            Color stoneL = new Color(132, 126, 120);
            Color stoneD = new Color(58, 54, 52);
            int mainX0 = 16;
            int mainX1 = pw - 20;
            int mid = (mainX0 + mainX1) / 2;
            int eaveHalf = (mainX1 - mainX0) / 2;
            int ridgeHalf = eaveHalf * 5 / 8;
            int ridgeY = 12;
            int eaveY = 50;
            int wallY = eaveY + 4;

            DrawHipRoof(d, w, mid, ridgeY, eaveY, ridgeHalf, eaveHalf, r0, r1, r2, r3);
            DrawFarmRidge(d, w, mid - ridgeHalf + 1, mid + ridgeHalf - 1, ridgeY, r1, r2, r3);
            for (int y = eaveY; y < wallY; y++)
            {
                int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                for (int x = mid - hw; x <= mid + hw; x++)
                    Plot(d, w, x, y, y == eaveY ? Mix(r3, Ink, 20) : Mix(r2, beam, 25));
            }

            for (int y = wallY; y < ph - 1; y++)
            {
                for (int x = mainX0; x < mainX1; x++)
                {
                    Color c = ((x / 4 + y / 3) & 1) == 0 ? plaster : Mix(plaster, plasterD, 22);
                    if (Hash(x / 3, y / 3, 19) % 7 == 0)
                        c = Mix(c, plasterL, 30);
                    if (x == mainX0)
                        c = plasterL;
                    if (x == mainX1 - 1)
                        c = plasterD;
                    if (y >= ph - 5)
                    {
                        c = ((x / 3 + y) & 1) == 0 ? stone : stoneL;
                        if (y == ph - 2)
                            c = stoneD;
                    }
                    Plot(d, w, x, y, c);
                }
            }
            for (int x = mainX0; x < mainX1; x++)
            {
                Plot(d, w, x, wallY, beamL);
                Plot(d, w, x, wallY + 1, beam);
                Plot(d, w, x, wallY + 22, beamL);
                Plot(d, w, x, wallY + 23, beam);
                Plot(d, w, x, ph - 6, beamL);
                Plot(d, w, x, ph - 5, beam);
            }
            int[] posts = { mainX0, mainX0 + (mainX1 - mainX0) / 3, mainX0 + (mainX1 - mainX0) * 2 / 3, mainX1 - 3 };
            for (int i = 0; i < posts.Length; i++)
            {
                int px = posts[i];
                for (int y = wallY; y < ph - 1; y++)
                {
                    Plot(d, w, px, y, beamL);
                    Plot(d, w, px + 1, y, beam);
                    Plot(d, w, px + 2, y, Mix(beam, Ink, 30));
                }
            }

            DrawFarmLeanTo(d, w, 1, wallY - 8, 20, ph);
            DrawFarmRightWing(d, w, mainX1 - 6, wallY - 4, pw - 2, ph, open);
            DrawHouseDoor(d, w, doorX0, wallY + 10, ph - 3, 1, beam, beamL, open);
            DrawVillageStep(d, w, doorX0, ph - 3, ph, stoneL, Mix(stoneL, Color.White, 20), stoneD);
            DrawFarmShutters(d, w, mainX0 + 10, wallY + 8);
            DrawFarmShutters(d, w, mainX1 - 24, wallY + 8);
            DrawFarmChimney(d, w, mid + ridgeHalf - 6, ridgeY + 4);
            DrawFarmBush(d, w, doorX0 - 14, ph - 12);
            DrawFarmBush(d, w, doorX0 + 16, ph - 12);
        }

        static void DrawFarmRidge(Color[] d, int w, int x0, int x1, int y, Color r1, Color r2, Color r3)
        {
            Color cap = Mix(r1, Color.White, 10);
            for (int x = x0; x <= x1; x++)
            {
                Plot(d, w, x, y, Mix(cap, Color.White, 20));
                Plot(d, w, x, y + 1, cap);
                Plot(d, w, x, y + 2, r2);
                Plot(d, w, x, y + 3, Mix(r3, Ink, 20));
            }
        }

        static int HipHalf(int y, int ridgeY, int eaveY, int ridgeHalf, int eaveHalf)
        {
            if (y < ridgeY)
                return 0;
            if (y >= eaveY)
                return eaveHalf;
            int span = eaveY - ridgeY;
            return ridgeHalf + (eaveHalf - ridgeHalf) * (y - ridgeY) / Math.Max(1, span);
        }

        static void DrawHipRoof(
            Color[] d, int w, int mid, int ridgeY, int eaveY,
            int ridgeHalf, int eaveHalf,
            Color r0, Color r1, Color r2, Color r3)
        {
            for (int y = ridgeY; y <= eaveY; y++)
            {
                int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                for (int x = mid - hw; x <= mid + hw; x++)
                {
                    Color c = VillageRoofTile(x, y, r0, r1, r2, r3, 1);
                    if (x == mid - hw || x == mid + hw)
                        c = Mix(r3, Ink, 45);
                    if (y == ridgeY)
                        c = Mix(r1, Color.White, 18);
                    if (y == eaveY)
                        c = Mix(r3, Ink, 25);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawFarmLeanTo(Color[] d, int w, int x0, int y0, int x1, int ph)
        {
            Color slat = new Color(196, 178, 138);
            Color slatL = new Color(220, 204, 164);
            Color slatD = new Color(148, 128, 92);
            Color plank = new Color(138, 96, 58);
            Color plankD = new Color(92, 62, 36);
            int doorX = x0 + 4;
            for (int y = y0; y < ph - 1; y++)
            {
                int drop = Math.Max(0, (y - y0) / 3);
                int rx = x1 - 2 + drop / 2;
                for (int x = x0; x < rx && x < x1 + 4; x++)
                {
                    Color c;
                    if (y < y0 + 10 + (x - x0) / 2)
                    {
                        int row = (y + x) / 2;
                        c = (row & 1) == 0 ? slat : slatD;
                        if ((x + y) % 5 == 0)
                            c = slatL;
                    }
                    else
                    {
                        int col = x / 2;
                        c = (col & 1) == 0 ? plank : plankD;
                        if (x % 2 == 0)
                            c = Mix(plankD, Ink, 20);
                        if (y >= ph - 4)
                            c = new Color(88, 84, 80);
                    }
                    Plot(d, w, x, y, c);
                }
            }
            for (int y = ph - 16; y < ph - 2; y++)
            {
                for (int x = doorX; x < doorX + 8; x++)
                {
                    Color c = (x - doorX) % 2 == 0 ? plank : Mix(plank, plankD, 30);
                    if (x == doorX || x == doorX + 7 || y == ph - 16)
                        c = Mix(plankD, Ink, 40);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawFarmRightWing(Color[] d, int w, int x0, int y0, int x1, int ph, bool open)
        {
            Color roof = new Color(176, 78, 42);
            Color roofD = new Color(118, 48, 28);
            Color board = new Color(86, 56, 34);
            Color boardD = new Color(56, 34, 20);
            Color glow = new Color(255, 186, 92);
            Color glowD = new Color(176, 96, 40);
            for (int y = y0; y < ph - 1; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    Color c;
                    if (y < y0 + 8 + (x - x0) / 4)
                    {
                        c = ((x / 3 + y / 2) & 1) == 0 ? roof : roofD;
                    }
                    else
                    {
                        int col = x / 2;
                        c = (col & 1) == 0 ? board : boardD;
                        if (x % 2 == 0)
                            c = Mix(boardD, Ink, 25);
                        if (y >= ph - 4)
                            c = new Color(72, 68, 66);
                    }
                    Plot(d, w, x, y, c);
                }
            }
            int dx0 = x0 + 4;
            int dx1 = Math.Min(x1 - 2, dx0 + 10);
            for (int y = ph - 18; y < ph - 2; y++)
            {
                for (int x = dx0; x < dx1; x++)
                {
                    float t = (y - (ph - 18)) / 16f;
                    Color c = Mix(glow, glowD, (int)(t * 70));
                    if (open)
                        c = Mix(c, new Color(255, 220, 140), 30);
                    if (x == dx0 || x == dx1 - 1 || y == ph - 18)
                        c = boardD;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawFarmShutters(Color[] d, int w, int x0, int y0)
        {
            Color frame = new Color(48, 30, 18);
            Color wood = new Color(86, 56, 34);
            Color glass = new Color(168, 196, 214);
            FillRect(d, w, x0, y0, 7, 7, frame);
            FillRect(d, w, x0 + 1, y0 + 1, 5, 5, glass);
            Plot(d, w, x0 + 3, y0 + 2, Mix(glass, Color.White, 40));
            for (int y = y0; y < y0 + 7; y++)
            {
                Plot(d, w, x0 - 2, y, wood);
                Plot(d, w, x0 - 1, y, Mix(wood, frame, 40));
                Plot(d, w, x0 + 7, y, Mix(wood, frame, 40));
                Plot(d, w, x0 + 8, y, wood);
            }
        }

        static void DrawFarmChimney(Color[] d, int w, int cx, int cy)
        {
            Color plaster = new Color(236, 232, 224);
            Color plasterD = new Color(186, 178, 168);
            Color plasterL = new Color(252, 248, 240);
            Color soot = new Color(48, 44, 42);
            Color smoke = new Color(236, 236, 238);
            Color smokeD = new Color(196, 196, 200);
            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 10; x++)
                {
                    Color c = plaster;
                    if (x == 0)
                        c = plasterD;
                    if (x == 9)
                        c = Mix(plasterD, soot, 20);
                    if (y == 0)
                        c = plasterL;
                    if (x == 4 && y >= 4 && y <= 12)
                        c = Mix(plasterD, soot, 55);
                    Plot(d, w, cx + x, cy + y, c);
                }
            }
            FillRect(d, w, cx + 1, cy - 2, 8, 2, plasterD);
            FillRect(d, w, cx + 3, cy - 3, 4, 2, soot);
            Plot(d, w, cx + 5, cy - 5, smoke);
            Plot(d, w, cx + 6, cy - 6, smokeD);
            Plot(d, w, cx + 7, cy - 8, smoke);
            Plot(d, w, cx + 8, cy - 7, Mix(smoke, Color.White, 30));
            Plot(d, w, cx + 9, cy - 9, smokeD);
        }

        static void DrawFarmBush(Color[] d, int w, int cx, int cy)
        {
            Color a = new Color(86, 168, 72);
            Color b = new Color(58, 128, 52);
            Color c = new Color(118, 196, 88);
            FillOval(d, w, cx, cy, cx + 14, cy + 11, b);
            FillOval(d, w, cx + 2, cy + 1, cx + 12, cy + 9, a);
            Plot(d, w, cx + 4, cy + 2, c);
            Plot(d, w, cx + 9, cy + 3, c);
            Plot(d, w, cx + 6, cy + 1, Mix(c, Color.White, 20));
        }

        public static Texture2D LogSlice(GraphicsDevice gd)
        {
            Color a = new Color(176, 132, 78);
            Color b = new Color(132, 92, 52);
            Color c = new Color(214, 176, 118);
            Color ring = new Color(92, 62, 36);
            return Build(gd, 12, 8, (d, w, h) =>
            {
                FillOval(d, w, 1, 1, 10, 7, b);
                FillOval(d, w, 2, 2, 9, 6, a);
                Plot(d, w, 5, 3, c);
                Plot(d, w, 6, 4, ring);
                Plot(d, w, 4, 4, Mix(a, ring, 40));
            });
        }

        /// <summary>
        /// Village blacksmith from the supplied L-shaped sprite, at 16px/tile then Scale2 to 32×32.
        /// Left timber-and-stone cottage, right stone workshop, outdoor furnace and anvil.
        /// </summary>
        static void PaintBlacksmith(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            int doorX0 = doorDx * tw;
            int wallY = roofH + fasciaH;
            int leftMid = 28;
            int leftHalf = 26;
            int rightMid = 78;
            int rightHalf = 30;
            int splitY = wallY;
            Color wood = new Color(156, 86, 52);
            Color woodL = new Color(186, 118, 70);
            Color woodD = new Color(108, 54, 32);
            Color trim = new Color(148, 82, 48);
            Color stone = new Color(176, 178, 182);
            Color stoneL = new Color(210, 212, 216);
            Color stoneD = new Color(120, 122, 128);
            Color mortar = new Color(92, 94, 100);
            Color glass = new Color(72, 186, 236);
            Color glassL = new Color(168, 228, 252);

            DrawGreyGable(d, w, rightMid, 18, ph - 1, rightHalf);
            FillSmithStone(d, w, rightMid, 18, ph - 1, splitY - 4, ph - 1, rightHalf, stone, stoneL, stoneD, mortar);
            DrawGreyGable(d, w, leftMid, 3, splitY + 2, leftHalf);
            FillSmithWood(d, w, leftMid, 3, ph - 1, splitY - 16, splitY, leftHalf, wood, woodL, woodD);
            FillSmithStone(d, w, leftMid, 3, ph - 1, splitY, ph - 1, leftHalf, stone, stoneL, stoneD, mortar);
            DrawGreyRidge(d, w, leftMid, 3, splitY + 2, leftHalf, trim);
            DrawGreyRidge(d, w, rightMid, 18, splitY, rightHalf, trim);
            DrawSmithChimney(d, w, rightMid + 8, 10, stone, stoneL, stoneD);
            DrawSmithBlueWindow(d, w, leftMid + 4, splitY - 14, glass, glassL, woodD);
            DrawSmithBlueWindow(d, w, doorX0 + 16, splitY + 6, glass, glassL, woodD);
            DrawHouseDoor(d, w, doorX0, splitY + 3, ph - 3, 1, woodD, woodL, open);
            DrawVillageStep(d, w, doorX0, ph - 3, ph, stoneL, Mix(stoneL, Color.White, 18), stoneD);
            DrawSmithFlowerPot(d, w, doorX0 - 10, ph - 14);
            DrawSmithTrough(d, w, doorX0 + 16, ph - 10, glass, wood, woodD);
            DrawSmithFurnace(d, w, 52, splitY - 8, ph, stone, stoneL, stoneD, mortar);
            DrawSmithAnvil(d, w, 86, ph - 16, wood, woodD);
            DrawSmithCrates(d, w, 94, ph - 18, wood, woodD);
        }

        static Color GreyShingle(int x, int y)
        {
            Color r0 = new Color(78, 82, 90);
            Color r1 = new Color(118, 122, 130);
            Color r2 = new Color(52, 54, 62);
            Color r3 = new Color(34, 36, 42);
            int row = y / 3;
            int shift = (row % 2) * 4;
            int col = (x + shift) / 6;
            int lx = (x + shift) % 6;
            int ly = y % 3;
            Color c = ((col + row) & 1) == 0 ? r0 : Mix(r0, r2, 28);
            if (ly == 0)
                c = Mix(c, r1, 48);
            else if (ly == 2)
                c = Mix(c, r3, 42);
            if (lx == 0)
                c = Mix(c, r3, 38);
            return c;
        }

        static Color SmithBrick(int x, int y, Color stone, Color stoneL, Color stoneD, Color mortar)
        {
            int row = y / 3;
            int shift = (row % 2) * 3;
            int lx = (x + shift) % 6;
            int ly = y % 3;
            Color c = ((x / 6 + row) & 1) == 0 ? stone : Mix(stone, stoneD, 22);
            if (Hash(x / 6, row, 19) % 5 == 0)
                c = stoneL;
            if (lx == 0 || ly == 0)
                c = mortar;
            return c;
        }

        static void DrawGreyGable(Color[] d, int w, int mid, int peakY, int baseY, int halfW)
        {
            for (int y = peakY; y <= baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw; x <= mid + hw; x++)
                {
                    Color c = GreyShingle(x, y);
                    if (x == mid - hw || x == mid + hw)
                        c = Mix(c, Ink, 40);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawGreyRidge(Color[] d, int w, int mid, int peakY, int baseY, int halfW, Color trim)
        {
            Color trimD = Mix(trim, Ink, 30);
            for (int y = peakY; y <= baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                Plot(d, w, mid, y, trim);
                Plot(d, w, mid - 1, y, Mix(trim, Color.White, 12));
                Plot(d, w, mid + 1, y, trimD);
                Plot(d, w, mid - hw, y, trimD);
                Plot(d, w, mid + hw, y, trimD);
            }
        }

        static void FillSmithWood(
            Color[] d, int w, int mid, int peakY, int gableBase, int y0, int y1, int halfW,
            Color wood, Color woodL, Color woodD)
        {
            for (int y = y0; y < y1; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, gableBase - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw + 2; x < mid + hw - 1; x++)
                {
                    Color c = (y / 2 & 1) == 0 ? wood : Mix(wood, woodD, 28);
                    if (y % 2 == 0)
                        c = Mix(c, woodD, 30);
                    if (x == mid - hw + 2)
                        c = woodL;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void FillSmithStone(
            Color[] d, int w, int mid, int peakY, int gableBase, int y0, int y1, int halfW,
            Color stone, Color stoneL, Color stoneD, Color mortar)
        {
            for (int y = y0; y <= y1; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, gableBase - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw + 1; x < mid + hw; x++)
                    Plot(d, w, x, y, SmithBrick(x, y, stone, stoneL, stoneD, mortar));
            }
        }

        static void DrawSmithBlueWindow(Color[] d, int w, int x0, int y0, Color glass, Color glassL, Color frame)
        {
            FillRect(d, w, x0, y0, 9, 9, frame);
            FillRect(d, w, x0 + 1, y0 + 1, 7, 7, glass);
            Plot(d, w, x0 + 2, y0 + 2, glassL);
            Plot(d, w, x0 + 3, y0 + 2, Mix(glassL, Color.White, 30));
            for (int i = 1; i < 8; i++)
            {
                Plot(d, w, x0 + 4, y0 + i, frame);
                Plot(d, w, x0 + i, y0 + 4, frame);
            }
        }

        static void DrawSmithChimney(Color[] d, int w, int cx, int cy, Color stone, Color stoneL, Color stoneD)
        {
            Color mortar = new Color(92, 94, 100);
            for (int y = 0; y < 18; y++)
            {
                for (int x = 0; x < 10; x++)
                    Plot(d, w, cx + x, cy + y, SmithBrick(cx + x, cy + y, stone, stoneL, stoneD, mortar));
            }
            FillRect(d, w, cx + 1, cy - 2, 8, 2, stoneD);
            FillRect(d, w, cx + 3, cy - 3, 4, 2, Mix(stoneD, Ink, 30));
        }

        static void DrawSmithFlowerPot(Color[] d, int w, int x, int y)
        {
            Color pot = new Color(148, 96, 52);
            Color potD = new Color(108, 64, 36);
            Color leaf = new Color(62, 128, 64);
            Color bloom = new Color(168, 92, 196);
            FillRect(d, w, x, y + 6, 8, 6, pot);
            for (int i = 0; i < 8; i++)
                Plot(d, w, x + i, y + 6, potD);
            Plot(d, w, x + 2, y + 3, leaf);
            Plot(d, w, x + 3, y + 1, leaf);
            Plot(d, w, x + 4, y + 2, bloom);
            Plot(d, w, x + 5, y, bloom);
            Plot(d, w, x + 6, y + 3, Mix(bloom, Color.White, 20));
            Plot(d, w, x + 3, y + 4, leaf);
        }

        static void DrawSmithTrough(Color[] d, int w, int x, int y, Color water, Color wood, Color woodD)
        {
            FillRect(d, w, x, y, 10, 6, wood);
            FillRect(d, w, x + 1, y + 1, 8, 3, Mix(water, new Color(36, 92, 148), 30));
            Plot(d, w, x + 3, y + 2, Mix(water, Color.White, 40));
            for (int i = 0; i < 10; i++)
                Plot(d, w, x + i, y, woodD);
        }

        static void DrawSmithFurnace(
            Color[] d, int w, int x0, int y0, int ph,
            Color stone, Color stoneL, Color stoneD, Color mortar)
        {
            int fw = 22;
            int fy1 = ph - 2;
            Color glow = new Color(255, 148, 52);
            Color glowD = new Color(196, 72, 28);
            for (int y = y0; y < fy1; y++)
            {
                for (int x = x0; x < x0 + fw; x++)
                    Plot(d, w, x, y, SmithBrick(x, y, stone, stoneL, stoneD, mortar));
            }
            int stackX = x0 + 6;
            for (int y = y0 - 14; y < y0 + 4; y++)
            {
                for (int x = stackX; x < stackX + 10; x++)
                    Plot(d, w, x, y, SmithBrick(x, y, stoneL, stone, stoneD, mortar));
            }
            FillRect(d, w, stackX + 1, y0 - 16, 8, 2, stoneD);
            int mouthY = fy1 - 12;
            for (int y = mouthY; y < fy1 - 3; y++)
            {
                int inset = (y == mouthY || y == fy1 - 4) ? 3 : 2;
                for (int x = x0 + 5 + inset; x < x0 + fw - 5 - inset; x++)
                {
                    float t = (y - mouthY) / 10f;
                    Plot(d, w, x, y, Mix(glow, glowD, (int)(t * 70)));
                }
            }
            Plot(d, w, x0 + 11, mouthY + 2, Mix(glow, Color.White, 40));
        }

        static void DrawSmithAnvil(Color[] d, int w, int x, int y, Color wood, Color woodD)
        {
            Color anvil = new Color(86, 102, 124);
            Color anvilL = new Color(128, 146, 168);
            Color anvilD = new Color(48, 56, 70);
            FillRect(d, w, x + 1, y + 6, 10, 4, wood);
            for (int i = 0; i < 10; i++)
                Plot(d, w, x + 1 + i, y + 6, woodD);
            FillRect(d, w, x + 2, y, 9, 3, anvil);
            FillRect(d, w, x, y + 1, 4, 2, anvilL);
            FillRect(d, w, x + 4, y + 3, 5, 4, anvilD);
            Plot(d, w, x + 10, y + 1, anvilL);
            Plot(d, w, x + 3, y, Mix(anvilL, Color.White, 20));
        }

        static void DrawSmithCrates(Color[] d, int w, int x, int y, Color wood, Color woodD)
        {
            FillRect(d, w, x, y + 4, 12, 6, wood);
            FillRect(d, w, x + 2, y, 10, 5, Mix(wood, woodD, 20));
            for (int i = 0; i < 12; i++)
                Plot(d, w, x + i, y + 4, woodD);
            Plot(d, w, x + 6, y + 1, woodD);
            Plot(d, w, x + 6, y + 7, woodD);
        }

        static void DrawVillageRoof(
            Color[] d, int w, int pw, int roofH,
            Color r0, Color r1, Color r2, Color r3, int style)
        {
            bool thatch = style == 0 || style == 2;
            for (int y = 0; y < roofH; y++)
            {
                float t = y / (float)Math.Max(1, roofH - 1);
                int inset = thatch ? (int)((1f - t) * 4) : (int)((1f - t) * 3);
                int x0 = 1 + inset;
                int x1 = pw - 1 - inset;
                for (int x = x0; x < x1; x++)
                {
                    if (thatch && y == 0 && Hash(x, 0, 11) % 3 == 0)
                        continue;
                    int hang = 0;
                    if (thatch && y > roofH - 9)
                        hang = 1 + Hash(x / 2, style, 44) % 5;
                    if (thatch && y > roofH - hang)
                        continue;
                    Color c = thatch
                        ? ThatchPixel(x, y, r0, r1, r2, r3, style)
                        : VillageRoofTile(x, y, r0, r1, r2, r3, style);
                    float across = (x - x0) / (float)Math.Max(1, x1 - x0);
                    if (across < 0.16f)
                        c = Mix(c, r1, 42);
                    if (across > 0.84f)
                        c = Mix(c, r3, 48);
                    if (y < 3)
                        c = Mix(c, r1, 22);
                    if (y > roofH - 5)
                        c = Mix(c, r3, 28);
                    if (x == x0)
                        c = Mix(r1, Color.White, 18);
                    if (x == x1 - 1)
                        c = LineC(r3);
                    if (y == 0)
                        c = thatch ? Mix(r1, Color.White, 20) : LineC(r3);
                    Plot(d, w, x, y, c);
                }
            }
            if (thatch)
            {
                Color straw = Mix(r1, Color.White, 18);
                for (int x = 6; x < pw - 6; x += 3)
                {
                    if (Hash(x, 2, 19) % 4 == 0)
                        Plot(d, w, x, 1, straw);
                    if (Hash(x, 3, 23) % 5 == 0)
                        Plot(d, w, x + 1, 0, Mix(r0, r3, 40));
                }
            }
        }

        static Color ThatchPixel(int x, int y, Color r0, Color r1, Color r2, Color r3, int style)
        {
            int row = y / 3;
            int shift = (row % 2) * 4;
            int lx = (x + shift) % 8;
            int ly = y % 3;
            Color c = (Hash(x / 2, row, 31) & 1) == 0 ? r0 : Mix(r0, r2, 28);
            if (ly == 0)
                c = Mix(c, r1, 55);
            else if (ly == 2)
                c = Mix(c, r3, 45);
            if (lx == 0)
                c = Mix(c, r3, 40);
            else if (lx <= 2 && ly == 0)
                c = Mix(c, r1, 35);
            Color moss = new Color(86, 128, 64);
            if (Hash(x, y, 77 + style) % 18 == 0)
                c = Mix(c, moss, 55);
            if (style == 2 && Hash(x / 3, y / 3, 91) % 6 == 0)
                c = Mix(c, moss, 40);
            return c;
        }

        static Color VillageRoofTile(int x, int y, Color r0, Color r1, Color r2, Color r3, int style)
        {
            int row = y / 4;
            int shift = (row % 2) * 3;
            int col = (x + shift) / 6;
            int lx = (x + shift) % 6;
            int ly = y % 4;
            Color c = ((col + row) & 1) == 0 ? r0 : Mix(r0, r2, 30);
            if (Hash(col, row, 53) % 8 == 0)
                c = Mix(c, r1, 36);
            if (ly == 0)
                c = Mix(c, r1, 58);
            else if (ly == 3)
                c = Mix(c, r3, 55);
            if (lx == 0)
                c = Mix(c, r3, 52);
            else if (lx == 1 && ly <= 1)
                c = Mix(c, r1, 40);
            if (style == 2 && Hash(col, row, 91) % 10 == 0)
                c = Mix(c, new Color(78, 112, 58), 48);
            if (style == 2 && Hash(x, y, 77) % 23 == 0)
                c = Mix(c, new Color(92, 118, 54), 32);
            return c;
        }

        static void DrawVillageFascia(Color[] d, int w, int pw, int y0, int fasciaH, Color r0, Color r2, Color r3, int style)
        {
            bool thatch = style == 0 || style == 2;
            Color under = new Color(32, 20, 16);
            for (int y = 0; y < fasciaH; y++)
            {
                for (int x = 1; x < pw - 1; x++)
                {
                    Color c;
                    if (thatch)
                    {
                        c = ThatchPixel(x, y0 + y, r0, r0, r2, r3, style);
                        if (y == fasciaH - 1)
                            c = Mix(r3, under, 40);
                        if (y == fasciaH - 2 && Hash(x, y, 41) % 4 == 0)
                            continue;
                    }
                    else if (y == 0)
                        c = Mix(r0, Color.White, 12);
                    else if (y == 1)
                        c = r2;
                    else if (y == fasciaH - 1)
                        c = under;
                    else
                        c = Mix(r3, under, 28);
                    if (x == 1)
                        c = Mix(c, Color.White, 18);
                    if (x == pw - 2)
                        c = LineC(r3);
                    Plot(d, w, x, y0 + y, c);
                }
            }
        }

        static void DrawTimberFrame(Color[] d, int w, int pw, int wallY, int y1, Color beam, Color beamL)
        {
            int x0 = 2;
            int x1 = pw - 6;
            Color ink = LineC(beam);
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, wallY + 1, beamL);
                Plot(d, w, x, wallY + 2, beam);
                Plot(d, w, x, wallY + 3, ink);
            }
            for (int px = x0; px < x1; px += 16)
            {
                for (int y = wallY + 1; y < y1; y++)
                {
                    Plot(d, w, px, y, beamL);
                    Plot(d, w, px + 1, y, beam);
                    if (px + 2 < x1)
                        Plot(d, w, px + 2, y, ink);
                }
            }
            int midY = wallY + (y1 - wallY) / 2;
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, midY, beamL);
                Plot(d, w, x, midY + 1, beam);
            }
        }

        static void DrawChimneyIvy(Color[] d, int w, int cx, int cy, int seed)
        {
            Color leaf = new Color(72, 128, 62);
            Color bloom = new Color(236, 140, 158);
            for (int i = 0; i < 7; i++)
            {
                int x = cx + ((i + seed) & 1);
                int y = cy + 4 + i;
                Plot(d, w, x, y, leaf);
                if ((i + seed) % 3 == 0)
                    Plot(d, w, x + 1, y, bloom);
            }
        }

        static void DrawVillageWall(
            Color[] d, int w, int pw, int y0, int y1,
            Color plaster, Color plasterD, Color plasterL,
            Color beam, Color beamL,
            Color stone, Color stoneL, Color stoneD)
        {
            int east = 4;
            int x0 = 1;
            int x1 = pw - 1 - east;
            for (int y = y0; y < y1; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    Color c = plaster;
                    if (x - x0 < 2)
                        c = plasterL;
                    if (x >= x1 - 2)
                        c = plasterD;
                    if (y == y0)
                        c = Mix(plasterD, beam, 28);
                    else if (y == y0 + 1)
                        c = Mix(plaster, plasterD, 45);
                    else if (y == y0 + 2)
                        c = Mix(plaster, beam, 18);
                    if (x == x0 + 1)
                        c = Mix(plasterL, beamL, 25);
                    if (x == x1 - 2)
                        c = Mix(plasterD, beam, 20);
                    if (y >= y1 - 3)
                    {
                        c = ((x + y) % 3 == 0) ? stoneL : stone;
                        if (y == y1 - 1)
                            c = stoneD;
                    }
                    if (x == x0 || x == x1 - 1 || y == y1 - 1)
                        c = LineC(c);
                    Plot(d, w, x, y, c);
                }
                for (int x = x1; x < pw - 1; x++)
                {
                    Color c = Mix(plasterD, beam, 22);
                    if (x == x1)
                        c = Mix(plasterD, plaster, 18);
                    if (x == pw - 2)
                        c = LineC(plasterD);
                    if (y >= y1 - 3)
                        c = stoneD;
                    if (y == y1 - 1)
                        c = LineC(stoneD);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawVillageChimney(
            Color[] d, int w, int pw, int cy, int cx,
            Color chim, Color chimL, Color chimD)
        {
            int cw = 12;
            int ch = 13;
            if (cx < 2 || cx + cw >= pw - 1)
                return;
            Color top = Mix(chimL, Color.White, 18);
            Color east = Mix(chimD, chim, 30);
            for (int y = 0; y < 5; y++)
            {
                int inset = y == 0 ? 1 : 0;
                for (int x = inset; x < cw - 2 - inset; x++)
                {
                    Color c = top;
                    if (x == inset || y == 0)
                        c = Mix(top, Color.White, 20);
                    if (x == cw - 3 - inset || y == 4)
                        c = Mix(top, chimD, 35);
                    Plot(d, w, cx + x + 1, cy + y, c);
                }
            }
            for (int y = 3; y < ch; y++)
            {
                for (int x = cw - 3; x < cw; x++)
                {
                    Color c = east;
                    if ((y / 3 + x) % 2 == 0)
                        c = chimD;
                    if (x == cw - 1)
                        c = LineC(chimD);
                    Plot(d, w, cx + x, cy + y, c);
                }
            }
            for (int y = 5; y < ch; y++)
            {
                for (int x = 0; x < cw - 2; x++)
                {
                    Color c = chim;
                    if ((y / 3) % 2 == 0)
                        c = (x < 5) ? chimL : chim;
                    else
                        c = (x >= 5) ? chimL : chim;
                    if (x % 5 == 0 || y % 3 == 0)
                        c = Mix(c, chimD, 40);
                    if (x == 0)
                        c = chimD;
                    if (x == cw - 3)
                        c = Mix(chim, chimD, 35);
                    if (y == ch - 1)
                        c = LineC(chimD);
                    Plot(d, w, cx + x, cy + y, c);
                }
            }
            Color soot = new Color(28, 22, 20);
            FillRect(d, w, cx + 2, cy - 2, cw - 2, 2, Mix(chimD, chimL, 40));
            FillRect(d, w, cx + 4, cy - 1, 4, 2, soot);
            Plot(d, w, cx + 5, cy - 3, Mix(soot, chimD, 30));
        }

        static void DrawVillageWindow(Color[] d, int w, int x0, int y0, int style)
        {
            int ww = 9;
            int wh = 8;
            Color frame = new Color(118, 82, 52);
            Color frameL = new Color(176, 138, 88);
            Color glass = new Color(186, 168, 118);
            Color glassD = new Color(132, 118, 78);
            Color shine = new Color(252, 236, 196);
            Color ink = LineC(frame);
            FillRect(d, w, x0, y0, ww, wh, ink);
            FillRect(d, w, x0 + 1, y0 + 1, ww - 2, wh - 2, frame);
            Plot(d, w, x0 + 1, y0 + 1, frameL);
            for (int y = y0 + 2; y < y0 + wh - 1; y++)
            {
                for (int x = x0 + 2; x < x0 + ww - 1; x++)
                {
                    Color c = (x + y) < x0 + y0 + 7 ? Mix(glass, shine, 28) : glassD;
                    Plot(d, w, x, y, c);
                }
            }
            int mx = x0 + ww / 2;
            int my = y0 + wh / 2;
            for (int y = y0 + 2; y < y0 + wh - 1; y++)
                Plot(d, w, mx, y, Mix(frame, ink, 30));
            for (int x = x0 + 2; x < x0 + ww - 1; x++)
                Plot(d, w, x, my, Mix(frame, ink, 30));
            Plot(d, w, x0 + 2, y0 + 2, shine);
            Color sill = new Color(186, 150, 96);
            for (int x = x0; x < x0 + ww; x++)
                Plot(d, w, x, y0 + wh - 1, Mix(sill, frame, 40));
            Color box = new Color(118, 78, 46);
            Color leaf = new Color(72, 128, 62);
            Color leafL = new Color(118, 168, 78);
            Color bloomA = style == 3 ? new Color(236, 96, 118) : new Color(242, 168, 186);
            Color bloomB = new Color(252, 244, 214);
            Color bloomC = new Color(232, 148, 72);
            Color bloomD = new Color(186, 92, 128);
            for (int x = x0 - 1; x < x0 + ww + 1; x++)
            {
                Plot(d, w, x, y0 + wh, box);
                Plot(d, w, x, y0 + wh + 1, Mix(box, ink, 35));
            }
            Plot(d, w, x0, y0 + wh - 1, leaf);
            Plot(d, w, x0 + 1, y0 + wh - 1, bloomA);
            Plot(d, w, x0 + 2, y0 + wh - 1, leafL);
            Plot(d, w, x0 + 3, y0 + wh, bloomB);
            Plot(d, w, x0 + 4, y0 + wh - 1, bloomC);
            Plot(d, w, x0 + 5, y0 + wh, leaf);
            Plot(d, w, x0 + 6, y0 + wh - 1, bloomA);
            Plot(d, w, x0 + ww - 3, y0 + wh, bloomD);
            Plot(d, w, x0 + ww - 2, y0 + wh - 1, leafL);
            Plot(d, w, x0 + ww - 1, y0 + wh, bloomC);
            Plot(d, w, x0 + 2, y0 + wh + 1, bloomA);
            Plot(d, w, x0 + 5, y0 + wh + 1, bloomB);
            Plot(d, w, x0 + 7, y0 + wh + 1, leaf);
            if (style == 3 || style == 1)
            {
                Color shut = style == 3 ? new Color(118, 72, 78) : new Color(96, 122, 78);
                Color shutL = Mix(shut, Color.White, 22);
                for (int y = y0 + 1; y < y0 + wh - 1; y++)
                {
                    Plot(d, w, x0 - 1, y, shutL);
                    Plot(d, w, x0 - 2, y, shut);
                    Plot(d, w, x0 + ww, y, shut);
                    Plot(d, w, x0 + ww + 1, y, shutL);
                }
            }
        }

        static void DrawVillageStep(Color[] d, int w, int doorX0, int y0, int ph, Color stone, Color stoneL, Color stoneD)
        {
            int x0 = doorX0;
            int x1 = doorX0 + 16;
            for (int y = y0; y < ph; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    Color c = ((x + y) % 3 == 0) ? stoneL : stone;
                    if (y == y0 || x == x0 || x == x1 - 1)
                        c = stoneD;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawClimbingRoses(Color[] d, int w, int x0, int y0, int y1, int seed)
        {
            Color leaf = new Color(72, 128, 62);
            Color leafL = new Color(118, 168, 78);
            Color leafD = new Color(44, 86, 48);
            Color[] blooms =
            {
                new Color(236, 150, 168),
                new Color(252, 236, 214),
                new Color(232, 118, 128),
                new Color(244, 186, 96)
            };
            int x = x0;
            for (int y = y0; y < y1; y += 2)
            {
                Plot(d, w, x, y, leafD);
                Plot(d, w, x + 1, y, leaf);
                Plot(d, w, x + 2, y, leafL);
                Plot(d, w, x, y + 1, leaf);
                Plot(d, w, x + 1, y + 1, leafL);
                if ((y / 2 + seed) % 2 == 0)
                    Plot(d, w, x + 3, y, blooms[(y / 4 + seed) & 3]);
                if ((y / 2 + seed) % 3 == 0)
                    Plot(d, w, x + 2, y - 1, blooms[(y / 3 + seed) & 3]);
                if ((y / 2) % 3 == 1)
                    x++;
                if (x > x0 + 8)
                    x = x0;
            }
        }

        static void DrawDoorWreath(Color[] d, int w, int x, int y)
        {
            Color leaf = new Color(62, 118, 58);
            Color leafL = new Color(118, 168, 78);
            Color bloom = new Color(228, 96, 112);
            Color cream = new Color(252, 240, 214);
            int[] ox = { 2, 4, 6, 8, 7, 6, 4, 2, 1, 0 };
            int[] oy = { 1, 0, 1, 3, 5, 7, 8, 7, 5, 3 };
            for (int i = 0; i < ox.Length; i++)
            {
                Plot(d, w, x + ox[i], y + oy[i], i % 2 == 0 ? leaf : leafL);
                if ((i & 1) == 0)
                    Plot(d, w, x + ox[i], y + oy[i] - 1, i % 4 == 0 ? bloom : cream);
            }
        }

        static void DrawHangingSign(Color[] d, int w, int x, int y)
        {
            Color chain = new Color(88, 68, 48);
            Color board = new Color(168, 114, 64);
            Color boardD = new Color(118, 74, 42);
            Color paint = new Color(186, 96, 108);
            Plot(d, w, x + 4, y - 2, chain);
            Plot(d, w, x + 5, y - 1, chain);
            Plot(d, w, x + 8, y - 2, chain);
            Plot(d, w, x + 7, y - 1, chain);
            FillRect(d, w, x, y, 13, 9, LineC(boardD));
            FillRect(d, w, x + 1, y + 1, 11, 7, board);
            FillRect(d, w, x + 2, y + 2, 9, 5, Mix(board, boardD, 30));
            FillRect(d, w, x + 3, y + 3, 7, 3, paint);
            Plot(d, w, x + 1, y + 1, Mix(board, Color.White, 25));
            Plot(d, w, x + 6, y + 2, new Color(72, 128, 62));
        }


        public static Texture2D CaveMouth(GraphicsDevice gd, int tilesW, int tilesH, int doorDx)
        {
            return CaveMouth(gd, tilesW, tilesH, doorDx, false);
        }

        public static Texture2D CaveMouth(GraphicsDevice gd, int tilesW, int tilesH, int doorDx, bool open)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int ph = (tilesH + 2) * tw;
            int doorX0 = doorDx * tw;
            Color face = new Color(158, 132, 108);
            Color faceL = new Color(196, 172, 142);
            Color faceD = new Color(112, 90, 74);
            Color faceX = new Color(78, 60, 50);
            Color lip = new Color(214, 194, 164);
            Color moss = new Color(96, 146, 70);
            Color hole = new Color(14, 10, 12);
            Color holeDeep = new Color(6, 4, 8);
            Color holeFloor = new Color(46, 32, 24);
            Color glow = new Color(72, 48, 28);
            return Build(gd, pw, ph, (d, w, h) =>
            {
                int[] ridge = new int[pw];
                int mid = pw / 2;
                for (int x = 0; x < pw; x++)
                {
                    float nx = (x - mid) / (pw * 0.48f);
                    int peak = 4 + (int)(nx * nx * 12);
                    int jag = Hash(x / 3, 3, 4401) % 5;
                    int flare = 0;
                    if (x < 8)
                        flare = 7 + Hash(x, 1, 9) % 6;
                    if (x > pw - 9)
                        flare = 6 + Hash(x, 2, 9) % 7;
                    ridge[x] = peak + jag + flare;
                    if (ridge[x] > ph - 28)
                        ridge[x] = ph - 28;
                }

                for (int x = 0; x < pw; x++)
                {
                    int top = ridge[x];
                    for (int y = top; y < ph; y++)
                    {
                        int col = (x + 1) / 6;
                        int lx = (x + 1) % 6;
                        Color c = ((col + (y / 8)) & 1) == 0 ? face : faceD;
                        if (lx == 0)
                            c = faceX;
                        else if (lx == 1)
                            c = faceL;
                        if (y > ph - 10)
                            c = Mix(c, faceX, 40);
                        if (Hash(x, y, 55) % 19 == 0)
                            c = Mix(c, faceX, 35);
                        if (Hash(x / 2, y / 3, 77) % 23 == 0)
                            c = moss;
                        bool southFace = y > ph - 36;
                        if (southFace)
                            c = Mix(c, faceX, 18);
                        if (x + y < top + 18)
                            c = Mix(c, faceL, 30);
                        Plot(d, w, x, y, c);
                    }
                    for (int y = top; y < top + 5 && y < ph; y++)
                    {
                        Color g = y == top ? G4 : (y == top + 1 ? G0 : G1);
                        if (y == top + 4)
                            g = Ink;
                        if (y == top + 3 && Hash(x, 4, 91) % 3 != 0)
                            g = G2;
                        Plot(d, w, x, y, g);
                    }
                    if (top + 5 < ph)
                        Plot(d, w, x, top + 5, lip);
                }

                int cx = doorX0 + tw / 2;
                int cy = ph - 6;
                int rx = open ? 16 : 13;
                int ry = open ? 26 : 22;
                for (int y = cy - ry; y < ph - 1; y++)
                {
                    for (int x = cx - rx - 2; x <= cx + rx + 2; x++)
                    {
                        int dx = x - cx;
                        int dy = y - (cy - 4);
                        int rr = dx * dx * 4 + dy * dy * (open ? 3 : 4);
                        int rad = rx * rx * 4 + Hash(x, y, 21) % 36 - 16;
                        if (rr > rad)
                            continue;
                        bool rim = rr > rad - 90;
                        Color c = holeDeep;
                        if (y > ph - 8)
                            c = Mix(holeFloor, hole, 40);
                        else if (open && y > cy - 10 && Math.Abs(dx) < 4)
                            c = Mix(holeDeep, glow, 35);
                        else if (dy < -6)
                            c = hole;
                        if (rim)
                            c = Mix(faceX, Ink, 40);
                        Plot(d, w, x, y, c);
                    }
                }

                for (int i = -2; i <= 2; i++)
                {
                    int bx = cx + i * 4;
                    int by = ph - 3;
                    StoneBlob(d, w, bx - 1, by - 1, 4, 3, faceD, faceL, faceX);
                }
                for (int i = 0; i < 7; i++)
                {
                    int mx = cx - 10 + i * 3;
                    int my = cy - ry + 2 + (i & 1);
                    Plot(d, w, mx, my, moss);
                    Plot(d, w, mx + 1, my + 1, G4);
                }
                for (int x = 0; x < pw; x++)
                {
                    if (ridge[x] <= 2)
                        continue;
                    bool left = x == 0 || d[ridge[x] * w + (x - 1)].A == 0;
                    bool right = x == pw - 1 || d[ridge[x] * w + (x + 1)].A == 0;
                    if (left || right || x == 0 || x == pw - 1)
                    {
                        for (int y = ridge[x]; y < ph; y++)
                        {
                            if (x == 0 || left)
                                Plot(d, w, x, y, Mix(At(d, w, ph, x, y), Ink, 35));
                            if (x == pw - 1 || right)
                                Plot(d, w, x, y, Mix(At(d, w, ph, x, y), Ink, 45));
                        }
                    }
                }
            });
        }

        public static Texture2D Outbuilding(
            GraphicsDevice gd, BuildingKind kind, int tilesW, int tilesH, int doorDx, bool open, bool ruined)
        {
            if (kind == BuildingKind.Greenhouse)
            {
                _ = tilesH;
                _ = doorDx;
                _ = open;
                return PackedBuildingTex(gd, GreenhouseAssetPath(), tilesW, ruined);
            }
            if (kind == BuildingKind.Barn)
            {
                _ = tilesH;
                _ = doorDx;
                _ = open;
                return PackedBuildingTex(gd, BarnAssetPath(), tilesW, ruined);
            }
            int pw, ph;
            HouseSize(tilesW, tilesH, out pw, out ph);
            return Build(gd, pw, ph, (d, w, h) => PaintCoop(d, w, tilesW, tilesH, doorDx, open, ruined));
        }

        /// <summary>
        /// Concrete farm silo with a red conical cap, ladder, and hatch.
        /// Painted at 16px/tile then Scale2 to 32×32, matching the supplied tower sprite.
        /// </summary>
        public static Texture2D Silo(GraphicsDevice gd, int tilesW, int tilesH, int doorDx)
        {
            int pw, ph;
            HouseSize(tilesW, tilesH, out pw, out ph);
            return Build(gd, pw, ph, (d, w, h) => PaintSilo(d, w, tilesW, tilesH, doorDx));
        }

        static void PaintSilo(Color[] d, int w, int tilesW, int tilesH, int doorDx)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            int mid = pw / 2;
            int bodyR = Math.Max(10, pw / 2 - 3);
            int capY = 3;
            int ring0 = capY + 14;
            int baseY = ph - 2;
            Color conc = new Color(186, 184, 176);
            Color concL = new Color(220, 216, 206);
            Color concD = new Color(132, 130, 124);
            Color concS = new Color(96, 94, 90);
            Color ring = new Color(78, 76, 74);
            Color cap = new Color(176, 48, 46);
            Color capL = new Color(214, 78, 64);
            Color capD = new Color(118, 28, 30);
            Color capRidge = new Color(92, 22, 24);
            Color hatch = new Color(96, 62, 36);
            Color hatchL = new Color(138, 92, 54);
            Color hatchD = new Color(62, 40, 24);
            Color iron = new Color(68, 70, 74);
            Color ironL = new Color(120, 124, 128);

            for (int y = ring0; y <= baseY; y++)
            {
                float u = (y - ring0) / (float)Math.Max(1, baseY - ring0);
                int r = bodyR - (int)(u * 1.2f);
                for (int x = mid - r; x <= mid + r; x++)
                {
                    float nx = (x - mid) / (float)Math.Max(1, r);
                    Color c = conc;
                    if (nx < -0.35f)
                        c = concL;
                    else if (nx > 0.42f)
                        c = concD;
                    if (nx > 0.72f)
                        c = concS;
                    if ((y - ring0) % 8 == 0)
                        c = ring;
                    if (Hash(x, y, 19) % 11 == 0)
                        c = Mix(c, concL, 28);
                    Plot(d, w, x, y, c);
                }
                Plot(d, w, mid - r, y, Ink);
                Plot(d, w, mid + r, y, Mix(concS, Ink, 40));
            }

            int coneH = ring0 - capY;
            for (int y = capY; y < ring0; y++)
            {
                float t = (y - capY) / (float)Math.Max(1, coneH);
                int r = 2 + (int)(t * (bodyR + 1));
                for (int x = mid - r; x <= mid + r; x++)
                {
                    float nx = (x - mid) / (float)Math.Max(1, r);
                    Color c = cap;
                    if (nx < -0.2f)
                        c = capL;
                    else if (nx > 0.35f)
                        c = capD;
                    int row = (y - capY) / 2;
                    if ((x + row) % 3 == 0)
                        c = Mix(c, capD, 35);
                    Plot(d, w, x, y, c);
                }
                Plot(d, w, mid - r, y, capRidge);
                Plot(d, w, mid + r, y, Mix(capD, Ink, 30));
            }
            FillRect(d, w, mid - 2, capY - 2, 5, 3, capD);
            Plot(d, w, mid, capY - 3, capL);
            Plot(d, w, mid, capY - 4, ironL);
            for (int x = mid - bodyR - 1; x <= mid + bodyR + 1; x++)
                Plot(d, w, x, ring0, ring);

            int doorX0 = Math.Max(mid - 5, doorDx * tw + 2);
            int doorX1 = doorX0 + 8;
            int doorY0 = baseY - 14;
            FillRect(d, w, doorX0, doorY0, doorX1 - doorX0, baseY - doorY0, hatch);
            for (int y = doorY0; y < baseY; y++)
            {
                Plot(d, w, doorX0, y, hatchD);
                Plot(d, w, doorX1 - 1, y, Mix(hatchD, Ink, 20));
                if ((y - doorY0) % 2 == 0)
                {
                    for (int x = doorX0 + 1; x < doorX1 - 1; x++)
                        Plot(d, w, x, y, (x - doorX0) % 3 == 0 ? hatchD : hatch);
                }
            }
            FillRect(d, w, doorX0, doorY0, doorX1 - doorX0, 2, hatchL);
            Plot(d, w, doorX1 - 3, doorY0 + 7, ironL);

            int lx = mid + bodyR - 2;
            for (int y = ring0 + 4; y < baseY - 2; y++)
            {
                Plot(d, w, lx, y, iron);
                Plot(d, w, lx + 3, y, iron);
                if ((y - ring0) % 4 == 0)
                {
                    Plot(d, w, lx + 1, y, ironL);
                    Plot(d, w, lx + 2, y, ironL);
                }
            }
            FillRect(d, w, mid - 3, baseY - 1, 7, 2, concS);
        }

        public static Texture2D HayField(GraphicsDevice gd, int variant)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                Color stem = new Color(196, 168, 64);
                Color stemL = new Color(232, 206, 96);
                Color stemD = new Color(142, 112, 42);
                Color leaf = new Color(108, 148, 58);
                for (int i = 0; i < 9; i++)
                {
                    int x = 1 + (i * 3 + variant) % 14;
                    int hgt = 9 + ((i + variant) % 5);
                    int lean = ((i + variant) & 1) == 0 ? 0 : 1;
                    for (int y = 0; y < hgt; y++)
                    {
                        int py = 15 - y;
                        int px = x + (y > hgt / 2 ? lean : 0);
                        Color c = y > hgt - 3 ? stemL : stem;
                        if (y < 3)
                            c = leaf;
                        if ((i + y + variant) % 4 == 0)
                            c = stemD;
                        Plot(d, w, px, py, c);
                        if (y > hgt - 4)
                            Plot(d, w, px + 1, py, stemL);
                    }
                    Plot(d, w, x + lean, 15 - hgt, stemL);
                }
            });
        }

        public static Texture2D HayStubble(GraphicsDevice gd, int variant)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                Color stub = new Color(176, 142, 58);
                Color stubD = new Color(124, 96, 40);
                Color leaf = new Color(92, 128, 52);
                for (int i = 0; i < 8; i++)
                {
                    int x = 2 + (i * 2 + variant) % 12;
                    int hgt = 2 + ((i + variant) % 3);
                    for (int y = 0; y < hgt; y++)
                        Plot(d, w, x, 14 - y, y == 0 ? stubD : stub);
                    Plot(d, w, x + 1, 14, leaf);
                }
            });
        }

        public static Texture2D HayBale(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                Color a = new Color(214, 176, 72);
                Color b = new Color(186, 142, 52);
                Color c = new Color(148, 108, 40);
                FillRect(d, w, 3, 5, 10, 8, b);
                for (int y = 5; y < 13; y++)
                {
                    for (int x = 3; x < 13; x++)
                    {
                        Color col = ((x + y) & 1) == 0 ? a : b;
                        if (x == 3 || y == 5)
                            col = a;
                        if (x == 12 || y == 12)
                            col = c;
                        if ((y - 5) % 3 == 0)
                            col = c;
                        Plot(d, w, x, y, col);
                    }
                }
                FillRect(d, w, 4, 4, 8, 2, a);
                Plot(d, w, 6, 8, new Color(92, 62, 32));
                Plot(d, w, 9, 8, new Color(92, 62, 32));
            });
        }

        public static Texture2D PlankStack(GraphicsDevice gd)
        {
            Color a = new Color(196, 148, 86);
            Color b = new Color(148, 102, 54);
            Color c = new Color(112, 72, 36);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int i = 0; i < 4; i++)
                {
                    int y = 4 + i * 2;
                    FillRect(d, w, 2 + (i & 1), y, 12, 2, i % 2 == 0 ? a : b);
                    Plot(d, w, 2 + (i & 1), y, c);
                    Plot(d, w, 13 - (i & 1), y + 1, c);
                }
                Plot(d, w, 6, 5, new Color(232, 196, 118));
                Plot(d, w, 10, 9, c);
            });
        }

        /// <summary>
        /// Front-gable farm barn from the supplied sprite, painted at 16px/tile then Scale2 to 32×32.
        /// Maroon shingles, hayloft with open shutters, and wide double doors.
        /// </summary>
        static void PaintBarn(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open, bool ruined)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            int mid = pw / 2;
            int peak = 3;
            int eaveY = roofH * 2 / 5 + 8;
            int loftY = eaveY + 2;
            int splitY = loftY + 18;
            Color sh0 = ruined ? new Color(132, 62, 58) : new Color(148, 48, 52);
            Color sh1 = ruined ? new Color(168, 86, 74) : new Color(176, 64, 62);
            Color sh2 = new Color(108, 32, 38);
            Color sh3 = new Color(72, 22, 28);
            Color ridge = new Color(186, 142, 92);
            Color ridgeD = new Color(128, 88, 54);
            Color plankH = ruined ? new Color(132, 96, 64) : new Color(158, 112, 70);
            Color plankHL = new Color(186, 140, 88);
            Color plankHD = new Color(108, 72, 44);
            Color plankV = ruined ? new Color(118, 84, 54) : new Color(138, 96, 58);
            Color plankVL = new Color(168, 124, 78);
            Color plankVD = new Color(88, 58, 36);
            Color hay = new Color(222, 178, 78);
            Color hayL = new Color(240, 206, 118);
            Color hayD = new Color(176, 128, 52);
            int half = pw / 2 - 3;

            DrawBarnGableFill(d, w, mid, peak, eaveY, half, sh0, sh1, sh2, true, ruined);
            DrawBarnShingles(d, w, mid, peak, eaveY, half, sh0, sh1, sh2, sh3, ruined);
            DrawBarnRidge(d, w, mid, peak, eaveY, half, ridge, ridgeD);
            DrawBarnHorizontalPlanks(d, w, mid, peak, ph - 1, eaveY, splitY, half, plankH, plankHL, plankHD, ruined);
            DrawBarnVerticalPlanks(d, w, mid, peak, ph - 1, splitY, ph - 1, half, plankV, plankVL, plankVD, ruined);
            DrawBarnLoft(d, w, mid, loftY + 2, hay, hayL, hayD, plankVD, plankVL, ruined);
            DrawBarnDoors(d, w, doorDx * tw, splitY + 2, ph - 2, plankVL, plankV, plankVD, hay, open, ruined);
            DrawBarnGableOutline(d, w, mid, peak, ph - 1, half, plankVD, ridgeD);
        }

        static void DrawBarnGableFill(
            Color[] d, int w, int mid, int peakY, int baseY, int halfW,
            Color a, Color b, Color c, bool shingles, bool ruined)
        {
            for (int y = peakY; y <= baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw; x <= mid + hw; x++)
                {
                    if (ruined && Hash(x, y, 11) % 10 == 0)
                        continue;
                    Color col = a;
                    if (shingles)
                    {
                        int row = (y - peakY) / 3;
                        int shift = (row & 1) * 2;
                        int brick = (x + shift) / 4;
                        col = (brick & 1) == 0 ? a : Mix(a, c, 28);
                        if ((y - peakY) % 3 == 0)
                            col = Mix(col, c, 40);
                        if ((x + shift) % 4 == 0)
                            col = c;
                        if (Hash(x, y, 17) % 7 == 0)
                            col = b;
                    }
                    else
                    {
                        col = ((x + y) & 3) == 0 ? Mix(a, b, 30) : a;
                    }
                    Plot(d, w, x, y, col);
                }
            }
        }

        static void DrawBarnShingles(
            Color[] d, int w, int mid, int peakY, int baseY, int halfW,
            Color sh0, Color sh1, Color sh2, Color sh3, bool ruined)
        {
            for (int y = peakY; y <= baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                int row = (y - peakY) / 3;
                int shift = (row & 1) * 2;
                for (int x = mid - hw; x <= mid + hw; x++)
                {
                    if (ruined && Hash(x / 2, y / 2, 5) % 6 == 0)
                        continue;
                    Color col = ((x + shift) / 4 & 1) == 0 ? sh0 : Mix(sh0, sh2, 22);
                    if ((y - peakY) % 3 == 0)
                        col = Mix(col, sh3, 45);
                    if ((x + shift) % 4 == 0)
                        col = sh2;
                    if (Hash(x, y, 29) % 8 == 0)
                        col = sh1;
                    if (x <= mid - hw + 1 || x >= mid + hw - 1)
                        col = Mix(sh3, Ink, 20);
                    Plot(d, w, x, y, col);
                }
            }
        }

        static void DrawBarnRidge(Color[] d, int w, int mid, int peakY, int eaveY, int halfW, Color ridge, Color ridgeD)
        {
            for (int y = peakY; y <= eaveY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, eaveY - peakY);
                int hw = 3 + (int)(t * halfW);
                Plot(d, w, mid, y, ridge);
                Plot(d, w, mid - 1, y, Mix(ridge, Color.White, 15));
                Plot(d, w, mid + 1, y, ridgeD);
                if (y == peakY)
                {
                    for (int x = mid - 2; x <= mid + 2; x++)
                        Plot(d, w, x, y, ridge);
                }
                Plot(d, w, mid - hw, y, ridgeD);
                Plot(d, w, mid + hw, y, ridgeD);
            }
        }

        static void DrawBarnHorizontalPlanks(
            Color[] d, int w, int mid, int peakY, int gableBase, int y0, int y1, int halfW,
            Color plank, Color plankL, Color plankD, bool ruined)
        {
            for (int y = y0; y < y1; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, gableBase - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw + 2; x < mid + hw - 1; x++)
                {
                    Color c = (y / 2 & 1) == 0 ? plank : Mix(plank, plankD, 28);
                    if (y % 2 == 0)
                        c = Mix(c, plankD, 35);
                    if (x == mid - hw + 2)
                        c = plankL;
                    if (ruined && Hash(x, y, 13) % 9 == 0)
                        c = Mix(c, new Color(86, 128, 64), 35);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawBarnVerticalPlanks(
            Color[] d, int w, int mid, int peakY, int gableBase, int y0, int y1, int halfW,
            Color plank, Color plankL, Color plankD, bool ruined)
        {
            for (int y = y0; y <= y1; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, gableBase - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = mid - hw + 2; x < mid + hw - 1; x++)
                {
                    int col = x / 3;
                    Color c = (col & 1) == 0 ? plank : Mix(plank, plankD, 24);
                    if (x % 3 == 0)
                        c = plankD;
                    if (x % 3 == 1)
                        c = plankL;
                    if (y >= y1 - 2)
                        c = Mix(c, plankD, 40);
                    if (ruined && Hash(x / 2, y / 3, 9) % 7 == 0)
                        continue;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawBarnLoft(
            Color[] d, int w, int mid, int y0,
            Color hay, Color hayL, Color hayD, Color frame, Color frameL, bool ruined)
        {
            int x0 = mid - 10;
            int x1 = mid + 10;
            int y1 = y0 + 12;
            FillRect(d, w, x0, y0, x1 - x0, y1 - y0, Mix(frame, Ink, 20));
            FillRect(d, w, x0 + 2, y0 + 2, x1 - x0 - 4, y1 - y0 - 3, ruined ? Mix(hayD, Ink, 30) : hayD);
            if (!ruined)
            {
                for (int i = 0; i < 4; i++)
                {
                    int hx = x0 + 4 + i * 4;
                    FillRect(d, w, hx, y0 + 4 + (i & 1), 3, 6, (i & 1) == 0 ? hay : hayL);
                    Plot(d, w, hx + 1, y0 + 3 + (i & 1), hayL);
                }
            }
            for (int y = y0; y < y1; y++)
            {
                Plot(d, w, x0, y, frame);
                Plot(d, w, x1 - 1, y, frame);
            }
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, y0, frameL);
                Plot(d, w, x, y1 - 1, frame);
            }
            DrawBarnShutter(d, w, x0 - 7, y0 + 1, frame, frameL, true);
            DrawBarnShutter(d, w, x1, y0 + 1, frame, frameL, false);
        }

        static void DrawBarnShutter(Color[] d, int w, int x0, int y0, Color wood, Color woodL, bool left)
        {
            int ww = 6;
            int hh = 11;
            for (int y = 0; y < hh; y++)
            {
                for (int x = 0; x < ww; x++)
                {
                    Color c = (y / 2 & 1) == 0 ? wood : Mix(wood, woodL, 40);
                    if (x == 0 || x == ww - 1 || y == 0 || y == hh - 1)
                        c = Mix(wood, Ink, 30);
                    Plot(d, w, x0 + x, y0 + y, c);
                }
            }
            int hingeX = left ? x0 + ww : x0 - 1;
            Plot(d, w, hingeX, y0 + 2, Mix(woodL, Color.White, 20));
            Plot(d, w, hingeX, y0 + hh - 3, Mix(woodL, Color.White, 20));
        }

        static void DrawBarnDoors(
            Color[] d, int w, int doorX0, int y0, int y1,
            Color plankL, Color plank, Color plankD, Color hay, bool open, bool ruined)
        {
            int x0 = doorX0 - 2;
            int x1 = doorX0 + 28;
            for (int y = y0; y < y1; y++)
            {
                Plot(d, w, x0, y, plankD);
                Plot(d, w, x0 + 1, y, plank);
                Plot(d, w, x1 - 2, y, plank);
                Plot(d, w, x1 - 1, y, Mix(plankD, Ink, 20));
            }
            int split = (x0 + x1) / 2;
            for (int y = y0 + 1; y < y1 - 1; y++)
            {
                for (int x = x0 + 2; x < x1 - 2; x++)
                {
                    Color c = (y / 2 & 1) == 0 ? plank : Mix(plank, plankD, 30);
                    if (y % 2 == 0)
                        c = Mix(c, plankD, 35);
                    if (x == split || x == split - 1)
                        c = plankD;
                    if (open && x > split - 6 && x < split + 6)
                        c = Mix(plankD, Ink, 45);
                    if (ruined && Hash(x, y, 4) % 5 == 0)
                        c = Mix(hay, plankD, 40);
                    Plot(d, w, x, y, c);
                }
            }
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, y0, plankL);
                Plot(d, w, x, y1 - 1, plankD);
            }
            Plot(d, w, x0 + 5, y0 + (y1 - y0) / 2, Mix(plankL, Color.White, 20));
            Plot(d, w, x1 - 6, y0 + (y1 - y0) / 2, Mix(plankL, Color.White, 20));
        }

        static void DrawBarnGableOutline(Color[] d, int w, int mid, int peakY, int baseY, int halfW, Color ink, Color eave)
        {
            for (int y = peakY; y <= baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                Plot(d, w, mid - hw, y, ink);
                Plot(d, w, mid + hw, y, ink);
            }
            for (int x = mid - halfW; x <= mid + halfW; x++)
                Plot(d, w, x, baseY, eave);
        }

        /// <summary>
        /// First spritesheet frame: timber greenhouse, teal glass, stone plinth, hipped ridge roof.
        /// Not a triangular A-frame. Painted at 16px/tile then Scale2 to 32×32.
        /// </summary>
        static void PaintGreenhouse(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open, bool ruined)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            Color wood, woodL, woodD, glass, glassL, glassD, stone, stoneL, stoneD;
            GreenhouseWood(ruined, out wood, out woodL, out woodD);
            GreenhouseGlass(ruined, false, out glass, out glassL, out glassD);
            GreenhouseStone(ruined, out stone, out stoneL, out stoneD);

            int mid, ridgeY, eaveY, stoneY, ridgeHalf, eaveHalf;
            GreenhouseHip(pw, ph, out mid, out ridgeY, out eaveY, out stoneY, out ridgeHalf, out eaveHalf);
            FillGreenhouseBody(d, w, mid, ridgeY, stoneY, ridgeY, eaveY, ridgeHalf, eaveHalf, glass, glassL, glassD, ruined, true);
            DrawGreenhouseStonePlinth(d, w, mid, stoneY, ph - 1, eaveHalf, stone, stoneL, stoneD, ruined);
            DrawGreenhouseTimber(d, w, mid, ridgeY, stoneY, ph - 1, ridgeY, eaveY, ridgeHalf, eaveHalf, wood, woodL, woodD, ruined);
            DrawGreenhouseTinyDoor(d, w, doorDx * tw, stoneY - 2, ph - 2, wood, woodL, woodD, open, ruined);
        }

        public static Texture2D GreenhouseInside(GraphicsDevice gd, int tilesW)
        {
            int pw, ph;
            HouseSize(tilesW, 5, out pw, out ph);
            return Build(gd, pw, ph, (d, w, h) => PaintGreenhouseInside(d, w, tilesW, 5));
        }

        /// <summary>
        /// Third spritesheet frame: interior back wall — hipped teal glass ceiling,
        /// reddish brick, door recess at the base. Same silhouette as the exterior.
        /// </summary>
        static void PaintGreenhouseInside(Color[] d, int w, int tilesW, int tilesH)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            Color wood, woodL, woodD, glass, glassL, glassD;
            GreenhouseWood(false, out wood, out woodL, out woodD);
            GreenhouseGlass(false, true, out glass, out glassL, out glassD);
            Color brick = new Color(156, 78, 52);
            Color brickL = new Color(186, 104, 70);
            Color brickD = new Color(112, 52, 36);
            int mid, ridgeY, eaveY, stoneY, ridgeHalf, eaveHalf;
            GreenhouseHip(pw, ph, out mid, out ridgeY, out eaveY, out stoneY, out ridgeHalf, out eaveHalf);
            int brickY = eaveY + 24;
            FillGreenhouseBody(d, w, mid, ridgeY, ph - 1, ridgeY, eaveY, ridgeHalf, eaveHalf, brick, brickL, brickD, false, false);
            FillGreenhouseBody(d, w, mid, ridgeY, brickY, ridgeY, eaveY, ridgeHalf, eaveHalf, glass, glassL, glassD, false, true);
            DrawGreenhouseBrick(d, w, mid, brickY, ph - 1, eaveHalf, brick, brickL, brickD);
            DrawGreenhouseTimber(d, w, mid, ridgeY, brickY, ph - 1, ridgeY, eaveY, ridgeHalf, eaveHalf, wood, woodL, woodD, false);
            int gapW = 14;
            int gapX = mid - gapW / 2;
            int gapY = ph - 12;
            for (int y = gapY; y < ph; y++)
            {
                for (int x = gapX; x < gapX + gapW; x++)
                {
                    Color c = Mix(brickD, Ink, 40);
                    if (x == gapX || x == gapX + gapW - 1 || y == gapY)
                        c = woodD;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void GreenhouseHip(
            int pw, int ph,
            out int mid, out int ridgeY, out int eaveY, out int stoneY,
            out int ridgeHalf, out int eaveHalf)
        {
            mid = pw / 2;
            eaveHalf = pw / 2 - 4;
            ridgeHalf = eaveHalf * 5 / 8;
            ridgeY = 8;
            eaveY = 28;
            stoneY = ph - 20;
        }

        static void GreenhouseWood(bool ruined, out Color wood, out Color woodL, out Color woodD)
        {
            wood = ruined ? new Color(128, 78, 52) : new Color(156, 86, 52);
            woodL = ruined ? new Color(158, 108, 74) : new Color(186, 118, 70);
            woodD = ruined ? new Color(86, 48, 32) : new Color(98, 50, 30);
        }

        static void GreenhouseGlass(bool ruined, bool inside, out Color glass, out Color glassL, out Color glassD)
        {
            if (inside)
            {
                glass = new Color(36, 108, 102);
                glassL = new Color(72, 156, 140);
                glassD = new Color(22, 72, 70);
                return;
            }
            glass = ruined ? new Color(64, 108, 98) : new Color(42, 124, 112);
            glassL = ruined ? new Color(110, 158, 146) : new Color(86, 176, 156);
            glassD = ruined ? new Color(36, 72, 68) : new Color(24, 78, 74);
        }

        static void GreenhouseStone(bool ruined, out Color stone, out Color stoneL, out Color stoneD)
        {
            stone = ruined ? new Color(176, 170, 154) : new Color(214, 206, 186);
            stoneL = ruined ? new Color(198, 192, 176) : new Color(236, 230, 214);
            stoneD = ruined ? new Color(132, 126, 112) : new Color(168, 160, 144);
        }

        static void FillGreenhouseBody(
            Color[] d, int w, int mid, int y0, int y1,
            int ridgeY, int eaveY, int ridgeHalf, int eaveHalf,
            Color fill, Color fillL, Color fillD, bool ruined, bool glint)
        {
            Color leaf = new Color(72, 148, 70);
            for (int y = y0; y <= y1; y++)
            {
                int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                if (hw <= 0)
                    continue;
                for (int x = mid - hw; x <= mid + hw; x++)
                {
                    if (ruined && Hash(x, y, 7) % 9 == 0)
                        continue;
                    Color c = fill;
                    if ((x + y * 2) % 11 == 0)
                        c = fillL;
                    if ((x - y) % 9 == 0)
                        c = Mix(fill, fillL, 35);
                    if (Hash(x / 3, y / 3, 11) % 6 == 0)
                        c = fillD;
                    if (glint && Hash(x, y, 29) % 17 == 0)
                        c = Mix(fillL, Color.White, 45);
                    if (glint && y > eaveY + 10 && Hash(x / 4, y / 5, 41) % 11 == 0)
                        c = Mix(c, leaf, 40);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawGreenhouseTimber(
            Color[] d, int w, int mid, int y0, int gridY1, int baseY,
            int ridgeY, int eaveY, int ridgeHalf, int eaveHalf,
            Color wood, Color woodL, Color woodD, bool ruined)
        {
            int eaveHw = HipHalf(eaveY, ridgeY, eaveY, ridgeHalf, eaveHalf);
            int ridgeHw = HipHalf(ridgeY, ridgeY, eaveY, ridgeHalf, eaveHalf);
            for (int y = ridgeY; y <= baseY; y++)
            {
                int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                if (hw <= 0)
                    continue;
                int left = mid - hw;
                int right = mid + hw;
                Plot(d, w, left, y, woodD);
                Plot(d, w, left + 1, y, wood);
                Plot(d, w, right, y, woodD);
                Plot(d, w, right - 1, y, woodL);
            }
            for (int x = mid - ridgeHw; x <= mid + ridgeHw; x++)
            {
                Plot(d, w, x, ridgeY, woodL);
                Plot(d, w, x, ridgeY + 1, wood);
                Plot(d, w, x, ridgeY + 2, woodD);
            }
            for (int x = mid - eaveHw; x <= mid + eaveHw; x++)
            {
                Plot(d, w, x, eaveY, wood);
                Plot(d, w, x, eaveY + 1, woodD);
                Plot(d, w, x, baseY, woodD);
                Plot(d, w, x, baseY - 1, wood);
            }
            for (int y = eaveY; y < gridY1; y += 8)
            {
                int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                for (int x = mid - hw + 2; x < mid + hw - 1; x++)
                {
                    if (ruined && Hash(x, y, 3) % 5 == 0)
                        continue;
                    Plot(d, w, x, y, wood);
                    Plot(d, w, x, y + 1, woodD);
                }
            }
            for (int col = -eaveHw + 10; col < eaveHw - 4; col += 12)
            {
                int x = mid + col;
                for (int y = eaveY; y < gridY1; y++)
                {
                    int hw = HipHalf(y, ridgeY, eaveY, ridgeHalf, eaveHalf);
                    if (x <= mid - hw + 2 || x >= mid + hw - 2)
                        continue;
                    if (ruined && Hash(x, y, 5) % 7 == 0)
                        continue;
                    Plot(d, w, x, y, woodL);
                    Plot(d, w, x + 1, y, woodD);
                }
            }
        }

        static void DrawGreenhouseStonePlinth(
            Color[] d, int w, int mid, int y0, int y1, int halfW,
            Color stone, Color stoneL, Color stoneD, bool ruined)
        {
            Color mortar = Mix(stoneD, Ink, 20);
            for (int y = y0; y <= y1; y++)
            {
                int row = (y - y0) / 5;
                int shift = (row & 1) == 0 ? 0 : 4;
                for (int x = mid - halfW; x <= mid + halfW; x++)
                {
                    Color c = ((x + shift) / 8 % 2 == 0) ? stone : Mix(stone, stoneD, 22);
                    if ((y - y0) % 5 == 0 || (x + shift) % 8 == 0)
                        c = mortar;
                    if ((x + shift) % 8 == 1)
                        c = stoneL;
                    if (ruined && Hash(x, y, 19) % 13 == 0)
                        c = Mix(c, new Color(86, 128, 64), 40);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawGreenhouseBrick(
            Color[] d, int w, int mid, int y0, int y1, int halfW,
            Color brick, Color brickL, Color brickD)
        {
            Color mortar = Mix(brickD, Ink, 25);
            for (int y = y0; y <= y1; y++)
            {
                int row = (y - y0) / 4;
                int shift = (row & 1) == 0 ? 0 : 4;
                for (int x = mid - halfW + 2; x < mid + halfW - 1; x++)
                {
                    Color c = ((x + shift) / 8 % 2 == 0) ? brick : Mix(brick, brickD, 28);
                    if ((y - y0) % 4 == 0 || (x + shift) % 8 == 0)
                        c = mortar;
                    if ((x + shift) % 8 == 1)
                        c = brickL;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawGreenhouseTinyDoor(
            Color[] d, int w, int doorX0, int y0, int y1,
            Color wood, Color woodL, Color woodD, bool open, bool ruined)
        {
            int x0 = doorX0 + 3;
            int x1 = doorX0 + 13;
            Color knob = new Color(232, 186, 64);
            for (int y = y0; y < y1; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    Color c = wood;
                    if ((x - x0) % 3 == 0)
                        c = woodD;
                    if (x == x0 || x == x1 - 1 || y == y0 || y == y1 - 1)
                        c = woodD;
                    if (open && x > x0 + 2 && x < x1 - 2)
                        c = Mix(woodD, Ink, 50);
                    if (ruined && y > y0 + 6 && Hash(x, y, 4) % 4 == 0)
                        c = Mix(woodD, new Color(72, 118, 58), 45);
                    Plot(d, w, x, y, c);
                }
            }
            Plot(d, w, x1 - 3, y0 + (y1 - y0) / 2, knob);
            Plot(d, w, x1 - 4, y0 + (y1 - y0) / 2, Mix(knob, Color.White, 30));
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, y0, woodL);
                Plot(d, w, x, y1 - 1, woodD);
            }
        }

        static void PaintCoop(Color[] d, int w, int tilesW, int tilesH, int doorDx, bool open, bool ruined)
        {
            int tw = 16;
            int pw = tilesW * tw;
            int fasciaH = 6;
            int wallH = 24;
            int roofH = tilesH * tw;
            int ph = roofH + fasciaH + wallH;
            Color roof = ruined ? new Color(148, 78, 58) : new Color(186, 68, 52);
            Color wall = ruined ? new Color(196, 186, 164) : new Color(232, 220, 196);
            Color wallD = new Color(168, 150, 122);
            Color trim = new Color(92, 64, 40);
            int wallY = roofH + fasciaH;
            DrawVillageRoof(d, w, pw, roofH, Mix(roof, Ink, 30), roof, Mix(roof, Color.White, 20), Mix(roof, Ink, 50), 0);
            DrawVillageFascia(d, w, pw, roofH, fasciaH, roof, Mix(roof, Ink, 20), Mix(roof, Ink, 40), 0);
            FillRect(d, w, 0, wallY, pw, ph - wallY, wall);
            for (int x = 0; x < pw; x += 4)
                FillRect(d, w, x, wallY, 1, ph - wallY, wallD);
            FillRect(d, w, 0, wallY, pw, 1, trim);
            int doorX0 = doorDx * tw;
            if (ruined)
            {
                FillRect(d, w, doorX0 + 2, wallY + 8, 10, ph - wallY - 10, Mix(wallD, Ink, 20));
                for (int i = 0; i < 6; i++)
                    Plot(d, w, doorX0 + 4 + i, wallY + 6 + i / 2, trim);
                Plot(d, w, 4, ph - 5, new Color(96, 146, 70));
                Plot(d, w, pw - 6, ph - 6, new Color(214, 176, 86));
            }
            else
            {
                DrawHouseDoor(d, w, doorX0, wallY + 5, ph - 2, 0, trim, Mix(trim, Color.White, 30), open);
                FillRect(d, w, 3, wallY + 8, 6, 5, Mix(trim, Color.White, 10));
                Plot(d, w, 5, wallY + 10, new Color(248, 232, 196));
            }
            DrawVillageStep(d, w, doorX0, ph - 3, ph, trim, wall, wallD);
        }

        static void DrawAwning(Color[] d, int w, int x0, int y0, int aw)
        {
            Color stripeA = new Color(168, 186, 118);
            Color stripeB = new Color(244, 232, 196);
            Color lip = new Color(118, 132, 78);
            for (int y = 0; y < 8; y++)
            {
                int inset = y == 7 ? 1 : 0;
                for (int x = inset; x < aw - inset; x++)
                {
                    Color c = ((x / 3) & 1) == 0 ? stripeA : stripeB;
                    if (y == 0) c = Mix(c, Color.White, 25);
                    if (y == 7) c = lip;
                    if (y == 0 || y == 7 || x == inset || x == aw - inset - 1)
                        c = LineC(c);
                    Plot(d, w, x0 + x, y0 + y, c);
                }
            }
            Color bloom = new Color(236, 140, 158);
            Plot(d, w, x0 + 4, y0 + 8, bloom);
            Plot(d, w, x0 + 12, y0 + 8, new Color(72, 128, 62));
            Plot(d, w, x0 + 18, y0 + 8, bloom);
            for (int x = 2; x < aw - 2; x += 4)
            {
                Plot(d, w, x0 + x, y0 + 8, new Color(40, 28, 20, 90));
                Plot(d, w, x0 + x, y0 + 9, new Color(40, 28, 20, 50));
            }
        }

        public static Texture2D TreeTrunk(GraphicsDevice gd, int variant)
        {
            int tw = 18;
            int th = 40;
            Color bark = new Color(226, 220, 204);
            Color barkL = new Color(244, 238, 224);
            Color barkD = new Color(92, 82, 70);
            Color moss = new Color(86, 128, 64);
            return Build(gd, tw, th, (d, w, h) =>
            {
                int lean = (variant & 1) == 0 ? 0 : 1;
                for (int y = 6; y < 37; y++)
                {
                    float t = (y - 6) / 31f;
                    int half = 2 + (int)(t * 2);
                    int cx = 8 + lean + (int)(Math.Sin(y * 0.18 + variant) * 0.6);
                    for (int x = cx - half; x <= cx + half; x++)
                    {
                        Color c = bark;
                        if (x <= cx - half + 1) c = barkL;
                        if (x >= cx + half - 1) c = barkD;
                        if ((x + y * 3 + variant) % 7 == 0) c = barkD;
                        if (y > 28 && (x + y) % 5 == 0) c = moss;
                        if (x == cx - half || x == cx + half) c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int i = -4; i <= 4; i++)
                {
                    int y = 36 - Math.Abs(i) / 2;
                    Plot(d, w, 8 + i, y, Ink);
                    Plot(d, w, 8 + i, y - 1, barkD);
                    Plot(d, w, 8 + i, 37, Mix(G4, barkD, 40));
                }
                Plot(d, w, 7, 18, barkD);
                Plot(d, w, 10, 22, barkL);
            });
        }

        public static Texture2D TreeCanopy(GraphicsDevice gd, int variant, bool autumn, bool fruit)
        {
            Color leaf = autumn ? new Color(196, 148, 64) : new Color(86, 118, 62);
            Color leafL = autumn ? new Color(220, 178, 88) : new Color(118, 142, 78);
            Color leafM = autumn ? new Color(176, 128, 52) : new Color(98, 128, 68);
            Color leafD = autumn ? new Color(138, 92, 40) : new Color(58, 82, 46);
            Color outline = autumn ? new Color(108, 72, 38) : new Color(48, 68, 40);
            Color fruitC = new Color(168, 52, 46);
            int tw = 58;
            int th = 50;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int seed = 900 + variant * 47;
                int[][] blobs =
                {
                    new[] { 29, 16, 14 },
                    new[] { 18, 20, 12 },
                    new[] { 40, 19, 12 },
                    new[] { 24, 28, 11 },
                    new[] { 35, 27, 11 },
                    new[] { 13, 26, 9 },
                    new[] { 45, 25, 9 },
                    new[] { 29, 34, 10 },
                    new[] { 21, 12, 8 },
                    new[] { 37, 11, 8 }
                };
                if ((variant & 1) == 1)
                {
                    blobs[0][0] = 28;
                    blobs[1][0] = 16;
                    blobs[2][0] = 42;
                }
                for (int i = 0; i < blobs.Length; i++)
                {
                    int cx = blobs[i][0] + (variant % 3) - 1;
                    int cy = blobs[i][1];
                    int r = blobs[i][2];
                    for (int y = cy - r; y <= cy + r; y++)
                    {
                        for (int x = cx - r; x <= cx + r; x++)
                        {
                            int dx = x - cx;
                            int dy = y - cy;
                            int r2 = dx * dx + dy * dy * 6 / 5;
                            if (r2 > r * r)
                                continue;
                            int n = Hash(x, y, seed + i);
                            Color c = leafM;
                            if (dx + dy < -3) c = leafL;
                            else if (dx + dy > 4) c = leafD;
                            else if (n % 5 == 0) c = leaf;
                            if (n % 11 == 0) c = leafD;
                            if (r2 > (r - 1) * (r - 1))
                                c = outline;
                            Plot(d, w, x, y, c);
                        }
                    }
                }
                if (fruit)
                {
                    int[][] apples = { new[] { 20, 24 }, new[] { 36, 18 }, new[] { 28, 30 }, new[] { 42, 26 }, new[] { 16, 28 } };
                    for (int i = 0; i < apples.Length; i++)
                    {
                        int ax = apples[i][0];
                        int ay = apples[i][1] + (variant & 1);
                        Plot(d, w, ax, ay, fruitC);
                        Plot(d, w, ax + 1, ay, fruitC);
                        Plot(d, w, ax, ay + 1, Mix(fruitC, Color.Black, 25));
                        Plot(d, w, ax + 1, ay - 1, new Color(196, 80, 64));
                    }
                }
            });
        }

        public static Texture2D PineTrunk(GraphicsDevice gd, int variant)
        {
            int tw = 14;
            int th = 48;
            Color bark = new Color(92, 62, 42);
            Color barkL = new Color(132, 96, 64);
            Color barkD = new Color(58, 38, 28);
            return Build(gd, tw, th, (d, w, h) =>
            {
                int lean = (variant & 1) == 0 ? 0 : 1;
                for (int y = 4; y < 44; y++)
                {
                    int half = 1 + (y > 28 ? 1 : 0);
                    int cx = 6 + lean;
                    for (int x = cx - half; x <= cx + half; x++)
                    {
                        Color c = bark;
                        if (x <= cx) c = barkL;
                        if (x >= cx + half) c = barkD;
                        if ((y + variant) % 6 == 0) c = barkD;
                        if (x == cx - half || x == cx + half) c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int i = -3; i <= 3; i++)
                {
                    Plot(d, w, 6 + i, 43, Ink);
                    Plot(d, w, 6 + i, 42, barkD);
                }
            });
        }

        public static Texture2D PineNeedles(GraphicsDevice gd, int variant, bool spruce)
        {
            Color mid = spruce ? new Color(52, 86, 68) : new Color(54, 98, 58);
            Color hi = spruce ? new Color(78, 112, 88) : new Color(86, 132, 72);
            Color lo = spruce ? new Color(34, 58, 48) : new Color(36, 68, 42);
            Color ink = spruce ? new Color(28, 46, 38) : new Color(32, 54, 36);
            int tw = spruce ? 38 : 42;
            int th = spruce ? 58 : 54;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int cx = tw / 2 + ((variant & 1) == 0 ? 0 : 1);
                int[][] layers = spruce
                    ? new[] { new[] { 2, 14, 7 }, new[] { 10, 16, 10 }, new[] { 20, 18, 13 }, new[] { 30, 20, 15 }, new[] { 40, 18, 14 } }
                    : new[] { new[] { 2, 16, 8 }, new[] { 12, 18, 12 }, new[] { 24, 20, 16 }, new[] { 36, 18, 15 } };
                int seed = 400 + variant * 19 + (spruce ? 80 : 0);
                for (int i = 0; i < layers.Length; i++)
                    NeedleLayer(d, w, cx, layers[i][0], layers[i][1], layers[i][2], mid, hi, lo, ink, seed + i);
                Plot(d, w, cx, 1, ink);
                Plot(d, w, cx, 2, hi);
            });
        }

        static void NeedleLayer(Color[] d, int w, int cx, int y0, int hh, int half, Color mid, Color hi, Color lo, Color ink, int seed)
        {
            for (int y = 0; y < hh; y++)
            {
                int span = 1 + half * y / Math.Max(1, hh - 1);
                for (int x = cx - span; x <= cx + span; x++)
                {
                    Color c = mid;
                    if (x < cx - span / 3) c = hi;
                    if (x > cx + span / 3) c = lo;
                    int n = Hash(x, y0 + y, seed);
                    if (n % 9 == 0) c = lo;
                    if (n % 13 == 0) c = hi;
                    if (x == cx - span || x == cx + span || y == 0)
                        c = ink;
                    Plot(d, w, x, y0 + y, c);
                }
            }
        }

        public static Texture2D WillowCanopy(GraphicsDevice gd, int variant)
        {
            Color leaf = new Color(118, 148, 72);
            Color leafL = new Color(154, 176, 92);
            Color leafD = new Color(72, 102, 54);
            Color outline = new Color(52, 74, 42);
            int tw = 64;
            int th = 56;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int seed = 210 + variant * 31;
                int[][] blobs =
                {
                    new[] { 32, 14, 16 },
                    new[] { 18, 18, 13 },
                    new[] { 46, 18, 13 },
                    new[] { 32, 26, 14 },
                    new[] { 12, 28, 10 },
                    new[] { 52, 28, 10 }
                };
                for (int i = 0; i < blobs.Length; i++)
                    LeafBlob(d, w, blobs[i][0] + (variant % 3) - 1, blobs[i][1], blobs[i][2], 8, 7, leaf, leafL, leafD, outline, seed + i);
                for (int x = 8; x < 56; x++)
                {
                    int drop = 8 + Hash(x, variant, 44) % 14;
                    int top = 30 + (Math.Abs(x - 32) / 6);
                    for (int y = 0; y < drop; y++)
                    {
                        Color c = y % 3 == 0 ? leafL : leaf;
                        if (y == drop - 1) c = leafD;
                        Plot(d, w, x, top + y, c);
                    }
                }
            });
        }

        public static Texture2D BlossomCanopy(GraphicsDevice gd, int variant)
        {
            Color leaf = new Color(232, 168, 186);
            Color leafL = new Color(248, 214, 220);
            Color leafD = new Color(196, 108, 132);
            Color outline = new Color(156, 78, 96);
            Color green = new Color(92, 148, 70);
            int tw = 54;
            int th = 46;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int seed = 330 + variant * 17;
                int[][] blobs =
                {
                    new[] { 27, 16, 13 },
                    new[] { 16, 20, 11 },
                    new[] { 38, 20, 11 },
                    new[] { 22, 28, 10 },
                    new[] { 33, 27, 10 },
                    new[] { 27, 10, 8 }
                };
                for (int i = 0; i < blobs.Length; i++)
                    LeafBlob(d, w, blobs[i][0], blobs[i][1], blobs[i][2], 6, 5, leaf, leafL, leafD, outline, seed + i);
                for (int i = 0; i < 10; i++)
                {
                    int ax = 12 + Hash(i, variant, 9) % 30;
                    int ay = 12 + Hash(i, variant, 11) % 22;
                    Plot(d, w, ax, ay, green);
                }
            });
        }

        public static Texture2D BirchCanopy(GraphicsDevice gd, int variant)
        {
            Color leaf = new Color(148, 178, 86);
            Color leafL = new Color(186, 202, 112);
            Color leafD = new Color(92, 124, 62);
            Color outline = new Color(64, 88, 48);
            int tw = 46;
            int th = 40;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int seed = 510 + variant * 23;
                int[][] blobs =
                {
                    new[] { 23, 14, 11 },
                    new[] { 14, 18, 9 },
                    new[] { 32, 18, 9 },
                    new[] { 23, 24, 10 },
                    new[] { 18, 10, 7 },
                    new[] { 29, 10, 7 }
                };
                for (int i = 0; i < blobs.Length; i++)
                    LeafBlob(d, w, blobs[i][0] + (variant & 1), blobs[i][1], blobs[i][2], 5, 5, leaf, leafL, leafD, outline, seed + i);
            });
        }

        public static Texture2D OakCanopy(GraphicsDevice gd, int variant)
        {
            Color leaf = new Color(64, 102, 56);
            Color leafL = new Color(98, 132, 70);
            Color leafD = new Color(42, 74, 44);
            Color outline = new Color(34, 58, 36);
            int tw = 62;
            int th = 52;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int seed = 620 + variant * 29;
                int[][] blobs =
                {
                    new[] { 31, 18, 16 },
                    new[] { 18, 22, 13 },
                    new[] { 44, 22, 13 },
                    new[] { 26, 32, 12 },
                    new[] { 38, 31, 12 },
                    new[] { 12, 28, 10 },
                    new[] { 50, 28, 10 },
                    new[] { 31, 10, 9 }
                };
                for (int i = 0; i < blobs.Length; i++)
                    LeafBlob(d, w, blobs[i][0], blobs[i][1], blobs[i][2], 6, 5, leaf, leafL, leafD, outline, seed + i);
            });
        }

        static void LeafBlob(Color[] d, int w, int cx, int cy, int r, int stretchN, int stretchD, Color leaf, Color leafL, Color leafD, Color outline, int seed)
        {
            for (int y = cy - r; y <= cy + r; y++)
            {
                for (int x = cx - r; x <= cx + r; x++)
                {
                    int dx = x - cx;
                    int dy = y - cy;
                    int r2 = dx * dx + dy * dy * stretchN / Math.Max(1, stretchD);
                    if (r2 > r * r)
                        continue;
                    int n = Hash(x, y, seed);
                    Color c = leaf;
                    if (dx + dy < -3) c = leafL;
                    else if (dx + dy > 4) c = leafD;
                    if (n % 7 == 0) c = leafD;
                    if (r2 > (r - 1) * (r - 1))
                        c = outline;
                    Plot(d, w, x, y, c);
                }
            }
        }

        public static Texture2D PalmTrunk(GraphicsDevice gd, int variant)
        {
            int tw = 18;
            int th = 44;
            Color bark = new Color(176, 132, 78);
            Color barkL = new Color(214, 176, 112);
            Color barkD = new Color(118, 82, 48);
            return Build(gd, tw, th, (d, w, h) =>
            {
                int lean = (variant % 3) - 1;
                for (int y = 6; y < 40; y++)
                {
                    float t = (y - 6) / 34f;
                    int cx = 8 + (int)(lean * t * 4);
                    int half = 1 + (y > 24 ? 1 : 0);
                    for (int x = cx - half; x <= cx + half; x++)
                    {
                        Color c = bark;
                        if (x < cx) c = barkL;
                        if (x > cx) c = barkD;
                        if ((y / 2 + variant) % 4 == 0) c = barkD;
                        if (x == cx - half || x == cx + half) c = Ink;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int i = -3; i <= 3; i++)
                    Plot(d, w, 8 + i, 39, Mix(barkD, Ink, 40));
            });
        }

        public static Texture2D PalmFronds(GraphicsDevice gd, int variant)
        {
            Color leaf = new Color(68, 132, 70);
            Color leafL = new Color(118, 164, 86);
            Color leafD = new Color(42, 88, 52);
            int tw = 56;
            int th = 36;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int cx = 28;
                int cy = 16;
                int[][] dirs = { new[] { 0, -1 }, new[] { 1, -1 }, new[] { -1, -1 }, new[] { 2, 0 }, new[] { -2, 0 }, new[] { 1, 1 }, new[] { -1, 1 }, new[] { 2, -1 }, new[] { -2, -1 } };
                for (int i = 0; i < dirs.Length; i++)
                {
                    int dx = dirs[i][0];
                    int dy = dirs[i][1];
                    if ((variant & 1) == 1 && i == 3)
                        dx += 1;
                    for (int s = 0; s < 16; s++)
                    {
                        int x = cx + dx * s / 2;
                        int y = cy + dy * s / 2 + s * s / 40;
                        Color c = s < 4 ? leafL : leaf;
                        if (s > 11) c = leafD;
                        Plot(d, w, x, y, c);
                        Plot(d, w, x + 1, y, c);
                        Plot(d, w, x, y + 1, Mix(c, Ink, 20));
                        if (s % 3 == 0)
                        {
                            Plot(d, w, x + (dx >= 0 ? 2 : -2), y + 1, leaf);
                            Plot(d, w, x + (dx >= 0 ? 3 : -3), y + 2, leafD);
                        }
                    }
                }
                Plot(d, w, cx, cy, new Color(214, 176, 80));
                Plot(d, w, cx + 1, cy, new Color(186, 140, 58));
            });
        }

        public static Texture2D DeadCrown(GraphicsDevice gd, int variant)
        {
            Color wood = new Color(118, 96, 74);
            Color woodD = new Color(72, 56, 44);
            int tw = 44;
            int th = 40;
            return Build(gd, tw, th, (d, w, h) =>
            {
                int cx = 22;
                int cy = 28;
                int[][] arms =
                {
                    new[] { -1, -2, 14 },
                    new[] { 1, -2, 13 },
                    new[] { -2, -1, 11 },
                    new[] { 2, -1, 12 },
                    new[] { 0, -2, 10 }
                };
                for (int i = 0; i < arms.Length; i++)
                {
                    int dx = arms[i][0];
                    int dy = arms[i][1];
                    if ((variant & 1) == 1)
                        dx = -dx;
                    int len = arms[i][2];
                    for (int s = 0; s < len; s++)
                    {
                        int x = cx + dx * s + (int)(Math.Sin((s + variant) * 0.4) * 1.2);
                        int y = cy + dy * s / 2 - s / 3;
                        Plot(d, w, x, y, s % 4 == 0 ? woodD : wood);
                        Plot(d, w, x, y + 1, Ink);
                        if (s > 6 && s % 4 == 0)
                        {
                            Plot(d, w, x + 2, y - 1, wood);
                            Plot(d, w, x - 2, y - 1, woodD);
                        }
                    }
                }
            });
        }

        public static Texture2D CanopyStump(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 8; y <= 13; y++)
                    for (int x = 4; x <= 11; x++)
                    {
                        Color c = WoodA;
                        if (y == 8) c = new Color(214, 186, 140);
                        if (x == 4 || x == 11 || y == 13) c = Ink;
                        Plot(d, w, x, y, c);
                    }
                Plot(d, w, 6, 10, WoodC);
                Plot(d, w, 9, 11, WoodD);
            });
        }

        public static Texture2D CanopyRock(GraphicsDevice gd)
        {
            Color a = new Color(148, 146, 140);
            Color b = new Color(112, 110, 106);
            Color hi = new Color(186, 184, 176);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 6; y <= 13; y++)
                    for (int x = 3; x <= 13; x++)
                    {
                        int dx = x - 8;
                        int dy = y - 10;
                        if (dx * dx + dy * dy * 2 > 28)
                            continue;
                        Color c = a;
                        if (dx + dy < -1) c = hi;
                        if (dx + dy > 3) c = b;
                        if (dx * dx + dy * dy * 2 > 22) c = Ink;
                        Plot(d, w, x, y, c);
                    }
            });
        }

        public static Texture2D MineralVein(GraphicsDevice gd)
        {
            Color a = new Color(118, 116, 124);
            Color b = new Color(78, 76, 86);
            Color hi = new Color(168, 166, 176);
            Color gold = new Color(224, 176, 64);
            Color silver = new Color(214, 220, 230);
            Color teal = new Color(86, 186, 168);
            Color green = new Color(118, 176, 86);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 5; y <= 14; y++)
                    for (int x = 2; x <= 13; x++)
                    {
                        int dx = x - 8;
                        int dy = y - 10;
                        if (dx * dx + dy * dy * 2 > 36)
                            continue;
                        Color c = a;
                        if (dx + dy < -2) c = hi;
                        if (dx + dy > 3) c = b;
                        if (dx * dx + dy * dy * 2 > 28) c = Ink;
                        Plot(d, w, x, y, c);
                    }
                Plot(d, w, 6, 8, gold);
                Plot(d, w, 7, 7, gold);
                Plot(d, w, 7, 8, new Color(246, 214, 120));
                Plot(d, w, 10, 9, silver);
                Plot(d, w, 11, 10, silver);
                Plot(d, w, 5, 11, teal);
                Plot(d, w, 8, 12, green);
                Plot(d, w, 9, 7, teal);
            });
        }

        public static Texture2D OreChunk(GraphicsDevice gd, Color hi, Color lo)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                Color mid = Mix(hi, lo, 40);
                for (int y = 4; y <= 12; y++)
                    for (int x = 3; x <= 12; x++)
                    {
                        int dx = x - 8;
                        int dy = y - 8;
                        if (dx * dx + dy * dy * 2 > 22)
                            continue;
                        Color c = mid;
                        if (dx + dy < -1) c = hi;
                        if (dx + dy > 2) c = lo;
                        if (dx * dx + dy * dy * 2 > 16) c = Ink;
                        Plot(d, w, x, y, c);
                    }
            });
        }

        public static Texture2D GeodeIcon(GraphicsDevice gd)
        {
            Color shell = new Color(132, 118, 108);
            Color shellLo = new Color(88, 76, 70);
            Color inner = new Color(156, 118, 196);
            Color spark = new Color(220, 196, 246);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 4; y <= 13; y++)
                    for (int x = 3; x <= 12; x++)
                    {
                        int dx = x - 8;
                        int dy = y - 9;
                        if (dx * dx + dy * dy > 18)
                            continue;
                        Color c = shell;
                        if (dx < 0) c = inner;
                        if (dx + dy < -3) c = spark;
                        if (dx > 1) c = shellLo;
                        if (dx * dx + dy * dy > 13) c = Ink;
                        Plot(d, w, x, y, c);
                    }
            });
        }

        public static Texture2D BeachShell(GraphicsDevice gd, int kind)
        {
            Color cream = new Color(244, 226, 198);
            Color creamLo = new Color(196, 168, 132);
            Color pink = new Color(232, 168, 156);
            Color pinkLo = new Color(186, 118, 108);
            Color spiral = new Color(214, 186, 148);
            Color spiralLo = new Color(168, 128, 88);
            Color sand = new Color(236, 220, 186);
            Color sandLo = new Color(176, 148, 108);
            Color conch = new Color(216, 124, 92);
            Color conchLo = new Color(148, 72, 52);
            Color hi = new Color(255, 246, 230);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                if (kind <= 0)
                {
                    FillOval(d, w, 5, 7, 11, 12, creamLo);
                    FillOval(d, w, 6, 8, 10, 11, cream);
                    Plot(d, w, 8, 9, hi);
                    Plot(d, w, 7, 10, creamLo);
                    Plot(d, w, 9, 10, creamLo);
                }
                else if (kind == 1)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        int x0 = 4 + i;
                        Plot(d, w, x0, 11 - i / 2, pinkLo);
                        Plot(d, w, 12 - i, 11 - i / 2, pinkLo);
                    }
                    FillOval(d, w, 5, 6, 11, 11, pink);
                    Plot(d, w, 8, 8, hi);
                    Plot(d, w, 7, 9, pinkLo);
                    Plot(d, w, 9, 9, pinkLo);
                    Plot(d, w, 8, 10, cream);
                }
                else if (kind == 2)
                {
                    Plot(d, w, 10, 5, spiralLo);
                    Plot(d, w, 11, 6, spiral);
                    Plot(d, w, 11, 7, hi);
                    FillOval(d, w, 5, 7, 11, 12, spiralLo);
                    FillOval(d, w, 6, 8, 10, 11, spiral);
                    Plot(d, w, 8, 9, cream);
                    Plot(d, w, 7, 10, spiralLo);
                }
                else if (kind == 3)
                {
                    FillOval(d, w, 4, 6, 12, 12, sandLo);
                    FillOval(d, w, 5, 7, 11, 11, sand);
                    Plot(d, w, 8, 9, sandLo);
                    Plot(d, w, 7, 8, hi);
                    Plot(d, w, 9, 8, hi);
                    Plot(d, w, 6, 9, sandLo);
                    Plot(d, w, 10, 9, sandLo);
                    Plot(d, w, 8, 10, Ink);
                }
                else
                {
                    FillOval(d, w, 4, 5, 12, 12, conchLo);
                    FillOval(d, w, 5, 6, 11, 11, conch);
                    Plot(d, w, 9, 7, hi);
                    Plot(d, w, 7, 8, cream);
                    Plot(d, w, 8, 9, conchLo);
                    Plot(d, w, 6, 10, conchLo);
                    Plot(d, w, 10, 6, conch);
                }
            });
        }

        public static Texture2D BeachSeaweed(GraphicsDevice gd)
        {
            Color a = new Color(62, 118, 78);
            Color b = new Color(42, 86, 58);
            Color c = new Color(118, 156, 88);
            Color dlo = new Color(36, 64, 44);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 4; y <= 14; y++)
                {
                    int sway = ((y / 3) & 1) == 0 ? 0 : 1;
                    Plot(d, w, 7 + sway, y, a);
                    Plot(d, w, 8 + sway, y, b);
                    if ((y & 1) == 0)
                        Plot(d, w, 6 + sway, y, c);
                    if (y > 8 && (y & 1) == 1)
                        Plot(d, w, 9 + sway, y, dlo);
                }
                Plot(d, w, 7, 14, dlo);
                Plot(d, w, 8, 14, dlo);
                Plot(d, w, 6, 6, c);
                Plot(d, w, 10, 8, a);
            });
        }

        static void FillOval(Color[] d, int w, int x0, int y0, int x1, int y1, Color c)
        {
            int cx = (x0 + x1) / 2;
            int cy = (y0 + y1) / 2;
            int rx = Math.Max(1, (x1 - x0) / 2);
            int ry = Math.Max(1, (y1 - y0) / 2);
            for (int y = y0; y <= y1; y++)
            {
                for (int x = x0; x <= x1; x++)
                {
                    int dx = x - cx;
                    int dy = y - cy;
                    if (dx * dx * ry * ry + dy * dy * rx * rx <= rx * rx * ry * ry)
                        Plot(d, w, x, y, c);
                }
            }
        }

        public static Texture2D GemIcon(GraphicsDevice gd, Color hi, Color lo)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                int[][] pts =
                {
                    new[] {8, 3}, new[] {5, 6}, new[] {11, 6}, new[] {4, 9}, new[] {12, 9},
                    new[] {6, 12}, new[] {10, 12}, new[] {8, 13}
                };
                for (int i = 0; i < pts.Length; i++)
                    Plot(d, w, pts[i][0], pts[i][1], Ink);
                for (int y = 4; y <= 12; y++)
                    for (int x = 5; x <= 11; x++)
                    {
                        int dx = Math.Abs(x - 8);
                        int top = 4 + dx / 2;
                        int bot = 12 - dx / 2;
                        if (y < top || y > bot)
                            continue;
                        Color c = y < 7 ? hi : (x > 9 ? lo : Mix(hi, lo, 35));
                        Plot(d, w, x, y, c);
                    }
                Plot(d, w, 7, 5, new Color(255, 255, 255));
            });
        }

        static void RoofPalette(int style, out Color a, out Color b, out Color c, out Color d)
        {
            if (style == 2)
            {
                a = new Color(148, 142, 78);
                b = new Color(186, 176, 104);
                c = new Color(108, 118, 64);
                d = new Color(72, 80, 48);
            }
            else if (style == 3)
            {
                a = new Color(186, 86, 64);
                b = new Color(220, 128, 88);
                c = new Color(140, 62, 48);
                d = new Color(92, 42, 34);
            }
            else if (style == 1)
            {
                a = new Color(196, 108, 78);
                b = new Color(228, 152, 104);
                c = new Color(154, 78, 56);
                d = new Color(102, 48, 36);
            }
            else
            {
                a = new Color(198, 160, 82);
                b = new Color(232, 204, 124);
                c = new Color(156, 118, 58);
                d = new Color(108, 76, 40);
            }
        }

        static void WallPalette(
            int style,
            out Color plaster, out Color plasterD, out Color plasterL,
            out Color beam, out Color beamL, out Color beamH)
        {
            plaster = new Color(246, 226, 188);
            plasterD = new Color(210, 178, 132);
            plasterL = new Color(254, 242, 214);
            beam = new Color(118, 78, 48);
            beamL = new Color(176, 128, 78);
            beamH = new Color(206, 160, 102);
            if (style == 1)
            {
                plaster = new Color(236, 220, 186);
                plasterD = new Color(196, 176, 140);
                plasterL = new Color(250, 240, 214);
            }
            else if (style == 2)
            {
                plaster = new Color(232, 230, 196);
                plasterD = new Color(190, 188, 148);
                plasterL = new Color(246, 244, 216);
                beam = new Color(96, 78, 48);
                beamL = new Color(148, 118, 72);
            }
            else if (style == 3)
            {
                plaster = new Color(244, 214, 168);
                plasterD = new Color(206, 168, 118);
                plasterL = new Color(252, 236, 196);
            }
        }

        static void StonePalette(
            int style,
            out Color stone, out Color stoneL, out Color stoneD,
            out Color chim, out Color chimL, out Color chimD)
        {
            stone = new Color(150, 142, 130);
            stoneL = new Color(194, 186, 172);
            stoneD = new Color(96, 88, 82);
            chim = new Color(160, 96, 70);
            chimL = new Color(198, 134, 100);
            chimD = new Color(98, 52, 40);
            if (style == 2)
            {
                stone = new Color(158, 144, 126);
                stoneL = new Color(202, 188, 166);
                stoneD = new Color(100, 88, 76);
            }
            else if (style == 0)
            {
                stone = new Color(154, 144, 128);
                stoneL = new Color(198, 188, 170);
                stoneD = new Color(96, 88, 76);
            }
        }

        static Color LineC(Color c)
        {
            return new Color(
                Math.Max(22, c.R * 42 / 100),
                Math.Max(18, c.G * 40 / 100),
                Math.Max(16, c.B * 38 / 100));
        }

        static void DrawPeakedRoof(
            Color[] d, int w, int pw, int roofBottom,
            Color r0, Color r1, Color r2, Color r3, int style)
        {
            for (int y = 0; y < roofBottom; y++)
            {
                float t = 1f - y / (float)Math.Max(1, roofBottom);
                int inset = (int)(t * (pw / 2 - 6));
                if (inset < 0) inset = 0;
                for (int x = inset; x < pw - inset; x++)
                {
                    Color c = RoofPixel(x, y, r0, r1, r2, r3, style);
                    float across = (x - inset) / (float)Math.Max(1, pw - inset * 2);
                    if (across < 0.22f) c = Mix(c, r1, 45);
                    if (across > 0.78f) c = Mix(c, r3, 50);
                    if (x == inset) c = Mix(c, r1, 55);
                    if (x == pw - inset - 1) c = LineC(r3);
                    Plot(d, w, x, y, c);
                }
            }
            int ridgeY = 2;
            for (int x = pw / 2 - 6; x <= pw / 2 + 6; x++)
            {
                Plot(d, w, x, ridgeY, r3);
                Plot(d, w, x, ridgeY + 1, r0);
            }
            Plot(d, w, pw / 2, 0, r3);
            Plot(d, w, pw / 2 - 1, 1, r2);
            Plot(d, w, pw / 2 + 1, 1, r0);
            if (style == 2)
            {
                for (int x = pw / 2 - 8; x <= pw / 2 + 8; x++)
                    Plot(d, w, x, ridgeY + 2, Mix(r2, r3, 30));
            }
            if (style == 3)
            {
                for (int x = pw / 2 - 7; x <= pw / 2 + 7; x += 2)
                {
                    Plot(d, w, x, ridgeY, r1);
                    Plot(d, w, x, ridgeY - 1, r0);
                }
            }
        }

        static Color RoofPixel(int x, int y, Color r0, Color r1, Color r2, Color r3, int style)
        {
            int row = y / 3;
            int shift = (row % 2) * 4;
            int col = (x + shift) / 7;
            int lx = (x + shift) % 7;
            int ly = y % 3;
            Color c = ((col + row) & 1) == 0 ? r0 : r2;
            if (Hash(col, row, 41) % 6 == 0) c = Mix(c, r1, 40);
            if (lx <= 1 && ly == 0) c = Mix(c, r1, 70);
            else if (lx == 0 || ly == 2) c = Mix(c, r3, 55);
            else if (ly == 0) c = Mix(c, r1, 45);
            if (style == 2 && Hash(x, y, 77) % 17 == 0)
                c = Mix(c, new Color(92, 118, 54), 30);
            return c;
        }

        static void DrawEaves(
            Color[] d, int w, int pw, int wallTop, int wallLeft, int wallRight, int eaveH,
            Color r0, Color r2, Color r3)
        {
            Color under = new Color(28, 18, 14, 220);
            Color lip = Mix(r3, r2, 40);
            for (int y = 0; y < eaveH; y++)
            {
                int inset = y == 0 ? 0 : 1;
                for (int x = inset; x < pw - inset; x++)
                {
                    Color c = y == 0 ? r0 : (y == 1 ? lip : under);
                    if (y >= 2 && (x < wallLeft || x >= wallRight))
                        c = Mix(r3, under, 30);
                    if (y == eaveH - 1) c = Mix(under, r3, 40);
                    Plot(d, w, x, wallTop + y, c);
                }
            }
            for (int x = wallLeft; x < wallRight; x++)
            {
                Plot(d, w, x, wallTop + eaveH, new Color(36, 24, 18, 180));
                if ((x & 1) == 0)
                    Plot(d, w, x, wallTop + eaveH + 1, new Color(40, 28, 20, 90));
            }
        }

        static void DrawChimney(Color[] d, int w, int pw, int wallTop, int style, Color chim, Color chimL, Color chimD)
        {
            int bw = style == 3 ? 12 : 10;
            int cx = pw - 18 - bw;
            int y1 = Math.Max(6, wallTop / 6);
            int y2 = wallTop;
            for (int y = y1; y < y2; y++)
            {
                for (int x = cx; x < cx + bw; x++)
                {
                    Color c = chim;
                    if ((y / 3) % 2 == 0)
                    {
                        if ((x - cx) < bw / 2) c = chimL;
                    }
                    else if ((x - cx) >= bw / 2) c = chimL;
                    if ((x - cx) % 5 == 0 || y % 3 == 0) c = chimD;
                    if (x == cx) c = chimD;
                    if (x == cx + bw - 1) c = Mix(chim, chimD, 40);
                    Plot(d, w, x, y, c);
                }
            }
            int capY = y1 - 3;
            for (int y = capY; y < y1; y++)
            {
                for (int x = cx - 2; x < cx + bw + 2; x++)
                    Plot(d, w, x, y, y == capY ? chimD : chimL);
            }
            for (int x = cx + 2; x < cx + bw - 2; x++)
            {
                Plot(d, w, x, capY + 1, new Color(28, 22, 20));
                Plot(d, w, x, capY, chimD);
            }
            Plot(d, w, cx + bw / 2, capY - 1, chimD);
        }

        static void DrawSideGable(
            Color[] d, int w, int peakX, int peakY, int baseY, int halfW,
            Color r0, Color r1, Color r2, Color r3,
            Color plaster, Color plasterD, Color beam)
        {
            for (int y = peakY; y < baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 3 + (int)(t * halfW);
                for (int x = peakX - hw; x <= peakX + hw; x++)
                {
                    bool edge = x == peakX - hw || x == peakX + hw || y == peakY;
                    bool face = y > peakY + 8 && x > peakX - hw + 3 && x < peakX + hw - 3;
                    Color c = edge ? r3 : RoofPixel(x, y, r0, r1, r2, r3, 3);
                    if (face) c = (x + y) % 9 == 0 ? plasterD : plaster;
                    Plot(d, w, x, y, c);
                }
            }
            DrawHouseWindow(d, w, peakX - 6, baseY - 16, 3, 9);
            for (int y = peakY + 8; y < baseY; y++)
            {
                Plot(d, w, peakX - 3 - (y - peakY) / 4, y, beam);
                Plot(d, w, peakX + 3 + (y - peakY) / 4, y, beam);
            }
        }

        static void DrawDormer(
            Color[] d, int w, int x0, int peakY, int baseY, int width,
            Color r0, Color r1, Color r2, Color r3, Color plaster, Color beam, int style)
        {
            int peakX = x0 + width / 2;
            for (int y = peakY; y < baseY; y++)
            {
                float t = (y - peakY) / (float)Math.Max(1, baseY - peakY);
                int hw = 2 + (int)(t * (width / 2));
                for (int x = peakX - hw; x <= peakX + hw; x++)
                {
                    bool edge = x == peakX - hw || x == peakX + hw;
                    Color c = edge ? r3 : RoofPixel(x, y, r0, r1, r2, r3, style);
                    if (y > peakY + 6 && x > peakX - hw + 2 && x < peakX + hw - 2)
                        c = plaster;
                    Plot(d, w, x, y, c);
                }
            }
            for (int x = peakX - 5; x <= peakX + 5; x++)
                Plot(d, w, x, peakY + 1, beam);
            DrawHouseWindow(d, w, peakX - 6, baseY - 14, style, 8);
        }

        static void DrawTimberStory(
            Color[] d, int w, int wallLeft, int wallRight, int y0, int y1,
            Color plaster, Color plasterD, Color plasterL,
            Color beam, Color beamL, Color beamH)
        {
            Color ink = LineC(beam);
            for (int y = y0; y < y1; y++)
            {
                for (int x = wallLeft; x < wallRight; x++)
                {
                    Color c = plaster;
                    if ((x * 3 + y) % 13 == 0) c = plasterD;
                    else if ((x + y * 2) % 11 == 0) c = plasterL;
                    if (x + y < wallLeft + y0 + 10) c = Mix(c, plasterL, 35);
                    if (x > wallRight - 5) c = Mix(c, plasterD, 30);
                    Plot(d, w, x, y, c);
                }
            }
            for (int y = y0; y < y1; y++)
            {
                Plot(d, w, wallLeft, y, ink);
                Plot(d, w, wallLeft + 1, y, beamL);
                Plot(d, w, wallLeft + 2, y, beamH);
                Plot(d, w, wallRight - 1, y, ink);
                Plot(d, w, wallRight - 2, y, beam);
                Plot(d, w, wallRight - 3, y, beamL);
            }
            for (int x = wallLeft; x < wallRight; x++)
            {
                Plot(d, w, x, y0, ink);
                Plot(d, w, x, y0 + 1, beamL);
                Plot(d, w, x, y0 + 2, beamH);
                Plot(d, w, x, y1 - 1, ink);
                Plot(d, w, x, y1 - 2, beam);
            }
            int span = 14;
            for (int px = wallLeft + span; px < wallRight - 4; px += span)
            {
                for (int y = y0; y < y1; y++)
                {
                    Color c = beam;
                    if ((y & 1) == 0) c = beamL;
                    if ((y % 5) == 0) c = Mix(beam, beamH, 40);
                    Plot(d, w, px, y, c);
                    Plot(d, w, px + 1, y, beamH);
                    Plot(d, w, px - 1, y, ink);
                }
            }
            int mid = (y0 + y1) / 2;
            for (int x = wallLeft; x < wallRight; x++)
            {
                Plot(d, w, x, mid, beam);
                Plot(d, w, x, mid + 1, beamL);
            }
            for (int i = 0; i < 9; i++)
            {
                int bx = wallLeft + 4 + i;
                int by = y0 + 4 + i;
                if (by < y1 - 2)
                {
                    Plot(d, w, bx, by, beam);
                    Plot(d, w, bx + 1, by, beamL);
                }
            }
        }

        static void DrawMasonryStory(
            Color[] d, int w, int wallLeft, int wallRight, int y0, int y1,
            Color stone, Color stoneL, Color stoneD, int style)
        {
            Color ink = LineC(stoneD);
            int rowH = 4;
            for (int y = y0; y < y1; y++)
            {
                int row = (y - y0) / rowH;
                int shift = (row % 2) * 3;
                for (int x = wallLeft; x < wallRight; x++)
                {
                    int col = (x - wallLeft + shift) / 6;
                    int lx = (x - wallLeft + shift) % 6;
                    int ly = (y - y0) % rowH;
                    int n = Hash(col, row, 19 + style);
                    Color c = stone;
                    if ((n % 3) == 0) c = Mix(stone, stoneL, 40);
                    else if ((n % 3) == 1) c = Mix(stone, stoneD, 25);
                    if (lx == 0 || ly == 0) c = Mix(c, stoneL, 55);
                    if (lx == 5 || ly == rowH - 1) c = Mix(c, stoneD, 50);
                    if (x + y < wallLeft + y0 + 8) c = Mix(c, stoneL, 30);
                    if (x == wallLeft || x == wallRight - 1 || y == y0 || y == y1 - 1)
                        c = ink;
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawTimber(
            Color[] d, int w, int wallLeft, int wallRight, int wallTop, int ph, int foundH,
            int doorX0, Color beam, Color beamL, Color beamH, int style)
        {
            int y0 = wallTop + 6;
            int y1 = ph - foundH;
            if (style == 0)
            {
                for (int y = y0; y < y1; y++)
                {
                    for (int x = wallLeft; x < wallRight; x++)
                    {
                        int plank = (x - wallLeft) / 3;
                        Color c = (plank & 1) == 0 ? beamH : Mix(beamL, beamH, 40);
                        if ((x - wallLeft) % 3 == 0) c = beam;
                        if (x + y < wallLeft + y0 + 8) c = Mix(c, beamH, 35);
                        if (x > wallRight - 6) c = Mix(c, beam, 40);
                        Plot(d, w, x, y, c);
                    }
                }
            }
            for (int y = y0; y < y1; y++)
            {
                Plot(d, w, wallLeft, y, beam);
                Plot(d, w, wallLeft + 1, y, beamL);
                Plot(d, w, wallLeft + 2, y, beamH);
                Plot(d, w, wallRight - 1, y, beam);
                Plot(d, w, wallRight - 2, y, beamL);
                Plot(d, w, wallRight - 3, y, beam);
            }
            for (int x = wallLeft; x < wallRight; x++)
            {
                Plot(d, w, x, y0, beam);
                Plot(d, w, x, y0 + 1, beamL);
            }
            if (style == 1)
            {
                for (int y = y0 + 2; y < y1; y += 3)
                {
                    for (int x = wallLeft + 3; x < wallRight - 3; x++)
                    {
                        if (x > doorX0 + 1 && x < doorX0 + 14)
                            continue;
                        Plot(d, w, x, y, Mix(beamL, new Color(188, 186, 178), 70));
                    }
                }
                return;
            }
            int span = style == 3 ? 20 : 16;
            for (int px = wallLeft + span; px < wallRight - 4; px += span)
            {
                if (px > doorX0 - 2 && px < doorX0 + 16)
                    continue;
                for (int y = y0; y < y1; y++)
                {
                    Plot(d, w, px, y, beam);
                    Plot(d, w, px + 1, y, beamL);
                }
            }
            int mid = (y0 + y1) / 2;
            for (int x = wallLeft; x < wallRight; x++)
            {
                if (x > doorX0 + 1 && x < doorX0 + 14 && mid > y0 + 8)
                    continue;
                Plot(d, w, x, mid, beam);
                Plot(d, w, x, mid + 1, beamL);
            }
            if (style == 0 || style == 2)
            {
                int bx = wallLeft + 4;
                for (int i = 0; i < 10; i++)
                {
                    Plot(d, w, bx + i, y0 + 3 + i, beam);
                    Plot(d, w, bx + i + 1, y0 + 3 + i, beamL);
                }
                int rx = wallRight - 14;
                if (rx > doorX0 + 16 || rx + 10 < doorX0)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Plot(d, w, rx + i, mid - i, beam);
                        Plot(d, w, rx + i + 1, mid - i, beamL);
                    }
                }
            }
        }

        static void DrawFoundation(
            Color[] d, int w, int wallLeft, int wallRight, int y0, int y1,
            Color stone, Color stoneL, Color stoneD, int style)
        {
            for (int y = y0; y < y1; y++)
            {
                for (int x = wallLeft; x < wallRight; x++)
                {
                    int col = (x / 5) + ((y - y0) / 2) * 3;
                    Color c = (col % 3 == 0) ? stone : (col % 3 == 1) ? stoneL : stoneD;
                    if (x % 5 == 0 || y == y0) c = stoneD;
                    if (style == 2 && Hash(x, y, 5) % 9 == 0) c = Mix(c, new Color(110, 140, 70), 35);
                    Plot(d, w, x, y, c);
                }
            }
        }

        static void DrawHouseWindow(Color[] d, int w, int x0, int y0, int style, int seed)
        {
            int ww = 12;
            int wh = 11;
            Color frame = new Color(86, 58, 38);
            Color frameL = new Color(148, 112, 72);
            Color mull = Mix(frame, new Color(48, 36, 28), 40);
            Color glass = new Color(108, 148, 176);
            Color glassD = new Color(62, 92, 118);
            Color shine = new Color(228, 240, 248);
            Color ink = LineC(frame);
            FillRect(d, w, x0, y0, ww, wh, ink);
            FillRect(d, w, x0 + 1, y0 + 1, ww - 2, wh - 2, frame);
            Plot(d, w, x0 + 1, y0 + 1, frameL);
            Plot(d, w, x0 + 2, y0 + 1, frameL);
            for (int y = y0 + 2; y < y0 + wh - 2; y++)
            {
                for (int x = x0 + 2; x < x0 + ww - 2; x++)
                {
                    Color c = (x + y) < x0 + y0 + 8 ? Mix(glass, shine, 20) : glassD;
                    Plot(d, w, x, y, c);
                }
            }
            int mx = x0 + ww / 2;
            int my = y0 + wh / 2;
            for (int y = y0 + 2; y < y0 + wh - 2; y++)
                Plot(d, w, mx, y, mull);
            for (int x = x0 + 2; x < x0 + ww - 2; x++)
                Plot(d, w, x, my, mull);
            Plot(d, w, x0 + 3, y0 + 3, shine);
            Plot(d, w, x0 + 4, y0 + 3, Mix(glass, shine, 50));
            Color sill = new Color(168, 138, 96);
            Color sillD = new Color(108, 82, 54);
            for (int x = x0 - 1; x < x0 + ww + 1; x++)
            {
                Plot(d, w, x, y0 + wh - 1, sillD);
                Plot(d, w, x, y0 + wh, sill);
                Plot(d, w, x, y0 + wh + 1, LineC(sillD));
            }
            Color box = new Color(108, 72, 42);
            Color leaf = new Color(72, 128, 62);
            Color bloom = new Color(242, 242, 236);
            for (int x = x0 + 1; x < x0 + ww - 1; x++)
            {
                Plot(d, w, x, y0 + wh + 1, box);
                Plot(d, w, x, y0 + wh + 2, Mix(box, LineC(box), 40));
            }
            Plot(d, w, x0 + 3, y0 + wh, leaf);
            Plot(d, w, x0 + 4, y0 + wh - 1, bloom);
            Plot(d, w, x0 + 5, y0 + wh, leaf);
            Plot(d, w, x0 + ww - 4, y0 + wh, leaf);
            Plot(d, w, x0 + ww - 5, y0 + wh - 1, bloom);
            if ((seed & 1) == 0)
                Plot(d, w, x0 + ww / 2, y0 + wh - 1, bloom);
            if (style == 3)
            {
                Color shut = new Color(86, 36, 42);
                Color shutL = new Color(128, 58, 62);
                for (int y = y0 + 1; y < y0 + wh - 1; y++)
                {
                    Plot(d, w, x0 - 2, y, shut);
                    Plot(d, w, x0 - 3, y, shutL);
                    Plot(d, w, x0 + ww + 1, y, shut);
                    Plot(d, w, x0 + ww + 2, y, shutL);
                }
            }
        }

        static void DrawHouseDoor(
            Color[] d, int w, int doorX0, int y0, int y1,
            int style, Color beam, Color beamL, bool open)
        {
            int x0 = doorX0 + 2;
            int x1 = doorX0 + 14;
            Color plank = new Color(138, 96, 58);
            Color plankD = new Color(92, 60, 36);
            Color plankL = new Color(176, 132, 82);
            Color ink = LineC(plankD);
            Color iron = new Color(72, 72, 78);
            Color ironL = new Color(128, 128, 132);
            if (style == 3)
            {
                plank = new Color(118, 62, 48);
                plankD = new Color(78, 36, 28);
                plankL = new Color(158, 92, 68);
            }
            for (int y = y0; y < y1; y++)
            {
                for (int x = x0 - 1; x < x1 + 1; x++)
                {
                    int dx0 = x - (x0 - 1);
                    int dx1 = (x1) - x;
                    bool round = y <= y0 + 2 && (dx0 + dx1 < 3 + (y0 + 2 - y));
                    if (y == y0 && (x <= x0 || x >= x1 - 1))
                        continue;
                    if (y == y0 + 1 && (x == x0 - 1 || x == x1))
                        continue;
                    if (round && y == y0)
                        continue;
                    Color c = beam;
                    Plot(d, w, x, y, c);
                }
            }
            for (int y = y0 + 1; y < y1; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    if (y == y0 + 1 && (x == x0 || x == x1 - 1))
                        continue;
                    Color c = plank;
                    int px = x - x0;
                    if (px % 4 == 0) c = plankD;
                    if (px % 4 == 1) c = plankL;
                    if (x + y < x0 + y0 + 8) c = Mix(c, plankL, 30);
                    if (x == x0 || x == x1 - 1 || y == y1 - 1)
                        c = ink;
                    Plot(d, w, x, y, c);
                }
            }
            int split = (x0 + x1) / 2;
            for (int y = y0 + 3; y < y1 - 1; y++)
                Plot(d, w, split, y, Mix(plankL, plank, 40));
            int ky = y0 + Math.Min(8, (y1 - y0) / 2);
            int kx = x1 - 4;
            Plot(d, w, kx, ky, ironL);
            Plot(d, w, kx + 1, ky, iron);
            Plot(d, w, kx, ky + 1, iron);
            Plot(d, w, kx - 1, ky, iron);
            Plot(d, w, kx, ky - 1, iron);
            Plot(d, w, kx + 1, ky + 2, iron);
            Plot(d, w, x0 + 1, y0 + 5, iron);
            Plot(d, w, x0 + 1, y0 + 6, ironL);
            Plot(d, w, x0 + 1, y1 - 5, iron);
            Plot(d, w, x0 + 1, y1 - 4, ironL);
            if (open)
                DrawHouseDoorOpen(d, w, x0, x1, y0, y1, plank, plankD, plankL, ink, iron, ironL);
        }

        static void DrawHouseDoorOpen(
            Color[] d, int w, int x0, int x1, int y0, int y1,
            Color plank, Color plankD, Color plankL, Color ink, Color iron, Color ironL)
        {
            Color hole = new Color(18, 12, 14);
            Color warm = new Color(62, 42, 32);
            Color floor = new Color(48, 34, 26);
            for (int y = y0 + 2; y < y1; y++)
            {
                for (int x = x0 + 1; x < x1 - 1; x++)
                {
                    float t = (y - y0) / (float)Math.Max(1, y1 - y0);
                    Color c = Mix(warm, hole, (int)(t * 85));
                    if (y > y1 - 4)
                        c = Mix(c, floor, 55);
                    Plot(d, w, x, y, c);
                }
            }
            for (int y = y0 + 1; y < y1; y++)
            {
                int lean = (y - y0) / 7;
                for (int i = 0; i < 4; i++)
                {
                    int lx = x0 - 3 - lean + i;
                    int rx = x1 + lean - i;
                    Color lc = i == 0 || i == 3 ? ink : (i == 1 ? plankL : plank);
                    Color rc = i == 0 || i == 3 ? ink : (i == 1 ? plank : plankD);
                    if (y == y0 + 1)
                    {
                        lc = plankL;
                        rc = plankL;
                    }
                    Plot(d, w, lx, y, lc);
                    Plot(d, w, rx, y, rc);
                }
            }
            int hy = y0 + 6;
            Plot(d, w, x0 - 1, hy, ironL);
            Plot(d, w, x0, hy, iron);
            Plot(d, w, x1 - 1, hy, iron);
            Plot(d, w, x1, hy, ironL);
            Plot(d, w, x0 - 1, y1 - 6, iron);
            Plot(d, w, x1, y1 - 6, iron);
        }

        static void DrawDoorstep(
            Color[] d, int w, int doorX0, int y0, int ph,
            Color stone, Color stoneL, Color stoneD, int style)
        {
            int x0 = doorX0;
            int x1 = doorX0 + 16;
            if (style == 3)
            {
                x0 -= 2;
                x1 += 2;
            }
            for (int y = y0; y < ph; y++)
            {
                for (int x = x0; x < x1; x++)
                {
                    Color c = (x + y) % 3 == 0 ? stoneL : stone;
                    if (y == y0 || x == x0 || x == x1 - 1) c = stoneD;
                    Plot(d, w, x, y, c);
                }
            }
            if (style == 1)
            {
                for (int x = doorX0 + 1; x < doorX0 + 15; x++)
                {
                    Plot(d, w, x, y0, WoodA);
                    Plot(d, w, x, y0 + 1, WoodC);
                }
            }
        }

        static void DrawVines(Color[] d, int w, int x0, int y0, int y1)
        {
            Color leaf = new Color(62, 138, 52);
            Color leafL = new Color(118, 186, 72);
            Color leafD = new Color(36, 86, 40);
            int x = x0;
            for (int y = y0; y < y1; y += 2)
            {
                Plot(d, w, x, y, leafD);
                Plot(d, w, x + 1, y, leaf);
                Plot(d, w, x, y + 1, leafL);
                if ((y / 2) % 3 == 0)
                    Plot(d, w, x + 2, y, leaf);
                if ((y / 2) % 4 == 1)
                    x++;
            }
        }

        static void DrawShopSign(Color[] d, int w, int doorX0, int y, Color beam, Color beamL)
        {
            int x0 = doorX0 + 1;
            for (int i = 0; i < 4; i++)
                Plot(d, w, x0 + 6, y - 4 + i, beam);
            FillRect(d, w, x0, y, 14, 7, new Color(42, 56, 82));
            for (int x = x0; x < x0 + 14; x++)
            {
                Plot(d, w, x, y, beam);
                Plot(d, w, x, y + 6, beamL);
            }
            Plot(d, w, x0 + 3, y + 3, new Color(232, 197, 71));
            Plot(d, w, x0 + 6, y + 3, new Color(232, 197, 71));
            Plot(d, w, x0 + 9, y + 3, new Color(232, 197, 71));
        }

        static void DrawLantern(Color[] d, int w, int x, int y)
        {
            Color iron = new Color(48, 36, 32);
            Color glow = new Color(236, 186, 72);
            Color glowD = new Color(196, 128, 40);
            Plot(d, w, x, y - 2, iron);
            Plot(d, w, x + 1, y - 2, iron);
            FillRect(d, w, x - 1, y, 5, 5, iron);
            FillRect(d, w, x, y + 1, 3, 3, glow);
            Plot(d, w, x + 1, y + 1, glowD);
            Plot(d, w, x + 1, y + 5, iron);
        }

        static void FillRect(Color[] d, int w, int x0, int y0, int rw, int rh, Color c)
        {
            for (int y = 0; y < rh; y++)
            {
                for (int x = 0; x < rw; x++)
                    Plot(d, w, x0 + x, y0 + y, c);
            }
        }

        static Color Mix(Color a, Color b, int bAmt)
        {
            int aAmt = 100 - bAmt;
            return new Color(
                (a.R * aAmt + b.R * bAmt) / 100,
                (a.G * aAmt + b.G * bAmt) / 100,
                (a.B * aAmt + b.B * bAmt) / 100,
                (a.A * aAmt + b.A * bAmt) / 100);
        }

        public static Texture2D Wall(GraphicsDevice gd, bool window)
        {
            return Wall(gd, window, 0);
        }

        public static Texture2D Wall(GraphicsDevice gd, bool window, int theme)
        {
            Color cream, creamD, creamL;
            WallTheme(theme, out cream, out creamD, out creamL);
            bool cave = theme == 7;
            Color fa, fb, fc, seam;
            FloorTheme(theme, out fa, out fb, out fc, out seam);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                if (cave)
                {
                    for (int y = 0; y < h; y++)
                    {
                        for (int x = 0; x < w; x++)
                        {
                            Color c = cream;
                            int n = Hash(x, y, 40 + theme) % 18;
                            if (n == 0) c = creamL;
                            else if (n == 1) c = creamD;
                            if ((x + y * 3) % 9 == 0)
                                c = creamD;
                            Plot(d, w, x, y, c);
                        }
                    }
                    return;
                }

                int wallH = 14;
                for (int y = 0; y < wallH; y++)
                {
                    for (int x = 0; x < w; x++)
                    {
                        Color c = cream;
                        int n = Hash(x, y, 40 + theme) % 22;
                        if (n == 0) c = creamL;
                        else if (n == 1) c = creamD;
                        Plot(d, w, x, y, c);
                    }
                }
                Color rail = Mix(creamD, new Color(86, 58, 38), 40);
                for (int x = 0; x < w; x++)
                {
                    Plot(d, w, x, wallH, rail);
                    Plot(d, w, x, wallH + 1, Mix(rail, cream, 30));
                }
                for (int y = wallH + 2; y < h; y++)
                {
                    Color row = ((y - wallH) / 3) % 2 == 0 ? fa : fb;
                    for (int x = 0; x < w; x++)
                    {
                        Color col = row;
                        if (x % 8 == 0) col = seam;
                        else if (x % 8 == 1) col = fc;
                        Plot(d, w, x, y, col);
                    }
                }
                if (window)
                    DrawInteriorWindow(d, w, 6, 1);
            });
        }

        static void DrawInteriorWindow(Color[] d, int w, int x0, int y0)
        {
            int ww = 20;
            int wh = 11;
            Color frame = new Color(86, 58, 38);
            Color frameL = new Color(148, 112, 72);
            Color glass = new Color(186, 168, 118);
            Color glassD = new Color(132, 118, 78);
            Color shine = new Color(252, 236, 196);
            Color mull = new Color(72, 50, 34);
            FillRect(d, w, x0, y0, ww, wh, frame);
            FillRect(d, w, x0 + 1, y0 + 1, ww - 2, wh - 2, frameL);
            for (int y = y0 + 2; y < y0 + wh - 2; y++)
            {
                for (int x = x0 + 2; x < x0 + ww - 2; x++)
                {
                    Color c = (x + y) < x0 + y0 + 10 ? Mix(glass, shine, 22) : glassD;
                    Plot(d, w, x, y, c);
                }
            }
            int mx = x0 + ww / 2;
            for (int y = y0 + 2; y < y0 + wh - 2; y++)
                Plot(d, w, mx, y, mull);
            Plot(d, w, x0 + 3, y0 + 2, shine);
        }

        static void WallTheme(int theme, out Color cream, out Color creamD, out Color creamL)
        {
            if (theme == 1)
            {
                cream = new Color(214, 210, 198);
                creamD = new Color(176, 172, 160);
                creamL = new Color(236, 232, 220);
            }
            else if (theme == 2)
            {
                cream = new Color(232, 210, 186);
                creamD = new Color(198, 168, 142);
                creamL = new Color(246, 228, 206);
            }
            else if (theme == 3)
            {
                cream = new Color(210, 196, 168);
                creamD = new Color(168, 152, 124);
                creamL = new Color(232, 218, 190);
            }
            else if (theme == 4)
            {
                cream = new Color(148, 108, 72);
                creamD = new Color(108, 74, 48);
                creamL = new Color(176, 132, 88);
            }
            else if (theme == 5)
            {
                cream = new Color(156, 148, 132);
                creamD = new Color(118, 112, 96);
                creamL = new Color(186, 178, 158);
            }
            else if (theme == 6)
            {
                cream = new Color(210, 186, 148);
                creamD = new Color(168, 142, 108);
                creamL = new Color(232, 210, 176);
            }
            else if (theme == 7)
            {
                cream = new Color(72, 68, 78);
                creamD = new Color(48, 44, 52);
                creamL = new Color(96, 92, 104);
            }
            else if (theme == 9)
            {
                cream = new Color(156, 78, 52);
                creamD = new Color(112, 52, 36);
                creamL = new Color(186, 104, 70);
            }
            else
            {
                cream = new Color(242, 226, 192);
                creamD = new Color(212, 188, 148);
                creamL = new Color(252, 242, 218);
            }
        }

        public static Texture2D Floor(GraphicsDevice gd)
        {
            return Floor(gd, 0);
        }

        public static Texture2D Floor(GraphicsDevice gd, int theme)
        {
            Color a, b, c, seam;
            FloorTheme(theme, out a, out b, out c, out seam);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                int plank = theme == 3 ? 6 : 8;
                for (int y = 0; y < h; y++)
                {
                    Color row = (y / 4) % 2 == 0 ? a : b;
                    for (int x = 0; x < w; x++)
                    {
                        Color col = row;
                        if (x % plank == 0) col = seam;
                        else if (x % plank == 1) col = c;
                        else if ((x + y + theme) % 13 == 0) col = Mix(b, seam, 40);
                        Plot(d, w, x, y, col);
                    }
                }
                for (int row = 3; row < 16; row += 4)
                    for (int x = 0; x < 16; x++)
                        Plot(d, w, x, row, Mix(seam, b, 30));
            });
        }

        static void FloorTheme(int theme, out Color a, out Color b, out Color c, out Color seam)
        {
            if (theme == 1)
            {
                a = new Color(148, 132, 108);
                b = new Color(128, 114, 92);
                c = new Color(168, 152, 124);
                seam = new Color(72, 60, 48);
            }
            else if (theme == 2)
            {
                a = new Color(186, 140, 88);
                b = new Color(164, 120, 72);
                c = new Color(210, 164, 108);
                seam = new Color(96, 64, 40);
            }
            else if (theme == 3)
            {
                a = new Color(118, 82, 54);
                b = new Color(96, 66, 42);
                c = new Color(142, 102, 68);
                seam = new Color(52, 34, 24);
            }
            else if (theme == 4)
            {
                a = new Color(108, 78, 50);
                b = new Color(88, 62, 40);
                c = new Color(128, 94, 60);
                seam = new Color(48, 32, 22);
            }
            else if (theme == 5)
            {
                a = new Color(118, 96, 72);
                b = new Color(96, 78, 56);
                c = new Color(142, 118, 88);
                seam = new Color(58, 44, 32);
            }
            else if (theme == 6)
            {
                a = new Color(176, 140, 92);
                b = new Color(148, 114, 72);
                c = new Color(198, 162, 108);
                seam = new Color(86, 58, 36);
            }
            else if (theme == 7)
            {
                a = new Color(58, 54, 62);
                b = new Color(42, 40, 48);
                c = new Color(78, 74, 86);
                seam = new Color(28, 26, 32);
            }
            else if (theme == 9)
            {
                a = new Color(176, 138, 88);
                b = new Color(152, 116, 72);
                c = new Color(198, 158, 104);
                seam = new Color(92, 64, 40);
            }
            else
            {
                a = FloorA;
                b = FloorB;
                c = FloorC;
                seam = WoodD;
            }
        }

        public static Texture2D Door(GraphicsDevice gd)
        {
            return Door(gd, false, 0);
        }

        public static Texture2D Door(GraphicsDevice gd, bool open)
        {
            return Door(gd, open, 0);
        }

        public static Texture2D Door(GraphicsDevice gd, bool open, int theme)
        {
            Color fa, fb, fc, seam;
            FloorTheme(theme, out fa, out fb, out fc, out seam);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    Color row = (y / 4) % 2 == 0 ? fa : fb;
                    for (int x = 0; x < w; x++)
                    {
                        Color col = row;
                        if (x % 8 == 0) col = seam;
                        else if (x % 8 == 1) col = fc;
                        Plot(d, w, x, y, col);
                    }
                }
                int dx0 = 8;
                int dx1 = 23;
                int dy0 = 8;
                int dy1 = 31;
                if (!open)
                {
                    FillRect(d, w, dx0, dy0, dx1 - dx0 + 1, dy1 - dy0 + 1, WoodD);
                    FillRect(d, w, dx0 + 2, dy0 + 2, dx1 - dx0 - 3, dy1 - dy0 - 3, WoodB);
                    FillRect(d, w, dx0 + 3, dy0 + 3, 5, 8, WoodA);
                    FillRect(d, w, dx0 + 9, dy0 + 3, 5, 8, WoodA);
                    FillRect(d, w, dx0 + 3, dy0 + 13, 5, 8, WoodA);
                    FillRect(d, w, dx0 + 9, dy0 + 13, 5, 8, WoodA);
                    Plot(d, w, dx1 - 3, 20, new Color(232, 197, 71));
                    Plot(d, w, dx1 - 3, 21, new Color(196, 150, 48));
                    return;
                }
                Color hole = new Color(22, 16, 18);
                Color warm = new Color(70, 48, 36);
                for (int y = dy0; y < dy1; y++)
                {
                    for (int x = 13; x <= 18; x++)
                        Plot(d, w, x, y, Mix(warm, hole, (y - dy0) * 4));
                }
                for (int y = dy0; y < dy1; y++)
                {
                    int lean = (y - dy0) / 12;
                    FillRect(d, w, dx0 + lean, y, 4, 1, WoodD);
                    FillRect(d, w, dx1 - 3 - lean, y, 4, 1, WoodD);
                    Plot(d, w, dx0 + 1 + lean, y, WoodA);
                    Plot(d, w, dx1 - 2 - lean, y, WoodA);
                }
                Plot(d, w, dx0 + 1, 20, new Color(232, 197, 71));
                Plot(d, w, dx1 - 2, 20, new Color(196, 150, 48));
            });
        }

        public static Texture2D Counter(GraphicsDevice gd)
        {
            Color top = new Color(214, 176, 124);
            Color topL = new Color(232, 200, 150);
            Color topD = new Color(168, 128, 84);
            Color face = new Color(148, 96, 58);
            Color faceD = new Color(108, 70, 42);
            Color knob = new Color(232, 197, 71);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 0, 0, 32, 10, top);
                for (int x = 0; x < 32; x++)
                {
                    Plot(d, w, x, 0, topL);
                    Plot(d, w, x, 9, topD);
                }
                FillRect(d, w, 0, 10, 32, 22, face);
                FillRect(d, w, 2, 12, 13, 16, faceD);
                FillRect(d, w, 17, 12, 13, 16, faceD);
                FillRect(d, w, 3, 13, 11, 6, Mix(face, topL, 20));
                FillRect(d, w, 18, 13, 11, 6, Mix(face, topL, 20));
                Plot(d, w, 8, 16, knob);
                Plot(d, w, 23, 16, knob);
                Plot(d, w, 8, 24, knob);
                Plot(d, w, 23, 24, knob);
            });
        }

        public static Texture2D Keg(GraphicsDevice gd)
        {
            Color wood = new Color(148, 96, 52);
            Color woodL = new Color(186, 132, 78);
            Color woodD = new Color(98, 62, 34);
            Color band = new Color(72, 70, 76);
            Color bandL = new Color(140, 138, 146);
            Color tap = new Color(186, 186, 196);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 4; y < 30; y++)
                {
                    for (int x = 6; x < 26; x++)
                    {
                        int dx = x - 16;
                        int dy = (y - 17);
                        if (dx * dx / 100.0 + dy * dy / 169.0 > 1.0)
                            continue;
                        Color c = wood;
                        if (x < 10) c = woodD;
                        else if (x > 21) c = woodL;
                        if (y == 10 || y == 11 || y == 21 || y == 22)
                            c = band;
                        Plot(d, w, x, y, c);
                    }
                }
                FillRect(d, w, 8, 10, 16, 2, band);
                FillRect(d, w, 8, 21, 16, 2, band);
                Plot(d, w, 24, 16, tap);
                Plot(d, w, 25, 16, tap);
                Plot(d, w, 26, 16, Mix(tap, bandL, 40));
                Plot(d, w, 26, 17, new Color(168, 92, 42));
            });
        }

        public static Texture2D Stairs(GraphicsDevice gd)
        {
            Color step = new Color(176, 118, 68);
            Color stepL = new Color(210, 154, 96);
            Color stepD = new Color(118, 74, 42);
            Color rail = new Color(92, 58, 34);
            Color hole = new Color(48, 32, 24);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                for (int y = 0; y < 32; y++)
                    for (int x = 0; x < 32; x++)
                        Plot(d, w, x, y, Mix(stepD, hole, 30));
                for (int i = 0; i < 6; i++)
                {
                    int top = 2 + i * 5;
                    int inset = 2 + (5 - i);
                    FillRect(d, w, inset, top, 28 - inset, 4, i % 2 == 0 ? step : stepL);
                    for (int x = inset; x < 28; x++)
                        Plot(d, w, x, top, stepL);
                    for (int x = inset; x < 28; x++)
                        Plot(d, w, x, top + 3, stepD);
                }
                for (int y = 0; y < 32; y++)
                {
                    Plot(d, w, 1, y, rail);
                    Plot(d, w, 2, y, Mix(rail, stepL, 25));
                    if ((y % 6) == 1)
                        Plot(d, w, 2, y, stepL);
                }
                FillRect(d, w, 20, 0, 12, 6, hole);
            });
        }

        public static Texture2D Fridge(GraphicsDevice gd, int variant)
        {
            Color steel = new Color(186, 196, 206);
            Color steelL = new Color(228, 236, 244);
            Color steelD = new Color(112, 124, 138);
            Color ink = new Color(48, 56, 68);
            Color glass = new Color(170, 214, 228, 110);
            Color shine = new Color(255, 255, 255, 70);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 0, 0, 32, 4, steelL);
                FillRect(d, w, 0, 28, 32, 4, steelD);
                FillRect(d, w, 0, 0, 3, 32, steel);
                FillRect(d, w, 29, 0, 3, 32, steel);
                for (int y = 0; y < 32; y++)
                {
                    Plot(d, w, 0, y, ink);
                    Plot(d, w, 31, y, ink);
                }
                FridgeStock(d, w, variant);
                for (int y = 4; y < 28; y++)
                {
                    for (int x = 3; x < 29; x++)
                    {
                        Color g = (x - y < -6) ? shine : glass;
                        Plot(d, w, x, y, MixAlpha(d[y * w + x], g));
                    }
                }
                FillRect(d, w, 26, 8, 2, 12, steelD);
                Plot(d, w, 27, 10, steelL);
                for (int x = 3; x < 29; x++)
                    Plot(d, w, x, 27, Mix(steel, Foam, 25));
            });
        }

        static void FridgeStock(Color[] d, int w, int variant)
        {
            if (variant == 0)
            {
                Color jug = new Color(244, 248, 252);
                Color cap = new Color(72, 128, 186);
                for (int i = 0; i < 3; i++)
                {
                    int x = 6 + i * 7;
                    FillRect(d, w, x, 8, 5, 10, jug);
                    FillRect(d, w, x + 1, 6, 3, 3, cap);
                    Plot(d, w, x + 2, 12, new Color(186, 210, 230));
                }
                FillRect(d, w, 7, 20, 16, 5, new Color(244, 220, 96));
            }
            else if (variant == 1)
            {
                Color leaf = new Color(86, 168, 78);
                Color leafD = new Color(48, 110, 54);
                Color carrot = new Color(220, 118, 48);
                for (int i = 0; i < 4; i++)
                {
                    int x = 6 + i * 5;
                    FillRect(d, w, x, 7, 4, 8, leaf);
                    Plot(d, w, x + 1, 8, leafD);
                    Plot(d, w, x + 2, 10, Foam);
                }
                for (int i = 0; i < 3; i++)
                    FillRect(d, w, 7 + i * 6, 18, 4, 7, carrot);
            }
            else if (variant == 2)
            {
                Color[] bottles =
                {
                    new Color(196, 118, 54),
                    new Color(72, 128, 72),
                    new Color(176, 86, 64),
                    new Color(148, 148, 156)
                };
                for (int i = 0; i < 4; i++)
                {
                    int x = 6 + i * 6;
                    FillRect(d, w, x + 1, 6, 3, 3, new Color(210, 220, 230));
                    FillRect(d, w, x, 9, 5, 14, bottles[i]);
                    Plot(d, w, x + 2, 12, Foam);
                }
            }
            else
            {
                Color tray = new Color(232, 236, 240);
                Color fish = new Color(186, 96, 86);
                Color wrap = new Color(244, 248, 236);
                FillRect(d, w, 6, 8, 20, 8, tray);
                FillRect(d, w, 8, 10, 7, 5, fish);
                FillRect(d, w, 16, 10, 8, 5, wrap);
                FillRect(d, w, 6, 18, 9, 7, tray);
                FillRect(d, w, 17, 18, 9, 7, tray);
                Plot(d, w, 10, 20, fish);
                Plot(d, w, 21, 21, new Color(168, 72, 64));
            }
        }

        static Color MixAlpha(Color under, Color over)
        {
            int a = over.A;
            int ia = 255 - a;
            int r = (under.R * ia + over.R * a) / 255;
            int g = (under.G * ia + over.G * a) / 255;
            int b = (under.B * ia + over.B * a) / 255;
            int outA = under.A + a * (255 - under.A) / 255;
            return new Color(r, g, b, outA);
        }

        public static Texture2D Shelf(GraphicsDevice gd, int variant)
        {
            Color wood = new Color(128, 82, 48);
            Color woodD = new Color(86, 54, 32);
            Color woodL = new Color(176, 122, 74);
            Color ink = new Color(48, 32, 24);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 1, 0, 30, 32, woodD);
                FillRect(d, w, 2, 1, 28, 30, wood);
                for (int y = 0; y < 32; y++)
                {
                    Plot(d, w, 0, y, ink);
                    Plot(d, w, 31, y, ink);
                }
                int[] shelves = { 3, 13, 23 };
                for (int s = 0; s < shelves.Length; s++)
                {
                    int y = shelves[s];
                    FillRect(d, w, 2, y + 8, 28, 2, woodD);
                    FillRect(d, w, 2, y + 7, 28, 1, woodL);
                    ShelfRow(d, w, y, variant, s);
                }
            });
        }

        static void ShelfRow(Color[] d, int w, int y, int variant, int row)
        {
            int kind = (variant + row) & 3;
            if (kind == 0)
            {
                Color[] bags = { new Color(86, 168, 78), new Color(196, 148, 64), new Color(176, 86, 64), new Color(92, 128, 196) };
                for (int i = 0; i < 4; i++)
                {
                    int x = 3 + i * 7;
                    FillRect(d, w, x, y, 6, 7, bags[i]);
                    Plot(d, w, x + 2, y + 2, new Color(244, 228, 166));
                }
            }
            else if (kind == 1)
            {
                Color can = new Color(176, 92, 64);
                Color lid = new Color(210, 210, 216);
                for (int i = 0; i < 5; i++)
                {
                    int x = 4 + i * 5;
                    FillRect(d, w, x, y + 1, 4, 6, can);
                    FillRect(d, w, x, y, 4, 2, lid);
                }
            }
            else if (kind == 2)
            {
                Color box = new Color(214, 176, 108);
                Color boxD = new Color(168, 118, 62);
                for (int i = 0; i < 3; i++)
                {
                    int x = 4 + i * 8;
                    FillRect(d, w, x, y, 7, 7, box);
                    FillRect(d, w, x, y + 5, 7, 2, boxD);
                    Plot(d, w, x + 3, y + 2, new Color(148, 64, 48));
                }
            }
            else
            {
                Color jar = new Color(186, 216, 196);
                Color cap = new Color(148, 86, 48);
                for (int i = 0; i < 4; i++)
                {
                    int x = 4 + i * 6;
                    FillRect(d, w, x + 1, y, 4, 2, cap);
                    FillRect(d, w, x, y + 2, 6, 5, jar);
                    Plot(d, w, x + 2, y + 4, new Color(176, 64, 54));
                }
            }
        }

        public static Texture2D Stove(GraphicsDevice gd)
        {
            Color iron = new Color(62, 58, 64);
            Color ironL = new Color(96, 92, 98);
            Color ironD = new Color(36, 34, 40);
            Color grate = new Color(28, 26, 30);
            Color ember = new Color(220, 92, 48);
            Color pot = new Color(72, 78, 88);
            Color potL = new Color(120, 128, 138);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 0, 8, 32, 24, iron);
                FillRect(d, w, 1, 9, 30, 10, ironD);
                FillRect(d, w, 2, 10, 12, 8, grate);
                FillRect(d, w, 18, 10, 12, 8, grate);
                Plot(d, w, 7, 13, ember);
                Plot(d, w, 8, 14, Mix(ember, ironL, 40));
                Plot(d, w, 24, 13, ember);
                FillRect(d, w, 3, 20, 26, 10, ironL);
                FillRect(d, w, 5, 22, 8, 6, ironD);
                FillRect(d, w, 19, 22, 8, 6, ironD);
                FillRect(d, w, 20, 2, 9, 8, pot);
                FillRect(d, w, 21, 3, 7, 5, potL);
                Plot(d, w, 19, 5, pot);
                Plot(d, w, 29, 5, pot);
                Plot(d, w, 23, 1, new Color(186, 190, 196));
                Plot(d, w, 24, 0, new Color(210, 214, 218));
            });
        }

        public static Texture2D Sink(GraphicsDevice gd)
        {
            Color top = new Color(214, 176, 124);
            Color basin = new Color(176, 196, 206);
            Color basinD = new Color(118, 140, 152);
            Color chrome = new Color(198, 206, 214);
            Color chromeD = new Color(120, 128, 138);
            Color face = new Color(148, 96, 58);
            Color water = new Color(148, 196, 214);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 0, 0, 32, 12, top);
                FillRect(d, w, 4, 3, 24, 8, basinD);
                FillRect(d, w, 5, 4, 22, 6, basin);
                FillRect(d, w, 8, 6, 16, 3, water);
                FillRect(d, w, 14, 0, 4, 5, chromeD);
                FillRect(d, w, 12, 1, 8, 2, chrome);
                Plot(d, w, 15, 5, water);
                Plot(d, w, 16, 6, water);
                FillRect(d, w, 0, 12, 32, 20, face);
                FillRect(d, w, 6, 16, 20, 12, Mix(face, top, 18));
                Plot(d, w, 16, 22, new Color(232, 197, 71));
            });
        }

        public static Texture2D Table(GraphicsDevice gd)
        {
            Color top = new Color(196, 148, 92);
            Color topL = new Color(222, 180, 124);
            Color topD = new Color(138, 96, 58);
            Color cloth = new Color(232, 236, 240);
            Color loaf = new Color(198, 142, 78);
            Color plate = new Color(236, 232, 224);
            Color stew = new Color(176, 92, 48);
            return BuildHi(gd, 64, 32, (d, w, h) =>
            {
                FillRect(d, w, 4, 8, 56, 16, top);
                for (int x = 4; x < 60; x++)
                {
                    Plot(d, w, x, 8, topL);
                    Plot(d, w, x, 23, topD);
                }
                FillRect(d, w, 8, 24, 3, 7, topD);
                FillRect(d, w, 53, 24, 3, 7, topD);
                FillRect(d, w, 18, 10, 28, 10, cloth);
                FillRect(d, w, 22, 11, 8, 4, loaf);
                FillRect(d, w, 36, 12, 6, 5, plate);
                FillRect(d, w, 37, 13, 4, 3, stew);
            });
        }

        public static Texture2D IndoorPlant(GraphicsDevice gd)
        {
            Color pot = new Color(176, 86, 64);
            Color potD = new Color(128, 58, 42);
            Color leaf = new Color(72, 148, 78);
            Color leafL = new Color(118, 186, 96);
            return BuildHi(gd, 32, 32, (d, w, h) =>
            {
                FillRect(d, w, 10, 20, 12, 10, pot);
                FillRect(d, w, 11, 21, 10, 3, potD);
                FillRect(d, w, 12, 18, 8, 3, new Color(96, 68, 42));
                FillRect(d, w, 8, 8, 16, 12, leaf);
                FillRect(d, w, 10, 6, 12, 8, leafL);
                Plot(d, w, 12, 5, leaf);
                Plot(d, w, 19, 5, leafL);
                Plot(d, w, 16, 4, leaf);
            });
        }

        public static Texture2D Bed(GraphicsDevice gd)
        {
            Color frame = new Color(128, 82, 48);
            Color frameL = new Color(176, 124, 78);
            Color frameD = new Color(86, 54, 32);
            Color pillow = new Color(246, 240, 228);
            Color pillowD = new Color(214, 204, 188);
            Color quilt = new Color(86, 132, 186);
            Color quiltL = new Color(128, 168, 210);
            Color quiltD = new Color(58, 96, 148);
            Color sheet = new Color(236, 232, 224);
            return BuildHi(gd, 64, 64, (d, w, h) =>
            {
                FillRect(d, w, 2, 0, 60, 10, frame);
                FillRect(d, w, 4, 2, 56, 6, frameL);
                for (int x = 6; x < 58; x += 8)
                    FillRect(d, w, x, 3, 3, 4, frameD);
                FillRect(d, w, 0, 8, 64, 52, frameD);
                FillRect(d, w, 3, 10, 58, 46, frame);
                FillRect(d, w, 5, 12, 54, 14, sheet);
                FillRect(d, w, 8, 13, 20, 10, pillow);
                FillRect(d, w, 36, 13, 20, 10, pillow);
                FillRect(d, w, 10, 15, 16, 6, pillowD);
                FillRect(d, w, 38, 15, 16, 6, pillowD);
                FillRect(d, w, 6, 26, 52, 28, quilt);
                for (int y = 28; y < 52; y += 6)
                    for (int x = 8; x < 56; x++)
                        Plot(d, w, x, y, (x / 7 + y / 6) % 2 == 0 ? quiltL : quilt);
                FillRect(d, w, 6, 26, 52, 3, sheet);
                FillRect(d, w, 5, 54, 54, 4, frameL);
                FillRect(d, w, 4, 58, 56, 4, frameD);
                FillRect(d, w, 2, 12, 3, 44, frame);
                FillRect(d, w, 59, 12, 3, 44, frame);
                Plot(d, w, 14, 16, quiltL);
                Plot(d, w, 42, 16, quiltL);
                FillRect(d, w, 6, 50, 52, 3, quiltD);
            });
        }

        public static Texture2D SeedPouch(GraphicsDevice gd, Color crop)
        {
            Color bag = new Color(150, 110, 64);
            Color bagD = new Color(98, 68, 36);
            Color stitch = new Color(214, 186, 130);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 3; y < 15; y++)
                {
                    int inset = y < 6 ? 6 - y : 2;
                    for (int x = inset; x < 16 - inset; x++)
                    {
                        Color c = bag;
                        if ((x + y) % 5 == 0) c = bagD;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 4; x < 12; x++)
                {
                    Plot(d, w, x, 3, stitch);
                    Plot(d, w, x, 4, crop);
                    Plot(d, w, x, 5, crop);
                }
                Plot(d, w, 7, 2, bagD);
                Plot(d, w, 8, 1, bagD);
                Plot(d, w, 8, 2, stitch);
                Plot(d, w, 6, 9, crop);
                Plot(d, w, 7, 9, crop);
                Plot(d, w, 8, 9, crop);
                Plot(d, w, 9, 9, crop);
            });
        }

        public static Texture2D FishIcon(GraphicsDevice gd, Color body, Color fin)
        {
            Color hi = Mix(body, new Color(244, 236, 214), 35);
            Color lo = Mix(body, Ink, 35);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 5; y <= 10; y++)
                {
                    for (int x = 3; x <= 11; x++)
                    {
                        int dx = x - 7;
                        int dy = y - 8;
                        if (dx * dx + dy * dy * 3 > 22)
                            continue;
                        Color c = body;
                        if (dx + dy < -1) c = hi;
                        if (dx + dy > 2) c = lo;
                        Plot(d, w, x, y, c);
                    }
                }
                Plot(d, w, 12, 7, fin);
                Plot(d, w, 12, 8, fin);
                Plot(d, w, 13, 6, fin);
                Plot(d, w, 13, 9, fin);
                Plot(d, w, 11, 7, Ink);
                Plot(d, w, 4, 7, hi);
                Plot(d, w, 5, 8, Ink);
            });
        }

        public static Texture2D FoodIcon(GraphicsDevice gd, string id)
        {
            if (id == "food.stew")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    for (int y = 7; y <= 13; y++)
                        for (int x = 3; x <= 12; x++)
                            Plot(d, w, x, y, (x == 3 || x == 12 || y == 7 || y == 13) ? Ink : new Color(148, 86, 48));
                    for (int x = 5; x <= 10; x++)
                    {
                        Plot(d, w, x, 8, new Color(176, 118, 62));
                        Plot(d, w, x, 9, new Color(196, 92, 48));
                    }
                    Plot(d, w, 7, 10, new Color(86, 128, 62));
                    Plot(d, w, 8, 10, new Color(232, 196, 92));
                });
            }
            if (id == "food.pie")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    for (int y = 6; y <= 12; y++)
                        for (int x = 2; x <= 13; x++)
                        {
                            int dx = x - 8;
                            int dy = y - 9;
                            if (dx * dx + dy * dy * 2 > 28)
                                continue;
                            Color c = new Color(196, 132, 56);
                            if (y <= 8) c = new Color(214, 168, 86);
                            if (x == 2 || x == 13 || y == 6) c = Ink;
                            Plot(d, w, x, y, c);
                        }
                    Plot(d, w, 8, 8, new Color(176, 64, 54));
                    Plot(d, w, 7, 9, new Color(176, 64, 54));
                    Plot(d, w, 9, 9, new Color(176, 64, 54));
                });
            }
            if (id == "food.cider")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    Color mug = new Color(196, 118, 54);
                    Color amber = new Color(214, 148, 48);
                    Color foam = new Color(244, 228, 176);
                    for (int y = 5; y <= 13; y++)
                        for (int x = 4; x <= 11; x++)
                            Plot(d, w, x, y, (x == 4 || x == 11 || y == 13) ? Ink : mug);
                    for (int y = 6; y <= 10; y++)
                        for (int x = 5; x <= 10; x++)
                            Plot(d, w, x, y, amber);
                    for (int x = 5; x <= 10; x++)
                        Plot(d, w, x, 6, foam);
                    Plot(d, w, 12, 8, mug);
                    Plot(d, w, 13, 8, mug);
                    Plot(d, w, 13, 9, mug);
                    Plot(d, w, 12, 10, mug);
                });
            }
            if (id == "food.tea")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    Color cup = new Color(232, 220, 196);
                    Color tea = new Color(118, 72, 36);
                    for (int y = 7; y <= 12; y++)
                        for (int x = 4; x <= 11; x++)
                            Plot(d, w, x, y, (x == 4 || x == 11 || y == 12) ? Ink : cup);
                    for (int y = 8; y <= 10; y++)
                        for (int x = 5; x <= 10; x++)
                            Plot(d, w, x, y, tea);
                    Plot(d, w, 12, 8, cup);
                    Plot(d, w, 13, 9, cup);
                    Plot(d, w, 12, 10, cup);
                    Plot(d, w, 7, 5, new Color(186, 186, 186));
                    Plot(d, w, 7, 6, new Color(210, 210, 214));
                });
            }
            if (id == "food.ale")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    Color pewter = new Color(148, 148, 156);
                    Color beer = new Color(196, 132, 42);
                    Color foam = new Color(244, 232, 196);
                    for (int y = 4; y <= 13; y++)
                        for (int x = 4; x <= 11; x++)
                            Plot(d, w, x, y, (x == 4 || x == 11 || y == 13) ? Ink : pewter);
                    for (int y = 6; y <= 11; y++)
                        for (int x = 5; x <= 10; x++)
                            Plot(d, w, x, y, beer);
                    for (int x = 5; x <= 10; x++)
                    {
                        Plot(d, w, x, 5, foam);
                        Plot(d, w, x, 6, foam);
                    }
                    Plot(d, w, 12, 7, pewter);
                    Plot(d, w, 13, 8, pewter);
                    Plot(d, w, 13, 9, pewter);
                    Plot(d, w, 12, 10, pewter);
                });
            }
            if (id == "food.cocoa")
            {
                return Build(gd, 16, 16, (d, w, h) =>
                {
                    Color mug = new Color(176, 86, 64);
                    Color cocoa = new Color(92, 52, 32);
                    Color cream = new Color(244, 228, 196);
                    for (int y = 6; y <= 13; y++)
                        for (int x = 4; x <= 11; x++)
                            Plot(d, w, x, y, (x == 4 || x == 11 || y == 13) ? Ink : mug);
                    for (int y = 7; y <= 10; y++)
                        for (int x = 5; x <= 10; x++)
                            Plot(d, w, x, y, cocoa);
                    Plot(d, w, 7, 7, cream);
                    Plot(d, w, 8, 7, cream);
                    Plot(d, w, 12, 8, mug);
                    Plot(d, w, 13, 9, mug);
                    Plot(d, w, 12, 10, mug);
                });
            }
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 6; y <= 11; y++)
                    for (int x = 3; x <= 12; x++)
                    {
                        Color c = new Color(214, 176, 108);
                        if (y == 6 || y == 11 || x == 3 || x == 12) c = new Color(148, 102, 56);
                        if ((x + y) % 4 == 0) c = new Color(232, 196, 132);
                        Plot(d, w, x, y, c);
                    }
                Plot(d, w, 5, 8, new Color(176, 128, 72));
            });
        }

        public static Texture2D WoodLog(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 5; y < 12; y++)
                {
                    for (int x = 1; x < 15; x++)
                    {
                        Color c = WoodA;
                        if (y == 5 || y == 11) c = WoodD;
                        if (x == 1 || x == 14) c = WoodB;
                        if ((x + y) % 4 == 0) c = WoodC;
                        Plot(d, w, x, y, c);
                    }
                }
                for (int x = 1; x < 15; x++)
                {
                    Plot(d, w, x, 5, Ink);
                    Plot(d, w, x, 11, Ink);
                }
                Plot(d, w, 1, 6, Ink);
                Plot(d, w, 1, 10, Ink);
                Plot(d, w, 14, 6, Ink);
                Plot(d, w, 14, 10, Ink);
                Plot(d, w, 3, 7, new Color(214, 176, 118));
                Plot(d, w, 4, 8, new Color(214, 176, 118));
                Plot(d, w, 12, 8, WoodD);
            });
        }

        public static Texture2D StonePile(GraphicsDevice gd)
        {
            Color a = new Color(168, 166, 160);
            Color b = new Color(124, 122, 118);
            Color hi = new Color(210, 208, 200);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                StoneBlob(d, w, 2, 7, 7, 5, a, hi, b);
                StoneBlob(d, w, 7, 6, 7, 6, b, hi, new Color(88, 86, 82));
                StoneBlob(d, w, 5, 9, 6, 4, a, hi, b);
                Plot(d, w, 4, 8, hi);
                Plot(d, w, 11, 10, new Color(88, 86, 82));
            });
        }

        public static Texture2D Scarecrow(GraphicsDevice gd)
        {
            Color pole = new Color(148, 108, 62);
            Color poleLo = new Color(96, 68, 38);
            Color sack = new Color(214, 186, 124);
            Color sackLo = new Color(168, 132, 78);
            Color rag = new Color(176, 72, 64);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int y = 2; y <= 14; y++)
                {
                    Plot(d, w, 7, y, pole);
                    Plot(d, w, 8, y, poleLo);
                }
                for (int x = 3; x <= 12; x++)
                {
                    Plot(d, w, x, 6, pole);
                    Plot(d, w, x, 7, poleLo);
                }
                StoneBlob(d, w, 5, 2, 6, 5, sack, new Color(236, 214, 160), sackLo);
                Plot(d, w, 6, 4, Ink);
                Plot(d, w, 9, 4, Ink);
                Plot(d, w, 7, 6, rag);
                Plot(d, w, 8, 6, rag);
                Plot(d, w, 3, 6, rag);
                Plot(d, w, 12, 6, rag);
            });
        }

        public static Texture2D FiberBundle(GraphicsDevice gd)
        {
            Color a = new Color(186, 168, 88);
            Color b = new Color(142, 124, 58);
            Color c = new Color(98, 86, 40);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                for (int i = 0; i < 11; i++)
                {
                    Plot(d, w, 3 + i / 2, 3 + i, a);
                    Plot(d, w, 4 + i / 2, 3 + i, b);
                    Plot(d, w, 8 - i / 3, 4 + i, a);
                    Plot(d, w, 10, 4 + i, c);
                }
                for (int x = 3; x < 13; x++)
                {
                    Plot(d, w, x, 9, WoodB);
                    Plot(d, w, x, 10, WoodA);
                }
            });
        }

        public static Texture2D Shadow(GraphicsDevice gd)
        {
            return Build(gd, 22, 8, (d, w, h) =>
            {
                Color s = new Color(36, 42, 38, 78);
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        int cx = x - 12;
                        int cy = y - 3;
                        if (cx * cx + cy * cy * 6 < 70)
                            Plot(d, w, x, y, s);
                    }
            });
        }

        public static Texture2D Barrel(GraphicsDevice gd)
        {
            return Build(gd, 16, 18, (d, w, h) =>
            {
                for (int y = 4; y < 16; y++)
                    for (int x = 4; x < 12; x++)
                    {
                        Color c = WoodA;
                        if (x == 4) c = WoodC;
                        if (x == 11) c = WoodD;
                        if (y == 7 || y == 12) c = new Color(92, 92, 98);
                        Plot(d, w, x, y, c);
                    }
                for (int x = 4; x < 12; x++)
                {
                    Plot(d, w, x, 4, Ink);
                    Plot(d, w, x, 15, Ink);
                }
            });
        }

        public static Texture2D Crate(GraphicsDevice gd)
        {
            return Build(gd, 16, 16, (d, w, h) =>
            {
                FillRect(d, w, 3, 6, 10, 8, WoodA);
                for (int x = 3; x < 13; x++)
                {
                    Plot(d, w, x, 6, WoodC);
                    Plot(d, w, x, 13, Ink);
                }
                Plot(d, w, 3, 7, Ink);
                Plot(d, w, 12, 7, Ink);
                Plot(d, w, 7, 8, WoodD);
                Plot(d, w, 8, 8, WoodD);
            });
        }

        public static Texture2D FishCrate(GraphicsDevice gd)
        {
            Color fish = new Color(132, 164, 176);
            Color fishD = new Color(72, 108, 124);
            Color fishL = new Color(186, 210, 214);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                FillRect(d, w, 3, 6, 10, 8, WoodA);
                for (int x = 3; x < 13; x++)
                {
                    Plot(d, w, x, 6, WoodC);
                    Plot(d, w, x, 13, Ink);
                }
                Plot(d, w, 3, 7, Ink);
                Plot(d, w, 12, 7, Ink);
                FillRect(d, w, 4, 4, 8, 5, fish);
                Plot(d, w, 5, 5, fishL);
                Plot(d, w, 8, 4, fishD);
                Plot(d, w, 10, 6, fishL);
                Plot(d, w, 6, 6, fishD);
            });
        }

        public static Texture2D FishRack(GraphicsDevice gd)
        {
            Color pole = new Color(118, 82, 48);
            Color poleD = new Color(78, 50, 28);
            Color fish = new Color(72, 148, 132);
            Color fishB = new Color(86, 168, 196);
            return Build(gd, 18, 20, (d, w, h) =>
            {
                for (int y = 2; y < 18; y++)
                {
                    Plot(d, w, 3, y, pole);
                    Plot(d, w, 14, y, poleD);
                }
                for (int x = 3; x <= 14; x++)
                    Plot(d, w, x, 4, pole);
                for (int i = 0; i < 4; i++)
                {
                    int x = 5 + i * 3;
                    Color f = (i & 1) == 0 ? fish : fishB;
                    Plot(d, w, x, 5, Ink);
                    for (int y = 6; y <= 11; y++)
                    {
                        Plot(d, w, x, y, f);
                        Plot(d, w, x + 1, y, Mix(f, Ink, 25));
                    }
                    Plot(d, w, x, 12, Mix(f, Color.White, 20));
                }
            });
        }

        public static Texture2D DockShark(GraphicsDevice gd)
        {
            Color body = new Color(36, 64, 110);
            Color bodyL = new Color(72, 108, 156);
            Color bodyD = new Color(18, 32, 62);
            Color rope = new Color(186, 156, 96);
            return Build(gd, 28, 16, (d, w, h) =>
            {
                FillOval(d, w, 3, 6, 22, 14, body);
                FillOval(d, w, 5, 7, 18, 12, bodyL);
                Plot(d, w, 22, 8, body);
                Plot(d, w, 23, 9, bodyD);
                Plot(d, w, 24, 9, body);
                Plot(d, w, 25, 10, bodyD);
                Plot(d, w, 21, 6, bodyD);
                Plot(d, w, 12, 4, bodyD);
                Plot(d, w, 12, 5, body);
                Plot(d, w, 13, 3, body);
                Plot(d, w, 13, 4, bodyL);
                Plot(d, w, 14, 5, bodyD);
                Plot(d, w, 6, 9, Ink);
                for (int x = 6; x <= 18; x++)
                    Plot(d, w, x, 10, rope);
                Plot(d, w, 8, 9, rope);
                Plot(d, w, 14, 11, rope);
                Plot(d, w, 18, 9, rope);
            });
        }

        public static Texture2D DockSack(GraphicsDevice gd)
        {
            Color a = new Color(168, 164, 148);
            Color b = new Color(132, 128, 112);
            Color c = new Color(92, 88, 74);
            return Build(gd, 16, 16, (d, w, h) =>
            {
                FillOval(d, w, 4, 5, 12, 14, b);
                FillOval(d, w, 5, 6, 11, 12, a);
                FillRect(d, w, 6, 4, 5, 3, c);
                Plot(d, w, 7, 3, a);
                Plot(d, w, 9, 3, a);
                Plot(d, w, 8, 8, Mix(a, Color.White, 20));
            });
        }

        public static Texture2D Rowboat(GraphicsDevice gd)
        {
            Color hull = new Color(128, 86, 52);
            Color hullD = new Color(82, 52, 30);
            Color hullL = new Color(176, 128, 78);
            Color seat = new Color(196, 154, 96);
            return Build(gd, 14, 22, (d, w, h) =>
            {
                for (int y = 2; y < 20; y++)
                {
                    int inset = y < 5 || y > 16 ? 2 : 1;
                    for (int x = inset; x < 14 - inset; x++)
                    {
                        Color c = hull;
                        if (x == inset) c = hullL;
                        if (x == 13 - inset) c = hullD;
                        Plot(d, w, x, y, c);
                    }
                }
                FillRect(d, w, 3, 7, 8, 2, seat);
                FillRect(d, w, 3, 13, 8, 2, seat);
            });
        }

        public static Texture2D Sailboat(GraphicsDevice gd, bool blueHull)
        {
            Color hull = blueHull ? new Color(48, 92, 168) : new Color(128, 82, 48);
            Color hullD = blueHull ? new Color(28, 52, 110) : new Color(82, 48, 28);
            Color hullL = blueHull ? new Color(92, 148, 214) : new Color(176, 124, 74);
            Color sail = new Color(236, 232, 220);
            Color sailD = new Color(196, 190, 176);
            Color mast = new Color(96, 68, 40);
            Color sack = new Color(168, 164, 148);
            Color crate = new Color(176, 124, 72);
            Color fish = new Color(132, 164, 176);
            return Build(gd, 24, 30, (d, w, h) =>
            {
                FillOval(d, w, 2, 18, 21, 28, hull);
                FillRect(d, w, 3, 20, 18, 6, hullL);
                for (int x = 3; x < 21; x++)
                    Plot(d, w, x, 26, hullD);
                for (int y = 4; y < 22; y++)
                    Plot(d, w, 11, y, mast);
                if (blueHull)
                {
                    FillOval(d, w, 12, 8, 20, 16, sail);
                    FillOval(d, w, 13, 9, 19, 15, sailD);
                    FillRect(d, w, 4, 21, 4, 3, sack);
                    FillRect(d, w, 16, 21, 5, 4, crate);
                    Plot(d, w, 17, 20, fish);
                    Plot(d, w, 18, 20, fish);
                    Plot(d, w, 19, 21, Mix(fish, Color.White, 30));
                }
                else
                {
                    for (int y = 5; y < 18; y++)
                    {
                        int span = 1 + (y - 5) / 2;
                        if (span > 8) span = 8;
                        for (int s = 0; s < span; s++)
                        {
                            Color c = (s + y) % 3 == 0 ? sailD : sail;
                            Plot(d, w, 12 + s, y, c);
                        }
                    }
                }
                Plot(d, w, 5, 21, new Color(168, 132, 78));
                Plot(d, w, 16, 22, WoodA);
            });
        }

        public static Texture2D DockPiling(GraphicsDevice gd)
        {
            Color a = new Color(72, 48, 28);
            Color b = new Color(48, 30, 18);
            Color c = new Color(108, 78, 48);
            return Build(gd, 7, 16, (d, w, h) =>
            {
                for (int y = 0; y < h; y++)
                {
                    Plot(d, w, 1, y, c);
                    Plot(d, w, 2, y, a);
                    Plot(d, w, 3, y, a);
                    Plot(d, w, 4, y, a);
                    Plot(d, w, 5, y, b);
                    if (y % 5 == 0)
                    {
                        Plot(d, w, 1, y, b);
                        Plot(d, w, 5, y, a);
                    }
                }
            });
        }

        public static Texture2D Chest(GraphicsDevice gd, bool open)
        {
            Color body = new Color(168, 108, 54);
            Color bodyL = new Color(206, 150, 82);
            Color bodyD = new Color(112, 68, 36);
            Color band = new Color(214, 176, 72);
            Color bandD = new Color(148, 108, 40);
            Color coin = new Color(236, 196, 72);
            Color coinL = new Color(252, 228, 140);
            Color coinD = new Color(176, 124, 36);
            return Build(gd, 16, 18, (d, w, h) =>
            {
                FillRect(d, w, 1, 9, 14, 8, bodyD);
                FillRect(d, w, 2, 10, 12, 6, body);
                FillRect(d, w, 2, 10, 12, 2, bodyL);
                FillRect(d, w, 1, 12, 14, 2, band);
                Plot(d, w, 7, 12, bandD);
                Plot(d, w, 8, 12, Mix(band, Color.White, 30));
                Plot(d, w, 8, 13, bandD);
                Plot(d, w, 1, 9, Ink);
                Plot(d, w, 14, 9, Ink);
                if (open)
                {
                    FillRect(d, w, 2, 4, 12, 5, bodyL);
                    FillRect(d, w, 3, 5, 10, 3, Mix(body, Color.White, 24));
                    Plot(d, w, 2, 4, Ink);
                    Plot(d, w, 13, 4, Ink);
                    Coin(d, w, 5, 11, coin, coinL, coinD);
                    Coin(d, w, 8, 10, coin, coinL, coinD);
                    Coin(d, w, 11, 11, coin, coinL, coinD);
                    Coin(d, w, 7, 13, coin, coinL, coinD);
                    Coin(d, w, 10, 13, coin, coinL, coinD);
                    Coin(d, w, 4, 14, coin, coinL, coinD);
                }
                else
                {
                    FillRect(d, w, 2, 6, 12, 4, body);
                    FillRect(d, w, 2, 6, 12, 1, bodyL);
                    Plot(d, w, 7, 7, band);
                    Plot(d, w, 8, 7, coinL);
                    Coin(d, w, 4, 14, coin, coinL, coinD);
                    Coin(d, w, 12, 14, coin, coinL, coinD);
                    Coin(d, w, 8, 15, coin, coinL, coinD);
                }
            });
        }

        static void Coin(Color[] d, int w, int x, int y, Color coin, Color coinL, Color coinD)
        {
            Plot(d, w, x, y, coin);
            Plot(d, w, x + 1, y, coinL);
            Plot(d, w, x, y + 1, coinD);
            Plot(d, w, x + 1, y + 1, coin);
        }

        public static Texture2D Picnic(GraphicsDevice gd)
        {
            Color clothA = new Color(236, 214, 168);
            Color clothB = new Color(186, 72, 78);
            Color basket = new Color(186, 132, 72);
            Color loaf = new Color(214, 168, 96);
            return Build(gd, 24, 16, (d, w, h) =>
            {
                for (int y = 6; y < 12; y++)
                {
                    for (int x = 2; x < 22; x++)
                    {
                        Color c = ((x / 2 + y / 2) & 1) == 0 ? clothA : clothB;
                        Plot(d, w, x, y, c);
                    }
                }
                FillRect(d, w, 8, 3, 6, 4, basket);
                Plot(d, w, 9, 2, basket);
                Plot(d, w, 12, 2, basket);
                Plot(d, w, 10, 4, loaf);
                Plot(d, w, 11, 4, loaf);
                Plot(d, w, 16, 5, new Color(72, 128, 62));
                Plot(d, w, 17, 5, new Color(236, 140, 158));
            });
        }

        public static Texture2D Bush(GraphicsDevice gd)
        {
            return Build(gd, 16, 14, (d, w, h) =>
            {
                for (int y = 4; y < 13; y++)
                    for (int x = 2; x < 14; x++)
                    {
                        int dx = x - 8;
                        int dy = y - 9;
                        if (dx * dx + dy * dy * 2 > 28)
                            continue;
                        Color c = G1;
                        if (dx + dy < -1) c = G3;
                        if (dx + dy > 3) c = G0;
                        Plot(d, w, x, y, c);
                    }
                Plot(d, w, 5, 6, new Color(236, 150, 168));
                Plot(d, w, 8, 5, new Color(252, 240, 214));
                Plot(d, w, 11, 7, new Color(232, 118, 128));
                Plot(d, w, 7, 8, new Color(244, 186, 96));
            });
        }

        static Texture2D BuildHi(GraphicsDevice gd, int w, int h, Action<Color[], int, int> paint)
        {
            Color[] data = new Color[w * h];
            paint(data, w, h);
            Texture2D tex = new Texture2D(gd, w, h);
            tex.SetData(data);
            return tex;
        }

        static Texture2D Build(GraphicsDevice gd, int w, int h, Action<Color[], int, int> paint)
        {
            Color[] data = new Color[w * h];
            paint(data, w, h);
            return Scale2(gd, data, w, h);
        }

        public static Texture2D Scale2(GraphicsDevice gd, Color[] src, int w, int h)
        {
            int nw = w * 2;
            int nh = h * 2;
            Color[] dst = new Color[nw * nh];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    Color e = At(src, w, h, x, y);
                    Color b = At(src, w, h, x, y - 1);
                    Color d = At(src, w, h, x - 1, y);
                    Color f = At(src, w, h, x + 1, y);
                    Color hh = At(src, w, h, x, y + 1);
                    Color e0 = e, e1 = e, e2 = e, e3 = e;
                    if (Same(d, b) && !Same(d, hh) && !Same(b, f)) e0 = d;
                    if (Same(b, f) && !Same(b, d) && !Same(f, hh)) e1 = f;
                    if (Same(d, hh) && !Same(d, b) && !Same(hh, f)) e2 = d;
                    if (Same(hh, f) && !Same(d, hh) && !Same(b, f)) e3 = f;
                    int i = (y * 2) * nw + x * 2;
                    dst[i] = e0;
                    dst[i + 1] = e1;
                    dst[i + nw] = e2;
                    dst[i + nw + 1] = e3;
                }
            }
            Texture2D tex = new Texture2D(gd, nw, nh);
            tex.SetData(dst);
            return tex;
        }

        static Color At(Color[] src, int w, int h, int x, int y)
        {
            if (x < 0) x = 0;
            if (y < 0) y = 0;
            if (x >= w) x = w - 1;
            if (y >= h) y = h - 1;
            return src[y * w + x];
        }

        static bool Same(Color a, Color b)
        {
            return a.PackedValue == b.PackedValue;
        }

        /// <summary>
        /// Soft terrain base: broad 4x4 patches of two mid tones with rare accents,
        /// so tiles read as one field instead of per-pixel noise.
        /// </summary>
        static void PaintClusterBase(Color[] d, int w, int h, int seed, Color a, Color b, Color c, Color e)
        {
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int patch = Hash(x / 4, y / 4, seed) % 10;
                    Color col = patch < 6 ? c : b;
                    if (patch == 9)
                        col = e;
                    Plot(d, w, x, y, col);
                }
            }
            for (int i = 0; i < 5; i++)
            {
                int px = Hash(i, 1, seed) % w;
                int py = Hash(i, 2, seed) % h;
                Blotch(d, w, h, px, py, 3, a);
            }
        }

        static void Blotch(Color[] d, int w, int h, int cx, int cy, int r, Color c)
        {
            for (int y = -r; y <= r; y++)
            {
                for (int x = -r; x <= r; x++)
                {
                    if (x * x + y * y > r * r)
                        continue;
                    int px = cx + x;
                    int py = cy + y;
                    if (px < 0 || py < 0 || px >= w || py >= h)
                        continue;
                    Plot(d, w, px, py, c);
                }
            }
        }

        static void GrassBlade(Color[] d, int w, int x, int y, Color tip, Color mid, Color root)
        {
            Plot(d, w, x, y, root);
            Plot(d, w, x, y - 1, mid);
            Plot(d, w, x, y - 2, tip);
            Plot(d, w, x + 1, y - 1, mid);
        }

        static void Flower(Color[] d, int w, int x, int y, Color petal, Color center)
        {
            Plot(d, w, x, y, center);
            Plot(d, w, x - 1, y, petal);
            Plot(d, w, x + 1, y, petal);
            Plot(d, w, x, y - 1, petal);
            Plot(d, w, x, y + 1, petal);
            Plot(d, w, x, y + 2, G0);
        }

        static void StoneBlob(Color[] d, int w, int x, int y, int bw, int bh, Color fill, Color hi, Color sh)
        {
            Color edge = Mix(fill, Ink, 50);
            for (int yy = 0; yy < bh; yy++)
            {
                for (int xx = 0; xx < bw; xx++)
                {
                    Color c = fill;
                    if (xx == 0 || yy == 0)
                        c = Mix(fill, hi, 55);
                    if (xx == bw - 1 || yy == bh - 1)
                        c = Mix(fill, sh, 55);
                    if (xx == 0 || yy == 0 || xx == bw - 1 || yy == bh - 1)
                        c = Mix(c, edge, 40);
                    Plot(d, w, x + xx, y + yy, c);
                }
            }
            if (bw > 2 && bh > 2)
                Plot(d, w, x + 1, y + 1, Mix(fill, hi, 60));
        }

        static readonly Color MtRim = new Color(214, 210, 202);
        static readonly Color MtRimHi = new Color(236, 232, 222);
        static readonly Color MtFace = new Color(126, 122, 116);
        static readonly Color MtFaceL = new Color(158, 154, 146);
        static readonly Color MtFaceD = new Color(90, 86, 82);
        static readonly Color MtInk = new Color(48, 44, 46);
        static readonly Color MtCrack = new Color(70, 64, 60);
        static readonly Color MtDirt = new Color(92, 74, 58);
        static readonly Color MtMoss = new Color(88, 126, 76);
        static readonly Color MtQuartz = new Color(232, 228, 220);

        static Color PlateauPixel(int x, int y, int variant)
        {
            int seed = 2201 + variant * 47;
            int patch = Hash(x / 5, y / 5, seed) % 8;
            Color c = patch < 5 ? MtFace : Mix(MtFace, MtFaceL, 35);
            if (patch == 6)
                c = Mix(MtFace, MtRim, 28);
            if (patch == 7)
                c = Mix(MtFace, MtFaceD, 40);
            int n = Hash(x, y, seed + 3) % 28;
            if (n == 0)
                c = Mix(c, MtMoss, 55);
            else if (n == 1)
                c = Mix(c, MtInk, 22);
            else if (n == 2 && patch == 6)
                c = Mix(c, MtQuartz, 40);
            return c;
        }

        static void PaintMountainFill(Color[] d, int w, int h, int variant)
        {
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                    Plot(d, w, x, y, PlateauPixel(x, y, variant));
            }
            int seed = 2201 + variant * 47;
            for (int i = 0; i < 7; i++)
            {
                int bx = Hash(i, 4, seed) % 26 + 2;
                int by = Hash(i, 8, seed + 9) % 24 + 3;
                int bw = 2 + (i % 3);
                int bh = 2 + ((i + 1) % 2);
                StoneBlob(d, w, bx, by, bw, bh, MtRim, MtQuartz, MtFaceD);
            }
            for (int i = 0; i < 4; i++)
            {
                int gx = Hash(i, 1, seed) % 28 + 2;
                int gy = Hash(i, 2, seed) % 24 + 6;
                GrassBlade(d, w, gx, gy, G2, MtMoss, G0);
            }
            for (int i = 0; i < 3; i++)
            {
                int mx = Hash(i, 5, seed) % 28 + 1;
                int my = Hash(i, 6, seed) % 26 + 2;
                Plot(d, w, mx, my, MtMoss);
                Plot(d, w, mx + 1, my, MtMoss);
                Plot(d, w, mx, my + 1, Mix(MtMoss, MtInk, 30));
            }
        }

        static Color CliffFaceAt(int along, int down, int variant, bool bottom)
        {
            int wave = (Hash(along / 5, variant, 70) % 3) - 1;
            if ((along / 3) % 2 == 0)
                wave += (Hash(along, variant, 14) % 2);
            int l1 = 5 + wave;
            int l2 = 12 + wave;
            int ledge = 0;
            if (down >= l1)
                ledge = 1;
            if (down >= l2)
                ledge = 2;
            Color c = ledge == 0 ? Mix(MtFaceL, MtFace, 25) : (ledge == 1 ? MtFace : Mix(MtFaceD, MtDirt, 18));
            int patch = Hash(along / 4, down / 3, variant + 2) % 5;
            if (patch == 0)
                c = Mix(c, MtFaceL, 22);
            else if (patch == 1)
                c = Mix(c, MtFaceD, 22);
            int ledgeTop = ledge == 0 ? 0 : (ledge == 1 ? l1 : l2);
            int chip = Hash(along, variant, 81) % 5 == 0 ? 1 : 0;
            if (down == ledgeTop + chip)
                c = Mix(c, MtRimHi, 50);
            else if (down == ledgeTop + 1 + chip)
                c = Mix(c, MtFaceL, 30);
            int next = ledge == 0 ? l1 : (ledge == 1 ? l2 : 40);
            if (down == next - 1)
                c = Mix(c, MtInk, 48);
            else if (down == next - 2)
                c = Mix(c, MtCrack, 28);
            int c1 = 7 + (variant * 5 + 3) % 9;
            int c2 = 20 + (variant * 3) % 7;
            bool crack = (along == c1 || along == c2) && down > 1 && down < 18;
            if (crack && Hash(down, along, variant) % 4 != 0)
                c = Mix(c, MtInk, 62);
            int spec = Hash(along, down, variant + 9) % 22;
            if (spec == 0)
                c = Mix(c, MtDirt, 40);
            else if (spec == 1)
                c = Mix(c, MtMoss, 35);
            if (bottom)
                c = Mix(c, MtInk, 50);
            return c;
        }

        static void PaintUnderLip(Color[] d, int w, int y, int x0, int x1, int variant)
        {
            for (int x = x0; x < x1; x++)
            {
                Plot(d, w, x, y, MtInk);
                if (Hash(x, variant, 12) % 3 != 0)
                    Plot(d, w, x, y + 1, Mix(MtCrack, MtDirt, 30));
            }
        }

        static void PaintGrassOverhang(Color[] d, int w, int lipY, int variant, int x0)
        {
            for (int i = 0; i < 6; i++)
            {
                int gx = x0 + 2 + Hash(i, variant, 21) % 26;
                GrassBlade(d, w, gx, lipY + 2, G3, G1, G0);
                if (Hash(i, variant, 33) % 2 == 0)
                    Plot(d, w, gx + 1, lipY + 1, MtMoss);
            }
        }

        static void PaintFaceDetails(Color[] d, int w, int faceY0, int faceY1, int variant, bool jaggedBottom)
        {
            for (int i = 0; i < 3; i++)
            {
                int px = 3 + Hash(i, variant, 8) % 22;
                int py = faceY0 + 3 + Hash(i, variant, 9) % Math.Max(1, faceY1 - faceY0 - 6);
                int bw = 3 + (i % 3);
                int bh = 2 + ((i + variant) % 2);
                StoneBlob(d, w, px, py, bw, bh, MtFaceL, MtQuartz, MtInk);
            }
            for (int i = 0; i < 4; i++)
            {
                int mx = 2 + Hash(i, variant, 55) % 26;
                int my = faceY0 + 4 + Hash(i, variant, 77) % Math.Max(1, faceY1 - faceY0 - 6);
                Plot(d, w, mx, my, MtMoss);
                Plot(d, w, mx + 1, my, MtMoss);
                Plot(d, w, mx, my + 1, Mix(MtMoss, MtInk, 35));
            }
            if (!jaggedBottom)
                return;
            for (int x = 0; x < w; x++)
            {
                int chunk = x / 4;
                int dip = Hash(chunk, variant, 4401) % 3 + (Hash(x, variant, 91) % 5 == 0 ? 2 : 0);
                for (int k = 0; k < dip; k++)
                    Plot(d, w, x, faceY1 - k, Color.Transparent);
                int edge = faceY1 - dip;
                if (edge >= faceY0)
                    Plot(d, w, x, edge, MtInk);
            }
        }

        static int SouthBottom(int x, int h, int variant)
        {
            const int rim = 6;
            int chunk = x / 5;
            int jag = Hash(chunk, variant, 4401) % 3;
            int bottom = h - 2 - jag;
            if (bottom < rim + 12)
                bottom = rim + 12;
            return bottom;
        }

        static void PaintSouthDrop(Color[] d, int w, int h, int variant)
        {
            const int rim = 6;
            for (int x = 0; x < w; x++)
            {
                int bottom = SouthBottom(x, h, variant);
                for (int y = 0; y <= bottom; y++)
                {
                    Color c;
                    if (y < 4)
                        c = PlateauPixel(x, y, variant);
                    else if (y == 4)
                        c = Mix(MtRim, MtFaceL, 40);
                    else if (y == 5)
                        c = MtInk;
                    else
                    {
                        c = CliffFaceAt(x, y - rim, variant, y == bottom);
                        if (y > bottom - 2)
                            c = Mix(c, MtInk, 40);
                    }
                    Plot(d, w, x, y, c);
                }
            }
            PaintGrassOverhang(d, w, 5, variant, 0);
            PaintFaceDetails(d, w, rim, h - 1, variant, false);
        }

        static void PaintNorthDrop(Color[] d, int w, int h, int variant)
        {
            const int rim = 6;
            int rim0 = h - rim;
            for (int x = 0; x < w; x++)
            {
                int jag = Hash(x / 4, variant, 3307) % 3;
                int notch = Hash(x, variant, 44) % 7 == 0 ? 2 : 0;
                int top = jag + notch;
                for (int y = top; y < h; y++)
                {
                    Color c;
                    if (y >= h - 4)
                        c = PlateauPixel(x, y - (h - 4), variant);
                    else if (y == rim0)
                        c = MtInk;
                    else if (y == rim0 - 1)
                        c = Mix(MtCrack, MtDirt, 30);
                    else
                    {
                        c = CliffFaceAt(x, rim0 - 1 - y, variant, y == top);
                        if (y < top + 2)
                            c = Mix(c, MtInk, 40);
                    }
                    Plot(d, w, x, y, c);
                }
            }
            for (int i = 0; i < 4; i++)
            {
                int gx = 2 + Hash(i, variant, 21) % 26;
                GrassBlade(d, w, gx, rim0 + 1, G2, MtMoss, G0);
            }
        }

        static void PaintSideDrop(Color[] d, int w, int h, int variant, bool east)
        {
            const int rim = 5;
            for (int y = 0; y < h; y++)
            {
                int jag = Hash(y / 4, variant, east ? 2203 : 2209) % 3;
                int notch = Hash(y, variant, 17) % 8 == 0 ? 2 : 0;
                int faceW = w - rim - jag - notch;
                if (faceW < 6)
                    faceW = 6;
                int x0 = east ? 0 : w - rim - faceW;
                int x1 = east ? rim + faceW : w;
                for (int x = x0; x < x1; x++)
                {
                    int along = east ? x : (w - 1 - x);
                    Color c;
                    if (along < 3)
                        c = PlateauPixel(y, along, variant);
                    else if (along == 3)
                        c = Mix(MtRim, MtFace, 40);
                    else if (along == 4)
                        c = MtInk;
                    else
                    {
                        c = CliffFaceAt(y, along - rim, variant, false);
                        int fromOuter = east ? (x1 - 1 - x) : (x - x0);
                        if (fromOuter == 0)
                            c = Mix(c, MtInk, 55);
                        else if (fromOuter == 1)
                            c = Mix(c, MtCrack, 30);
                    }
                    Plot(d, w, x, y, c);
                }
                if (Hash(y, variant, 29) % 6 == 0)
                {
                    int mx = east ? 2 : w - 3;
                    Plot(d, w, mx, y, MtMoss);
                }
            }
            for (int i = 0; i < 3; i++)
            {
                int py = 4 + Hash(i, variant, 9) % 22;
                int px = east ? rim + 2 + Hash(i, variant, 8) % 4 : w - rim - 6 + Hash(i, variant, 8) % 4;
                StoneBlob(d, w, px, py, 3, 2, MtFaceL, MtQuartz, MtInk);
            }
        }

        static void Plot(Color[] d, int w, int x, int y, Color c)
        {
            int hh = d.Length / w;
            if (x < 0 || y < 0 || x >= w || y >= hh)
                return;
            d[y * w + x] = c;
        }

        static int Hash(int x, int y, int seed)
        {
            int n = x * 374761393 + y * 668265263 + seed * 1274126177;
            n = (n ^ (n >> 13)) * 1274126177;
            return n & 0x7fffffff;
        }

        public static void WriteWaterPreview(string dir)
        {
            System.IO.Directory.CreateDirectory(dir);
            for (int f = 0; f < 4; f++)
            {
                Color[] river = new Color[32 * 32];
                PaintStream(river, 32, 32, f, 0);
                WritePpm(System.IO.Path.Combine(dir, "river_" + f + ".ppm"), river, 32, 32);
                Color[] coast = new Color[32 * 32];
                PaintStream(coast, 32, 32, f, 1);
                WritePpm(System.IO.Path.Combine(dir, "coast_" + f + ".ppm"), coast, 32, 32);
                Color[] ocean = new Color[32 * 32];
                PaintStream(ocean, 32, 32, f, 2);
                WritePpm(System.IO.Path.Combine(dir, "ocean_" + f + ".ppm"), ocean, 32, 32);
            }
        }

        public static void CaptureGreenhouse(bool open, bool ruined, out Color[] d, out int pw, out int ph)
        {
            _ = open;
            if (!BlitPackedBuilding32(GreenhouseAssetPath(), 7, ruined, out d, out pw, out ph))
            {
                pw = 7 * 32;
                ph = 2;
                d = new Color[pw * ph];
            }
        }

        public static void CaptureBarn(bool open, bool ruined, out Color[] d, out int pw, out int ph)
        {
            if (!BlitPackedBuilding32(BarnAssetPath(), 8, ruined, out d, out pw, out ph))
            {
                pw = 8 * 32;
                ph = 2;
                d = new Color[pw * ph];
                return;
            }
            if (open)
                SlideBarnDoors(d, pw, ph, 1f);
        }

        public static void CaptureBlacksmith(bool open, out Color[] d, out int pw, out int ph)
        {
            _ = open;
            if (!BlitPackedBuilding32(ForgeAssetPath(), 7, false, out d, out pw, out ph))
            {
                pw = 7 * 32;
                ph = 2;
                d = new Color[pw * ph];
            }
        }

        public static void CaptureGreenhouseInside(out Color[] d, out int pw, out int ph)
        {
            HouseSize(12, 5, out pw, out ph);
            d = new Color[pw * ph];
            PaintGreenhouseInside(d, pw, 12, 5);
        }

        public static void CaptureFarmhouse(bool open, out Color[] d, out int pw, out int ph)
        {
            _ = open;
            if (!BlitCottageAsset32(out d, out pw, out ph))
            {
                pw = 7 * 32;
                ph = 2;
                d = new Color[pw * ph];
            }
        }

        public static void WriteCottagePreview(string dir)
        {
            System.IO.Directory.CreateDirectory(dir);
            WriteHousePpm(dir, "farm_cottage", 7, 5, 0, 3);
            WriteHousePpm(dir, "ash_forge", 7, 5, 4, 1);
            WriteHousePpm(dir, "barn", 8, 6, 8, 3);
            WriteHousePpm(dir, "greenhouse", 7, 5, 9, 3);
            WriteHousePpm(dir, "greenhouse_inside", 12, 5, 9, 6);
            WriteHousePpm(dir, "mira_cottage", 6, 5, 2, 2);
            WriteHousePpm(dir, "hearth_inn", 9, 6, 3, 4);
            WriteHousePpm(dir, "piper_market", 8, 6, 1, 3);
            WriteHousePpm(dir, "bram_lodge", 6, 5, 0, 2);
            WriteHousePpm(dir, "nell_garden", 6, 5, 2, 2);
        }

        static void WriteHousePpm(string dir, string name, int tilesW, int tilesH, int style, int doorDx)
        {
            int pw, ph;
            Color[] d;
            if (name == "farm_cottage")
            {
                if (!BlitCottageAsset32(out d, out pw, out ph))
                    return;
            }
            else if (name == "ash_forge")
            {
                if (!BlitPackedBuilding32(ForgeAssetPath(), tilesW, false, out d, out pw, out ph))
                    return;
            }
            else if (name == "barn")
            {
                if (!BlitPackedBuilding32(BarnAssetPath(), tilesW, false, out d, out pw, out ph))
                    return;
            }
            else if (name == "greenhouse")
            {
                if (!BlitPackedBuilding32(GreenhouseAssetPath(), tilesW, false, out d, out pw, out ph))
                    return;
            }
            else
            {
                HouseSize(tilesW, tilesH, out pw, out ph);
                d = new Color[pw * ph];
                if (name == "greenhouse_inside")
                    PaintGreenhouseInside(d, pw, tilesW, tilesH);
                else
                    PaintHouse(d, pw, tilesW, tilesH, style, doorDx, false);
            }
            WritePpm(System.IO.Path.Combine(dir, name + ".ppm"), d, pw, ph);
        }

        public static void WriteMountainPreview(string dir)
        {
            System.IO.Directory.CreateDirectory(dir);
            for (int v = 0; v < 4; v++)
            {
                Color[] fill = new Color[32 * 32];
                PaintMountainFill(fill, 32, 32, v);
                WritePpm(System.IO.Path.Combine(dir, "fill_" + v + ".ppm"), fill, 32, 32);
                Color[] south = new Color[32 * 32];
                PaintSouthDrop(south, 32, 32, v);
                WritePpm(System.IO.Path.Combine(dir, "south_" + v + ".ppm"), south, 32, 32);
                Color[] north = new Color[32 * 22];
                PaintNorthDrop(north, 32, 22, v);
                WritePpm(System.IO.Path.Combine(dir, "north_" + v + ".ppm"), north, 32, 22);
                Color[] east = new Color[18 * 32];
                PaintSideDrop(east, 18, 32, v, true);
                WritePpm(System.IO.Path.Combine(dir, "east_" + v + ".ppm"), east, 18, 32);
                Color[] cliff = new Color[32 * 32];
                for (int x = 0; x < 32; x++)
                {
                    for (int y = 0; y < 32; y++)
                    {
                        if (y < 5)
                            Plot(cliff, 32, x, y, PlateauPixel(x, y, v));
                        else
                            Plot(cliff, 32, x, y, CliffFaceAt(x, y - 5, v, y == 31));
                    }
                }
                PaintUnderLip(cliff, 32, 5, 0, 32, v);
                PaintGrassOverhang(cliff, 32, 5, v, 0);
                PaintFaceDetails(cliff, 32, 5, 27, v, false);
                WritePpm(System.IO.Path.Combine(dir, "cliff_" + v + ".ppm"), cliff, 32, 32);
            }
        }

        static void WritePpm(string path, Color[] d, int w, int h)
        {
            using (System.IO.StreamWriter s = new System.IO.StreamWriter(path))
            {
                s.Write("P3\n" + w + " " + h + "\n255\n");
                for (int i = 0; i < d.Length; i++)
                {
                    Color c = d[i];
                    if (c.A < 8)
                        s.Write("0 0 0\n");
                    else
                        s.Write(c.R + " " + c.G + " " + c.B + "\n");
                }
            }
        }
    }
}
