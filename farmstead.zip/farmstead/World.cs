using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    public sealed partial class World
    {
        public int Gold = 500;
        public int Energy = GameConst.MaxEnergy;
        /// <summary>Testing cheat: tools and cave hits never drain energy. Toggle with F3.</summary>
        public bool InfiniteEnergy = true;
        public int Day = 1;
        public float Minutes = GameConst.DayStart;
        public bool Raining;
        public bool Storming;
        public bool StormDay;
        readonly Random _weather = new Random();
        public Vector2 PlayerPos = new Vector2((20.5f + GameConst.FarmOx) * GameConst.Tile, (8.5f + GameConst.FarmOy) * GameConst.Tile);
        public int Dir; // 0 down, 1 left, 2 right, 3 up
        public bool Moving;
        public float Anim;
        public int CanWater = GameConst.CanCapacity;
        public int Selected;
        public Screen Screen = Screen.Title;
        public string Hint = "";
        public string Toast = "";
        public float ToastTimer;
        public bool PickupCue;
        public int ShippedTonight;
        public float ActionLock;
        public float SwingT;
        public float SwingDur = 0.32f;
        public string SwingAct = "";
        public Point Face = new Point(20 + GameConst.FarmOx, 8 + GameConst.FarmOy);
        public string ZoneName = "Harvest Hollow";
        public string OutdoorZone = "Harvest Hollow";
        public bool ShareWorldView;
        public FarmerLook Look = FarmerLook.Classic;
        public readonly SkillSet Skills = new SkillSet();
        public string LoadingZone = "";
        public float LoadTimer;
        public const float LoadFadeOut = 0.55f;
        public const float LoadHold = 0.40f;
        public const float LoadFadeIn = 0.90f;
        public const float LoadDuration = LoadFadeOut + LoadHold + LoadFadeIn;
        public bool LoadApplied;
        public string ArriveBanner = "";
        public float ArriveBannerTimer;
        public readonly Dictionary<string, int> TreeHits = new Dictionary<string, int>();
        public readonly Dictionary<string, int> RockHits = new Dictionary<string, int>();
        public readonly List<MineralSpot> MineralSpawns = new List<MineralSpot>();
        public readonly List<CaveTroll> Trolls = new List<CaveTroll>();
        public readonly List<FarmAnimal> Animals = new List<FarmAnimal>();
        public readonly List<CaveGuest> CaveGuests = new List<CaveGuest>();
        public string PendingFish;
        public Vector2 OutdoorPos = new Vector2((20.5f + GameConst.FarmOx) * GameConst.Tile, (8.5f + GameConst.FarmOy) * GameConst.Tile);
        readonly Random _fishRng = new Random();
        readonly Random _trollRng = new Random();
        readonly Random _animalRng = new Random();
        public readonly List<Building> Buildings = new List<Building>();
        public readonly List<GateSign> Gates = new List<GateSign>();
        public readonly List<StoneBridge> Bridges = new List<StoneBridge>();
        public readonly List<Deco> Decos = new List<Deco>();
        float _stormRoll;
        float _stormCell;
        public Building Inside;
        public int InsideFloor;
        public Building DoorSwing;
        public float DoorOpenU;
        public bool DoorForced;
        public Building LoadingBuilding;
        public bool LoadingExit;
        public int LoadingFloor = -1;
        public bool LoadingCaveDescend;
        public int CaveChestsLooted;
        public int FarmRepairs;
        public string PlanReturnId = "";
        public int HayInSilo;
        public readonly List<FallingTree> FallingTrees = new List<FallingTree>();
        public bool[,] HiddenWall;
        public readonly int[] NpcTx;
        public readonly int[] NpcTy;
        int _loadedSaveVer;
        readonly Dictionary<string, float> _hayTimers = new Dictionary<string, float>();
        public float StairLock;

        public readonly InvSlot[] Bar = new InvSlot[GameConst.BarSlots];
        public readonly InvSlot[] Pack = new InvSlot[GameConst.PackMaxSlots];
        public int PackUpgrades;

        public int PackOpen
        {
            get { return GameConst.PackBaseSlots + PackUpgrades * GameConst.PackUpgradeSize; }
        }

        public int PackRowsOpen
        {
            get { return (PackOpen + GameConst.PackCols - 1) / GameConst.PackCols; }
        }
        public readonly Dictionary<string, Crop> Crops = new Dictionary<string, Crop>();
        public TileType[,] Tiles;
        int _savedOutdoorW;
        int _savedOutdoorH;

        public World()
        {
            for (int i = 0; i < Bar.Length; i++)
                Bar[i] = new InvSlot();
            for (int i = 0; i < Pack.Length; i++)
                Pack[i] = new InvSlot();
            Bar[0].Set("hoe", 1);
            Bar[1].Set("can", 1);
            Bar[2].Set("scythe", 1);
            Bar[3].Set("axe", 1);
            Bar[4].Set(ItemCatalog.SeedId("turnip"), 15);
            Bar[5].Set(ItemCatalog.SeedId("potato"), 8);
            Bar[6].Set(ItemCatalog.SeedId("cabbage"), 5);
            Bar[7].Set(ItemCatalog.SeedId("melon"), 3);
            Bar[8].Set("rod", 1);
            Pack[0].Set(ItemCatalog.SeedId("pumpkin"), 1);
            Pack[1].Set("pickaxe", 1);
            Pack[2].Set("sword", 1);
            Pack[3].Set("plank", GameConst.TestPlanks);
            Pack[4].Set("pail", 1);
            Pack[5].Set("shears", 1);
            HiddenWall = new bool[GameConst.MapW, GameConst.MapH];
            NpcTx = new int[VillageFolk.Outdoor.Length];
            NpcTy = new int[VillageFolk.Outdoor.Length];
            for (int i = 0; i < VillageFolk.Outdoor.Length; i++)
            {
                NpcTx[i] = VillageFolk.Outdoor[i].Tx;
                NpcTy[i] = VillageFolk.Outdoor[i].Ty;
            }
            MapGen.RegisterHouses(Buildings);
            Tiles = MapGen.Build(Buildings);
            MapGen.CarveZoneGates(Tiles, Gates);
            MapGen.ConnectRoads(Tiles, Buildings);
            MapGen.ScatterRoadsideStone(Tiles);
            MapGen.PlaceBridges(Tiles, Bridges);
            MapGen.PlaceProps(Tiles, Decos);
            MapGen.ScatterBeachForage(Tiles);
            RecordMineralSpawns();
            SpawnCaveTrolls();
            EnsureStarterCows();
            EnsureStarterSheep();
        }

        public ItemDef HeldItem()
        {
            if (Selected < 0 || Selected >= Bar.Length)
                return null;
            return ItemCatalog.Find(Bar[Selected].Id);
        }

        public ToolId CurrentTool
        {
            get
            {
                ItemDef d = HeldItem();
                if (d == null)
                    return ToolId.Hoe;
                return d.Tool;
            }
        }

        public bool Swinging
        {
            get { return SwingT > 0f; }
        }

        public float SwingU
        {
            get { return SwingDur <= 0.0001f ? 1f : 1f - SwingT / SwingDur; }
        }

        public void TickSwing(float dt)
        {
            bool reeling = SwingT > 0f && SwingAct == "fish";
            if (SwingT > 0f)
                SwingT = Math.Max(0f, SwingT - dt);
            if (reeling && SwingT <= 0f)
                LandFish();
        }

        public void BeginSwing(string act)
        {
            ItemDef held = HeldItem();
            if (held == null || held.Kind == ItemKind.Produce || held.Kind == ItemKind.Resource)
                return;
            if (held.Kind == ItemKind.Food)
            {
                if (act != "eat")
                    return;
                SwingAct = "eat";
                SwingDur = SwingDuration("eat");
                SwingT = SwingDur;
                return;
            }
            if (held.Kind == ItemKind.Placeable)
            {
                if (act == "none")
                    return;
                SwingAct = "plant";
                SwingDur = SwingDuration("plant");
                SwingT = SwingDur;
                return;
            }
            if (act == "none")
                return;
            string kind = act;
            if (act == "fail" || act == "")
            {
                if (held.Kind == ItemKind.Seed)
                    kind = "plant";
                else if (held.Tool == ToolId.Can)
                    kind = "water";
                else if (held.Tool == ToolId.Axe)
                    kind = "chop";
                else if (held.Tool == ToolId.Pickaxe)
                    kind = "pick";
                else if (held.Tool == ToolId.Sword)
                    kind = "slash";
                else if (held.Tool == ToolId.Scythe)
                    kind = "scythe";
                else if (held.Tool == ToolId.Rod)
                    kind = "fish";
                else if (held.Tool == ToolId.MilkPail)
                    kind = "milk";
                else if (held.Tool == ToolId.Shears)
                    kind = "shear";
                else
                    kind = "hoe";
            }
            kind = ToolSwingAct(held, kind);
            SwingAct = kind;
            SwingDur = SwingDuration(kind);
            SwingT = SwingDur;
        }

        public static string ToolSwingAct(ItemDef held, string act)
        {
            if (held == null || held.Kind != ItemKind.Tool)
                return act;
            if (act == "chop")
            {
                if (held.Tool == ToolId.Pickaxe)
                    return "pick";
                if (held.Tool == ToolId.Sword)
                    return "slash";
                if (held.Tool == ToolId.Hoe)
                    return "hoe";
                if (held.Tool == ToolId.Scythe)
                    return "scythe";
            }
            return act;
        }

        public static float SwingDuration(string act)
        {
            if (act == "fish")
                return 0.56f;
            if (act == "water")
                return 0.46f;
            if (act == "chop")
                return 0.42f;
            if (act == "pick")
                return 0.40f;
            if (act == "scythe")
                return 0.40f;
            if (act == "slash")
                return 0.34f;
            if (act == "hoe")
                return 0.38f;
            if (act == "plant")
                return 0.34f;
            if (act == "harvest")
                return 0.32f;
            if (act == "eat")
                return 0.38f;
            if (act == "milk")
                return 0.42f;
            if (act == "shear")
                return 0.36f;
            return 0.30f;
        }

        public void ShowToast(string text)
        {
            Toast = text;
            ToastTimer = 2.4f;
        }

        public bool SpendEnergy(int n)
        {
            if (InfiniteEnergy)
            {
                Energy = GameConst.MaxEnergy;
                return true;
            }
            if (Energy < n)
            {
                ShowToast("You're too tired. Sleep in the cottage.");
                return false;
            }
            Energy -= n;
            return true;
        }

        public int PlayCols
        {
            get
            {
                if (Inside == null)
                    return GameConst.MapW;
                return Inside.FloorTiles(InsideFloor).GetLength(0);
            }
        }

        public int PlayRows
        {
            get
            {
                if (Inside == null)
                    return GameConst.MapH;
                return Inside.FloorTiles(InsideFloor).GetLength(1);
            }
        }

        public TileType TileAt(int x, int y)
        {
            if (Inside != null)
            {
                TileType[,] map = Inside.FloorTiles(InsideFloor);
                int w = map.GetLength(0);
                int h = map.GetLength(1);
                if (x < 0 || y < 0 || x >= w || y >= h)
                    return TileType.HouseWall;
                return map[x, y];
            }
            if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                return TileType.HouseWall;
            return Tiles[x, y];
        }

        public void SetTile(int x, int y, TileType t)
        {
            if (Inside != null)
            {
                TileType[,] map = Inside.FloorTiles(InsideFloor);
                int w = map.GetLength(0);
                int h = map.GetLength(1);
                if (x >= 0 && y >= 0 && x < w && y < h)
                    map[x, y] = t;
                return;
            }
            if (x >= 0 && y >= 0 && x < GameConst.MapW && y < GameConst.MapH)
                Tiles[x, y] = t;
        }

        string HitKey(int tx, int ty)
        {
            if (Inside != null)
                return "in:" + Inside.Id + ":" + InsideFloor.ToString() + ":" + tx.ToString() + "," + ty.ToString();
            return CropKey(tx, ty);
        }

        TileType SoftAfterMine(int tx, int ty)
        {
            if (Inside != null)
                return TileType.HouseFloor;
            if (GameConst.InDeepForest(tx, ty))
                return TileType.WoodsGrass;
            if (ty >= GameConst.BeachOy)
                return TileType.Sand;
            if (ty >= GameConst.VillageH && ty < GameConst.FarmOy)
                return TileType.Mountain;
            return TileType.Grass;
        }

        void NoteSkill(SkillId id, int xp)
        {
            string leveled;
            if (Skills.Gain(id, xp, out leveled) && !string.IsNullOrEmpty(leveled))
                ShowToast(leveled + ". Skill point!");
        }

        string MineVein(int tx, int ty)
        {
            if (!SpendEnergy(4))
                return "fail";
            string hk = HitKey(tx, ty);
            int hits;
            RockHits.TryGetValue(hk, out hits);
            hits++;
            RockHits[hk] = hits;
            int need = Skills.MineHits() + 1;
            if (hits < need)
            {
                ShowToast("The vein sparks.");
                NoteSkill(SkillId.Mining, 8);
                NoteSkill(SkillId.Attack, 2);
                return "pick";
            }
            RockHits.Remove(hk);
            SetTile(tx, ty, SoftAfterMine(tx, ty));
            string dropId;
            int dropN;
            ItemCatalog.RollVein(_trollRng, Skills.Level[(int)SkillId.Mining], out dropId, out dropN);
            AddItem(dropId, dropN);
            ItemDef drop = ItemCatalog.Find(dropId);
            string name = drop != null ? drop.Name : dropId;
            if (dropId.StartsWith("gem."))
                ShowToast("A " + name.ToLowerInvariant() + "!");
            else
                ShowToast("Broke the vein. +" + dropN.ToString() + " " + name.ToLowerInvariant() + ".");
            NoteSkill(SkillId.Mining, 28);
            NoteSkill(SkillId.Attack, 2);
            return "pick";
        }

        void RecordMineralSpawns()
        {
            MineralSpawns.Clear();
            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (Tiles[x, y] == TileType.Mineral)
                    {
                        MineralSpot s = new MineralSpot();
                        s.InsideId = "";
                        s.X = x;
                        s.Y = y;
                        MineralSpawns.Add(s);
                    }
                }
            }
            for (int b = 0; b < Buildings.Count; b++)
            {
                Building house = Buildings[b];
                if (house.Kind == BuildingKind.Cave)
                    continue;
                if (house.Interior == null)
                    continue;
                for (int y = 0; y < house.Ih; y++)
                {
                    for (int x = 0; x < house.Iw; x++)
                    {
                        if (house.Interior[x, y] != TileType.Mineral)
                            continue;
                        MineralSpot s = new MineralSpot();
                        s.InsideId = house.Id;
                        s.X = x;
                        s.Y = y;
                        MineralSpawns.Add(s);
                    }
                }
            }
        }

        void RestoreMineralNodes()
        {
            for (int i = 0; i < MineralSpawns.Count; i++)
            {
                MineralSpot s = MineralSpawns[i];
                if (string.IsNullOrEmpty(s.InsideId))
                {
                    if (s.X >= 0 && s.Y >= 0 && s.X < GameConst.MapW && s.Y < GameConst.MapH)
                        Tiles[s.X, s.Y] = TileType.Mineral;
                    RockHits.Remove(CropKey(s.X, s.Y));
                }
                else
                {
                    Building house = FindBuilding(s.InsideId);
                    if (house != null && house.Interior != null
                        && s.X >= 0 && s.Y >= 0 && s.X < house.Iw && s.Y < house.Ih)
                        house.Interior[s.X, s.Y] = TileType.Mineral;
                    RockHits.Remove("in:" + s.InsideId + ":" + s.X.ToString() + "," + s.Y.ToString());
                }
            }
        }

        public static bool IsSolid(TileType t)
        {
            return t == TileType.Water || t == TileType.Fence || t == TileType.HouseWall
                || t == TileType.HouseWindow || t == TileType.Tree || t == TileType.Rock || t == TileType.Mineral || t == TileType.Bin || t == TileType.Counter
                || t == TileType.Roof || t == TileType.Cliff || t == TileType.Dummy || t == TileType.Bed
                || t == TileType.Chest || t == TileType.InvisibleWall;
        }

        public bool HasHiddenWall(int tx, int ty)
        {
            if (Inside != null)
                return false;
            if (HiddenWall == null)
                return false;
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return false;
            return HiddenWall[tx, ty];
        }

        public void SetHiddenWall(int tx, int ty, bool on)
        {
            if (HiddenWall == null)
                HiddenWall = new bool[GameConst.MapW, GameConst.MapH];
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return;
            HiddenWall[tx, ty] = on;
        }

        public bool Blocked(float px, float py)
        {
            float hw = GameConst.BodyHalfW;
            float hh = GameConst.BodyHalfH;
            Point[] pts =
            {
                new Point((int)Math.Floor(px - hw), (int)Math.Floor(py - hh)),
                new Point((int)Math.Floor(px + hw), (int)Math.Floor(py - hh)),
                new Point((int)Math.Floor(px - hw), (int)Math.Floor(py + hh)),
                new Point((int)Math.Floor(px + hw), (int)Math.Floor(py + hh))
            };
            for (int i = 0; i < pts.Length; i++)
            {
                int tx = pts[i].X / GameConst.Tile;
                int ty = pts[i].Y / GameConst.Tile;
                if (IsSolid(TileAt(tx, ty)) || HasHiddenWall(tx, ty))
                    return true;
            }
            return TrollBlocks(px, py);
        }

        bool TrollBlocks(float px, float py)
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
                return false;
            for (int i = 0; i < Trolls.Count; i++)
            {
                CaveTroll t = Trolls[i];
                if (!t.Alive)
                    continue;
                float dx = px - t.Pos.X;
                float dy = py - t.Pos.Y;
                float rad = CaveMobCatalog.BlockRadius(t.Kind);
                if (dx * dx + dy * dy < rad * rad)
                    return true;
            }
            return false;
        }

        public CaveTroll TrollNear(Vector2 pos, float radius)
        {
            CaveTroll best = null;
            float bestD = radius;
            for (int i = 0; i < Trolls.Count; i++)
            {
                CaveTroll t = Trolls[i];
                if (!t.Alive)
                    continue;
                float d = Vector2.Distance(pos, t.Pos);
                if (d < bestD)
                {
                    bestD = d;
                    best = t;
                }
            }
            return best;
        }

        CaveTroll NearestTrollInReach()
        {
            Vector2 face = new Vector2(0f, 1f);
            if (Dir == 1) face = new Vector2(-1f, 0f);
            else if (Dir == 2) face = new Vector2(1f, 0f);
            else if (Dir == 3) face = new Vector2(0f, -1f);
            CaveTroll best = null;
            float bestD = 58f;
            for (int i = 0; i < Trolls.Count; i++)
            {
                CaveTroll t = Trolls[i];
                if (!t.Alive)
                    continue;
                Vector2 to = t.Pos - PlayerPos;
                float d = to.Length();
                if (d > bestD || d < 0.01f)
                    continue;
                to.Normalize();
                if (Vector2.Dot(to, face) < -0.15f && d > 30f)
                    continue;
                bestD = d;
                best = t;
            }
            return best;
        }

        string StrikeSword()
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
            {
                ShowToast("The sword is for Ridge Hollow's beasts. Train on the dummy if you like.");
                return "fail";
            }
            CaveTroll t = NearestTrollInReach();
            if (t == null)
            {
                ShowToast("Nothing in reach. Close in, then swing.");
                return "fail";
            }
            if (!SpendEnergy(2))
                return "fail";
            int dmg = 5 + Skills.Level[(int)SkillId.Attack] * 2;
            t.Hp -= dmg;
            t.HurtT = 0.4f;
            NoteSkill(SkillId.Attack, 12);
            string who = CaveMobCatalog.Name(t.Kind);
            if (t.Hp <= 0)
            {
                t.Hp = 0;
                t.Alive = false;
                int gold = 3 + t.Kind * 2 + _trollRng.Next(0, 6);
                Gold += gold;
                bool stone = t.Kind == (int)CaveMobKind.Troll;
                if (stone)
                    AddItem("stone", 1);
                ShowToast(CaveMobCatalog.KillLine(t.Kind, gold, stone));
                NoteSkill(SkillId.Attack, 22);
            }
            else
                ShowToast("Hit! " + who + " " + t.Hp.ToString() + "/" + t.MaxHp.ToString() + " hp.");
            return "slash";
        }

        public void SpawnCaveTrolls()
        {
            Trolls.Clear();
            Building cave = FindBuilding("ridge-cave");
            if (cave == null)
                return;
            int floor = Inside != null && Inside.Kind == BuildingKind.Cave ? InsideFloor : 0;
            CaveFloor plan = cave.EnsureCave(floor);
            int n = 3 + floor / 10;
            if (n > 8)
                n = 8;
            if (plan != null && plan.Vault)
                n = 0;
            TileType[,] map = cave.FloorTiles(floor);
            int tries = 0;
            while (Trolls.Count < n && tries < 80)
            {
                tries++;
                int tx = 2 + _trollRng.Next(cave.Iw - 4);
                int ty = 2 + _trollRng.Next(cave.Ih - 5);
                if (IsSolid(map[tx, ty]) || map[tx, ty] == TileType.Door)
                    continue;
                CaveTroll t = new CaveTroll();
                t.Kind = CaveMobCatalog.Pick(Trolls.Count, floor);
                t.Pos = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
                t.Wander = t.Pos;
                t.MaxHp = CaveMobCatalog.BaseHp(t.Kind, floor);
                t.Hp = t.MaxHp;
                t.Alive = true;
                t.Dir = 0;
                t.WanderT = 0.3f + (float)_trollRng.NextDouble() * 1.4f;
                Trolls.Add(t);
            }
        }

        CaveFloor EnsureCaveFloor()
        {
            Building cave = Inside != null && Inside.Kind == BuildingKind.Cave ? Inside : FindBuilding("ridge-cave");
            if (cave == null)
                return null;
            int fl = Inside != null && Inside.Kind == BuildingKind.Cave ? InsideFloor : 0;
            return cave.EnsureCave(fl);
        }

        public void TickTrolls(float dt)
        {
            Building cave = FindBuilding("ridge-cave");
            if (cave == null)
                return;
            for (int i = 0; i < Trolls.Count; i++)
            {
                CaveTroll t = Trolls[i];
                t.HurtT = Math.Max(0f, t.HurtT - dt);
                t.AtkCd = Math.Max(0f, t.AtkCd - dt);
                if (!t.Alive)
                {
                    t.Moving = false;
                    continue;
                }
                t.WanderT -= dt;
                TileType[,] roam = cave.FloorTiles(Inside != null && Inside.Id == "ridge-cave" ? InsideFloor : 0);
                bool hunting = Inside != null && Inside.Id == "ridge-cave"
                    && Vector2.Distance(t.Pos, PlayerPos) < CaveMobCatalog.Aggro(t.Kind);
                if (hunting)
                    t.Wander = PlayerPos;
                else if (t.WanderT <= 0f)
                {
                    int span = t.Kind == (int)CaveMobKind.Bat ? 5 : 3;
                    int tx = (int)Math.Floor(t.Pos.X / GameConst.Tile) + _trollRng.Next(-span, span + 1);
                    int ty = (int)Math.Floor(t.Pos.Y / GameConst.Tile) + _trollRng.Next(-span, span + 1);
                    if (tx > 0 && ty > 0 && tx < cave.Iw - 1 && ty < cave.Ih - 1
                        && !IsSolid(roam[tx, ty]) && roam[tx, ty] != TileType.Door)
                        t.Wander = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
                    t.WanderT = t.Kind == (int)CaveMobKind.Spider
                        ? 0.4f + (float)_trollRng.NextDouble() * 0.8f
                        : 0.8f + (float)_trollRng.NextDouble() * 2.2f;
                }
                Vector2 delta = t.Wander - t.Pos;
                float dist = delta.Length();
                t.Moving = dist > 4f;
                if (t.Moving)
                {
                    delta.Normalize();
                    Vector2 next = t.Pos + delta * CaveMobCatalog.Speed(t.Kind) * dt;
                    if (!CaveFootBlocked(roam, cave, next.X, next.Y))
                        t.Pos = next;
                    else
                        t.WanderT = 0f;
                    if (Math.Abs(delta.X) > Math.Abs(delta.Y))
                        t.Dir = delta.X < 0 ? 1 : 2;
                    else
                        t.Dir = delta.Y < 0 ? 3 : 0;
                    t.Anim += dt;
                }
                if (t.AtkCd > 0f)
                    continue;
                float reach = 28f + CaveMobCatalog.BlockRadius(t.Kind);
                int dmg = CaveMobCatalog.HitEnergy(t.Kind);
                float cd = CaveMobCatalog.HitCd(t.Kind);
                if (Inside != null && Inside.Id == "ridge-cave" && Vector2.Distance(t.Pos, PlayerPos) < reach)
                {
                    t.AtkCd = cd;
                    t.HurtT = 0.2f;
                    if (!InfiniteEnergy)
                    {
                        Energy = Math.Max(0, Energy - dmg);
                        ShowToast(Energy <= 0 ? "A " + CaveMobCatalog.Name(t.Kind) + " knocks you down. Sleep at the cottage." : CaveMobCatalog.HitLine(t.Kind));
                    }
                }
                for (int g = 0; g < CaveGuests.Count; g++)
                {
                    if (t.AtkCd > 0f)
                        break;
                    CaveGuest guest = CaveGuests[g];
                    if (Vector2.Distance(t.Pos, guest.Pos) < reach)
                    {
                        guest.Hurt(dmg);
                        t.AtkCd = cd;
                        t.HurtT = 0.2f;
                    }
                }
            }
        }

        static bool CaveFootBlocked(TileType[,] map, Building cave, float px, float py)
        {
            float hw = GameConst.BodyHalfW;
            float hh = GameConst.BodyHalfH;
            Point[] pts =
            {
                new Point((int)Math.Floor(px - hw), (int)Math.Floor(py - hh)),
                new Point((int)Math.Floor(px + hw), (int)Math.Floor(py - hh)),
                new Point((int)Math.Floor(px - hw), (int)Math.Floor(py + hh)),
                new Point((int)Math.Floor(px + hw), (int)Math.Floor(py + hh))
            };
            for (int i = 0; i < pts.Length; i++)
            {
                int tx = pts[i].X / GameConst.Tile;
                int ty = pts[i].Y / GameConst.Tile;
                if (tx < 0 || ty < 0 || tx >= cave.Iw || ty >= cave.Ih)
                    return true;
                if (IsSolid(map[tx, ty]))
                    return true;
            }
            return false;
        }

        public string CropKey(int x, int y)
        {
            return x.ToString() + "," + y.ToString();
        }

        public string UseTool(int tx, int ty)
        {
            if (Inside != null)
            {
                if (tx < 0 || ty < 0 || tx >= Inside.Iw || ty >= Inside.Ih)
                    return "none";
            }
            else if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return "none";
            if (!ZoneLit(tx, ty))
                return "none";

            ItemDef held = HeldItem();
            if (held == null || Bar[Selected].Empty)
            {
                ShowToast("That hotbar slot is empty. Open the satchel with I.");
                return "fail";
            }
            if (held.Kind == ItemKind.Food)
                return EatFood();
            if (held.Kind == ItemKind.Placeable)
                return PlaceHeld(tx, ty);
            if (held.Kind == ItemKind.Produce || held.Kind == ItemKind.Resource)
            {
                ShowToast("Hold a tool or a seed packet.");
                return "fail";
            }
            ToolId tool = held.Tool;
            TileType t = TileAt(tx, ty);
            string k = CropKey(tx, ty);
            Crop crop;
            Crops.TryGetValue(k, out crop);

            if (tool == ToolId.Rod)
                return CastLine(tx, ty, t);

            if (tool == ToolId.MilkPail)
                return MilkCowAt(tx, ty);

            if (tool == ToolId.Shears)
                return ShearSheepAt(tx, ty);

            if (crop != null)
            {
                CropDef ripe = CropCatalog.Find(crop.Id);
                if (ripe != null && crop.Stage >= ripe.Days && tool != ToolId.Can)
                    return Harvest(tx, ty);
            }

            if (tool == ToolId.Hoe)
            {
                if (t == TileType.WoodsGrass || t == TileType.Stump || t == TileType.Mountain
                    || t == TileType.Cliff || t == TileType.Cobble || t == TileType.Roof
                    || t == TileType.HouseWall || t == TileType.HouseWindow || t == TileType.HouseFloor || t == TileType.Door || t == TileType.Sand || t == TileType.Shell || t == TileType.Seaweed || t == TileType.Water || t == TileType.Dock || t == TileType.Dummy || t == TileType.Rock || t == TileType.Mineral || t == TileType.Bridge || t == TileType.Cliff)
                {
                    ShowToast("You can't till here.");
                    return "fail";
                }
                if (t == TileType.Grass || t == TileType.FarmSoil || t == TileType.Weed)
                {
                    if (!SpendEnergy(2))
                        return "fail";
                    SetTile(tx, ty, TileType.Tilled);
                    Crops.Remove(k);
                    return "hoe";
                }
                if (t == TileType.Hay || t == TileType.HayCut)
                {
                    ShowToast("That's a hayfield. Cut it with the scythe.");
                    return "fail";
                }
                return "fail";
            }

            if (tool == ToolId.Can)
            {
                if (t == TileType.Water)
                {
                    CanWater = GameConst.CanCapacity;
                    ShowToast("Watering can refilled.");
                    return "water";
                }
                if (t == TileType.Tilled || t == TileType.Wet || crop != null)
                {
                    if (CanWater <= 0)
                    {
                        ShowToast("The can is empty. Fill it at the river or the sea.");
                        return "fail";
                    }
                    if (!SpendEnergy(1))
                        return "fail";
                    CanWater--;
                    if (t == TileType.Tilled)
                        SetTile(tx, ty, TileType.Wet);
                    if (crop != null)
                        crop.Watered = true;
                    return "water";
                }
                return "fail";
            }

            if (t == TileType.Dummy)
            {
                if (tool == ToolId.Axe || tool == ToolId.Pickaxe || tool == ToolId.Scythe || tool == ToolId.Hoe || tool == ToolId.Sword)
                {
                    if (!SpendEnergy(2))
                        return "fail";
                    ShowToast("The dummy takes the hit.");
                    NoteSkill(SkillId.Attack, 10);
                    if (tool == ToolId.Sword)
                        return "slash";
                    if (tool == ToolId.Pickaxe)
                        return "pick";
                    if (tool == ToolId.Hoe)
                        return "hoe";
                    if (tool == ToolId.Scythe)
                        return "scythe";
                    return "chop";
                }
                ShowToast("Swing a tool at the dummy to train Attack.");
                return "fail";
            }

            if (tool == ToolId.Sword)
                return StrikeSword();

            if (tool == ToolId.Axe)
            {
                if (t == TileType.Tree)
                {
                    if (!SpendEnergy(4))
                        return "fail";
                    string hk = HitKey(tx, ty);
                    int hits;
                    TreeHits.TryGetValue(hk, out hits);
                    hits++;
                    TreeHits[hk] = hits;
                    if (hits < Skills.WoodHits())
                    {
                        ShowToast("The tree shudders.");
                        NoteSkill(SkillId.Woodcutting, 6);
                        NoteSkill(SkillId.Attack, 2);
                        return "chop";
                    }
                    TreeHits.Remove(hk);
                    SetTile(tx, ty, TileType.Stump);
                    BeginTreeFall(tx, ty);
                    int wood = Skills.WoodYield();
                    AddItem("wood", wood);
                    ShowToast("Chopped down. +" + wood.ToString() + " wood.");
                    NoteSkill(SkillId.Woodcutting, 20);
                    NoteSkill(SkillId.Attack, 2);
                    return "chop";
                }
                if (t == TileType.Stump)
                {
                    ShowToast("Only a stump remains.");
                    return "fail";
                }
                ShowToast("The axe is for trees.");
                return "fail";
            }

            if (tool == ToolId.Pickaxe)
            {
                if (t == TileType.Mineral)
                    return MineVein(tx, ty);
                if (t == TileType.Rock)
                {
                    if (!SpendEnergy(3))
                        return "fail";
                    string hk = HitKey(tx, ty);
                    int hits;
                    RockHits.TryGetValue(hk, out hits);
                    hits++;
                    RockHits[hk] = hits;
                    if (hits < Skills.MineHits())
                    {
                        ShowToast("The stone cracks.");
                        NoteSkill(SkillId.Mining, 6);
                        NoteSkill(SkillId.Attack, 2);
                        return "pick";
                    }
                    RockHits.Remove(hk);
                    SetTile(tx, ty, SoftAfterMine(tx, ty));
                    int stone = Skills.StoneYield();
                    AddItem("stone", stone);
                    ShowToast("Mined. +" + stone.ToString() + " stone.");
                    NoteSkill(SkillId.Mining, 20);
                    NoteSkill(SkillId.Attack, 2);
                    return "pick";
                }
                ShowToast("The pickaxe is for stone and mineral veins.");
                return "fail";
            }

            if (tool == ToolId.Scythe)
            {
                if (t == TileType.Hay)
                    return CutHay(tx, ty);
                if (t == TileType.HayCut)
                {
                    ShowToast("Stubble. The hay will grow back.");
                    return "fail";
                }
                if (t == TileType.Weed)
                {
                    if (!SpendEnergy(1))
                        return "fail";
                    SetTile(tx, ty, TileType.Grass);
                    AddItem("fiber", 1);
                    ShowToast("Cut some fiber.");
                    return "scythe";
                }
                if (t == TileType.Shell || t == TileType.Seaweed)
                {
                    PickBeachForage(tx, ty);
                    return "scythe";
                }
                return "fail";
            }

            CropDef seed = held.Kind == ItemKind.Seed ? CropCatalog.Find(held.CropId) : null;
            if (seed != null)
            {
                if (t != TileType.Tilled && t != TileType.Wet)
                {
                    ShowToast("Till the soil first.");
                    return "fail";
                }
                if (crop != null)
                {
                    ShowToast("Something is already growing here.");
                    return "fail";
                }
                if (Bar[Selected].Count <= 0)
                {
                    ShowToast("You're out of those seeds.");
                    return "fail";
                }
                if (!SpendEnergy(1))
                    return "fail";
                Bar[Selected].Count--;
                if (Bar[Selected].Count <= 0)
                    Bar[Selected].Clear();
                Crop planted = new Crop();
                planted.Id = seed.Id;
                planted.Stage = 0;
                planted.Watered = t == TileType.Wet;
                Crops[k] = planted;
                return "plant";
            }

            return "none";
        }

        public string Harvest(int tx, int ty)
        {
            string k = CropKey(tx, ty);
            Crop crop;
            if (!Crops.TryGetValue(k, out crop))
                return "fail";
            CropDef def = CropCatalog.Find(crop.Id);
            if (def == null || crop.Stage < def.Days)
            {
                ShowToast("It's not ready yet.");
                return "fail";
            }
            Crops.Remove(k);
            SetTile(tx, ty, TileType.Tilled);
            AddItem(crop.Id, 1);
            ShowToast("Harvested " + def.Name + ".");
            return "harvest";
        }

        public string CastLine(int tx, int ty, TileType t)
        {
            if (Inside != null)
            {
                ShowToast("Not from inside.");
                return "fail";
            }
            if (t != TileType.Water && t != TileType.Dock)
            {
                ShowToast("Cast the line into the water.");
                return "fail";
            }
            if (OutdoorZone != "Saltwind Beach")
            {
                ShowToast("Only the sea holds a catch here. Try Saltwind Beach.");
                return "fail";
            }
            if (!SpendEnergy(3))
                return "fail";
            if (_fishRng.Next(100) < 18)
            {
                PendingFish = "";
                ShowToast("A nibble... then nothing.");
                return "fish";
            }
            FishDef fish = FishCatalog.RollSaltwater(_fishRng);
            PendingFish = FishCatalog.ItemId(fish.Id);
            ShowToast("The line goes taut...");
            return "fish";
        }

        void LandFish()
        {
            string id = PendingFish;
            PendingFish = null;
            if (string.IsNullOrEmpty(id))
                return;
            FishDef fish = FishCatalog.Find(id);
            AddItem(id, 1);
            if (fish != null)
                ShowToast("Caught a " + fish.Name + "!");
            else
                ShowToast("Caught a fish!");
        }

        public void SellAllFish()
        {
            int total = 0;
            int count = 0;
            SellFishFrom(Bar, ref total, ref count);
            SellFishFrom(Pack, ref total, ref count);
            if (count == 0)
            {
                ShowToast("Finn: Bring me saltwater fish and I'll pay on the spot.");
                return;
            }
            Gold += total;
            ShowToast("Finn: " + count.ToString() + " fish for " + total.ToString() + "g. Fair wind.");
        }

        static void SellFishFrom(InvSlot[] slots, ref int total, ref int count)
        {
            for (int i = 0; i < slots.Length; i++)
            {
                if (slots[i].Empty || !FishCatalog.IsFish(slots[i].Id))
                    continue;
                ItemDef def = ItemCatalog.Find(slots[i].Id);
                if (def == null)
                    continue;
                total += def.Sell * slots[i].Count;
                count += slots[i].Count;
                slots[i].Clear();
            }
        }

        public void Interact(int tx, int ty)
        {
            if (!ZoneLit(tx, ty))
                return;
            if (Inside == null)
            {
                Building silo = SiloAt(tx, ty);
                if (silo != null)
                {
                    UseSilo();
                    return;
                }
            }
            TileType t = TileAt(tx, ty);
            if (t == TileType.Door)
            {
                Building b = Inside != null ? Inside : HouseAtDoor(tx, ty);
                if (b == null)
                    return;
                if (Inside == null && b.NeedsRepair)
                {
                    TryRepair(b);
                    return;
                }
                DoorSwing = b;
                DoorForced = true;
                if (DoorOpenU < 0.92f)
                {
                    if (DoorOpenU < 0.35f)
                        DoorOpenU = 0.35f;
                    return;
                }
                if (Inside != null && Inside.Kind == BuildingKind.Cave)
                {
                    UseCaveDoor(tx, ty);
                    return;
                }
                if (Inside != null)
                    BeginExit();
                else if (b.NeedsRepair)
                    TryRepair(b);
                else
                    BeginEnter(b);
                return;
            }
            if (t == TileType.Chest)
            {
                OpenCaveChest(tx, ty);
                return;
            }
            if (t == TileType.Stairs)
            {
                BeginFloorChange(InsideFloor == 0 ? 1 : 0);
                return;
            }
            if (t == TileType.Bed)
            {
                Screen = Screen.Sleep;
                return;
            }
            if (t == TileType.Counter)
            {
                if (Inside != null && Inside.IsResidence)
                {
                    FurnishKind fk = Inside.FurnishAt(tx, ty);
                    if (fk == FurnishKind.Stove)
                        ShowToast("The kettle's warm on the stove.");
                    else if (fk == FurnishKind.Sink)
                        ShowToast("A stone sink. The pump still works.");
                    else
                        ShowToast("Kitchen shelves and a chopping board.");
                    return;
                }
                if (Inside != null && Inside.Kind == BuildingKind.Inn)
                {
                    Screen = Screen.Shop;
                    return;
                }
                if (Inside != null && Inside.Kind == BuildingKind.FishMarket)
                {
                    Screen = Screen.Shop;
                    return;
                }
                if (Inside != null && Inside.Kind == BuildingKind.GeneralStore)
                {
                    FurnishKind stock = Inside.FurnishAt(tx, ty);
                    if (stock == FurnishKind.Fridge)
                    {
                        ShowToast("The glass is freezing. Stock keeps on the shelves inside.");
                        return;
                    }
                    if (stock == FurnishKind.Shelf)
                    {
                        ShowToast("Piper: Take it to the counter if you want it.");
                        return;
                    }
                    Screen = Screen.Shop;
                    return;
                }
                Screen = Screen.Shop;
                return;
            }
            if (Inside == null)
            {
                FarmAnimal stock = AnimalAtTile(tx, ty);
                if (stock != null && stock.Kind == AnimalKind.Cow)
                {
                    ItemDef heldCow = HeldItem();
                    if (heldCow != null && AnimalCatalog.IsLivestock(heldCow.Id))
                    {
                        TryPickAnimal(tx, ty);
                        return;
                    }
                    MilkCowAt(tx, ty);
                    return;
                }
                if (stock != null && stock.Kind == AnimalKind.Sheep)
                {
                    ItemDef heldSheep = HeldItem();
                    if (heldSheep != null && AnimalCatalog.IsLivestock(heldSheep.Id))
                    {
                        TryPickAnimal(tx, ty);
                        return;
                    }
                    ShearSheepAt(tx, ty);
                    return;
                }
            }
            if (Inside == null && TryPickAnimal(tx, ty))
                return;
            if (Inside == null && ty < GameConst.VillageH)
            {
                for (int i = 0; i < VillageFolk.Outdoor.Length; i++)
                {
                    NpcDef n = VillageFolk.Outdoor[i];
                    int nx = NpcTileX(i);
                    int ny = NpcTileY(i);
                    if (Math.Abs(tx - nx) <= 2 && Math.Abs(ty - ny) <= 2)
                    {
                        ShowToast(n.Line);
                        return;
                    }
                }
            }
            if (Inside != null && Inside.Kind == BuildingKind.Home && t == TileType.Flower)
            {
                ShowToast("Someone tends this room with care.");
                return;
            }
            if (t == TileType.Fence)
            {
                PickFence(tx, ty);
                return;
            }
            if (t == TileType.Shell || t == TileType.Seaweed)
            {
                PickBeachForage(tx, ty);
                return;
            }
            if (t == TileType.Bin)
            {
                ShipAll();
                return;
            }
            if (t == TileType.Hay)
            {
                ShowToast("Tall hay. Cut it with the scythe, then store it in the silo.");
                return;
            }
            if (t == TileType.HayCut)
            {
                ShowToast("Hay stubble. It grows back with the days.");
                return;
            }
            if (t == TileType.Water)
            {
                CanWater = GameConst.CanCapacity;
                ShowToast("Watering can refilled.");
                return;
            }

            string k = CropKey(tx, ty);
            Crop crop;
            if (Crops.TryGetValue(k, out crop))
            {
                CropDef def = CropCatalog.Find(crop.Id);
                if (def != null && crop.Stage >= def.Days)
                    Harvest(tx, ty);
                else if (def != null)
                    ShowToast(crop.Watered ? def.Name + " looks happy." : def.Name + " needs water.");
            }
        }

        public void ShipAll()
        {
            int total = 0;
            int count = 0;
            ShipFrom(Bar, ref total, ref count);
            ShipFrom(Pack, ref total, ref count);
            if (count == 0)
            {
                ShowToast("Nothing to ship.");
                return;
            }
            ShippedTonight += total;
            ShowToast("Shipped produce. " + total.ToString() + "g arrives in the morning.");
        }

        static void ShipFrom(InvSlot[] slots, ref int total, ref int count)
        {
            for (int i = 0; i < slots.Length; i++)
            {
                ItemDef def = ItemCatalog.Find(slots[i].Id);
                if (def == null || def.Sell <= 0 || slots[i].Empty)
                    continue;
                if (def.Kind != ItemKind.Produce && def.Kind != ItemKind.Resource)
                    continue;
                total += def.Sell * slots[i].Count;
                count += slots[i].Count;
                slots[i].Clear();
            }
        }

        public void Buy(CropDef def)
        {
            if (Gold < def.SeedCost)
            {
                ShowToast("Not enough gold.");
                return;
            }
            Gold -= def.SeedCost;
            AddItem(ItemCatalog.SeedId(def.Id), 1);
            ShowToast("Bought " + def.SeedName + ".");
        }

        public void BuyFood(ItemDef food)
        {
            if (food == null || food.Kind != ItemKind.Food)
                return;
            int cost = FoodCost(food);
            if (Gold < cost)
            {
                ShowToast("Not enough gold.");
                return;
            }
            Gold -= cost;
            AddItem(food.Id, 1);
            ShowToast("Bought " + food.Name + ".");
        }

        public void BuyAnimal(int i)
        {
            if (i < 0 || i >= ItemCatalog.Livestock.Length)
                return;
            ItemDef stock = ItemCatalog.Livestock[i];
            int cost = AnimalCatalog.Prices[i];
            if (Gold < cost)
            {
                ShowToast("Not enough gold.");
                return;
            }
            Gold -= cost;
            AddItem(stock.Id, 1);
            ShowToast("Bess: " + stock.Name + " is yours. Set it on the farm.");
        }

        public void BuyDrink(int i)
        {
            if (i < 0 || i >= ItemCatalog.Drinks.Length)
                return;
            BuyFood(ItemCatalog.Drinks[i]);
        }

        public static int FoodCost(ItemDef food)
        {
            if (food.Id == "food.bread") return 40;
            if (food.Id == "food.stew") return 80;
            if (food.Id == "food.pie") return 140;
            if (food.Id == "food.cider") return 35;
            if (food.Id == "food.tea") return 25;
            if (food.Id == "food.ale") return 45;
            if (food.Id == "food.cocoa") return 40;
            return 50;
        }

        public void BuyPackUpgrade()
        {
            if (PackUpgrades >= GameConst.PackUpgradeMax)
            {
                ShowToast("Piper: That's as roomy as the leather gets.");
                return;
            }
            int cost = ItemCatalog.PackUpgradePrices[PackUpgrades];
            if (Gold < cost)
            {
                ShowToast("Not enough gold.");
                return;
            }
            Gold -= cost;
            PackUpgrades++;
            ShowToast("Piper: Five more pockets. Satchel is " + PackOpen.ToString() + " slots.");
        }

        public string EatFood()
        {
            ItemDef held = HeldItem();
            if (held == null || held.Kind != ItemKind.Food)
                return "fail";
            if (Energy >= GameConst.MaxEnergy)
            {
                ShowToast("You're already full.");
                return "fail";
            }
            Energy += held.Restore;
            if (Energy > GameConst.MaxEnergy)
                Energy = GameConst.MaxEnergy;
            InvSlot slot = Bar[Selected];
            slot.Count--;
            if (slot.Count <= 0)
                slot.Clear();
            ShowToast((ItemCatalog.IsDrink(held.Id) ? "Drank " : "Ate ") + held.Name + ".");
            return "eat";
        }

        public void AdvanceDay(bool passedOut)
        {
            int payout = ShippedTonight;
            ShippedTonight = 0;
            Day++;
            Minutes = GameConst.DayStart;
            Raining = _weather.NextDouble() < 0.28;
            StormDay = Raining && _weather.NextDouble() < 0.36;
            Storming = StormDay;
            _stormRoll = StormDay ? 12f + (float)_weather.NextDouble() * 18f : 8f + (float)_weather.NextDouble() * 12f;
            _stormCell = 0f;
            Energy = (passedOut && !InfiniteEnergy) ? 50 : GameConst.MaxEnergy;
            if (passedOut)
            {
                Gold = Math.Max(0, Gold - 50);
                ShowToast("You collapsed. -50g, and you feel worn out.");
            }

            List<string> keys = new List<string>(Crops.Keys);
            for (int i = 0; i < keys.Count; i++)
            {
                string k = keys[i];
                Crop crop = Crops[k];
                bool indoor = k.IndexOf("in:", StringComparison.Ordinal) == 0;
                TileType ground = TileType.Tilled;
                int x = 0;
                int y = 0;
                bool haveTile = false;
                if (!indoor)
                {
                    string[] xy = k.Split(',');
                    if (xy.Length < 2 || !int.TryParse(xy[0], out x) || !int.TryParse(xy[1], out y))
                        continue;
                    if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                        continue;
                    ground = Tiles[x, y];
                    haveTile = true;
                }
                bool wet = crop.Watered || (!indoor && (Raining || ground == TileType.Wet));
                if (wet)
                    crop.Stage++;
                crop.Watered = !indoor && Raining;
                if (haveTile && ground == TileType.Wet)
                    Tiles[x, y] = TileType.Tilled;
            }

            if (Raining)
            {
                for (int y = 0; y < GameConst.MapH; y++)
                {
                    for (int x = 0; x < GameConst.MapW; x++)
                    {
                        if (Tiles[x, y] == TileType.Tilled)
                            Tiles[x, y] = TileType.Wet;
                    }
                }
                if (StormDay)
                    ShowToast("A thunderstorm soaked the fields overnight.");
                else
                    ShowToast("Rain overnight soaked the fields.");
            }

            if (payout > 0)
            {
                Gold += payout;
                ShowToast("The shipping bin paid out " + payout.ToString() + "g.");
            }
            SpawnCaveTrolls();
            RestoreMineralNodes();
            MapGen.RefillBeachForage(Tiles);
            GrowAllHay();
            ClearMilkedToday();
            GrowWoolOvernight();
        }

        void ClearMilkedToday()
        {
            for (int i = 0; i < Animals.Count; i++)
                Animals[i].MilkedToday = false;
        }

        void GrowWoolOvernight()
        {
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                if (a.Kind != AnimalKind.Sheep || a.HasWool)
                    continue;
                if (Day - a.LastShearDay >= GameConst.WoolRegrowDays)
                    a.HasWool = true;
            }
        }

        public void WakeInCottage()
        {
            Building home = null;
            for (int i = 0; i < Buildings.Count; i++)
            {
                if (Buildings[i].Kind == BuildingKind.Cottage)
                    home = Buildings[i];
            }
            if (home == null)
                return;
            Inside = home;
            InsideFloor = 0;
            PlayerPos = new Vector2(3.5f * GameConst.Tile, 4.2f * GameConst.Tile);
            Dir = 0;
            ZoneName = home.Name;
            OutdoorPos = home.OutdoorExit;
        }

        public InvSlot SlotAt(SlotLoc loc)
        {
            if (!loc.Valid)
                return null;
            InvSlot[] set = loc.Bar ? Bar : Pack;
            int cap = loc.Bar ? set.Length : PackOpen;
            if (loc.Index < 0 || loc.Index >= cap)
                return null;
            return set[loc.Index];
        }

        public bool MoveItem(SlotLoc from, SlotLoc to)
        {
            InvSlot a = SlotAt(from);
            InvSlot b = SlotAt(to);
            if (a == null || b == null || a.Empty)
                return false;
            if (from.Same(to))
                return false;
            if (!b.Empty && a.Id == b.Id)
            {
                ItemDef def = ItemCatalog.Find(a.Id);
                int max = def != null ? def.MaxStack : 999;
                if (def != null && def.Stackable && b.Count < max)
                {
                    int room = max - b.Count;
                    int take = a.Count < room ? a.Count : room;
                    b.Count += take;
                    a.Count -= take;
                    if (a.Count <= 0)
                        a.Clear();
                    return true;
                }
            }
            string id = a.Id;
            int count = a.Count;
            a.Set(b.Id, b.Count);
            b.Set(id, count);
            return true;
        }

        public void AddItem(string id, int n)
        {
            ItemDef def = ItemCatalog.Find(id);
            int max = def != null && def.Stackable ? def.MaxStack : 1;
            n = FillStacks(Pack, id, n, max, PackOpen);
            n = FillStacks(Bar, id, n, max, Bar.Length);
            n = FillEmpty(Pack, id, n, max, PackOpen);
            n = FillEmpty(Bar, id, n, max, Bar.Length);
            if (n > 0)
                ShowToast("Your satchel is full.");
        }

        public bool CanFitItem(string id, int n)
        {
            if (n <= 0)
                return true;
            ItemDef def = ItemCatalog.Find(id);
            int max = def != null && def.Stackable ? def.MaxStack : 1;
            n = CountRoom(Pack, id, n, max, PackOpen);
            n = CountRoom(Bar, id, n, max, Bar.Length);
            return n <= 0;
        }

        static int CountRoom(InvSlot[] slots, string id, int n, int max, int cap)
        {
            if (n <= 0)
                return n;
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last && n > 0; i++)
            {
                if (slots[i].Empty)
                {
                    n -= n < max ? n : max;
                    continue;
                }
                if (slots[i].Id != id)
                    continue;
                int room = max - slots[i].Count;
                if (room <= 0)
                    continue;
                int take = n < room ? n : room;
                n -= take;
            }
            return n;
        }

        static int FillStacks(InvSlot[] slots, string id, int n, int max, int cap)
        {
            if (n <= 0)
                return n;
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last && n > 0; i++)
            {
                if (slots[i].Empty || slots[i].Id != id)
                    continue;
                int room = max - slots[i].Count;
                if (room <= 0)
                    continue;
                int take = n < room ? n : room;
                slots[i].Count += take;
                n -= take;
            }
            return n;
        }

        static int FillEmpty(InvSlot[] slots, string id, int n, int max, int cap)
        {
            if (n <= 0)
                return n;
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last && n > 0; i++)
            {
                if (!slots[i].Empty)
                    continue;
                int take = n < max ? n : max;
                slots[i].Set(id, take);
                n -= take;
            }
            return n;
        }

        public int CountItem(string id)
        {
            int n = 0;
            n += CountIn(Bar, id, Bar.Length);
            n += CountIn(Pack, id, PackOpen);
            return n;
        }

        public void EnsureTestPlanks()
        {
            int have = CountItem("plank");
            int need = GameConst.TestPlanks - have;
            if (need > 0)
                AddItem("plank", need);
        }

        public void EnsureMilkPail()
        {
            if (CountItem("pail") < 1)
                AddItem("pail", 1);
        }

        public void EnsureShears()
        {
            if (CountItem("shears") < 1)
                AddItem("shears", 1);
        }

        static int CountIn(InvSlot[] slots, string id, int cap)
        {
            int n = 0;
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last; i++)
            {
                if (!slots[i].Empty && slots[i].Id == id)
                    n += slots[i].Count;
            }
            return n;
        }

        public bool TakeItem(string id, int n)
        {
            if (n <= 0)
                return true;
            if (CountItem(id) < n)
                return false;
            n = Drain(Bar, id, n, Bar.Length);
            Drain(Pack, id, n, PackOpen);
            return true;
        }

        static int Drain(InvSlot[] slots, string id, int n, int cap)
        {
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last && n > 0; i++)
            {
                if (slots[i].Empty || slots[i].Id != id)
                    continue;
                int take = slots[i].Count < n ? slots[i].Count : n;
                slots[i].Count -= take;
                n -= take;
                if (slots[i].Count <= 0)
                    slots[i].Clear();
            }
            return n;
        }

        public void CraftFence()
        {
            if (CountItem("wood") < 1)
            {
                ShowToast("Need 1 wood. Chop a tree with the axe.");
                return;
            }
            if (!TakeItem("wood", 1))
                return;
            AddItem("fence", 1);
            ShowToast("Crafted a fence. 1 wood.");
        }

        public void CraftPlank()
        {
            int need = ItemCatalog.WoodPerPlank;
            if (CountItem("wood") < need)
            {
                ShowToast("Need " + need.ToString() + " wood to mill a plank.");
                return;
            }
            if (!TakeItem("wood", need))
                return;
            AddItem("plank", 1);
            ShowToast("Milled a wooden plank from " + need.ToString() + " wood.");
        }

        public void CraftMilkPail()
        {
            int need = ItemCatalog.PlanksPerPail;
            if (CountItem("plank") < need)
            {
                ShowToast("Need " + need.ToString() + " wooden planks for a milk pail.");
                return;
            }
            if (!TakeItem("plank", need))
                return;
            if (!CanFitItem("pail", 1))
            {
                AddItem("plank", need);
                ShowToast("Your satchel is full.");
                return;
            }
            AddItem("pail", 1);
            ShowToast("Crafted a milk pail. " + need.ToString() + " planks.");
        }

        public void CraftShears()
        {
            int need = ItemCatalog.PlanksPerShears;
            if (CountItem("plank") < need)
            {
                ShowToast("Need " + need.ToString() + " wooden planks for shears.");
                return;
            }
            if (!TakeItem("plank", need))
                return;
            if (!CanFitItem("shears", 1))
            {
                AddItem("plank", need);
                ShowToast("Your satchel is full.");
                return;
            }
            AddItem("shears", 1);
            ShowToast("Crafted shears. " + need.ToString() + " planks.");
        }

        public void TryRepair(Building b)
        {
            if (b == null || !b.NeedsRepair)
                return;
            int need = b.RepairPlanks;
            int have = CountItem("plank");
            if (have < need)
            {
                ShowToast("Need " + need.ToString() + " wooden planks. Have " + have.ToString()
                    + ". Shift+C mills 1 from " + ItemCatalog.WoodPerPlank.ToString() + " wood.");
                return;
            }
            if (!TakeItem("plank", need))
                return;
            b.Repaired = true;
            b.Name = b.RepairName;
            b.RebuildInterior();
            FarmRepairs = PackFarmRepairs();
            ShowToast("You rebuild the " + b.Name.ToLowerInvariant() + ".");
        }

        public int PackFarmRepairs()
        {
            int n = 0;
            Building barn = FindBuilding("barn");
            Building green = FindBuilding("greenhouse");
            Building coop = FindBuilding("coop");
            if (barn != null && barn.Repaired)
                n |= 1;
            if (green != null && green.Repaired)
                n |= 2;
            if (coop != null && coop.Repaired)
                n |= 4;
            return n;
        }

        public void ApplyFarmRepairFlags()
        {
            ApplyOneRepair("barn", (FarmRepairs & 1) != 0);
            ApplyOneRepair("greenhouse", (FarmRepairs & 2) != 0);
            ApplyOneRepair("coop", (FarmRepairs & 4) != 0);
        }

        void ApplyOneRepair(string id, bool repaired)
        {
            Building b = FindBuilding(id);
            if (b == null || !b.IsFarmOutbuilding)
                return;
            b.Repaired = repaired;
            b.Name = b.RepairName;
            b.RebuildInterior();
        }

        string PlaceHeld(int tx, int ty)
        {
            ItemDef held = HeldItem();
            if (held != null && AnimalCatalog.IsLivestock(held.Id))
                return PlaceAnimal(tx, ty);
            return PlaceFence(tx, ty);
        }

        public string PlaceAnimal(int tx, int ty)
        {
            ItemDef held = HeldItem();
            AnimalKind kind;
            if (held == null || !AnimalCatalog.TryParse(held.Id, out kind))
            {
                ShowToast("Hold a livestock crate from Bess.");
                return "fail";
            }
            if (Inside != null)
            {
                ShowToast("Livestock stay on the farm.");
                return "fail";
            }
            if (!AnimalCanStand(tx, ty))
            {
                ShowToast("They need open pasture on the farm.");
                return "fail";
            }
            if (Crops.ContainsKey(CropKey(tx, ty)))
            {
                ShowToast("Something is already growing there.");
                return "fail";
            }
            if (Animals.Count >= AnimalCatalog.MaxOnFarm)
            {
                ShowToast("The pasture is full. Pack one up first.");
                return "fail";
            }
            if (!SpendHeld(held.Id, 1))
            {
                ShowToast("You have no livestock to place.");
                return "fail";
            }
            FarmAnimal a = new FarmAnimal();
            a.Kind = kind;
            a.Pos = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
            a.Wander = a.Pos;
            a.Dir = 0;
            a.WanderT = 0.4f + (float)_animalRng.NextDouble();
            if (kind == AnimalKind.Sheep)
                a.HasWool = true;
            Animals.Add(a);
            ShowToast(AnimalCatalog.Name(kind) + " settles on the grass.");
            return "plant";
        }

        public bool HasMilkPail()
        {
            return CountItem("pail") >= 1;
        }

        public FarmAnimal FindCow()
        {
            for (int i = 0; i < Animals.Count; i++)
            {
                if (Animals[i].Kind == AnimalKind.Cow)
                    return Animals[i];
            }
            return null;
        }

        public bool HasCow()
        {
            if (FindCow() != null)
                return true;
            return CountItem("animal.cow") >= 1;
        }

        public void EnsureStarterCows()
        {
            if (HasCow())
                return;
            SpawnCowNearBarn();
            SpawnCowNearBarn();
        }

        public bool HasShears()
        {
            return CountItem("shears") >= 1;
        }

        public FarmAnimal FindSheep()
        {
            for (int i = 0; i < Animals.Count; i++)
            {
                if (Animals[i].Kind == AnimalKind.Sheep)
                    return Animals[i];
            }
            return null;
        }

        public bool HasSheep()
        {
            if (FindSheep() != null)
                return true;
            return CountItem("animal.sheep") >= 1;
        }

        public void EnsureStarterSheep()
        {
            if (HasSheep())
                return;
            SpawnSheepNearBarn();
            SpawnSheepNearBarn();
        }

        public FarmAnimal SpawnSheepNearBarn()
        {
            FarmAnimal a = SpawnStockNearBarn(AnimalKind.Sheep);
            if (a != null)
                a.HasWool = true;
            return a;
        }

        public FarmAnimal SpawnCowNearBarn()
        {
            return SpawnStockNearBarn(AnimalKind.Cow);
        }

        FarmAnimal SpawnStockNearBarn(AnimalKind kind)
        {
            if (Animals.Count >= AnimalCatalog.MaxOnFarm)
                return null;
            Building barn = FindBuilding("barn");
            int ox = barn != null ? barn.DoorX : GameConst.FarmOx + 12;
            int oy = barn != null ? barn.DoorY + 2 : GameConst.FarmOy + 20;
            int tx = -1;
            int ty = -1;
            for (int r = 0; r <= 8 && tx < 0; r++)
            {
                for (int dy = -r; dy <= r && tx < 0; dy++)
                {
                    for (int dx = -r; dx <= r; dx++)
                    {
                        int x = ox + dx;
                        int y = oy + dy;
                        if (!AnimalCanStand(x, y) || Crops.ContainsKey(CropKey(x, y)))
                            continue;
                        if (AnimalOnTile(x, y))
                            continue;
                        tx = x;
                        ty = y;
                        break;
                    }
                }
            }
            if (tx < 0)
                return null;
            FarmAnimal a = new FarmAnimal();
            a.Kind = kind;
            a.Pos = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
            a.Wander = a.Pos;
            a.Dir = 0;
            a.WanderT = 0.4f + (float)_animalRng.NextDouble();
            if (kind == AnimalKind.Sheep)
                a.HasWool = true;
            Animals.Add(a);
            return a;
        }

        public string MilkCowAt(int tx, int ty)
        {
            FarmAnimal a = AnimalAtTile(tx, ty);
            if (a == null || a.Kind != AnimalKind.Cow)
            {
                ShowToast("No cow in reach.");
                return "fail";
            }
            return TryMilkCow(a);
        }

        public string TryMilkCow(FarmAnimal a)
        {
            if (a == null || a.Kind != AnimalKind.Cow)
            {
                ShowToast("Only cows give milk.");
                return "fail";
            }
            if (!HasMilkPail())
            {
                ShowToast("Need a milk pail.");
                return "fail";
            }
            if (a.MilkedToday)
            {
                ShowToast("Already milked today.");
                return "fail";
            }
            if (!CanFitItem("milk", 1))
            {
                ShowToast("Your satchel is full.");
                return "fail";
            }
            a.MilkedToday = true;
            AddItem("milk", 1);
            PickupCue = true;
            BeginSwing("milk");
            ShowToast("Got milk.");
            return "milk";
        }

        public string ShearSheepAt(int tx, int ty)
        {
            FarmAnimal a = AnimalAtTile(tx, ty);
            if (a == null || a.Kind != AnimalKind.Sheep)
            {
                ShowToast("No sheep in reach.");
                return "fail";
            }
            return TryShearSheep(a);
        }

        public string TryShearSheep(FarmAnimal a)
        {
            if (a == null || a.Kind != AnimalKind.Sheep)
            {
                ShowToast("Only sheep grow wool.");
                return "fail";
            }
            if (!HasShears())
            {
                ShowToast("Need shears.");
                return "fail";
            }
            if (!a.HasWool)
            {
                ShowToast("Its wool is still growing back.");
                return "fail";
            }
            if (!CanFitItem("wool", 1))
            {
                ShowToast("Your satchel is full.");
                return "fail";
            }
            a.HasWool = false;
            a.LastShearDay = Day;
            AddItem("wool", 1);
            PickupCue = true;
            BeginSwing("shear");
            ShowToast("Sheared a bundle of wool.");
            return "shear";
        }

        public bool TryPickAnimal(int tx, int ty)
        {
            FarmAnimal a = AnimalAtTile(tx, ty);
            if (a == null)
                return false;
            string id = AnimalCatalog.ItemId(a.Kind);
            string name = AnimalCatalog.Name(a.Kind);
            Animals.Remove(a);
            AddItem(id, 1);
            ShowToast(name + " packed up.");
            return true;
        }

        public FarmAnimal AnimalAtTile(int tx, int ty)
        {
            FarmAnimal best = null;
            float bestD = 40f;
            Vector2 center = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                int ax = (int)Math.Floor(a.Pos.X / GameConst.Tile);
                int ay = (int)Math.Floor(a.Pos.Y / GameConst.Tile);
                if (ax == tx && ay == ty)
                    return a;
                float d = Vector2.Distance(a.Pos, center);
                if (d < bestD)
                {
                    bestD = d;
                    best = a;
                }
            }
            return best;
        }

        public bool AnimalOnTile(int tx, int ty)
        {
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                int ax = (int)Math.Floor(a.Pos.X / GameConst.Tile);
                int ay = (int)Math.Floor(a.Pos.Y / GameConst.Tile);
                if (ax == tx && ay == ty)
                    return true;
            }
            return false;
        }

        public void TickAnimals(float dt)
        {
            if (Animals.Count == 0)
                return;
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                a.WanderT -= dt;
                if (a.WanderT <= 0f)
                {
                    int tx = (int)Math.Floor(a.Pos.X / GameConst.Tile) + _animalRng.Next(-4, 5);
                    int ty = (int)Math.Floor(a.Pos.Y / GameConst.Tile) + _animalRng.Next(-4, 5);
                    if (AnimalCanStand(tx, ty) && !Crops.ContainsKey(CropKey(tx, ty)))
                        a.Wander = new Vector2((tx + 0.5f) * GameConst.Tile, (ty + 0.5f) * GameConst.Tile);
                    a.WanderT = 0.9f + (float)_animalRng.NextDouble() * 2.4f;
                }
                Vector2 delta = a.Wander - a.Pos;
                float dist = delta.Length();
                a.Moving = dist > 4f;
                if (!a.Moving)
                    continue;
                delta.Normalize();
                Vector2 next = a.Pos + delta * AnimalCatalog.WalkSpeed(a.Kind) * dt;
                int nx = (int)Math.Floor(next.X / GameConst.Tile);
                int ny = (int)Math.Floor(next.Y / GameConst.Tile);
                if (AnimalCanStand(nx, ny) && !Crops.ContainsKey(CropKey(nx, ny)))
                    a.Pos = next;
                else
                    a.WanderT = 0f;
                if (Math.Abs(delta.X) > Math.Abs(delta.Y))
                    a.Dir = delta.X < 0 ? 1 : 2;
                else
                    a.Dir = delta.Y < 0 ? 3 : 0;
                a.Anim += dt;
            }
        }

        public bool AnimalCanStand(int tx, int ty)
        {
            if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                return false;
            if (!GameConst.InFarmBand(ty) || GameConst.InDeepForest(tx, ty))
                return false;
            if (HasHiddenWall(tx, ty))
                return false;
            TileType t = TileAt(tx, ty);
            if (IsSolid(t) || t == TileType.Path || t == TileType.Cobble || t == TileType.Door
                || t == TileType.HouseFloor || t == TileType.Sand || t == TileType.Dock
                || t == TileType.Bridge)
                return false;
            return t == TileType.Grass || t == TileType.Weed || t == TileType.FarmSoil
                || t == TileType.Tilled || t == TileType.Wet || t == TileType.Flower
                || t == TileType.Stump || t == TileType.Hay || t == TileType.HayCut;
        }

        public string PlaceFence(int tx, int ty)
        {
            if (Inside != null)
            {
                ShowToast("Fences go outside.");
                return "fail";
            }
            TileType t = TileAt(tx, ty);
            if (t != TileType.Grass && t != TileType.Weed && t != TileType.FarmSoil && t != TileType.WoodsGrass)
            {
                ShowToast("Plant the fence in open ground.");
                return "fail";
            }
            if (Crops.ContainsKey(CropKey(tx, ty)))
            {
                ShowToast("Something is already growing there.");
                return "fail";
            }
            if (!SpendHeld("fence", 1))
            {
                ShowToast("You have no fence to place.");
                return "fail";
            }
            SetTile(tx, ty, TileType.Fence);
            ShowToast("Fence set.");
            return "plant";
        }

        public void PickFence(int tx, int ty)
        {
            if (TileAt(tx, ty) != TileType.Fence)
                return;
            SetTile(tx, ty, GameConst.InDeepForest(tx, ty) ? TileType.WoodsGrass : TileType.Grass);
            AddItem("fence", 1);
            ShowToast("Fence packed up.");
        }

        public void PickBeachForage(int tx, int ty)
        {
            TileType t = TileAt(tx, ty);
            if (t == TileType.Seaweed)
            {
                SetTile(tx, ty, TileType.Sand);
                AddItem(BeachForage.SeaweedId, 1);
                ShowToast("Picked up seaweed.");
                return;
            }
            if (t != TileType.Shell)
                return;
            string id = BeachForage.ShellIdAt(tx, ty);
            string name = BeachForage.ShellNameAt(tx, ty);
            SetTile(tx, ty, TileType.Sand);
            AddItem(id, 1);
            ShowToast("Picked up a " + name.ToLowerInvariant() + ".");
        }

        bool SpendHeld(string id, int n)
        {
            if (!Bar[Selected].Empty && Bar[Selected].Id == id && Bar[Selected].Count >= n)
            {
                Bar[Selected].Count -= n;
                if (Bar[Selected].Count <= 0)
                    Bar[Selected].Clear();
                return true;
            }
            return TakeItem(id, n);
        }

        public void TickStorm(float dt)
        {
            if (!Raining)
            {
                Storming = false;
                StormDay = false;
                _stormCell = 0f;
                return;
            }

            if (StormDay)
            {
                _stormRoll -= dt;
                if (_stormRoll <= 0f)
                {
                    if (Storming && _weather.NextDouble() < 0.16)
                    {
                        Storming = false;
                        _stormRoll = 5f + (float)_weather.NextDouble() * 8f;
                    }
                    else
                    {
                        Storming = true;
                        _stormRoll = 16f + (float)_weather.NextDouble() * 22f;
                    }
                }
                return;
            }

            if (Storming)
            {
                _stormCell -= dt;
                if (_stormCell <= 0f)
                    Storming = false;
                return;
            }

            _stormRoll -= dt;
            if (_stormRoll <= 0f)
            {
                _stormRoll = 9f + (float)_weather.NextDouble() * 16f;
                if (_weather.NextDouble() < 0.14)
                {
                    Storming = true;
                    _stormCell = 14f + (float)_weather.NextDouble() * 28f;
                    ShowToast("Thunderheads over the hollow.");
                }
            }
        }

        public void TickTime(float dt)
        {
            if (Screen != Screen.Play)
                return;
            if (InfiniteEnergy)
                Energy = GameConst.MaxEnergy;
            Minutes += dt * GameConst.MinutesPerSecond;
            TickStorm(dt);
            TickTrolls(dt);
            TickAnimals(dt);
            TickHay(dt);
            if (Minutes >= GameConst.DayEnd)
            {
                AdvanceDay(true);
                WakeInCottage();
            }
        }

        public static string ZoneAt(int tx, int ty)
        {
            if (ty < GameConst.VillageH)
                return "Hearth Village";
            if (ty < GameConst.FarmOy)
            {
                if (tx < GameConst.SummitW)
                    return "Ridge Summit";
                return "Mountain Path";
            }
            if (ty < GameConst.CountryOy)
            {
                if (GameConst.InMoonveil(tx, ty))
                    return "Moonveil Grove";
                if (GameConst.InWoods(tx, ty))
                    return "Forbidden Woods";
                return "Harvest Hollow";
            }
            if (ty < GameConst.BeachOy)
                return "Meadow Road";
            return "Saltwind Beach";
        }

        public static bool IsWorldZone(string name)
        {
            return name == "Hearth Village" || name == "Mountain Path" || name == "Ridge Summit"
                || name == "Harvest Hollow" || name == "Forbidden Woods" || name == "Moonveil Grove"
                || name == "Meadow Road" || name == "Saltwind Beach";
        }

        public bool ZoneLit(int tx, int ty)
        {
            if (ShareWorldView || Inside != null)
                return true;
            string here = ZoneAt(tx, ty);
            if (here == OutdoorZone)
                return true;
            int px = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
            int py = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
            return here == ZoneAt(px, py);
        }

        public string RoadHint(int tx, int ty)
        {
            if (Inside != null || !ZoneLit(tx, ty))
                return null;
            for (int i = 0; i < Gates.Count; i++)
            {
                GateSign g = Gates[i];
                if (Math.Abs(g.X - tx) <= 1 && Math.Abs(g.Y - ty) <= 1)
                    return "This road leads to " + g.Dest + ". Walk in.";
            }
            TileType here = TileAt(tx, ty);
            if (here != TileType.Path && here != TileType.Cobble)
                return null;
            int[] dx = { 0, 0, -1, 1 };
            int[] dy = { -1, 1, 0, 0 };
            for (int i = 0; i < 4; i++)
            {
                int nx = tx + dx[i];
                int ny = ty + dy[i];
                if (nx < 0 || ny < 0 || nx >= GameConst.MapW || ny >= GameConst.MapH)
                    continue;
                if (!ZoneLit(nx, ny))
                    return "This road leads to " + ZoneAt(nx, ny) + ". Walk in.";
            }
            return null;
        }

        public void UpdateZone()
        {
            if (Screen != Screen.Play || Inside != null)
                return;
            int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
            int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
            string zone = ZoneAt(tx, ty);
            if (zone == OutdoorZone)
                return;
            if (!IsWorldZone(OutdoorZone))
            {
                OutdoorZone = zone;
                ZoneName = zone;
                return;
            }
            LoadingZone = zone;
            LoadTimer = 0f;
            LoadApplied = false;
            Screen = Screen.Loading;
        }

        public Building HouseAtDoor(int tx, int ty)
        {
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                if (tx == b.DoorX && ty == b.DoorY)
                    return b;
            }
            return null;
        }

        public bool DoorLooksOpen(Building b)
        {
            return b != null && DoorSwing == b && DoorOpenU > 0.2f;
        }

        public Building BarnDoorsAt(int tx, int ty)
        {
            Building barn = FindBuilding("barn");
            if (barn == null || barn.Kind != BuildingKind.Barn)
                return null;
            int dx = tx - barn.ApproachX;
            int dy = ty - barn.ApproachY;
            if (Math.Abs(dx) > 2 || Math.Abs(dy) > GameConst.BarnDoorApproach)
                return null;
            if (barn.Rot == 0 && dy < 0)
                return null;
            if (barn.Rot == 2 && dy > 0)
                return null;
            if (barn.Rot == 1 && dx > 0)
                return null;
            if (barn.Rot == 3 && dx < 0)
                return null;
            return barn;
        }

        public bool InteriorDoorOpen
        {
            get { return Inside != null && DoorOpenU > 0.2f; }
        }

        public void CheckDoors()
        {
            CheckDoors(0.016f);
        }

        public void CheckDoors(float dt)
        {
            if (dt > 0.05f)
                dt = 0.05f;
            if (Screen == Screen.Loading)
            {
                if (DoorSwing != null)
                    DoorOpenU = 1f;
                return;
            }
            if (Screen != Screen.Play)
                return;
            int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
            int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
            Building want = null;
            bool leaving = false;
            if (Inside != null)
            {
                if (TileAt(tx, ty) == TileType.Door)
                {
                    want = Inside;
                    if (Inside.Kind == BuildingKind.Cave)
                        leaving = false;
                    else
                        leaving = true;
                }
            }
            else
            {
                want = HouseAtDoor(tx, ty);
                if (want != null && (want.NeedsRepair || want.Kind == BuildingKind.Silo))
                    want = null;
            }
            if (DoorForced && DoorSwing != null)
            {
                int dtx = Inside != null ? DoorSwing.InteriorDoorX : DoorSwing.DoorX;
                int dty = Inside != null ? DoorSwing.Ih - 1 : DoorSwing.DoorY;
                if (Math.Abs(tx - dtx) + Math.Abs(ty - dty) <= 3)
                    want = DoorSwing;
                else
                    DoorForced = false;
            }

            Building swing = want;
            if (swing == null && Inside == null)
                swing = BarnDoorsAt(tx, ty);

            if (swing != null)
            {
                if (DoorSwing != swing)
                {
                    DoorSwing = swing;
                    DoorOpenU = 0f;
                }
                DoorOpenU += dt / 0.32f;
                if (DoorOpenU >= 1f)
                {
                    DoorOpenU = 1f;
                    if (want != null)
                    {
                        DoorForced = false;
                        if (Inside != null && Inside.Kind == BuildingKind.Cave)
                        {
                            if (StairLock <= 0f)
                                UseCaveDoor(tx, ty);
                        }
                        else if (leaving || Inside == want)
                            BeginExit();
                        else
                            BeginEnter(want);
                    }
                }
            }
            else
            {
                DoorForced = false;
                DoorOpenU -= dt / 0.2f;
                if (DoorOpenU <= 0f)
                {
                    DoorOpenU = 0f;
                    DoorSwing = null;
                }
            }

            if (StairLock > 0f)
                StairLock -= dt;
            if (Inside != null && Inside.HasUpstairs && StairLock <= 0f
                && TileAt(tx, ty) == TileType.Stairs)
                BeginFloorChange(InsideFloor == 0 ? 1 : 0);
        }

        public void UseCaveDoor(int tx, int ty)
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
                return;
            if (Screen == Screen.Loading)
                return;
            if (StairLock > 0f)
                return;
            if (Inside.IsCaveDeepDoor(InsideFloor, tx, ty))
            {
                if (InsideFloor >= CaveGen.Levels - 1)
                {
                    ShowToast("The stone ends here. This is the heart of the hollow.");
                    return;
                }
                BeginCaveDepth(InsideFloor + 1, true);
                return;
            }
            if (InsideFloor <= 0)
                BeginExit();
            else
                BeginCaveDepth(InsideFloor - 1, false);
        }

        public void OpenCaveChest(int tx, int ty)
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
                return;
            int chest = Inside.CaveChestIndex(InsideFloor, tx, ty);
            if (chest < 0)
            {
                ShowToast("A stone coffer, long empty.");
                return;
            }
            int bit = CaveGen.LootBit(InsideFloor + 1, chest);
            if (((CaveChestsLooted >> bit) & 1) == 1)
            {
                ShowToast("The chest is empty. You already took the coins.");
                return;
            }
            CaveChestsLooted |= 1 << bit;
            int gold = CaveGen.ChestGold(InsideFloor + 1, chest);
            Gold += gold;
            ShowToast("Gold coins spill out. +" + gold.ToString() + "g.");
        }

        public bool CaveChestLooted(int tx, int ty)
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
                return false;
            int chest = Inside.CaveChestIndex(InsideFloor, tx, ty);
            if (chest < 0)
                return false;
            int bit = CaveGen.LootBit(InsideFloor + 1, chest);
            return ((CaveChestsLooted >> bit) & 1) == 1;
        }

        public void BeginCaveDepth(int floor, bool descend)
        {
            if (Inside == null || Inside.Kind != BuildingKind.Cave)
                return;
            if (Screen == Screen.Loading)
                return;
            if (floor < 0)
                floor = 0;
            if (floor >= CaveGen.Levels)
                floor = CaveGen.Levels - 1;
            if (floor == InsideFloor)
                return;
            LoadingFloor = floor;
            LoadingCaveDescend = descend;
            LoadingBuilding = null;
            LoadingExit = false;
            LoadingZone = Inside.FloorName(floor);
            LoadTimer = 0f;
            LoadApplied = false;
            Screen = Screen.Loading;
        }

        public void BeginFloorChange(int floor)
        {
            if (Inside == null || !Inside.HasUpstairs)
                return;
            if (Screen == Screen.Loading)
                return;
            if (floor == InsideFloor)
                return;
            if (floor != 0 && floor != 1)
                return;
            LoadingFloor = floor;
            LoadingBuilding = null;
            LoadingExit = false;
            LoadingZone = Inside.FloorName(floor);
            LoadTimer = 0f;
            LoadApplied = false;
            Screen = Screen.Loading;
        }

        public void BeginEnter(Building b)
        {
            DoorSwing = b;
            DoorOpenU = 1f;
            OutdoorPos = b.OutdoorExit;
            LoadingBuilding = b;
            LoadingExit = false;
            LoadingFloor = -1;
            LoadingZone = b.Name;
            LoadTimer = 0f;
            LoadApplied = false;
            Screen = Screen.Loading;
        }

        public void BeginExit()
        {
            if (Inside != null)
                OutdoorPos = Inside.OutdoorExit;
            int tx = (int)Math.Floor(OutdoorPos.X / GameConst.Tile);
            int ty = (int)Math.Floor(OutdoorPos.Y / GameConst.Tile);
            LoadingBuilding = null;
            LoadingExit = true;
            LoadingFloor = -1;
            LoadingZone = ZoneAt(tx, ty);
            LoadTimer = 0f;
            LoadApplied = false;
            Screen = Screen.Loading;
        }

        public void TickLoading(float dt)
        {
            if (dt > 0.05f)
                dt = 0.05f;
            LoadTimer += dt;
            if (!LoadApplied && LoadTimer >= LoadFadeOut)
                ApplyLoad();
            if (LoadTimer >= LoadDuration)
                Screen = Screen.Play;
        }

        public float LoadFadeAlpha()
        {
            float t = LoadTimer;
            if (t <= 0f)
                return 0f;
            if (t < LoadFadeOut)
                return Smooth01(t / LoadFadeOut);
            if (t < LoadFadeOut + LoadHold)
                return 1f;
            float u = (t - LoadFadeOut - LoadHold) / LoadFadeIn;
            if (u >= 1f)
                return 0f;
            return 1f - Smooth01(u);
        }

        public float LoadTitleAlpha()
        {
            float black = LoadFadeAlpha();
            if (black <= 0.28f)
                return 0f;
            return Smooth01(Math.Min(1f, (black - 0.28f) / 0.45f));
        }

        static float Smooth01(float x)
        {
            if (x <= 0f)
                return 0f;
            if (x >= 1f)
                return 1f;
            return x * x * (3f - 2f * x);
        }

        void ApplyLoad()
        {
            LoadApplied = true;
            if (LoadingExit)
            {
                Building left = Inside;
                Inside = null;
                InsideFloor = 0;
                PlayerPos = OutdoorPos;
                Dir = 0;
                LoadingExit = false;
                int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
                int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
                string zone = ZoneAt(tx, ty);
                ZoneName = zone;
                OutdoorZone = zone;
                DoorSwing = left;
                DoorOpenU = 1f;
                DoorForced = false;
                ShowArrive(zone);
                return;
            }

            if (LoadingFloor >= 0 && Inside != null)
            {
                InsideFloor = LoadingFloor;
                if (Inside.Kind == BuildingKind.Cave)
                    Inside.CaveArriveDown = LoadingCaveDescend;
                PlayerPos = Inside.FloorSpawn(InsideFloor);
                Dir = LoadingCaveDescend ? 3 : 0;
                ZoneName = Inside.FloorName(InsideFloor);
                StairLock = 0.7f;
                LoadingFloor = -1;
                LoadingCaveDescend = false;
                if (Inside.Kind == BuildingKind.Cave)
                    SpawnCaveTrolls();
                ShowArrive(ZoneName);
                return;
            }

            if (LoadingBuilding != null)
            {
                Inside = LoadingBuilding;
                InsideFloor = 0;
                PlayerPos = Inside.InteriorSpawn;
                Dir = 3;
                ZoneName = Inside.FloorName(0);
                LoadingBuilding = null;
                DoorSwing = Inside;
                DoorOpenU = 0f;
                DoorForced = false;
                if (Inside.Kind == BuildingKind.Cave)
                    SpawnCaveTrolls();
                ShowArrive(ZoneName);
                return;
            }

            string from = ZoneName;
            string to = LoadingZone;
            ZoneName = to;
            OutdoorZone = to;
            float t = GameConst.Tile;
            if (to == "Forbidden Woods" && from == "Harvest Hollow")
                PlayerPos.X = Math.Min(PlayerPos.X, GameConst.FarmOx * t - 1.4f * t);
            else if (to == "Harvest Hollow" && from == "Forbidden Woods")
                PlayerPos.X = Math.Max(PlayerPos.X, GameConst.FarmOx * t + 1.4f * t);
            else if (to == "Moonveil Grove" && from == "Forbidden Woods")
                PlayerPos.X = Math.Min(PlayerPos.X, GameConst.ShadeW * t - 1.4f * t);
            else if (to == "Forbidden Woods" && from == "Moonveil Grove")
                PlayerPos.X = Math.Max(PlayerPos.X, GameConst.ShadeW * t + 1.4f * t);
            else if (to == "Ridge Summit" && from == "Mountain Path")
                PlayerPos.X = Math.Min(PlayerPos.X, GameConst.SummitW * t - 1.4f * t);
            else if (to == "Mountain Path" && from == "Ridge Summit")
                PlayerPos.X = Math.Max(PlayerPos.X, GameConst.SummitW * t + 1.4f * t);

            if (to == "Mountain Path" && from == "Harvest Hollow")
                PlayerPos.Y = Math.Min(PlayerPos.Y, GameConst.FarmOy * t - 1.4f * t);
            else if (to == "Harvest Hollow" && from == "Mountain Path")
                PlayerPos.Y = Math.Max(PlayerPos.Y, GameConst.FarmOy * t + 1.4f * t);
            else if (to == "Hearth Village" && from == "Mountain Path")
                PlayerPos.Y = Math.Min(PlayerPos.Y, GameConst.VillageH * t - 1.4f * t);
            else if (to == "Mountain Path" && from == "Hearth Village")
                PlayerPos.Y = Math.Max(PlayerPos.Y, GameConst.VillageH * t + 1.4f * t);
            else if (to == "Meadow Road" && from == "Harvest Hollow")
                PlayerPos.Y = Math.Max(PlayerPos.Y, GameConst.CountryOy * t + 1.4f * t);
            else if (to == "Harvest Hollow" && from == "Meadow Road")
                PlayerPos.Y = Math.Min(PlayerPos.Y, GameConst.CountryOy * t - 1.4f * t);
            else if (to == "Saltwind Beach" && from == "Meadow Road")
                PlayerPos.Y = Math.Max(PlayerPos.Y, GameConst.BeachOy * t + 1.4f * t);
            else if (to == "Meadow Road" && from == "Saltwind Beach")
                PlayerPos.Y = Math.Min(PlayerPos.Y, GameConst.BeachOy * t - 1.4f * t);
            ShowArrive(to);
        }

        void ShowArrive(string name)
        {
            ArriveBanner = name;
            ArriveBannerTimer = 3.2f;
        }

        public void SyncDoorsSilent()
        {
            int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
            int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
            if (Inside != null)
            {
                if (TileAt(tx, ty) == TileType.Door)
                {
                    if (Inside.Kind == BuildingKind.Cave)
                        return;
                    Inside = null;
                    PlayerPos = OutdoorPos;
                    ZoneName = OutdoorZone;
                    Dir = 0;
                }
                return;
            }
            Building b = HouseAtDoor(tx, ty);
            if (b != null)
            {
                OutdoorPos = b.OutdoorExit;
                Inside = b;
                PlayerPos = b.InteriorSpawn;
                Dir = 3;
                ZoneName = b.Name;
            }
            else
            {
                string z = ZoneAt(tx, ty);
                OutdoorZone = z;
                ZoneName = z;
            }
        }

        public Vector2 SlotSpawn(int slot)
        {
            float x = (20.5f + GameConst.FarmOx) * GameConst.Tile + (slot % 3) * 36f;
            float y = (8.5f + GameConst.FarmOy) * GameConst.Tile + (slot / 3) * 28f;
            return new Vector2(x, y);
        }

        public void BeginTreeFall(int tx, int ty)
        {
            FallingTree f = new FallingTree();
            f.Tx = tx;
            f.Ty = ty;
            f.Dur = GameConst.TreeFallDur;
            f.Life = f.Dur;
            float stumpX = (tx + 0.5f) * GameConst.Tile;
            f.Sign = PlayerPos.X < stumpX ? 1 : -1;
            if (FallingTrees.Count >= 8)
                FallingTrees.RemoveAt(0);
            FallingTrees.Add(f);
        }

        public bool TickFallingTrees(float dt)
        {
            bool landed = false;
            for (int i = FallingTrees.Count - 1; i >= 0; i--)
            {
                FallingTree f = FallingTrees[i];
                float before = f.Life;
                f.Life -= dt;
                if (before > 0.14f && f.Life <= 0.14f)
                    landed = true;
                if (f.Life <= 0f)
                    FallingTrees.RemoveAt(i);
            }
            return landed;
        }

        public Building FindBuilding(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;
            for (int i = 0; i < Buildings.Count; i++)
            {
                if (Buildings[i].Id == id)
                    return Buildings[i];
            }
            return null;
        }

        public static bool IsMovableFarmBuilding(Building b)
        {
            if (b == null)
                return false;
            if (b.Kind == BuildingKind.Cave || b.Kind == BuildingKind.Carpenter
                || b.Kind == BuildingKind.FishMarket || b.Kind == BuildingKind.Inn
                || b.Kind == BuildingKind.Home || b.Kind == BuildingKind.GeneralStore
                || b.Kind == BuildingKind.AnimalShop)
                return false;
            return b.X >= GameConst.FarmOx && GameConst.InFarmBand(b.Y);
        }

        public Building FarmBuildingAt(int tx, int ty)
        {
            Building best = null;
            int bestD = int.MaxValue;
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                if (!IsMovableFarmBuilding(b))
                    continue;
                int y0 = b.Y - 2;
                if (tx < b.X || tx >= b.X + b.FootW || ty < y0 || ty >= b.Y + b.FootH)
                    continue;
                int cy = b.Y + b.FootH / 2;
                int cx = b.X + b.FootW / 2;
                int d = Math.Abs(tx - cx) + Math.Abs(ty - cy);
                if (d < bestD)
                {
                    bestD = d;
                    best = b;
                }
            }
            return best;
        }

        public int MovableFarmBuildingCount()
        {
            int n = 0;
            for (int i = 0; i < Buildings.Count; i++)
            {
                if (IsMovableFarmBuilding(Buildings[i]))
                    n++;
            }
            return n;
        }

        public bool CanPlaceFarmBuilding(Building b, int x, int y)
        {
            if (b == null || !IsMovableFarmBuilding(b))
                return false;
            if (x < GameConst.FarmOx || y < GameConst.FarmOy)
                return false;
            if (x + b.FootW > GameConst.MapW || y + b.FootH > GameConst.CountryOy)
                return false;
            int doorX, doorY, pathX, pathY;
            int lx, ly;
            Building.DoorLocal(b.W, b.H, b.DoorDx, b.Rot, out lx, out ly);
            doorX = x + lx;
            doorY = y + ly;
            b.ApproachAt(x, y, b.Rot, out pathX, out pathY);
            if (doorX < 0 || doorX >= GameConst.MapW || pathX < 0 || pathX >= GameConst.MapW
                || pathY < 0 || pathY >= GameConst.MapH)
                return false;
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building other = Buildings[i];
                if (other == b)
                    continue;
                if (other.HitsRect(x, y, b.FootW, b.FootH))
                    return false;
                if (other.ApproachX >= x && other.ApproachX < x + b.FootW
                    && other.ApproachY >= y && other.ApproachY < y + b.FootH
                    && !MapGen.IsFarmRoad(other.ApproachX, other.ApproachY))
                    return false;
            }
            for (int dy = 0; dy < b.FootH; dy++)
            {
                for (int dx = 0; dx < b.FootW; dx++)
                {
                    int tx = x + dx;
                    int ty = y + dy;
                    if (!TileFreeForFarmMove(b, tx, ty))
                        return false;
                }
            }
            return DoorPathClear(b, pathX, pathY);
        }

        bool TileFreeForFarmMove(Building skip, int tx, int ty)
        {
            if (tx < GameConst.FarmOx || ty < GameConst.FarmOy || ty >= GameConst.CountryOy
                || tx >= GameConst.MapW)
                return false;
            if (Crops.ContainsKey(CropKey(tx, ty)))
                return false;
            if (AnimalStandsOn(tx, ty))
                return false;
            for (int i = 0; i < Decos.Count; i++)
            {
                if (Decos[i].X == tx && Decos[i].Y == ty)
                    return false;
            }
            if (skip != null && skip.ContainsTile(tx, ty))
                return true;
            if (skip != null && tx == skip.ApproachX && ty == skip.ApproachY)
                return true;
            TileType t = Tiles[tx, ty];
            if (t == TileType.Water || t == TileType.Tree || t == TileType.Rock || t == TileType.Cliff
                || t == TileType.Bin || t == TileType.Fence || t == TileType.Dummy || t == TileType.Mineral
                || t == TileType.Roof || t == TileType.HouseWall || t == TileType.Door || t == TileType.HouseWindow
                || t == TileType.Bridge || t == TileType.Dock || t == TileType.Stump || t == TileType.Counter
                || t == TileType.Bed || t == TileType.Chest)
                return false;
            return t == TileType.Grass || t == TileType.Flower || t == TileType.Weed || t == TileType.FarmSoil
                || t == TileType.Tilled || t == TileType.Wet || t == TileType.Path || t == TileType.Cobble
                || t == TileType.WoodsGrass || t == TileType.Hay || t == TileType.HayCut;
        }

        bool DoorPathClear(Building skip, int doorX, int pathY)
        {
            if (doorX < 0 || pathY < 0 || doorX >= GameConst.MapW || pathY >= GameConst.MapH)
                return false;
            if (skip != null && doorX == skip.ApproachX && pathY == skip.ApproachY)
                return true;
            if (MapGen.IsFarmRoad(doorX, pathY))
                return true;
            if (Crops.ContainsKey(CropKey(doorX, pathY)))
                return false;
            if (AnimalStandsOn(doorX, pathY))
                return false;
            TileType t = Tiles[doorX, pathY];
            return t == TileType.Grass || t == TileType.Path || t == TileType.Flower || t == TileType.Weed
                || t == TileType.FarmSoil || t == TileType.Tilled || t == TileType.Wet || t == TileType.Cobble;
        }

        bool AnimalStandsOn(int tx, int ty)
        {
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                int ax = (int)Math.Floor(a.Pos.X / GameConst.Tile);
                int ay = (int)Math.Floor(a.Pos.Y / GameConst.Tile);
                if (ax == tx && ay == ty)
                    return true;
            }
            return false;
        }

        public bool MoveFarmBuilding(Building b, int x, int y)
        {
            if (b == null)
                return false;
            if (b.X == x && b.Y == y)
                return true;
            if (!CanPlaceFarmBuilding(b, x, y))
                return false;
            UnstampFarmBuilding(b);
            b.X = x;
            b.Y = y;
            MapGen.StampBuilding(Tiles, b);
            if (Inside == b)
                OutdoorPos = b.OutdoorExit;
            return true;
        }

        public bool RotateFarmBuilding(Building b)
        {
            if (b == null || !IsMovableFarmBuilding(b))
                return false;
            int oldRot = b.Rot;
            int oldX = b.X;
            int oldY = b.Y;
            int oldFw = b.FootW;
            int oldFh = b.FootH;
            UnstampFarmBuilding(b);
            b.Rot = (b.Rot + 1) & 3;
            int nx = oldX + (oldFw - b.FootW) / 2;
            int ny = oldY + (oldFh - b.FootH) / 2;
            if (!CanPlaceFarmBuilding(b, nx, ny))
            {
                nx = oldX;
                ny = oldY;
            }
            if (!CanPlaceFarmBuilding(b, nx, ny))
            {
                b.Rot = oldRot;
                MapGen.StampBuilding(Tiles, b);
                return false;
            }
            b.X = nx;
            b.Y = ny;
            MapGen.StampBuilding(Tiles, b);
            if (Inside == b)
                OutdoorPos = b.OutdoorExit;
            return true;
        }

        void UnstampFarmBuilding(Building b)
        {
            if (b == null || Tiles == null)
                return;
            for (int dy = 0; dy < b.FootH; dy++)
            {
                for (int dx = 0; dx < b.FootW; dx++)
                {
                    int tx = b.X + dx;
                    int ty = b.Y + dy;
                    if (tx < 0 || ty < 0 || tx >= GameConst.MapW || ty >= GameConst.MapH)
                        continue;
                    TileType t = Tiles[tx, ty];
                    if (t == TileType.Roof || t == TileType.HouseWall || t == TileType.Door || t == TileType.HouseWindow)
                        Tiles[tx, ty] = MapGen.IsFarmRoad(tx, ty) ? TileType.Path : TileType.Grass;
                }
            }
            int px = b.ApproachX;
            int py = b.ApproachY;
            if (px >= 0 && py >= 0 && px < GameConst.MapW && py < GameConst.MapH)
            {
                if (Tiles[px, py] == TileType.Path && !MapGen.IsFarmRoad(px, py))
                    Tiles[px, py] = TileType.Grass;
            }
        }

        public void BeginFarmPlan()
        {
            PlanReturnId = Inside != null ? Inside.Id : "";
            if (Inside != null)
            {
                OutdoorPos = Inside.OutdoorExit;
                PlayerPos = OutdoorPos;
                Inside = null;
                InsideFloor = 0;
                DoorSwing = null;
                DoorOpenU = 0f;
                DoorForced = false;
                int tx = (int)Math.Floor(PlayerPos.X / GameConst.Tile);
                int ty = (int)Math.Floor(PlayerPos.Y / GameConst.Tile);
                OutdoorZone = ZoneAt(tx, ty);
            }
            ShareWorldView = true;
            ZoneName = "Harvest Hollow";
            Screen = Screen.Plan;
            if (MovableFarmBuildingCount() <= 0)
                ShowToast("No farm buildings to move.");
            else
                ShowToast("I'll mark the stakes. Click a building, then a patch of pasture.");
        }

        public void EndFarmPlan(bool keepShareWorld)
        {
            ShareWorldView = keepShareWorld;
            Building home = FindBuilding(PlanReturnId);
            PlanReturnId = "";
            if (home != null)
            {
                Inside = home;
                InsideFloor = 0;
                PlayerPos = home.InteriorSpawn;
                Dir = 3;
                ZoneName = home.Name;
                DoorSwing = home;
                DoorOpenU = 0f;
                Screen = Screen.Shop;
                ShowToast("Stakes are in. Come back if you want another move.");
                return;
            }
            Screen = Screen.Play;
            ShowToast("Stakes are in.");
        }

        public void WriteFarmSites(System.IO.BinaryWriter w)
        {
            w.Write(Buildings.Count);
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                w.Write(b.Id ?? "");
                w.Write(b.X);
                w.Write(b.Y);
                w.Write(b.Rot);
            }
        }

        public void ReadFarmSites(System.IO.BinaryReader r)
        {
            int n = r.ReadInt32();
            if (n < 0)
                n = 0;
            if (n > 256)
                n = 256;
            for (int i = 0; i < n; i++)
            {
                string id = r.ReadString();
                int x = r.ReadInt32();
                int y = r.ReadInt32();
                int rot = r.ReadInt32();
                Building house = FindBuilding(id);
                if (house == null)
                    continue;
                if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                    continue;
                house.X = x;
                house.Y = y;
                house.Rot = rot & 3;
            }
        }

        public Building SiloAt(int tx, int ty)
        {
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                if (b.Kind != BuildingKind.Silo)
                    continue;
                if (b.ContainsTile(tx, ty) || (tx == b.ApproachX && ty == b.ApproachY))
                    return b;
            }
            return null;
        }

        public void UseSilo()
        {
            int have = CountItem("hay");
            if (have > 0)
            {
                int room = GameConst.SiloCapacity - HayInSilo;
                if (room <= 0)
                {
                    ShowToast("The silo is packed full (" + HayInSilo.ToString() + "/"
                        + GameConst.SiloCapacity.ToString() + ").");
                    return;
                }
                int n = have < room ? have : room;
                if (!TakeItem("hay", n))
                    return;
                HayInSilo += n;
                ShowToast("Stored " + n.ToString() + " hay. Silo " + HayInSilo.ToString()
                    + "/" + GameConst.SiloCapacity.ToString() + ".");
                return;
            }
            if (HayInSilo <= 0)
            {
                ShowToast("The silo is empty. Cut a hayfield with the scythe.");
                return;
            }
            int take = HayInSilo < 99 ? HayInSilo : 99;
            int before = CountItem("hay");
            AddItem("hay", take);
            int got = CountItem("hay") - before;
            if (got <= 0)
            {
                ShowToast("Your satchel is full.");
                return;
            }
            HayInSilo -= got;
            ShowToast("Took " + got.ToString() + " hay. Silo " + HayInSilo.ToString()
                + "/" + GameConst.SiloCapacity.ToString() + ".");
        }

        string CutHay(int tx, int ty)
        {
            if (!SpendEnergy(1))
                return "fail";
            SetTile(tx, ty, TileType.HayCut);
            _hayTimers[CropKey(tx, ty)] = GameConst.HayRegrowMinutes;
            int n = 1;
            if (((tx * 13 + ty * 7) & 3) == 0)
                n = 2;
            AddItem("hay", n);
            ShowToast(n == 1 ? "Cut hay." : "Cut hay. +2");
            return "scythe";
        }

        void TickHay(float dt)
        {
            if (Tiles == null)
                return;
            List<string> keys = new List<string>(_hayTimers.Keys);
            for (int i = 0; i < keys.Count; i++)
            {
                string k = keys[i];
                float left = _hayTimers[k] - dt * GameConst.MinutesPerSecond;
                if (left > 0f)
                {
                    _hayTimers[k] = left;
                    continue;
                }
                _hayTimers.Remove(k);
                string[] xy = k.Split(',');
                int x, y;
                if (xy.Length < 2 || !int.TryParse(xy[0], out x) || !int.TryParse(xy[1], out y))
                    continue;
                if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                    continue;
                if (Tiles[x, y] == TileType.HayCut)
                    Tiles[x, y] = TileType.Hay;
            }
        }

        void GrowAllHay()
        {
            if (Tiles == null)
                return;
            for (int y = GameConst.FarmOy; y < GameConst.CountryOy; y++)
            {
                for (int x = GameConst.FarmOx; x < GameConst.MapW; x++)
                {
                    if (Tiles[x, y] == TileType.HayCut)
                        Tiles[x, y] = TileType.Hay;
                }
            }
            _hayTimers.Clear();
        }

        public int CountHayTiles()
        {
            int n = 0;
            if (Tiles == null)
                return 0;
            for (int y = GameConst.FarmOy; y < GameConst.CountryOy; y++)
            {
                for (int x = GameConst.FarmOx; x < GameConst.MapW; x++)
                {
                    if (Tiles[x, y] == TileType.Hay || Tiles[x, y] == TileType.HayCut)
                        n++;
                }
            }
            return n;
        }

        public void CapturePeer(FarmerPeer p)
        {
            p.Used = true;
            p.Pos = PlayerPos;
            p.Dir = Dir;
            p.Moving = Moving;
            p.Anim = Anim;
            p.Gold = Gold;
            p.Energy = Energy;
            p.CanWater = CanWater;
            p.Selected = Selected;
            p.PackUpgrades = PackUpgrades;
            p.ShippedTonight = ShippedTonight;
            p.FaceX = Face.X;
            p.FaceY = Face.Y;
            p.SwingT = SwingT;
            p.SwingDur = SwingDur;
            p.SwingAct = SwingAct ?? "";
            p.ActionLock = ActionLock;
            p.ZoneName = ZoneName ?? "";
            p.OutdoorZone = OutdoorZone ?? "";
            p.OutdoorPos = OutdoorPos;
            p.InsideId = Inside != null ? Inside.Id : "";
            p.InsideFloor = InsideFloor;
            p.PendingFish = PendingFish ?? "";
            p.HeldId = "";
            ItemDef held = HeldItem();
            if (held != null && !Bar[Selected].Empty)
                p.HeldId = held.Id;
            p.Look = Look;
            p.Skills.CopyFrom(Skills);
            CopySlots(Bar, p.Bar);
            CopySlots(Pack, p.Pack);
        }

        public void ApplyPeer(FarmerPeer p)
        {
            PlayerPos = p.Pos;
            Dir = p.Dir;
            Moving = p.Moving;
            Anim = p.Anim;
            Gold = p.Gold;
            Energy = p.Energy;
            CanWater = p.CanWater;
            Selected = p.Selected;
            PackUpgrades = p.PackUpgrades;
            ShippedTonight = p.ShippedTonight;
            Face = new Point(p.FaceX, p.FaceY);
            SwingT = p.SwingT;
            SwingDur = p.SwingDur;
            SwingAct = p.SwingAct ?? "";
            ActionLock = p.ActionLock;
            ZoneName = p.ZoneName;
            OutdoorZone = p.OutdoorZone;
            OutdoorPos = p.OutdoorPos;
            Inside = FindBuilding(p.InsideId);
            InsideFloor = p.InsideFloor;
            PendingFish = string.IsNullOrEmpty(p.PendingFish) ? null : p.PendingFish;
            Look = p.Look;
            Skills.CopyFrom(p.Skills);
            CopySlots(p.Bar, Bar);
            CopySlots(p.Pack, Pack);
        }

        public void ApplyInventoryFromPeer(FarmerPeer p)
        {
            Gold = p.Gold;
            Energy = p.Energy;
            CanWater = p.CanWater;
            Selected = p.Selected;
            PackUpgrades = p.PackUpgrades;
            ShippedTonight = p.ShippedTonight;
            PendingFish = string.IsNullOrEmpty(p.PendingFish) ? null : p.PendingFish;
            CopySlots(p.Bar, Bar);
            CopySlots(p.Pack, Pack);
            Skills.CopyFrom(p.Skills);
        }

        public void ApplyVisualPeer(FarmerPeer p)
        {
            PlayerPos = p.Pos;
            Dir = p.Dir;
            Moving = p.Moving;
            Anim = p.Anim;
            Face = new Point(p.FaceX, p.FaceY);
            SwingT = p.SwingT;
            SwingDur = p.SwingDur;
            SwingAct = p.SwingAct ?? "";
            ZoneName = p.ZoneName;
            OutdoorZone = p.OutdoorZone;
            OutdoorPos = p.OutdoorPos;
            Inside = FindBuilding(p.InsideId);
            InsideFloor = p.InsideFloor;
        }

        static void CopySlots(InvSlot[] from, InvSlot[] to)
        {
            int n = from.Length < to.Length ? from.Length : to.Length;
            for (int i = 0; i < n; i++)
            {
                to[i].Id = from[i].Id;
                to[i].Count = from[i].Count;
            }
        }

        public void WriteAnimals(System.IO.BinaryWriter w)
        {
            w.Write(Animals.Count);
            for (int i = 0; i < Animals.Count; i++)
            {
                FarmAnimal a = Animals[i];
                w.Write((byte)a.Kind);
                w.Write(a.Pos.X);
                w.Write(a.Pos.Y);
                w.Write(a.Dir);
                w.Write(a.MilkedToday);
                w.Write(a.HasWool);
                w.Write(a.LastShearDay);
            }
        }

        public void ReadAnimals(System.IO.BinaryReader r)
        {
            ReadAnimals(r, SaveGame.Version);
        }

        public void ReadAnimals(System.IO.BinaryReader r, int ver)
        {
            Animals.Clear();
            int n = r.ReadInt32();
            if (n < 0)
                n = 0;
            if (n > AnimalCatalog.MaxOnFarm)
                n = AnimalCatalog.MaxOnFarm;
            for (int i = 0; i < n; i++)
            {
                FarmAnimal a = new FarmAnimal();
                int k = r.ReadByte();
                if (k < 0 || k >= AnimalCatalog.Count)
                    k = 0;
                a.Kind = (AnimalKind)k;
                a.Pos = new Vector2(r.ReadSingle(), r.ReadSingle());
                a.Dir = r.ReadInt32();
                if (a.Dir < 0 || a.Dir > 3)
                    a.Dir = 0;
                if (ver >= 7)
                    a.MilkedToday = r.ReadBoolean();
                if (ver >= 8)
                {
                    a.HasWool = r.ReadBoolean();
                    a.LastShearDay = r.ReadInt32();
                }
                a.Wander = a.Pos;
                a.WanderT = 0.5f;
                Animals.Add(a);
            }
        }

        public void WriteWorldBody(System.IO.BinaryWriter w)
        {
            w.Write(Day);
            w.Write(Minutes);
            w.Write(Raining);
            w.Write(Storming);
            w.Write(StormDay);
            int mw = GameConst.MapW;
            int mh = GameConst.MapH;
            w.Write(mw);
            w.Write(mh);
            for (int y = 0; y < mh; y++)
            {
                for (int x = 0; x < mw; x++)
                    w.Write((byte)Tiles[x, y]);
            }
            w.Write(Crops.Count);
            foreach (KeyValuePair<string, Crop> kv in Crops)
            {
                w.Write(kv.Key);
                w.Write(kv.Value.Id ?? "");
                w.Write(kv.Value.Stage);
                w.Write(kv.Value.Watered);
            }
            w.Write(TreeHits.Count);
            foreach (KeyValuePair<string, int> kv in TreeHits)
            {
                w.Write(kv.Key);
                w.Write(kv.Value);
            }
            w.Write(RockHits.Count);
            foreach (KeyValuePair<string, int> kv in RockHits)
            {
                w.Write(kv.Key);
                w.Write(kv.Value);
            }
            w.Write(Trolls.Count);
            for (int i = 0; i < Trolls.Count; i++)
            {
                CaveTroll t = Trolls[i];
                w.Write(t.Pos.X);
                w.Write(t.Pos.Y);
                w.Write(t.Dir);
                w.Write(t.Anim);
                w.Write(t.Moving);
                w.Write(t.Hp);
                w.Write(t.MaxHp);
                w.Write(t.HurtT);
                w.Write(t.Alive);
                w.Write(t.Kind);
            }
            WriteHiddenWalls(w);
        }

        public void ReadWorldBody(System.IO.BinaryReader r, int ver)
        {
            Day = r.ReadInt32();
            Minutes = r.ReadSingle();
            Raining = r.ReadBoolean();
            Storming = r.ReadBoolean();
            StormDay = r.ReadBoolean();
            int mw;
            int mh;
            if (ver >= 2)
            {
                mw = r.ReadInt32();
                mh = r.ReadInt32();
                if (mw < 8)
                    mw = 8;
                if (mh < 8)
                    mh = 8;
            }
            else
            {
                mw = GameConst.MapW;
                mh = GameConst.LegacyMapH;
            }
            TileType[,] loaded = new TileType[mw, mh];
            for (int y = 0; y < mh; y++)
            {
                for (int x = 0; x < mw; x++)
                    loaded[x, y] = (TileType)r.ReadByte();
            }
            _savedOutdoorW = mw;
            _savedOutdoorH = mh;
            int copyW = mw < GameConst.MapW ? mw : GameConst.MapW;
            int copyH = mh < GameConst.MapH ? mh : GameConst.MapH;
            for (int y = 0; y < copyH; y++)
            {
                for (int x = 0; x < copyW; x++)
                    Tiles[x, y] = loaded[x, y];
            }
            Crops.Clear();
            int cc = r.ReadInt32();
            for (int i = 0; i < cc; i++)
            {
                string key = r.ReadString();
                Crop c = new Crop();
                c.Id = r.ReadString();
                c.Stage = r.ReadInt32();
                c.Watered = r.ReadBoolean();
                Crops[key] = c;
            }
            TreeHits.Clear();
            int tc = r.ReadInt32();
            for (int i = 0; i < tc; i++)
            {
                string key = r.ReadString();
                TreeHits[key] = r.ReadInt32();
            }
            RockHits.Clear();
            int rc = r.ReadInt32();
            for (int i = 0; i < rc; i++)
            {
                string key = r.ReadString();
                RockHits[key] = r.ReadInt32();
            }
            Trolls.Clear();
            int tn = r.ReadInt32();
            for (int i = 0; i < tn; i++)
            {
                CaveTroll t = new CaveTroll();
                t.Pos = new Vector2(r.ReadSingle(), r.ReadSingle());
                t.Dir = r.ReadInt32();
                t.Anim = r.ReadSingle();
                t.Moving = r.ReadBoolean();
                t.Hp = r.ReadInt32();
                t.MaxHp = r.ReadInt32();
                t.HurtT = r.ReadSingle();
                t.Alive = r.ReadBoolean();
                t.Kind = ver >= 3 ? CaveMobCatalog.Clamp(r.ReadInt32()) : (int)CaveMobKind.Troll;
                Trolls.Add(t);
            }
            if (ver >= 6)
                ReadHiddenWalls(r);
        }

        void WriteHiddenWalls(System.IO.BinaryWriter w)
        {
            int n = 0;
            if (HiddenWall != null)
            {
                for (int y = 0; y < GameConst.MapH; y++)
                {
                    for (int x = 0; x < GameConst.MapW; x++)
                    {
                        if (HiddenWall[x, y])
                            n++;
                    }
                }
            }
            w.Write(n);
            if (n <= 0 || HiddenWall == null)
                return;
            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (!HiddenWall[x, y])
                        continue;
                    w.Write(x);
                    w.Write(y);
                }
            }
        }

        void ReadHiddenWalls(System.IO.BinaryReader r)
        {
            if (HiddenWall == null)
                HiddenWall = new bool[GameConst.MapW, GameConst.MapH];
            else
            {
                for (int y = 0; y < GameConst.MapH; y++)
                {
                    for (int x = 0; x < GameConst.MapW; x++)
                        HiddenWall[x, y] = false;
                }
            }
            int n = r.ReadInt32();
            if (n < 0)
                n = 0;
            int cap = GameConst.MapW * GameConst.MapH;
            if (n > cap)
                n = cap;
            for (int i = 0; i < n; i++)
            {
                int x = r.ReadInt32();
                int y = r.ReadInt32();
                if (x >= 0 && y >= 0 && x < GameConst.MapW && y < GameConst.MapH)
                    HiddenWall[x, y] = true;
            }
        }

        public void WriteSave(System.IO.BinaryWriter w)
        {
            Look.Write(w);
            w.Write(PlayerPos.X);
            w.Write(PlayerPos.Y);
            w.Write(Dir);
            w.Write(Inside != null ? Inside.Id : "");
            w.Write(OutdoorPos.X);
            w.Write(OutdoorPos.Y);
            w.Write(OutdoorZone ?? "");
            w.Write(ZoneName ?? "");
            w.Write(Gold);
            w.Write(Energy);
            w.Write(CanWater);
            w.Write(Selected);
            w.Write(PackUpgrades);
            w.Write(ShippedTonight);
            w.Write(PendingFish ?? "");
            WriteSlots(w, Bar, Bar.Length);
            WriteSlots(w, Pack, Pack.Length);
            Skills.Write(w);
            WriteWorldBody(w);
            w.Write(Buildings.Count);
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                w.Write(b.Id ?? "");
                w.Write(b.Iw);
                w.Write(b.Ih);
                w.Write(b.X);
                w.Write(b.Y);
                w.Write(b.Rot);
                w.Write((int)b.Kind);
                w.Write(b.W);
                w.Write(b.H);
                w.Write(b.DoorDx);
                w.Write(b.Style);
                w.Write(b.Name ?? "");
                w.Write(b.Repaired);
                for (int y = 0; y < b.Ih; y++)
                {
                    for (int x = 0; x < b.Iw; x++)
                        w.Write((byte)b.Interior[x, y]);
                }
            }
            w.Write(Bridges.Count);
            for (int i = 0; i < Bridges.Count; i++)
            {
                StoneBridge b = Bridges[i];
                w.Write(b.X);
                w.Write(b.Y);
                w.Write(b.W);
                w.Write(b.H);
                w.Write(b.NorthSouth);
            }
            w.Write(InsideFloor);
            w.Write(CaveChestsLooted);
            w.Write(PackFarmRepairs());
            WriteAnimals(w);
            w.Write(HayInSilo);
            WriteMapExtras(w);
        }

        public void ReadSave(System.IO.BinaryReader r, int ver)
        {
            _loadedSaveVer = ver;
            Look = FarmerLook.ReadFrom(r);
            PlayerPos = new Vector2(r.ReadSingle(), r.ReadSingle());
            Dir = r.ReadInt32();
            string insideId = r.ReadString();
            OutdoorPos = new Vector2(r.ReadSingle(), r.ReadSingle());
            OutdoorZone = r.ReadString();
            ZoneName = r.ReadString();
            Gold = r.ReadInt32();
            Energy = r.ReadInt32();
            CanWater = r.ReadInt32();
            Selected = r.ReadInt32();
            PackUpgrades = r.ReadInt32();
            if (PackUpgrades < 0) PackUpgrades = 0;
            if (PackUpgrades > GameConst.PackUpgradeMax) PackUpgrades = GameConst.PackUpgradeMax;
            ShippedTonight = r.ReadInt32();
            string fish = r.ReadString();
            PendingFish = string.IsNullOrEmpty(fish) ? null : fish;
            ReadSlots(r, Bar);
            ReadSlots(r, Pack);
            Skills.Read(r);
            ReadWorldBody(r, ver);
            int bc = r.ReadInt32();
            for (int i = 0; i < bc; i++)
            {
                string id = r.ReadString();
                int iw = r.ReadInt32();
                int ih = r.ReadInt32();
                int savedX = 0;
                int savedY = 0;
                int savedRot = 0;
                bool hasSite = ver >= 4;
                if (hasSite)
                {
                    savedX = r.ReadInt32();
                    savedY = r.ReadInt32();
                    if (ver >= 5)
                        savedRot = r.ReadInt32();
                }
                int kindI = 0;
                int bw = 0;
                int bh = 0;
                int doorDx = 0;
                int style = 0;
                string houseName = "";
                bool repaired = true;
                if (ver >= 9)
                {
                    kindI = r.ReadInt32();
                    bw = r.ReadInt32();
                    bh = r.ReadInt32();
                    doorDx = r.ReadInt32();
                    style = r.ReadInt32();
                    houseName = r.ReadString();
                    repaired = r.ReadBoolean();
                }
                Building house = FindBuilding(id);
                if (house == null && ver >= 9 && bw > 0 && bh > 0 && Buildings.Count < 256)
                {
                    if (kindI < 0 || kindI > (int)BuildingKind.Silo)
                        kindI = (int)BuildingKind.Home;
                    if (string.IsNullOrEmpty(houseName))
                        houseName = "House";
                    house = Building.Make(id, houseName, savedX, savedY, bw, bh, doorDx, style, (BuildingKind)kindI);
                    house.Rot = savedRot & 3;
                    house.Repaired = repaired;
                    if (house.IsFarmOutbuilding)
                    {
                        house.Name = house.RepairName;
                        house.RebuildInterior();
                    }
                    Buildings.Add(house);
                }
                if (hasSite && house != null && savedX >= 0 && savedY >= 0
                    && savedX < GameConst.MapW && savedY < GameConst.MapH)
                {
                    house.X = savedX;
                    house.Y = savedY;
                    house.Rot = savedRot & 3;
                }
                bool skipCave = house != null && house.Kind == BuildingKind.Cave;
                for (int y = 0; y < ih; y++)
                {
                    for (int x = 0; x < iw; x++)
                    {
                        TileType t = (TileType)r.ReadByte();
                        if (skipCave)
                            continue;
                        if (house != null && house.Interior != null && x < house.Iw && y < house.Ih)
                            house.Interior[x, y] = t;
                    }
                }
            }
            Bridges.Clear();
            int br = r.ReadInt32();
            for (int i = 0; i < br; i++)
            {
                StoneBridge b = new StoneBridge();
                b.X = r.ReadInt32();
                b.Y = r.ReadInt32();
                b.W = r.ReadInt32();
                b.H = r.ReadInt32();
                b.NorthSouth = r.ReadBoolean();
                Bridges.Add(b);
            }
            if (r.BaseStream.Position < r.BaseStream.Length)
            {
                InsideFloor = r.ReadInt32();
                if (InsideFloor < 0)
                    InsideFloor = 0;
                if (InsideFloor >= CaveGen.Levels)
                    InsideFloor = CaveGen.Levels - 1;
            }
            if (r.BaseStream.Position < r.BaseStream.Length)
                CaveChestsLooted = r.ReadInt32();
            if (r.BaseStream.Position < r.BaseStream.Length)
                FarmRepairs = r.ReadInt32();
            if (r.BaseStream.Position < r.BaseStream.Length)
                ReadAnimals(r, ver);
            if (r.BaseStream.Position < r.BaseStream.Length)
            {
                HayInSilo = r.ReadInt32();
                if (HayInSilo < 0)
                    HayInSilo = 0;
                if (HayInSilo > GameConst.SiloCapacity)
                    HayInSilo = GameConst.SiloCapacity;
            }
            if (ver >= 6 && r.BaseStream.Position < r.BaseStream.Length)
                ReadMapExtras(r);
            Inside = FindBuilding(insideId);
            ShareWorldView = false;
            Screen = Screen.Title;
            if (Selected < 0 || Selected >= Bar.Length)
                Selected = 0;
            if (Energy < 0) Energy = 0;
            if (Energy > GameConst.MaxEnergy) Energy = GameConst.MaxEnergy;
            ScaleLegacyPixels();
        }

        /// <summary>
        /// 16px-tile saves store positions in a smaller pixel space.
        /// After returning to 32px tiles, those positions are doubled.
        /// </summary>
        void ScaleLegacyPixels()
        {
            float max16X = GameConst.LegacyMapW * 16 + 64f;
            float max16Y = GameConst.LegacyMapH * 16 + 64f;
            if (PlayerPos.X > max16X || PlayerPos.Y > max16Y)
                return;
            PlayerPos *= 2f;
            OutdoorPos *= 2f;
            for (int i = 0; i < Trolls.Count; i++)
                Trolls[i].Pos *= 2f;
            for (int i = 0; i < Animals.Count; i++)
                Animals[i].Pos *= 2f;
            for (int i = 0; i < CaveGuests.Count; i++)
                CaveGuests[i].Pos *= 2f;
        }

        public void RemeshOutdoorKeepingFarm()
        {
            TileType[,] old = Tiles;
            bool restoreExtras = _loadedSaveVer >= 6;
            List<StoneBridge> keepBridges = restoreExtras ? new List<StoneBridge>(Bridges) : null;
            List<Deco> keepDecos = restoreExtras ? new List<Deco>(Decos) : null;
            List<GateSign> keepGates = restoreExtras ? new List<GateSign>(Gates) : null;
            Gates.Clear();
            Bridges.Clear();
            Decos.Clear();
            Tiles = MapGen.Build(Buildings);
            MapGen.CarveZoneGates(Tiles, Gates);
            MapGen.ConnectRoads(Tiles, Buildings);
            MapGen.ScatterRoadsideStone(Tiles);
            MapGen.PlaceBridges(Tiles, Bridges);
            MapGen.PlaceProps(Tiles, Decos);
            MapGen.ScatterBeachForage(Tiles);
            int oy = GameConst.FarmOy;
            int y1 = GameConst.CountryOy;
            int farmW = GameConst.MapW - GameConst.FarmOx;
            int oldW = old.GetLength(0);
            int oldH = old.GetLength(1);
            int savedW = _savedOutdoorW > 0 ? _savedOutdoorW : oldW;
            int savedH = _savedOutdoorH > 0 ? _savedOutdoorH : oldH;
            if (savedW > oldW)
                savedW = oldW;
            if (savedH > oldH)
                savedH = oldH;
            int oldOx = savedW >= GameConst.MapW ? GameConst.FarmOx : savedW - farmW;
            if (oldOx < 0)
                oldOx = 0;
            int dx = GameConst.FarmOx - oldOx;
            if (dx != 0)
                ShiftOutdoorX(dx, savedW, savedH);
            int oldBeachOy = savedH - GameConst.LegacyBeachH;
            if (oldBeachOy < GameConst.CountryOy)
                oldBeachOy = GameConst.CountryOy;
            int dy = GameConst.BeachOy - oldBeachOy;
            if (dy != 0)
                ShiftOutdoorY(dy, oldBeachOy, savedW, savedH);
            bool same = savedW == GameConst.MapW && savedH == GameConst.MapH;
            if (same)
            {
                for (int y = 0; y < savedH; y++)
                {
                    for (int x = 0; x < savedW; x++)
                        Tiles[x, y] = old[x, y];
                }
            }
            else
            {
                for (int y = oy; y < y1; y++)
                {
                    if (y >= savedH)
                        break;
                    for (int i = 0; i < farmW; i++)
                    {
                        int ox = oldOx + i;
                        int nx = GameConst.FarmOx + i;
                        if (ox >= savedW || nx >= GameConst.MapW)
                            break;
                        TileType o = old[ox, y];
                        TileType n = Tiles[nx, y];
                        if (o == TileType.FarmSoil || o == TileType.Tilled || o == TileType.Wet || o == TileType.Weed)
                        {
                            if (n == TileType.Grass || n == TileType.FarmSoil || n == TileType.Flower || n == TileType.Path)
                                Tiles[nx, y] = o;
                        }
                        else if (o == TileType.Fence)
                        {
                            if (n == TileType.Grass || n == TileType.FarmSoil || n == TileType.Path || n == TileType.Flower
                                || n == TileType.Hay || n == TileType.HayCut)
                                Tiles[nx, y] = TileType.Fence;
                        }
                        else if (o == TileType.Hay || o == TileType.HayCut)
                        {
                            if (n == TileType.Grass || n == TileType.Hay || n == TileType.HayCut || n == TileType.Flower)
                                Tiles[nx, y] = o;
                        }
                    }
                }
            }
            for (int i = 0; i < Buildings.Count; i++)
                MapGen.StampBuilding(Tiles, Buildings[i]);
            foreach (KeyValuePair<string, Crop> kv in Crops)
            {
                string[] parts = kv.Key.Split(',');
                int cx, cy;
                if (parts.Length < 2 || !int.TryParse(parts[0], out cx) || !int.TryParse(parts[1], out cy))
                    continue;
                if (cx < 0 || cy < 0 || cx >= GameConst.MapW || cy >= GameConst.MapH)
                    continue;
                TileType ground = Tiles[cx, cy];
                if (ground == TileType.Grass || ground == TileType.Path || ground == TileType.Flower
                    || ground == TileType.FarmSoil || ground == TileType.Tilled || ground == TileType.Wet)
                    Tiles[cx, cy] = kv.Value.Watered ? TileType.Wet : TileType.Tilled;
            }
            if (restoreExtras)
            {
                if (keepBridges != null && keepBridges.Count > 0)
                {
                    Bridges.Clear();
                    for (int i = 0; i < keepBridges.Count; i++)
                        Bridges.Add(keepBridges[i]);
                }
                if (keepDecos != null && keepDecos.Count > 0)
                {
                    Decos.Clear();
                    for (int i = 0; i < keepDecos.Count; i++)
                        Decos.Add(keepDecos[i]);
                }
                if (keepGates != null && keepGates.Count > 0)
                {
                    Gates.Clear();
                    for (int i = 0; i < keepGates.Count; i++)
                        Gates.Add(keepGates[i]);
                }
            }
            RecordMineralSpawns();
            _savedOutdoorW = GameConst.MapW;
            _savedOutdoorH = GameConst.MapH;
        }

        void ShiftOutdoorX(int dx, int oldW, int oldH)
        {
            if (dx == 0)
                return;
            float px = dx * GameConst.Tile;
            if (Inside == null)
                PlayerPos.X += px;
            OutdoorPos.X += px;
            for (int i = 0; i < Animals.Count; i++)
                Animals[i].Pos.X += px;
            RemapHitKeys(Crops, dx, 0, 0, oldW, oldH);
            RemapIntKeys(TreeHits, dx, 0, 0, oldW, oldH);
            RemapIntKeys(RockHits, dx, 0, 0, oldW, oldH);
        }

        void ShiftOutdoorY(int dy, int yCut, int oldW, int oldH)
        {
            if (dy == 0)
                return;
            float py = dy * GameConst.Tile;
            float cut = yCut * GameConst.Tile;
            if (Inside == null && PlayerPos.Y >= cut)
                PlayerPos.Y += py;
            if (OutdoorPos.Y >= cut)
                OutdoorPos.Y += py;
            for (int i = 0; i < Animals.Count; i++)
            {
                if (Animals[i].Pos.Y >= cut)
                    Animals[i].Pos.Y += py;
            }
            RemapHitKeys(Crops, 0, dy, yCut, oldW, oldH);
            RemapIntKeys(TreeHits, 0, dy, yCut, oldW, oldH);
            RemapIntKeys(RockHits, 0, dy, yCut, oldW, oldH);
        }

        void RemapHitKeys(Dictionary<string, Crop> src, int dx, int dy, int yCut, int oldW, int oldH)
        {
            Dictionary<string, Crop> next = new Dictionary<string, Crop>();
            foreach (KeyValuePair<string, Crop> kv in src)
            {
                string[] parts = kv.Key.Split(',');
                int cx, cy;
                if (parts.Length < 2 || !int.TryParse(parts[0], out cx) || !int.TryParse(parts[1], out cy))
                {
                    next[kv.Key] = kv.Value;
                    continue;
                }
                if (cy >= 0 && cy < oldH && cx >= 0 && cx < oldW)
                {
                    cx += dx;
                    if (dy != 0 && cy >= yCut)
                        cy += dy;
                }
                next[CropKey(cx, cy)] = kv.Value;
            }
            src.Clear();
            foreach (KeyValuePair<string, Crop> kv in next)
                src[kv.Key] = kv.Value;
        }

        void RemapIntKeys(Dictionary<string, int> src, int dx, int dy, int yCut, int oldW, int oldH)
        {
            Dictionary<string, int> next = new Dictionary<string, int>();
            foreach (KeyValuePair<string, int> kv in src)
            {
                if (kv.Key != null && kv.Key.StartsWith("in:"))
                {
                    next[kv.Key] = kv.Value;
                    continue;
                }
                string[] parts = kv.Key.Split(',');
                int cx, cy;
                if (parts.Length < 2 || !int.TryParse(parts[0], out cx) || !int.TryParse(parts[1], out cy))
                {
                    next[kv.Key] = kv.Value;
                    continue;
                }
                if (cy >= 0 && cy < oldH && cx >= 0 && cx < oldW)
                {
                    cx += dx;
                    if (dy != 0 && cy >= yCut)
                        cy += dy;
                }
                next[CropKey(cx, cy)] = kv.Value;
            }
            src.Clear();
            foreach (KeyValuePair<string, int> kv in next)
                src[kv.Key] = kv.Value;
        }

        public void RebuildHouseInteriors()
        {
            for (int i = 0; i < Buildings.Count; i++)
            {
                Building b = Buildings[i];
                if (b.Kind == BuildingKind.Cave)
                    continue;
                b.RebuildInterior();
            }
            if (Inside == null || Inside.Kind == BuildingKind.Cave)
                return;
            int tx = (int)System.Math.Floor(PlayerPos.X / GameConst.Tile);
            int ty = (int)System.Math.Floor(PlayerPos.Y / GameConst.Tile);
            InsideFloor = 0;
            if (IsSolid(TileAt(tx, ty)))
                PlayerPos = Inside.InteriorSpawn;
        }

        static void WriteSlots(System.IO.BinaryWriter w, InvSlot[] slots, int n)
        {
            w.Write(n);
            for (int i = 0; i < n; i++)
            {
                w.Write(slots[i].Id ?? "");
                w.Write(slots[i].Count);
            }
        }

        static void ReadSlots(System.IO.BinaryReader r, InvSlot[] slots)
        {
            int n = r.ReadInt32();
            for (int i = 0; i < n; i++)
            {
                string id = r.ReadString();
                int c = r.ReadInt32();
                if (i < slots.Length)
                    slots[i].Set(string.IsNullOrEmpty(id) ? null : id, c);
            }
            for (int i = n; i < slots.Length; i++)
                slots[i].Clear();
        }

        public void FillDefaultInventory()
        {
            for (int i = 0; i < Bar.Length; i++)
                Bar[i].Clear();
            for (int i = 0; i < Pack.Length; i++)
                Pack[i].Clear();
            Bar[0].Set("hoe", 1);
            Bar[1].Set("can", 1);
            Bar[2].Set("scythe", 1);
            Bar[3].Set("axe", 1);
            Bar[4].Set(ItemCatalog.SeedId("turnip"), 15);
            Bar[5].Set(ItemCatalog.SeedId("potato"), 8);
            Bar[6].Set(ItemCatalog.SeedId("cabbage"), 5);
            Bar[7].Set(ItemCatalog.SeedId("melon"), 3);
            Bar[8].Set("rod", 1);
            Pack[0].Set(ItemCatalog.SeedId("pumpkin"), 1);
            Pack[1].Set("pickaxe", 1);
            Pack[2].Set("sword", 1);
            Pack[3].Set("plank", GameConst.TestPlanks);
            Pack[4].Set("pail", 1);
            Pack[5].Set("shears", 1);
            Gold = 500;
            Energy = GameConst.MaxEnergy;
            CanWater = GameConst.CanCapacity;
            PackUpgrades = 0;
            Selected = 0;
            ShippedTonight = 0;
            Skills.Reset();
        }

        public bool SpendSkillPoint(int skill)
        {
            if (!Skills.Spend((SkillId)skill))
            {
                ShowToast(Skills.Points <= 0 ? "No skill points to spend." : "That skill is maxed.");
                return false;
            }
            ShowToast(SkillSet.Names[skill] + " " + Skills.Level[skill].ToString() + ".");
            return true;
        }
    }
}
