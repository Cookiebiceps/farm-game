using System;
using System.Collections.Generic;

namespace HarvestHollow
{
    public static class MapGen
    {
        static int Vx(int x)
        {
            return x + GameConst.ShadeW;
        }

        public static void RegisterHouses(List<Building> houses)
        {
            int ox = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            houses.Add(Building.Make("cottage", "Your Cottage", 7 + ox, 1 + oy, 7, 5, 3, 0, BuildingKind.Cottage));
            houses.Add(Building.Make("barn", "Broken Barn", 2 + ox, 32 + oy, 8, 6, 3, 8, BuildingKind.Barn));
            houses.Add(Building.Make("greenhouse", "Broken Greenhouse", 12 + ox, 32 + oy, 7, 5, 3, 9, BuildingKind.Greenhouse));
            houses.Add(Building.Make("coop", "Broken Chicken Coop", 2 + ox, 42 + oy, 6, 4, 2, 10, BuildingKind.Coop));
            houses.Add(Building.Make("silo", "Silo", 23 + ox, 32 + oy, 2, 3, 0, 11, BuildingKind.Silo));
            houses.Add(Building.Make("rowan", "Rowan's Shop", 32 + ox, 1 + oy, 6, 5, 2, 1, BuildingKind.Shop));
            houses.Add(Building.Make("mira-home", "Quiet Cottage", Vx(26), 6, 6, 5, 2, 2, BuildingKind.Home));
            houses.Add(Building.Make("inn", "Hearth Inn", Vx(38), 5, 9, 6, 4, 3, BuildingKind.Inn));
            houses.Add(Building.Make("cob", "Cob's Cabin", Vx(56), 8, 6, 5, 2, 2, BuildingKind.Home));
            houses.Add(Building.Make("ash", "Ash's Forge", Vx(56), 18, 7, 5, 1, 4, BuildingKind.Carpenter));
            houses.Add(Building.Make("bess", "Bess's Stockyard", Vx(56), 38, 7, 5, 3, 1, BuildingKind.AnimalShop));
            houses.Add(Building.Make("piper", "Piper's Market", Vx(34), 28, 8, 6, 3, 1, BuildingKind.GeneralStore));
            houses.Add(Building.Make("lila", "Lila's Bakehouse", Vx(18), 30, 6, 5, 2, 2, BuildingKind.Home));
            houses.Add(Building.Make("bram", "Bram's Lodge", Vx(48), 30, 6, 5, 2, 0, BuildingKind.Home));
            houses.Add(Building.Make("nell", "Nell's Garden House", Vx(6), 44, 6, 5, 2, 2, BuildingKind.Home));
            houses.Add(Building.Make("ridge-cave", "Ridge Hollow", Vx(7), GameConst.VillageH + 6, 6, 4, 2, 4, BuildingKind.Cave));
            houses.Add(Building.Make("finn", "Finn's Dock House", Vx(50), GameConst.BeachOy + 5, 6, 4, 2, 1, BuildingKind.FishMarket));
        }

        public static TileType[,] Build(List<Building> houses)
        {
            TileType[,] tiles = new TileType[GameConst.MapW, GameConst.MapH];
            int ox = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (y < GameConst.VillageH)
                        tiles[x, y] = TileType.Grass;
                    else if (y < oy)
                        tiles[x, y] = TileType.Mountain;
                    else if (y < GameConst.CountryOy)
                        tiles[x, y] = x < GameConst.FarmOx ? TileType.WoodsGrass : TileType.Grass;
                    else if (y < GameConst.BeachOy)
                        tiles[x, y] = TileType.Grass;
                    else
                        tiles[x, y] = TileType.Sand;
                }
            }

            CarveVillage(tiles);
            CarveMountain(tiles);
            CarveWoods(tiles);
            CarveMoonveil(tiles);
            CarveCountry(tiles);
            CarveBeach(tiles);

            int spine = GameConst.SpineX;
            for (int y = oy; y < GameConst.CountryOy; y++)
                PutLane(tiles, spine, y);
            for (int x = GameConst.FarmOx - 2; x < GameConst.MapW - 1; x++)
            {
                Put(tiles, x, 4 + oy, TileType.Path);
                Put(tiles, x, 5 + oy, TileType.Path);
            }
            for (int y = 6 + oy; y <= 48 + oy; y++)
                PutLane(tiles, 10 + ox, y);
            for (int x = 2 + ox; x <= 18 + ox; x++)
            {
                Put(tiles, x, 38 + oy, TileType.Path);
                Put(tiles, x, 39 + oy, TileType.Path);
            }

            Put(tiles, 18 + ox, 26 + oy, TileType.Bin);
            Put(tiles, 19 + ox, 26 + oy, TileType.Bin);

            int[,] trees =
            {
                {2,8},{3,14},{4,22},{8,18},{14,27},{24,3},{26,10},
                {33,8},{38,6},{37,12},{35,22},{38,26},{32,28},{6,28},{1,4},{39,18},
                {5,2},{11,3},{28,2},{2,3},{36,4},
                {16,44},{18,48},{4,48},{15,40},{17,22},{3,20},{8,50},{16,50},{22,36},{22,46}
            };
            for (int i = 0; i < trees.GetLength(0); i++)
                Put(tiles, trees[i, 0] + ox, trees[i, 1] + oy, TileType.Tree);

            int[,] flowers = { {11,6},{12,7},{24,8},{25,22},{27,24},{15,8},{4,40},{18,36},{8,40},{16,42} };
            for (int i = 0; i < flowers.GetLength(0); i++)
                Put(tiles, flowers[i, 0] + ox, flowers[i, 1] + oy, TileType.Flower);

            int[,] weeds = { {13,11},{16,13},{22,15},{14,18},{24,20},{17,16},{5,36},{14,46},{8,47},{19,34} };
            for (int i = 0; i < weeds.GetLength(0); i++)
            {
                int x = weeds[i, 0] + ox;
                int y = weeds[i, 1] + oy;
                if (x < GameConst.MapW && y < GameConst.MapH)
                    tiles[x, y] = TileType.Weed;
            }

            Put(tiles, 15 + ox, 12 + oy, TileType.Rock);
            Put(tiles, 23 + ox, 18 + oy, TileType.Rock);
            Put(tiles, 18 + ox, 6 + oy, TileType.Dummy);
            CottageGarden(tiles, 32 + ox, 1 + oy, 6, 5, 2);
            FarmhouseYard(tiles, 7 + ox, 1 + oy, 7, 5, 3);
            PlaceHayfields(tiles);
            StampHouses(tiles, houses);
            return tiles;
        }

        static void PlaceHayfields(TileType[,] tiles)
        {
            int ox = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            StampHayPatch(tiles, 24 + ox, 10 + oy, 8, 8);
            StampHayPatch(tiles, 13 + ox, 14 + oy, 6, 7);
            StampHayPatch(tiles, 24 + ox, 40 + oy, 7, 6);
        }

        static void StampHayPatch(TileType[,] tiles, int x0, int y0, int w, int h)
        {
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int tx = x0 + x;
                    int ty = y0 + y;
                    if (tx < GameConst.FarmOx || ty < GameConst.FarmOy || tx >= GameConst.MapW || ty >= GameConst.CountryOy)
                        continue;
                    if (tiles[tx, ty] != TileType.Grass)
                        continue;
                    tiles[tx, ty] = TileType.Hay;
                }
            }
        }

        public static void PlaceProps(TileType[,] tiles, List<Deco> decos)
        {
            int ox = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            AddProp(tiles, decos, Vx(36), 13, 2);
            AddProp(tiles, decos, Vx(49), 9, 0);
            AddProp(tiles, decos, Vx(50), 9, 0);
            AddProp(tiles, decos, Vx(51), 10, 1);
            AddProp(tiles, decos, Vx(35), 10, 3);
            AddProp(tiles, decos, Vx(47), 14, 3);
            AddProp(tiles, decos, Vx(7), 14, 3);
            AddProp(tiles, decos, Vx(18), 16, 0);
            AddProp(tiles, decos, Vx(19), 16, 1);
            AddProp(tiles, decos, Vx(16), 7, 3);
            AddProp(tiles, decos, Vx(30), 20, 2);
            AddProp(tiles, decos, Vx(54), 24, 0);
            AddProp(tiles, decos, Vx(55), 24, 1);
            AddProp(tiles, decos, Vx(63), 24, 2);
            AddProp(tiles, decos, Vx(32), 36, 0);
            AddProp(tiles, decos, Vx(33), 36, 1);
            AddProp(tiles, decos, Vx(45), 36, 0);
            AddProp(tiles, decos, Vx(46), 36, 1);
            AddProp(tiles, decos, Vx(28), 38, 3);
            AddProp(tiles, decos, Vx(50), 38, 3);
            AddProp(tiles, decos, Vx(14), 40, 2);
            AddProp(tiles, decos, Vx(40), 48, 3);
            AddProp(tiles, decos, Vx(52), 50, 0);
            AddProp(tiles, decos, Vx(53), 50, 1);
            AddProp(tiles, decos, Vx(10), GameConst.VillageH + 18, 2);
            AddProp(tiles, decos, Vx(14), GameConst.VillageH + 22, 0);
            AddProp(tiles, decos, Vx(15), GameConst.VillageH + 22, 1);
            AddProp(tiles, decos, Vx(20), GameConst.VillageH + 12, 3);
            AddProp(tiles, decos, 7 + ox, 6 + oy, DecoKind.Barrel);
            AddProp(tiles, decos, 7 + ox, 7 + oy, DecoKind.LogSlice);
            AddProp(tiles, decos, 8 + ox, 7 + oy, DecoKind.LogSlice);
            AddProp(tiles, decos, 14 + ox, 7 + oy, 3);
            AddProp(tiles, decos, 22 + ox, 8 + oy, 2);
            AddProp(tiles, decos, Vx(28), 12, 3);
            AddProp(tiles, decos, Vx(33), 12, 3);
            AddProp(tiles, decos, Vx(47), 12, 3);
            AddProp(tiles, decos, Vx(54), 12, 3);
            AddProp(tiles, decos, Vx(57), 14, 3);
            AddProp(tiles, decos, Vx(19), 36, 3);
            AddProp(tiles, decos, Vx(25), 36, 3);
            AddProp(tiles, decos, Vx(47), 36, 3);
            AddProp(tiles, decos, Vx(53), 36, 3);
            AddProp(tiles, decos, Vx(8), 50, 3);
            AddProp(tiles, decos, Vx(13), 50, 3);
            AddProp(tiles, decos, Vx(40), 15, 2);
            AddProp(tiles, decos, Vx(12), 20, 2);
            AddProp(tiles, decos, Vx(36), 32, 2);
            AddProp(tiles, decos, Vx(24), 12, 3);
            AddProp(tiles, decos, Vx(33), 12, 3);
            AddProp(tiles, decos, Vx(48), 12, 3);
            AddProp(tiles, decos, Vx(16), 36, 3);
            AddProp(tiles, decos, Vx(55), 36, 3);
            AddProp(tiles, decos, Vx(4), 50, 3);
            AddProp(tiles, decos, Vx(14), 50, 3);
            AddProp(tiles, decos, Vx(41), 13, 3);
            AddProp(tiles, decos, Vx(46), 13, 3);
            PlaceDockDressing(tiles, decos);
        }

        static void AddProp(TileType[,] tiles, List<Deco> decos, int x, int y, int kind)
        {
            if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                return;
            TileType k = tiles[x, y];
            if (k == TileType.Water || k == TileType.Roof || k == TileType.HouseWall || k == TileType.Door
                || k == TileType.Tree || k == TileType.Cliff)
                return;
            decos.Add(new Deco { X = x, Y = y, Kind = kind });
        }

        static void PlaceWaterProp(TileType[,] tiles, List<Deco> decos, int x, int y, int kind)
        {
            if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                return;
            if (tiles[x, y] != TileType.Water)
                return;
            decos.Add(new Deco { X = x, Y = y, Kind = kind });
        }

        static void PlaceDockDressing(TileType[,] tiles, List<Deco> decos)
        {
            int y0 = GameConst.BeachOy;
            AddProp(tiles, decos, Vx(47), y0 + 4, DecoKind.Bush);
            AddProp(tiles, decos, Vx(56), y0 + 4, DecoKind.Bush);
            AddProp(tiles, decos, Vx(56), y0 + 9, DecoKind.FishRack);
            AddProp(tiles, decos, Vx(57), y0 + 10, DecoKind.FishCrate);
            AddProp(tiles, decos, Vx(58), y0 + 11, DecoKind.FishCrate);
            AddProp(tiles, decos, Vx(52), y0 + 12, DecoKind.Shark);
            AddProp(tiles, decos, Vx(54), y0 + 11, DecoKind.Barrel);
            AddProp(tiles, decos, Vx(55), y0 + 10, DecoKind.Crate);
            AddProp(tiles, decos, Vx(61), y0 + 9, DecoKind.Barrel);
            AddProp(tiles, decos, Vx(61), y0 + 11, DecoKind.FishCrate);
            AddProp(tiles, decos, Vx(62), y0 + 10, DecoKind.Sack);
            AddProp(tiles, decos, Vx(62), y0 + 12, DecoKind.Sack);
            PlaceWaterProp(tiles, decos, Vx(64), y0 + 10, DecoKind.Rowboat);
            PlaceWaterProp(tiles, decos, Vx(64), y0 + 12, DecoKind.Rowboat);
            PlaceWaterProp(tiles, decos, Vx(62), y0 + 15, DecoKind.SailBlue);
            PlaceWaterProp(tiles, decos, Vx(54), y0 + 24, DecoKind.SailBrown);
        }

        static void StampHouses(TileType[,] tiles, List<Building> houses)
        {
            for (int i = 0; i < houses.Count; i++)
                StampBuilding(tiles, houses[i]);
        }

        public static void StampBuilding(TileType[,] tiles, Building b)
        {
            if (b == null || tiles == null)
                return;
            if (b.Kind == BuildingKind.Cave)
            {
                for (int dy = 0; dy < b.H; dy++)
                {
                    for (int dx = 0; dx < b.W; dx++)
                        Put(tiles, b.X + dx, b.Y + dy, TileType.Cliff);
                }
                Put(tiles, b.DoorX, b.DoorY, TileType.Door);
                Put(tiles, b.DoorX, b.DoorY + 1, TileType.Path);
                Put(tiles, b.DoorX - 1, b.DoorY + 1, TileType.Mountain);
                Put(tiles, b.DoorX + 1, b.DoorY + 1, TileType.Mountain);
                return;
            }
            for (int dy = 0; dy < b.FootH; dy++)
            {
                for (int dx = 0; dx < b.FootW; dx++)
                {
                    bool facade = false;
                    int r = b.Rot & 3;
                    if (r == 0)
                        facade = dy == b.FootH - 1;
                    else if (r == 1)
                        facade = dx == 0;
                    else if (r == 2)
                        facade = dy == 0;
                    else
                        facade = dx == b.FootW - 1;
                    TileType t = facade ? TileType.HouseWall : TileType.Roof;
                    Put(tiles, b.X + dx, b.Y + dy, t);
                }
            }
            Put(tiles, b.DoorX, b.DoorY, TileType.Door);
            if (b.Kind == BuildingKind.FishMarket)
                Put(tiles, b.DoorX, b.DoorY + 1, TileType.Dock);
            else
                Put(tiles, b.ApproachX, b.ApproachY, TileType.Path);
        }

        /// <summary>
        /// Dirt lanes Ash should not erase when a farmhouse is lifted off them.
        /// </summary>
        public static bool IsFarmRoad(int x, int y)
        {
            int ox = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                return false;
            if (x == GameConst.SpineX && y >= oy && y < GameConst.CountryOy)
                return true;
            if ((y == 4 + oy || y == 5 + oy) && x >= GameConst.FarmOx - 2 && x < GameConst.MapW - 1)
                return true;
            if (x == 10 + ox && y >= 6 + oy && y <= 48 + oy)
                return true;
            if ((y == 38 + oy || y == 39 + oy) && x >= 2 + ox && x <= 18 + ox)
                return true;
            return false;
        }

        static void CarveVillage(TileType[,] tiles)
        {
            CarveWillowPark(tiles);

            CobblePad(tiles, 38, 11, 47, 13);
            CobblePad(tiles, 26, 11, 32, 12);
            CobblePad(tiles, 56, 13, 62, 14);
            CobblePad(tiles, 56, 23, 59, 23);
            CobblePad(tiles, 56, 43, 63, 44);
            CobblePad(tiles, 34, 34, 42, 36);
            CobblePad(tiles, 18, 35, 24, 36);
            CobblePad(tiles, 48, 35, 54, 36);
            CobblePad(tiles, 6, 49, 12, 51);

            for (int x = 8; x <= 60; x++)
            {
                Put(tiles, x, 16, TileType.Path);
                Put(tiles, x, 17, TileType.Path);
            }
            for (int x = 8; x <= 58; x++)
            {
                Put(tiles, x, 26, TileType.Path);
                Put(tiles, x, 27, TileType.Path);
            }
            for (int x = 6; x <= 50; x++)
            {
                Put(tiles, x, 48, TileType.Path);
                Put(tiles, x, 49, TileType.Path);
            }
            for (int y = 27; y <= 48; y++)
            {
                Put(tiles, 24, y, TileType.Path);
                Put(tiles, 25, y, TileType.Path);
            }
            for (int y = 8; y < GameConst.VillageH; y++)
                PutLane(tiles, GameConst.SpineX - GameConst.ShadeW, y);

            CottageGarden(tiles, 26, 6, 6, 5, 2);
            CottageGarden(tiles, 38, 5, 9, 6, 4);
            CottageGarden(tiles, 56, 8, 6, 5, 2);
            ForgeYard(tiles, 56, 18, 7, 5, 1);
            CottageGarden(tiles, 56, 38, 7, 5, 3);
            CottageGarden(tiles, 34, 28, 8, 6, 3);
            CottageGarden(tiles, 18, 30, 6, 5, 2);
            CottageGarden(tiles, 48, 30, 6, 5, 2);
            CottageGarden(tiles, 6, 44, 6, 5, 2);

            FlowerPatch(tiles, 29, 13, 3, 2);
            FlowerPatch(tiles, 48, 13, 3, 2);
            FlowerPatch(tiles, 20, 36, 3, 2);
            FlowerPatch(tiles, 44, 36, 3, 2);
            FlowerPatch(tiles, 10, 50, 3, 2);
            FlowerPatch(tiles, 36, 20, 2, 2);

            Put(tiles, 40, 18, TileType.Water);
            Put(tiles, 41, 18, TileType.Water);
            Put(tiles, 40, 19, TileType.Water);
            Put(tiles, 41, 19, TileType.Water);

            int[,] trees =
            {
                {26, 3}, {31, 3}, {52, 3}, {60, 8}, {62, 14}, {64, 6}, {48, 4},
                {30, 24}, {53, 24}, {58, 22}, {62, 26}, {10, 32}, {14, 36}, {4, 38},
                {60, 32}, {63, 40}, {58, 46}, {32, 46}, {50, 52}, {20, 52}, {14, 54},
                {38, 52}, {8, 56}, {28, 56}, {54, 56}, {62, 52}, {3, 48}, {64, 18},
                {22, 8}, {33, 8}, {50, 8}, {12, 28}, {16, 32}, {42, 24}, {20, 40}
            };
            for (int i = 0; i < trees.GetLength(0); i++)
                SoftPut(tiles, trees[i, 0], trees[i, 1], TileType.Tree);

            int[,] flowers =
            {
                {29, 14}, {33, 20}, {48, 14}, {50, 20}, {58, 18}, {27, 24},
                {30, 36}, {48, 36}, {28, 40}, {50, 44}, {12, 40}, {16, 50},
                {36, 50}, {56, 50}, {8, 52}, {22, 54}, {60, 54}, {4, 28},
                {36, 14}, {44, 14}, {40, 20}, {22, 18}, {18, 22}, {32, 28},
                {38, 32}, {46, 32}, {10, 46}, {14, 46}, {52, 18}, {28, 8},
                {42, 8}, {8, 18}, {12, 22}, {20, 28}, {54, 40}, {36, 44}
            };
            for (int i = 0; i < flowers.GetLength(0); i++)
                SoftPut(tiles, flowers[i, 0], flowers[i, 1], TileType.Flower);

            FlowerBorder(tiles, 8, 15, 60, 15);
            FlowerBorder(tiles, 8, 18, 60, 18);
            FlowerBorder(tiles, 8, 25, 58, 25);
            FlowerBorder(tiles, 8, 28, 58, 28);
            FlowerBorder(tiles, 23, 28, 23, 48);
            FlowerBorder(tiles, 26, 28, 26, 48);

            ShiftBandEast(tiles, 0, GameConst.VillageH);
            for (int y = 2; y < GameConst.VillageH - 2; y++)
            {
                if ((y % 4) == 0)
                    SoftPut(tiles, 4, y, TileType.Tree);
                if ((y % 5) == 2)
                    SoftPut(tiles, 8, y, TileType.Tree);
                if ((y % 7) == 1)
                    SoftPut(tiles, 2, y, TileType.Flower);
            }
        }

        static void ShiftBandEast(TileType[,] tiles, int y0, int y1)
        {
            int dx = GameConst.ShadeW;
            if (dx <= 0)
                return;
            for (int y = y0; y < y1; y++)
            {
                for (int x = GameConst.MapW - 1; x >= dx; x--)
                    tiles[x, y] = tiles[x - dx, y];
                for (int x = 0; x < dx; x++)
                    tiles[x, y] = y0 >= GameConst.VillageH ? TileType.Mountain : TileType.Grass;
            }
        }

        static void CarveWillowPark(TileType[,] tiles)
        {
            for (int x = 3; x <= 23; x++)
            {
                if (x == 16 || x == 17)
                    continue;
                if ((x % 5) == 0)
                    Put(tiles, x, 6, TileType.Flower);
                else
                    Put(tiles, x, 6, TileType.Fence);
                if ((x % 4) == 2)
                    Put(tiles, x, 26, TileType.Flower);
                else if (x != 16 && x != 17)
                    Put(tiles, x, 26, TileType.Fence);
            }
            for (int y = 7; y <= 25; y++)
            {
                if (y == 16 || y == 17)
                    continue;
                Put(tiles, 2, y, (y % 5) == 0 ? TileType.Flower : TileType.Fence);
                if (y != 16 && y != 17)
                    Put(tiles, 24, y, (y % 4) == 1 ? TileType.Flower : TileType.Fence);
            }

            int cx = 12;
            int cy = 16;
            for (int y = 8; y <= 24; y++)
            {
                for (int x = 4; x <= 21; x++)
                {
                    int dx = x - cx;
                    int dy = y - cy;
                    if (dx * dx / 72.0 + dy * dy / 48.0 <= 1.0)
                        Put(tiles, x, y, TileType.Water);
                }
            }

            for (int y = 14; y <= 18; y++)
            {
                for (int x = 10; x <= 14; x++)
                {
                    int dx = x - 12;
                    int dy = y - 16;
                    if (dx * dx + dy * dy <= 8)
                        Put(tiles, x, y, TileType.Grass);
                }
            }
            Put(tiles, 12, 16, TileType.Tree);
            Put(tiles, 11, 17, TileType.Flower);
            Put(tiles, 13, 17, TileType.Flower);
            Put(tiles, 13, 15, TileType.Flower);
            Put(tiles, 11, 15, TileType.Flower);

            for (int x = 14; x <= 25; x++)
            {
                Put(tiles, x, 16, TileType.Path);
                Put(tiles, x, 17, TileType.Path);
            }

            int[,] blooms = { { 4, 7 }, { 6, 7 }, { 8, 7 }, { 16, 7 }, { 20, 7 }, { 4, 25 }, { 8, 25 }, { 15, 25 }, { 20, 25 }, { 3, 12 }, { 3, 20 }, { 21, 12 }, { 21, 22 }, { 5, 14 }, { 7, 18 }, { 19, 14 }, { 18, 20 }, { 9, 8 }, { 15, 8 } };
            for (int i = 0; i < blooms.GetLength(0); i++)
                Put(tiles, blooms[i, 0], blooms[i, 1], TileType.Flower);

            Put(tiles, 6, 10, TileType.Tree);
            Put(tiles, 19, 10, TileType.Tree);
            Put(tiles, 5, 22, TileType.Tree);
            Put(tiles, 18, 22, TileType.Tree);
        }

        static void CarveMountain(TileType[,] tiles)
        {
            int y0 = GameConst.VillageH;
            int y1 = GameConst.FarmOy;
            int split = GameConst.SummitW;
            int spine = GameConst.SpineX;

            for (int y = y0; y < y1; y++)
            {
                for (int x = split; x < GameConst.MapW; x++)
                {
                    int dist = Math.Abs(x - spine);
                    if (x >= GameConst.MapW - 2 || (dist > 10 && (x * 13 + y * 7) % 3 == 0))
                        Put(tiles, x, y, TileType.Cliff);
                    else if (dist > 8 && (x + y) % 8 == 0)
                        Put(tiles, x, y, TileType.Rock);
                    else if (dist > 6 && dist < 14 && (x * 11 + y * 5) % 7 == 0)
                        Put(tiles, x, y, TileType.Tree);
                    else
                        Put(tiles, x, y, TileType.Mountain);
                }
            }

            for (int y = y0; y < y1; y++)
            {
                PutLane(tiles, spine, y);
                Bank(tiles, spine - 1, y, TileType.Mountain);
                Bank(tiles, spine + 2, y, TileType.Mountain);
            }

            int spurY = y0 + (y1 - y0) / 2;
            for (int x = split - 2; x <= spine + 1; x++)
            {
                Put(tiles, x, spurY, TileType.Path);
                Put(tiles, x, spurY + 1, TileType.Path);
                Bank(tiles, x, spurY - 1, TileType.Mountain);
                Bank(tiles, x, spurY + 2, TileType.Mountain);
            }

            CarveSummit(tiles, y0, y1, split, spurY);
            PlaceSummitMinerals(tiles, y0, y1, split);
        }

        static void CarveSummit(TileType[,] tiles, int y0, int y1, int split, int spurY)
        {
            for (int y = y0; y < y1; y++)
            {
                for (int x = 0; x < split; x++)
                {
                    if (tiles[x, y] == TileType.Path)
                        continue;
                    bool rim = x < 3 || y <= y0 + 1 || y >= y1 - 2;
                    int n = (x * 19 + y * 11) & 7;
                    if (rim || n == 0)
                        Put(tiles, x, y, TileType.Cliff);
                    else if (n == 1 && (x + y) % 5 == 0)
                        Put(tiles, x, y, TileType.Rock);
                    else if (n <= 3 && x < 12 && y < y0 + 14)
                        Put(tiles, x, y, TileType.Cliff);
                    else
                        Put(tiles, x, y, TileType.Mountain);
                }
            }

            for (int x = 8; x < split; x++)
            {
                Put(tiles, x, spurY, TileType.Path);
                Put(tiles, x, spurY + 1, TileType.Path);
                Bank(tiles, x, spurY - 1, TileType.Mountain);
                Bank(tiles, x, spurY + 2, TileType.Mountain);
            }

            int caveX = 9 + GameConst.ShadeW;
            int caveY = y0 + 10;
            int yA = Math.Min(spurY, caveY);
            int yB = Math.Max(spurY + 1, caveY);
            for (int y = yA; y <= yB; y++)
                PutLane(tiles, caveX, y);

            int[,] trees = { {4,10},{18,8},{22,16},{5,20},{16,24},{3,28},{20,30},{12,32},{24,14},{6,36} };
            for (int i = 0; i < trees.GetLength(0); i++)
            {
                int x = trees[i, 0] + GameConst.ShadeW;
                int y = y0 + trees[i, 1];
                if (y < y1 && tiles[x, y] != TileType.Path)
                    Put(tiles, x, y, TileType.Tree);
            }
            int[,] flowers = { {12,14},{16,18},{8,20},{18,22},{14,28},{22,26} };
            for (int i = 0; i < flowers.GetLength(0); i++)
            {
                int x = flowers[i, 0] + GameConst.ShadeW;
                int y = y0 + flowers[i, 1];
                if (y < y1 && tiles[x, y] == TileType.Mountain)
                    Put(tiles, x, y, TileType.Flower);
            }
        }

        static void PlaceSummitMinerals(TileType[,] tiles, int y0, int y1, int split)
        {
            int[,] spots =
            {
                {7,12},{13,16},{19,11},{4,18},{15,22},{21,20},
                {8,26},{17,28},{5,32},{22,18},{11,13},{20,34},
                {3,22},{16,10},{9,30},{24,24},{6,15},{18,32},
                {12,19},{2,28},{23,12},{14,36}
            };
            for (int i = 0; i < spots.GetLength(0); i++)
            {
                int x = spots[i, 0] + GameConst.ShadeW;
                int y = y0 + spots[i, 1];
                if (x <= 0 || x >= split || y <= y0 || y >= y1 - 1)
                    continue;
                TileType t = tiles[x, y];
                if (t == TileType.Path || t == TileType.Door || t == TileType.Cliff || t == TileType.Tree || t == TileType.HouseWall)
                    continue;
                Put(tiles, x, y, TileType.Mineral);
            }
        }

        static void CarveWoods(TileType[,] tiles)
        {
            int west = GameConst.ShadeW;
            int east = GameConst.FarmOx;
            int oy = GameConst.FarmOy;
            int gateY = 4 + oy;
            for (int x = west; x < east; x++)
            {
                Put(tiles, x, gateY, TileType.Path);
                Put(tiles, x, gateY + 1, TileType.Path);
            }
            for (int y = gateY; y <= 20 + oy; y++)
                PutLane(tiles, west + 6, y);
            for (int x = west + 6; x <= west + 14; x++)
            {
                Put(tiles, x, 20 + oy, TileType.Path);
                Put(tiles, x, 21 + oy, TileType.Path);
            }

            for (int y = oy + 1; y < GameConst.CountryOy - 1; y++)
            {
                for (int x = west; x < east; x++)
                {
                    if (tiles[x, y] == TileType.Path)
                        continue;
                    int n = (x * 17 + y * 31) & 7;
                    if (n <= 2)
                        Put(tiles, x, y, TileType.Tree);
                    else if (n == 3 && (x + y) % 5 == 0)
                        Put(tiles, x, y, TileType.Flower);
                    else if (n == 4 && (x * y) % 11 == 0)
                        Put(tiles, x, y, TileType.Rock);
                }
            }

            for (int x = west; x < east; x++)
            {
                Put(tiles, x, oy, TileType.Tree);
                Put(tiles, x, GameConst.CountryOy - 1, TileType.Tree);
            }

            Put(tiles, east - 1, gateY, TileType.Path);
            Put(tiles, east - 1, gateY + 1, TileType.Path);
            Put(tiles, east - 2, gateY, TileType.Path);
            Put(tiles, east - 2, gateY + 1, TileType.Path);
            Put(tiles, west, gateY, TileType.Path);
            Put(tiles, west, gateY + 1, TileType.Path);
        }

        static void CarveMoonveil(TileType[,] tiles)
        {
            int w = GameConst.ShadeW;
            int oy = GameConst.FarmOy;
            int y1 = GameConst.CountryOy;
            int gateY = 4 + oy;

            for (int x = 3; x < w; x++)
            {
                Put(tiles, x, gateY, TileType.Path);
                Put(tiles, x, gateY + 1, TileType.Path);
            }
            int bendX = 8;
            for (int y = gateY; y <= oy + 22; y++)
                PutLane(tiles, bendX, y);
            for (int x = 5; x <= 13; x++)
            {
                Put(tiles, x, oy + 22, TileType.Path);
                Put(tiles, x, oy + 23, TileType.Path);
            }

            for (int y = oy + 1; y < y1 - 1; y++)
            {
                for (int x = 1; x < w; x++)
                {
                    if (tiles[x, y] == TileType.Path || tiles[x, y] == TileType.Water)
                        continue;
                    int n = (x * 19 + y * 29) & 15;
                    if (n <= 6)
                        Put(tiles, x, y, TileType.Tree);
                    else if (n == 7 || n == 8)
                        Put(tiles, x, y, TileType.Flower);
                    else if (n == 9 && (x + y) % 3 == 0)
                        Put(tiles, x, y, TileType.Rock);
                }
            }

            for (int y = oy + 18; y <= oy + 28; y++)
            {
                for (int x = 4; x <= 14; x++)
                {
                    if (tiles[x, y] == TileType.Tree || tiles[x, y] == TileType.Rock)
                        tiles[x, y] = TileType.WoodsGrass;
                }
            }
            Put(tiles, 8, oy + 24, TileType.Water);
            Put(tiles, 9, oy + 24, TileType.Water);
            Put(tiles, 8, oy + 25, TileType.Water);
            Put(tiles, 9, oy + 25, TileType.Water);
            Put(tiles, 6, oy + 22, TileType.Rock);
            Put(tiles, 12, oy + 22, TileType.Rock);
            Put(tiles, 5, oy + 25, TileType.Rock);
            Put(tiles, 13, oy + 25, TileType.Rock);
            Put(tiles, 7, oy + 27, TileType.Rock);
            Put(tiles, 11, oy + 27, TileType.Rock);
            Put(tiles, 6, oy + 20, TileType.Flower);
            Put(tiles, 12, oy + 20, TileType.Flower);
            Put(tiles, 7, oy + 26, TileType.Flower);
            Put(tiles, 11, oy + 26, TileType.Flower);
            Put(tiles, 10, oy + 23, TileType.Flower);
            Put(tiles, 4, oy + 24, TileType.Tree);
            Put(tiles, 14, oy + 24, TileType.Tree);

            for (int x = 0; x < w; x++)
            {
                Put(tiles, x, oy, TileType.Tree);
                Put(tiles, x, y1 - 1, TileType.Tree);
            }
            for (int y = oy; y < y1; y++)
                Put(tiles, 0, y, TileType.Tree);
            Put(tiles, w - 1, gateY, TileType.Path);
            Put(tiles, w - 1, gateY + 1, TileType.Path);
        }

        public static void CarveZoneGates(TileType[,] t, List<GateSign> signs)
        {
            int oy = GameConst.FarmOy;
            int spine = GameConst.SpineX;
            GateEastWest(t, signs, GameConst.FarmOx, 4 + oy, 5 + oy, "Harvest Hollow", "Forbidden Woods");
            GateEastWest(t, signs, GameConst.ShadeW, 4 + oy, 5 + oy, "Forbidden Woods", "Moonveil Grove");
            GateNorthSouth(t, signs, spine, spine + 1, oy, "Mountain Path", "Harvest Hollow");
            GateNorthSouth(t, signs, spine, spine + 1, GameConst.VillageH, "Hearth Village", "Mountain Path");
            int spurY = GameConst.VillageH + GameConst.MountainH / 2;
            GateEastWest(t, signs, GameConst.SummitW, spurY, spurY + 1, "Mountain Path", "Ridge Summit");
            GateNorthSouth(t, signs, spine, spine + 1, GameConst.CountryOy, "Harvest Hollow", "Meadow Road");
            GateNorthSouth(t, signs, spine, spine + 1, GameConst.BeachOy, "Meadow Road", "Saltwind Beach");
        }

        public static void ScatterRoadsideStone(TileType[,] tiles)
        {
            int[,] dxy = { { 0, -1 }, { 0, 1 }, { -1, 0 }, { 1, 0 } };
            for (int y = 1; y < GameConst.MapH - 1; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    TileType here = tiles[x, y];
                    if (here != TileType.Path && here != TileType.Cobble && here != TileType.Dock)
                        continue;
                    for (int i = 0; i < 4; i++)
                    {
                        int nx = x + dxy[i, 0];
                        int ny = y + dxy[i, 1];
                        if (nx <= 0 || ny <= 0 || nx >= GameConst.MapW - 1 || ny >= GameConst.MapH - 1)
                            continue;
                        TileType n = tiles[nx, ny];
                        if (n != TileType.Grass && n != TileType.WoodsGrass
                            && n != TileType.Sand && n != TileType.FarmSoil && n != TileType.Weed)
                            continue;
                        bool nearDoor = false;
                        for (int j = 0; j < 4; j++)
                        {
                            int ax = nx + dxy[j, 0];
                            int ay = ny + dxy[j, 1];
                            if (ax >= 0 && ay >= 0 && ax < GameConst.MapW && ay < GameConst.MapH
                                && tiles[ax, ay] == TileType.Door)
                                nearDoor = true;
                        }
                        if (nearDoor)
                            continue;
                        int h = (nx * 19 + ny * 37 + x * 7) & 7;
                        if (h > 2)
                            continue;
                        tiles[nx, ny] = TileType.Rock;
                    }
                }
            }
        }

        public static void ConnectRoads(TileType[,] tiles, List<Building> houses)
        {
            if (houses == null)
                return;
            for (int i = 0; i < houses.Count; i++)
            {
                Building b = houses[i];
                LeadToRoad(tiles, b.DoorX, b.DoorY + 1);
            }
        }

        static void LeadToRoad(TileType[,] tiles, int sx, int sy)
        {
            Road(tiles, sx, sy);
            Road(tiles, sx + 1, sy);
            int tx, ty;
            if (!NearestRoad(tiles, sx, sy, out tx, out ty))
                return;
            int x = sx;
            int y = sy;
            for (int step = 0; step < 36; step++)
            {
                if (x == tx && y == ty)
                    break;
                int nx = x;
                int ny = y;
                if (Math.Abs(tx - x) >= Math.Abs(ty - y) && x != tx)
                    nx = x + Math.Sign(tx - x);
                else if (y != ty)
                    ny = y + Math.Sign(ty - y);
                else
                    nx = x + Math.Sign(tx - x);
                if (nx <= 0 || ny <= 0 || nx >= GameConst.MapW - 1 || ny >= GameConst.MapH - 1)
                    break;
                TileType dest = tiles[nx, ny];
                if (dest == TileType.Water || dest == TileType.Cliff || dest == TileType.Roof
                    || dest == TileType.HouseWall || dest == TileType.Door)
                {
                    if (nx != x && y != ty)
                    {
                        ny = y + Math.Sign(ty - y);
                        nx = x;
                    }
                    else if (ny != y && x != tx)
                    {
                        nx = x + Math.Sign(tx - x);
                        ny = y;
                    }
                    else
                        break;
                    dest = tiles[nx, ny];
                    if (dest == TileType.Water || dest == TileType.Cliff || dest == TileType.Roof
                        || dest == TileType.HouseWall || dest == TileType.Door)
                        break;
                }
                x = nx;
                y = ny;
                Road(tiles, x, y);
                Road(tiles, x + 1, y);
                if (dest == TileType.Path || dest == TileType.Cobble || dest == TileType.Dock
                    || dest == TileType.Bridge)
                    break;
            }
        }

        static bool NearestRoad(TileType[,] tiles, int sx, int sy, out int tx, out int ty)
        {
            tx = sx;
            ty = sy;
            int best = 999;
            bool found = false;
            for (int y = 1; y < GameConst.MapH - 1; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    TileType t = tiles[x, y];
                    if (t != TileType.Path && t != TileType.Cobble && t != TileType.Dock && t != TileType.Bridge)
                        continue;
                    int d = Math.Abs(x - sx) + Math.Abs(y - sy);
                    if (d < 2 || d > 28)
                        continue;
                    bool stretch = tiles[x + 1, y] == t || tiles[x - 1, y] == t
                        || tiles[x, y + 1] == t || tiles[x, y - 1] == t;
                    if (!stretch)
                        continue;
                    if (d < best)
                    {
                        best = d;
                        tx = x;
                        ty = y;
                        found = true;
                    }
                }
            }
            return found;
        }

        public static void PlaceBridges(TileType[,] tiles, List<StoneBridge> bridges)
        {
            bridges.Clear();
            CarveRiver(tiles);
        }

        // Hollow River: a 2-tile stream east of the dirt spine, from Hearth Village
        // down the mountain path, across the farm, and out into Saltwind Beach.
        // Dirt roads that crossed the channel become small wooden decks. Bram's
        // lodge sits on the natural line, so the channel swings east around it.
        static void CarveRiver(TileType[,] tiles)
        {
            bool[,] wasPath = new bool[GameConst.MapW, GameConst.MapH];
            for (int y = 4; y <= 11; y++)
            {
                for (int x = Vx(47); x <= Vx(51); x++)
                    TryRiver(tiles, x, y, wasPath);
            }

            int mouth = GameConst.BeachOy + 48;
            if (mouth > GameConst.MapH - 2)
                mouth = GameConst.MapH - 2;
            for (int y = 8; y <= mouth; y++)
            {
                int cx = GameConst.RiverCenterX(y);
                int w = 2;
                if (y >= GameConst.BeachOy)
                    w = 2 + Math.Min(8, (y - GameConst.BeachOy + 1) / 2);
                bool nearDock = y >= GameConst.BeachOy && y <= GameConst.BeachOy + 16;
                for (int dx = 0; dx < w; dx++)
                {
                    if (nearDock && cx + dx >= Vx(48))
                        continue;
                    TryRiver(tiles, cx + dx, y, wasPath);
                }
                if ((y % 6) == 2)
                    TryRiver(tiles, cx - 1, y, wasPath);
                if (y >= GameConst.BeachOy + 3 && y < GameConst.BeachOy + 28)
                {
                    TryRiver(tiles, cx - 2, y, wasPath);
                    if ((y % 3) != 0)
                        TryRiver(tiles, cx - 3, y, wasPath);
                }
            }
            CarveEstuary(tiles, wasPath);
            for (int x = Vx(47); x <= Vx(56); x++)
            {
                TryRiver(tiles, x, 28, wasPath);
                TryRiver(tiles, x, 29, wasPath);
                TryRiver(tiles, x, 37, wasPath);
                TryRiver(tiles, x, 38, wasPath);
            }

            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (wasPath[x, y] && tiles[x, y] == TileType.Water)
                        tiles[x, y] = TileType.Bridge;
                }
            }
        }

        static void CarveEstuary(TileType[,] tiles, bool[,] wasPath)
        {
            int y0 = GameConst.BeachOy;
            for (int y = y0 + 10; y <= y0 + 34 && y < GameConst.MapH - 1; y++)
            {
                int cx = GameConst.RiverCenterX(y);
                int spread = 3 + (y - y0 - 10) / 3;
                for (int dx = -spread; dx <= spread + 1; dx++)
                    TryRiver(tiles, cx + dx, y, wasPath);
            }
            int[,] bars =
            {
                {Vx(44), 18}, {Vx(45), 18}, {Vx(44), 19}, {Vx(45), 19},
                {Vx(56), 22}, {Vx(57), 22}, {Vx(56), 23}, {Vx(57), 23}
            };
            for (int i = 0; i < bars.GetLength(0); i++)
            {
                int x = bars[i, 0];
                int y = y0 + bars[i, 1];
                if (x <= 1 || y <= 0 || x >= GameConst.MapW - 2 || y >= GameConst.MapH - 1)
                    continue;
                if (tiles[x, y] == TileType.Water)
                    tiles[x, y] = TileType.Sand;
            }
        }

        static void TryRiver(TileType[,] tiles, int x, int y, bool[,] wasPath)
        {
            if (x <= 1 || y <= 0 || x >= GameConst.MapW - 2 || y >= GameConst.MapH - 1)
                return;
            TileType t = tiles[x, y];
            if (t == TileType.Dock || t == TileType.Door
                || t == TileType.HouseWall || t == TileType.Roof || t == TileType.HouseWindow
                || t == TileType.Bin || t == TileType.Tree || t == TileType.Dummy
                || t == TileType.Fence || t == TileType.Cliff || t == TileType.Bridge
                || t == TileType.Mineral)
                return;
            if (t == TileType.Path)
                wasPath[x, y] = true;
            tiles[x, y] = TileType.Water;
        }

        static void Bank(TileType[,] tiles, int x, int y, TileType bank)
        {
            if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                return;
            TileType t = tiles[x, y];
            if (t == TileType.Path || t == TileType.Bridge || t == TileType.Door || t == TileType.Water
                || t == TileType.HouseWall || t == TileType.Roof || t == TileType.Bin)
                return;
            tiles[x, y] = bank;
        }

        static bool CanPave(TileType k)
        {
            return k != TileType.Roof && k != TileType.HouseWall && k != TileType.Door
                && k != TileType.Water && k != TileType.Bin && k != TileType.Bed
                && k != TileType.Cobble && k != TileType.Counter && k != TileType.HouseFloor && k != TileType.Dock
                && k != TileType.Bridge && k != TileType.Cliff && k != TileType.Mineral;
        }

        static void Road(TileType[,] t, int x, int y)
        {
            if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                return;
            if (CanPave(t[x, y]))
                t[x, y] = TileType.Path;
        }

        static void Avenue(TileType[,] t, int x0, int y0, int x1, int y1)
        {
            int n = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
            if (n < 1)
                n = 1;
            for (int i = 0; i <= n; i++)
            {
                float u = i / (float)n;
                int x = (int)Math.Round(x0 + (x1 - x0) * u);
                int y = (int)Math.Round(y0 + (y1 - y0) * u);
                Road(t, x, y);
                Road(t, x + 1, y);
                Road(t, x, y + 1);
            }
        }

        static void Posts(TileType[,] t, int x, int y)
        {
            if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                return;
            TileType k = t[x, y];
            if (k != TileType.Path && k != TileType.Cobble && k != TileType.Door
                && k != TileType.Water && k != TileType.Roof && k != TileType.HouseWall
                && k != TileType.Bin && k != TileType.Bed)
                t[x, y] = TileType.Fence;
        }

        static void FlowerLine(TileType[,] t, int x0, int y0, int x1, int y1)
        {
            int n = Math.Max(Math.Abs(x1 - x0), Math.Abs(y1 - y0));
            if (n < 1)
                n = 1;
            for (int i = 0; i <= n; i += 2)
            {
                float u = i / (float)n;
                int x = (int)Math.Round(x0 + (x1 - x0) * u);
                int y = (int)Math.Round(y0 + (y1 - y0) * u);
                if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                    continue;
                if (t[x, y] == TileType.Grass || t[x, y] == TileType.WoodsGrass || t[x, y] == TileType.Mountain)
                    t[x, y] = TileType.Flower;
            }
        }

        static void GateEastWest(TileType[,] t, List<GateSign> signs, int gx, int y0, int y1, string east, string west)
        {
            for (int y = y0 - 2; y <= y1 + 2; y++)
            {
                Road(t, gx - 2, y);
                Road(t, gx - 1, y);
                Road(t, gx, y);
                Road(t, gx + 1, y);
                Road(t, gx + 2, y);
            }
            Avenue(t, gx + 10, y0, gx + 2, y0);
            Avenue(t, gx + 10, y1, gx + 2, y1);
            Avenue(t, gx - 10, y0, gx - 2, y0);
            Avenue(t, gx - 10, y1, gx - 2, y1);
            Posts(t, gx - 2, y0 - 3);
            Posts(t, gx + 1, y0 - 3);
            Posts(t, gx - 2, y1 + 3);
            Posts(t, gx + 1, y1 + 3);
            FlowerLine(t, gx + 3, y0 - 3, gx + 9, y0 - 3);
            FlowerLine(t, gx + 3, y1 + 3, gx + 9, y1 + 3);
            FlowerLine(t, gx - 9, y0 - 3, gx - 3, y0 - 3);
            FlowerLine(t, gx - 9, y1 + 3, gx - 3, y1 + 3);
            signs.Add(new GateSign { X = gx + 4, Y = y0 - 2, Dest = west, Dir = 1 });
            signs.Add(new GateSign { X = gx - 4, Y = y0 - 2, Dest = east, Dir = 2 });
        }

        static void GateNorthSouth(TileType[,] t, List<GateSign> signs, int x0, int x1, int gy, string north, string south)
        {
            for (int x = x0 - 2; x <= x1 + 2; x++)
            {
                Road(t, x, gy - 2);
                Road(t, x, gy - 1);
                Road(t, x, gy);
                Road(t, x, gy + 1);
                Road(t, x, gy + 2);
            }
            Avenue(t, x0, gy - 10, x0, gy - 2);
            Avenue(t, x1, gy - 10, x1, gy - 2);
            Avenue(t, x0, gy + 10, x0, gy + 2);
            Avenue(t, x1, gy + 10, x1, gy + 2);
            Posts(t, x0 - 3, gy - 1);
            Posts(t, x1 + 3, gy - 1);
            Posts(t, x0 - 3, gy + 1);
            Posts(t, x1 + 3, gy + 1);
            FlowerLine(t, x0 - 3, gy - 9, x0 - 3, gy - 3);
            FlowerLine(t, x1 + 3, gy - 9, x1 + 3, gy - 3);
            FlowerLine(t, x0 - 3, gy + 3, x0 - 3, gy + 9);
            FlowerLine(t, x1 + 3, gy + 3, x1 + 3, gy + 9);
            signs.Add(new GateSign { X = x0 - 2, Y = gy - 4, Dest = south, Dir = 0 });
            signs.Add(new GateSign { X = x0 - 2, Y = gy + 4, Dest = north, Dir = 3 });
        }


        static void PutLane(TileType[,] tiles, int x, int y)
        {
            Put(tiles, x, y, TileType.Path);
            Put(tiles, x + 1, y, TileType.Path);
        }

        static void CarveCountry(TileType[,] tiles)
        {
            int y0 = GameConst.CountryOy;
            int y1 = GameConst.BeachOy;
            int spine = GameConst.SpineX;
            for (int y = y0; y < y1; y++)
                PutLane(tiles, spine, y);
            for (int y = y0 + 1; y < y1 - 1; y++)
            {
                int along = y - y0;
                if (along % 3 == 0)
                {
                    Put(tiles, spine - 2, y, TileType.Fence);
                    Put(tiles, spine + 3, y, TileType.Fence);
                }
                if ((y + 1) % 4 == 0)
                    Put(tiles, spine + 5, y, TileType.Flower);
                if (y % 5 == 0)
                    Put(tiles, spine - 4, y, TileType.Flower);
                if (along % 7 == 3)
                    Put(tiles, spine - 6, y, TileType.Flower);
                if (along % 8 == 5)
                    Put(tiles, spine + 7, y, TileType.Flower);
                if (along % 11 == 2)
                    Put(tiles, spine + 4, y, TileType.Rock);
            }

            for (int y = y0 + 2; y < y1 - 2; y += 3)
            {
                int n = (y * 11 + spine) & 3;
                Put(tiles, 6 + n, y, TileType.Tree);
                Put(tiles, 12 + (n % 2), y + 1, TileType.Tree);
                Put(tiles, spine - 9 - (n % 2), y, TileType.Tree);
                Put(tiles, spine + 10 + (n % 2), y + 1, TileType.Tree);
                Put(tiles, Vx(58) + (n % 2), y, TileType.Tree);
                if ((y + n) % 5 == 0)
                    Put(tiles, Vx(32) + n, y + 1, TileType.Tree);
            }

            int[,] trees = { {8,2},{12,8},{6,11},{Vx(28),3},{Vx(32),9},{Vx(58),4},{Vx(61),16},{3,6},{Vx(30),22},{10,24},{Vx(56),28},{4,32},{Vx(60),34} };
            for (int i = 0; i < trees.GetLength(0); i++)
            {
                int y = y0 + trees[i, 1];
                if (y > y0 && y < y1 - 1)
                    Put(tiles, trees[i, 0], y, TileType.Tree);
            }
            int[,] flowers = { {16,3},{22,7},{Vx(50),2},{Vx(54),8},{Vx(36),5},{Vx(40),12},{18,18},{Vx(38),20},{14,26},{Vx(52),30},{20,34},{Vx(42),36} };
            for (int i = 0; i < flowers.GetLength(0); i++)
            {
                int y = y0 + flowers[i, 1];
                if (y > y0 && y < y1 - 1)
                    Put(tiles, flowers[i, 0], y, TileType.Flower);
            }
        }

        static void CarveBeach(TileType[,] tiles)
        {
            int y0 = GameConst.BeachOy;
            int spine = GameConst.SpineX;
            for (int y = y0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (y >= BeachShoreY(x, y0))
                        Put(tiles, x, y, TileType.Water);
                    else
                        Put(tiles, x, y, TileType.Sand);
                }
            }
            int sandEnd = y0 + 14;
            for (int y = y0; y < sandEnd; y++)
                PutLane(tiles, spine, y);
            for (int x = spine; x <= Vx(52); x++)
            {
                if (tiles[x, sandEnd - 1] != TileType.Water)
                    Put(tiles, x, sandEnd - 1, TileType.Path);
                if (tiles[x, sandEnd - 2] != TileType.Water)
                    Put(tiles, x, sandEnd - 2, TileType.Path);
            }
            int[,] rocks = { {10,4},{18,7},{28,5},{Vx(48),3},{Vx(56),6},{Vx(62),8},{6,9},{Vx(40),10},{14,16},{Vx(36),18},{22,20},{Vx(58),22} };
            for (int i = 0; i < rocks.GetLength(0); i++)
            {
                int x = rocks[i,0], y = y0 + rocks[i,1];
                if (y < GameConst.MapH && tiles[x, y] == TileType.Sand)
                    Put(tiles, x, y, TileType.Rock);
            }
            int[,] drift = { {14,6},{24,9},{Vx(52),5},{Vx(33),8},{8,11},{18,17},{Vx(42),19},{12,21} };
            for (int i = 0; i < drift.GetLength(0); i++)
            {
                int x = drift[i,0], y = y0 + drift[i,1];
                if (y < GameConst.MapH && tiles[x, y] == TileType.Sand)
                    Put(tiles, x, y, TileType.Stump);
            }
            int[,] flowers = { {12,2},{20,3},{Vx(36),2},{Vx(44),4},{Vx(58),3},{Vx(30),6},{16,12},{Vx(48),14} };
            for (int i = 0; i < flowers.GetLength(0); i++)
            {
                int x = flowers[i,0], y = y0 + flowers[i,1];
                if (y < GameConst.MapH && tiles[x, y] != TileType.Water)
                    Put(tiles, x, y, TileType.Flower);
            }
            Put(tiles, 4, y0 + 3, TileType.Tree);
            Put(tiles, Vx(60), y0 + 2, TileType.Tree);
            Put(tiles, 10, y0 + 1, TileType.Tree);
            Put(tiles, Vx(54), y0 + 1, TileType.Tree);
            Put(tiles, 7, y0 + 12, TileType.Tree);
            Put(tiles, Vx(62), y0 + 11, TileType.Tree);
            for (int x = 1; x < GameConst.MapW - 1; x++)
            {
                int shore = BeachShoreY(x, y0);
                if (((x * 5 + 2) % 4) == 0 && shore - 1 >= y0 + 7 && tiles[x, shore - 1] == TileType.Sand)
                    Put(tiles, x, shore - 1, TileType.Water);
                if (((x * 3 + 1) % 5) == 0 && shore < GameConst.MapH - 1 && tiles[x, shore] == TileType.Water)
                    Put(tiles, x, shore, TileType.Sand);
            }
            CarveDock(tiles, y0);
        }

        static int BeachShoreY(int x, int y0)
        {
            int wave = (int)Math.Round(Math.Sin(x * 0.27) * 3.2 + Math.Sin(x * 0.73 + 0.4) * 2.0);
            int jag = ((x * 7 + 3) % 5) - 2;
            int shore = y0 + 22 + wave + jag / 2;
            int cx = GameConst.RiverCenterX(y0 + 18);
            int dx = Math.Abs(x - cx);
            if (dx < 14)
                shore -= (14 - dx) / 2;
            if (shore < y0 + 16)
                shore = y0 + 16;
            if (shore > y0 + 32)
                shore = y0 + 32;
            return shore;
        }

        static void CarveDock(TileType[,] tiles, int y0)
        {
            int platX0 = Vx(48);
            int platX1 = Vx(58);
            int platY0 = y0 + 7;
            int platY1 = y0 + 13;
            int pierX1 = Vx(63);
            FillDock(tiles, platX0, platY0, platX1, platY1);
            FillDock(tiles, Vx(57), y0 + 9, pierX1, y0 + 12);
            FillDock(tiles, Vx(60), y0 + 8, pierX1, y0 + 13);
            FillDock(tiles, Vx(53), platY1 + 1, Vx(55), y0 + 22);
            FillDock(tiles, Vx(59), platY1 + 1, Vx(61), y0 + 19);
            int spine = GameConst.SpineX;
            for (int x = spine; x < platX0; x++)
            {
                Put(tiles, x, platY0 + 1, TileType.Path);
                Put(tiles, x, platY0 + 2, TileType.Path);
            }
            Put(tiles, platX0, platY0 + 1, TileType.Dock);
            Put(tiles, platX0, platY0 + 2, TileType.Dock);
            FloodDockHarbor(tiles, platX0 - 1, platY0, pierX1 + 2, y0 + 26);
        }

        static void FillDock(TileType[,] tiles, int x0, int y0, int x1, int y1)
        {
            for (int y = y0; y <= y1; y++)
            {
                for (int x = x0; x <= x1; x++)
                    Put(tiles, x, y, TileType.Dock);
            }
        }

        static void FloodDockHarbor(TileType[,] tiles, int x0, int y0, int x1, int y1)
        {
            for (int y = y0; y <= y1; y++)
            {
                for (int x = x0; x <= x1; x++)
                {
                    if (x <= 0 || y <= 0 || x >= GameConst.MapW - 1 || y >= GameConst.MapH - 1)
                        continue;
                    TileType t = tiles[x, y];
                    if (t == TileType.Dock || t == TileType.Path || t == TileType.Bridge
                        || t == TileType.Roof || t == TileType.HouseWall || t == TileType.Door)
                        continue;
                    if (t == TileType.Sand || t == TileType.Grass || t == TileType.Flower
                        || t == TileType.Weed || t == TileType.Tree || t == TileType.Rock
                        || t == TileType.Stump || t == TileType.Shell || t == TileType.Seaweed)
                        tiles[x, y] = TileType.Water;
                }
            }
        }

        public static void ScatterBeachForage(TileType[,] tiles)
        {
            PlaceBeachForage(tiles, true);
        }

        public static void RefillBeachForage(TileType[,] tiles)
        {
            PlaceBeachForage(tiles, false);
        }

        static void PlaceBeachForage(TileType[,] tiles, bool replace)
        {
            int y0 = GameConst.BeachOy;
            for (int y = y0 + 1; y < GameConst.MapH - 1; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    TileType t = tiles[x, y];
                    if (t != TileType.Sand && t != TileType.Shell && t != TileType.Seaweed)
                        continue;
                    if (!replace && t != TileType.Sand)
                        continue;
                    int roll = (x * 19 + y * 41 + x * y) & 31;
                    bool wet = NeighborsWater(tiles, x, y);
                    if (wet)
                    {
                        if (roll <= 5)
                            tiles[x, y] = TileType.Seaweed;
                        else if (roll == 6 || roll == 7)
                            tiles[x, y] = TileType.Shell;
                    }
                    else if (roll <= 3)
                        tiles[x, y] = TileType.Shell;
                    else if (roll == 4)
                        tiles[x, y] = TileType.Seaweed;
                    else if (replace && t != TileType.Sand)
                        tiles[x, y] = TileType.Sand;
                }
            }
        }

        static bool NeighborsWater(TileType[,] tiles, int x, int y)
        {
            int[,] dxy = { { 0, -1 }, { 0, 1 }, { -1, 0 }, { 1, 0 } };
            for (int i = 0; i < 4; i++)
            {
                int nx = x + dxy[i, 0];
                int ny = y + dxy[i, 1];
                if (nx < 0 || ny < 0 || nx >= GameConst.MapW || ny >= GameConst.MapH)
                    continue;
                if (tiles[nx, ny] == TileType.Water)
                    return true;
            }
            return false;
        }

        static void Put(TileType[,] tiles, int x, int y, TileType t)
        {
            if (x >= 0 && y >= 0 && x < GameConst.MapW && y < GameConst.MapH)
                tiles[x, y] = t;
        }

        static void SoftPut(TileType[,] tiles, int x, int y, TileType t)
        {
            if (x < 0 || y < 0 || x >= GameConst.MapW || y >= GameConst.MapH)
                return;
            TileType here = tiles[x, y];
            if (here == TileType.Grass || here == TileType.Flower || here == TileType.Weed)
                tiles[x, y] = t;
        }

        static void CobblePad(TileType[,] tiles, int x0, int y0, int x1, int y1)
        {
            for (int y = y0; y <= y1; y++)
            {
                for (int x = x0; x <= x1; x++)
                {
                    if (((x * 3 + y * 5) & 3) == 0)
                    {
                        SoftPut(tiles, x, y, TileType.Flower);
                        continue;
                    }
                    if (((x + y) & 1) == 0)
                        continue;
                    Put(tiles, x, y, TileType.Cobble);
                }
            }
        }

        static void ForgeYard(TileType[,] tiles, int hx, int hy, int hw, int hh, int doorDx)
        {
            int doorX = hx + doorDx;
            int front = hy + hh;
            Put(tiles, doorX, front, TileType.Path);
            Put(tiles, doorX, front + 1, TileType.Path);
            int[,] stones =
            {
                { hx + 4, front }, { hx + 5, front + 1 }, { hx + 6, front },
                { hx + 5, front + 2 }, { hx + 4, front + 1 }
            };
            for (int i = 0; i < stones.GetLength(0); i++)
            {
                int x = stones[i, 0];
                int y = stones[i, 1];
                if (tiles[x, y] != TileType.Path && tiles[x, y] != TileType.Door)
                    Put(tiles, x, y, TileType.Rock);
            }
            Put(tiles, hx - 2, hy + 2, TileType.Rock);
            Put(tiles, hx - 1, hy + 3, TileType.Rock);
            Put(tiles, hx - 2, hy + 4, TileType.Rock);
            SoftPut(tiles, hx - 1, front + 2, TileType.Flower);
            SoftPut(tiles, hx + hw + 1, hy + 1, TileType.Flower);
        }

        static void FarmhouseYard(TileType[,] tiles, int hx, int hy, int hw, int hh, int doorDx)
        {
            int doorX = hx + doorDx;
            int front = hy + hh;
            for (int dx = -2; dx <= hw + 1; dx++)
            {
                int x = hx + dx;
                if (x == doorX || x == doorX - 1 || x == doorX + 1)
                    continue;
                if ((dx & 1) == 0)
                    SoftPut(tiles, x, front, TileType.Flower);
                if (dx % 3 == 0)
                    SoftPut(tiles, x, front + 2, TileType.Flower);
            }
            SoftPut(tiles, hx - 1, hy + 2, TileType.Flower);
            SoftPut(tiles, hx + hw, hy + 2, TileType.Flower);
            SoftPut(tiles, hx - 2, front + 1, TileType.Flower);
            SoftPut(tiles, hx + hw + 1, front + 1, TileType.Flower);
        }

        static void CottageGarden(TileType[,] tiles, int hx, int hy, int hw, int hh, int doorDx)
        {
            int doorX = hx + doorDx;
            int front = hy + hh;
            for (int dx = -2; dx <= hw + 1; dx++)
            {
                int x = hx + dx;
                if (x == doorX || x == doorX - 1 || x == doorX + 1)
                    continue;
                SoftPut(tiles, x, front, TileType.Flower);
                if ((dx & 1) == 0)
                    SoftPut(tiles, x, front + 1, TileType.Flower);
                if (dx % 3 == 0)
                    SoftPut(tiles, x, front + 2, TileType.Flower);
            }
            for (int dy = -1; dy < hh + 1; dy++)
            {
                SoftPut(tiles, hx - 1, hy + dy, TileType.Flower);
                SoftPut(tiles, hx + hw, hy + dy, TileType.Flower);
                if ((dy & 1) == 0)
                {
                    SoftPut(tiles, hx - 2, hy + dy, TileType.Flower);
                    SoftPut(tiles, hx + hw + 1, hy + dy, TileType.Flower);
                }
            }
            SoftPut(tiles, hx - 1, front, TileType.Fence);
            SoftPut(tiles, hx + hw, front, TileType.Fence);
            SoftPut(tiles, hx - 2, front + 1, TileType.Fence);
            SoftPut(tiles, hx + hw + 1, front + 1, TileType.Fence);
        }

        static void FlowerPatch(TileType[,] tiles, int x0, int y0, int w, int h)
        {
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    if (((x + y) & 1) == 0)
                        SoftPut(tiles, x0 + x, y0 + y, TileType.Flower);
                }
            }
        }

        static void FlowerBorder(TileType[,] tiles, int x0, int y0, int x1, int y1)
        {
            int dx = Math.Sign(x1 - x0);
            int dy = Math.Sign(y1 - y0);
            int x = x0;
            int y = y0;
            while (true)
            {
                if (((x + y) % 2) == 0)
                    SoftPut(tiles, x, y, TileType.Flower);
                if (x == x1 && y == y1)
                    break;
                if (x != x1)
                    x += dx == 0 ? 0 : dx;
                if (y != y1)
                    y += dy == 0 ? 0 : dy;
            }
        }
    }
}
