using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    public sealed class FishDef
    {
        public string Id;
        public string Name;
        public int Sell;
        public int Weight;
        public Color Body;
        public Color Fin;

        public FishDef(string id, string name, int sell, int weight, Color body, Color fin)
        {
            Id = id;
            Name = name;
            Sell = sell;
            Weight = weight;
            Body = body;
            Fin = fin;
        }
    }

    public static class FishCatalog
    {
        public static readonly FishDef[] Saltwater =
        {
            new FishDef("anchovy", "Anchovy", 18, 22, new Color(148, 156, 168), new Color(92, 98, 110)),
            new FishDef("sardine", "Sardine", 22, 20, new Color(176, 186, 196), new Color(72, 118, 148)),
            new FishDef("herring", "Herring", 28, 18, new Color(132, 154, 168), new Color(64, 96, 118)),
            new FishDef("mackerel", "Mackerel", 36, 16, new Color(58, 118, 132), new Color(36, 72, 86)),
            new FishDef("flounder", "Flounder", 44, 12, new Color(186, 164, 108), new Color(132, 108, 64)),
            new FishDef("cod", "Atlantic Cod", 52, 12, new Color(168, 176, 186), new Color(96, 108, 124)),
            new FishDef("seabass", "Sea Bass", 64, 10, new Color(48, 72, 86), new Color(28, 48, 58)),
            new FishDef("eel", "Conger Eel", 72, 8, new Color(62, 78, 72), new Color(36, 48, 44)),
            new FishDef("crab", "Dungeness Crab", 48, 10, new Color(196, 86, 48), new Color(148, 52, 32)),
            new FishDef("snapper", "Red Snapper", 88, 7, new Color(196, 72, 58), new Color(148, 40, 36)),
            new FishDef("squid", "Market Squid", 60, 8, new Color(186, 168, 196), new Color(118, 92, 148)),
            new FishDef("halibut", "Halibut", 110, 5, new Color(164, 168, 148), new Color(96, 102, 86)),
            new FishDef("puffer", "Pufferfish", 96, 4, new Color(214, 196, 86), new Color(72, 128, 92)),
            new FishDef("lobster", "Lobster", 130, 3, new Color(176, 42, 36), new Color(118, 24, 22)),
            new FishDef("tuna", "Bluefin Tuna", 180, 2, new Color(36, 72, 118), new Color(214, 140, 48))
        };

        public static FishDef Find(string id)
        {
            if (string.IsNullOrEmpty(id))
                return null;
            if (id.Length > 5 && id.StartsWith("fish."))
                id = id.Substring(5);
            for (int i = 0; i < Saltwater.Length; i++)
            {
                if (Saltwater[i].Id == id)
                    return Saltwater[i];
            }
            return null;
        }

        public static bool IsFish(string id)
        {
            return Find(id) != null;
        }

        public static string ItemId(string fishId)
        {
            return "fish." + fishId;
        }

        public static FishDef RollSaltwater(System.Random rng)
        {
            int total = 0;
            for (int i = 0; i < Saltwater.Length; i++)
                total += Saltwater[i].Weight;
            int roll = rng.Next(total);
            int acc = 0;
            for (int i = 0; i < Saltwater.Length; i++)
            {
                acc += Saltwater[i].Weight;
                if (roll < acc)
                    return Saltwater[i];
            }
            return Saltwater[0];
        }
    }
}
