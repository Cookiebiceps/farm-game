using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    public enum TileType
    {
        Grass = 0,
        FarmSoil = 1,
        Tilled = 2,
        Wet = 3,
        Water = 4,
        Path = 5,
        Fence = 6,
        HouseWall = 7,
        HouseFloor = 8,
        Tree = 9,
        Rock = 10,
        Bin = 11,
        Bed = 12,
        Counter = 13,
        Flower = 14,
        Weed = 15,
        Door = 16,
        WoodsGrass = 17,
        Stump = 18,
        Roof = 19,
        Cliff = 20,
        Mountain = 21,
        Cobble = 22,
        Sand = 23,
        HouseWindow = 24,
        Dock = 25,
        Dummy = 26,
        Mineral = 27,
        Bridge = 28,
        Stairs = 29,
        Chest = 30,
        Shell = 31,
        Seaweed = 32,
        Hay = 33,
        HayCut = 34,
        InvisibleWall = 35
    }

    public enum ToolId
    {
        Hoe,
        Can,
        Scythe,
        Axe,
        Pickaxe,
        Sword,
        Rod,
        MilkPail,
        Shears,
        Turnip,
        Potato,
        Cabbage,
        Melon,
        Pumpkin
    }

    public enum Screen
    {
        Title,
        Play,
        Shop,
        Sleep,
        Help,
        Bag,
        Loading,
        Settings,
        Join,
        Create,
        Skills,
        Admin,
        Plan,
        MapEdit
    }

    public enum MapEditTool
    {
        Move = 0,
        Paint = 1,
        Erase = 2,
        Wall = 3,
        Dropper = 4,
        Place = 5
    }

    public enum MapStampKind
    {
        Tile = 0,
        Building = 1,
        Deco = 2,
        Animal = 3,
        Crop = 4,
        Gate = 5
    }

    public sealed class MapStamp
    {
        public MapStampKind Kind;
        public string Name = "";
        public TileType Tile;
        public BuildingKind HouseKind;
        public string HouseName = "";
        public string HousePrefix = "";
        public int W = 1;
        public int H = 1;
        public int DoorDx;
        public int Style;
        public int Deco;
        public AnimalKind Animal;
        public string CropId = "";
        public string GateDest = "";
        public int GateDir;
    }

    public enum MapEditKind
    {
        None = 0,
        Building = 1,
        Tile = 2,
        Deco = 3,
        Gate = 4,
        Animal = 5,
        Npc = 6,
        Bridge = 7
    }

    public sealed class MapEditPick
    {
        public MapEditKind Kind;
        public string Name = "";
        public int X;
        public int Y;
        public int W = 1;
        public int H = 1;
        public Building House;
        public int Index = -1;
        public TileType Tile;
        public Crop Crop;
        public Deco DecoCopy;
        public GateSign GateCopy;
        public StoneBridge BridgeCopy;
        public AnimalKind AnimalKind;
        public Vector2 AnimalPos;
        public int AnimalDir;
        public string NpcId;
        public string NpcName;
        public string NpcLine;
    }

    public sealed class CropDef
    {
        public string Id;
        public string Name;
        public string SeedName;
        public int Days;
        public int SeedCost;
        public int Sell;
        public Color Fruit;
        public Color Leaf;

        public CropDef(string id, string name, string seedName, int days, int seedCost, int sell, Color fruit, Color leaf)
        {
            Id = id;
            Name = name;
            SeedName = seedName;
            Days = days;
            SeedCost = seedCost;
            Sell = sell;
            Fruit = fruit;
            Leaf = leaf;
        }
    }

    public sealed class Crop
    {
        public string Id;
        public int Stage;
        public bool Watered;
    }

    public enum AnimalKind
    {
        Chicken = 0,
        Rabbit = 1,
        Sheep = 2,
        Pig = 3,
        Cow = 4,
        Horse = 5
    }

    public sealed class FarmAnimal
    {
        public AnimalKind Kind;
        public Vector2 Pos;
        public int Dir;
        public float Anim;
        public bool Moving;
        public float WanderT;
        public Vector2 Wander;
        public bool MilkedToday;
        /// <summary>Sheep start woolly. Cleared when sheared; grows back the next morning.</summary>
        public bool HasWool = true;
        public int LastShearDay;
    }

    public static class AnimalCatalog
    {
        public const int Count = 6;
        public const int MaxOnFarm = 16;
        public static readonly string[] Ids =
        {
            "animal.chicken", "animal.rabbit", "animal.sheep",
            "animal.pig", "animal.cow", "animal.horse"
        };
        public static readonly string[] Names =
        {
            "Chicken", "Rabbit", "Sheep", "Pig", "Cow", "Horse"
        };
        public static readonly int[] Prices = { 80, 100, 250, 300, 400, 550 };
        public static readonly float[] DrawScale = { 0.36f, 0.40f, 0.50f, 0.48f, 0.58f, 0.66f };
        public static readonly float[] Speed = { 52f, 58f, 34f, 36f, 30f, 48f };

        public static string ItemId(AnimalKind kind)
        {
            int i = (int)kind;
            if (i < 0 || i >= Ids.Length)
                return Ids[0];
            return Ids[i];
        }

        public static string Name(AnimalKind kind)
        {
            int i = (int)kind;
            if (i < 0 || i >= Names.Length)
                return Names[0];
            return Names[i];
        }

        public static int Price(AnimalKind kind)
        {
            int i = (int)kind;
            if (i < 0 || i >= Prices.Length)
                return Prices[0];
            return Prices[i];
        }

        public static float Scale(AnimalKind kind)
        {
            int i = (int)kind;
            if (i < 0 || i >= DrawScale.Length)
                return 0.5f;
            return DrawScale[i];
        }

        public static float WalkSpeed(AnimalKind kind)
        {
            int i = (int)kind;
            if (i < 0 || i >= Speed.Length)
                return 40f;
            return Speed[i];
        }

        public static bool TryParse(string id, out AnimalKind kind)
        {
            kind = AnimalKind.Chicken;
            if (string.IsNullOrEmpty(id))
                return false;
            for (int i = 0; i < Ids.Length; i++)
            {
                if (Ids[i] == id)
                {
                    kind = (AnimalKind)i;
                    return true;
                }
            }
            return false;
        }

        public static bool IsLivestock(string id)
        {
            AnimalKind k;
            return TryParse(id, out k);
        }
    }

    public enum CaveMobKind
    {
        Bat = 0,
        Slime = 1,
        Spider = 2,
        Troll = 3
    }

    public static class CaveMobCatalog
    {
        public const int Count = 4;

        public static int Clamp(int kind)
        {
            if (kind < 0 || kind >= Count)
                return (int)CaveMobKind.Troll;
            return kind;
        }

        public static string Name(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return "cave bat";
            if (kind == (int)CaveMobKind.Slime)
                return "cave slime";
            if (kind == (int)CaveMobKind.Spider)
                return "cave spider";
            return "cave troll";
        }

        public static int Available(int floor)
        {
            if (floor < 8)
                return 2;
            if (floor < 20)
                return 3;
            return 4;
        }

        public static int Pick(int index, int floor)
        {
            int n = Available(floor);
            if (n < 1)
                n = 1;
            return index % n;
        }

        public static int BaseHp(int kind, int floor)
        {
            kind = Clamp(kind);
            int hp = 28;
            if (kind == (int)CaveMobKind.Bat)
                hp = 8;
            else if (kind == (int)CaveMobKind.Slime)
                hp = 16;
            else if (kind == (int)CaveMobKind.Spider)
                hp = 12;
            int grow = kind == (int)CaveMobKind.Troll ? 2 : 1;
            return hp + floor * grow;
        }

        public static float Speed(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 78f;
            if (kind == (int)CaveMobKind.Slime)
                return 28f;
            if (kind == (int)CaveMobKind.Spider)
                return 64f;
            return 42f;
        }

        public static float Aggro(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 80f;
            if (kind == (int)CaveMobKind.Slime)
                return 36f;
            if (kind == (int)CaveMobKind.Spider)
                return 58f;
            return 48f;
        }

        public static int HitEnergy(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 4;
            if (kind == (int)CaveMobKind.Slime)
                return 6;
            if (kind == (int)CaveMobKind.Spider)
                return 7;
            return 8;
        }

        public static float HitCd(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 0.85f;
            if (kind == (int)CaveMobKind.Slime)
                return 1.45f;
            if (kind == (int)CaveMobKind.Spider)
                return 0.95f;
            return 1.2f;
        }

        public static float Scale(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 0.40f;
            if (kind == (int)CaveMobKind.Slime)
                return 0.48f;
            if (kind == (int)CaveMobKind.Spider)
                return 0.44f;
            return GameConst.TrollScale;
        }

        public static float BlockRadius(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return 10f;
            if (kind == (int)CaveMobKind.Slime)
                return 16f;
            if (kind == (int)CaveMobKind.Spider)
                return 12f;
            return 18f;
        }

        public static string HitLine(int kind)
        {
            kind = Clamp(kind);
            if (kind == (int)CaveMobKind.Bat)
                return "A cave bat nips you!";
            if (kind == (int)CaveMobKind.Slime)
                return "A slime slaps you!";
            if (kind == (int)CaveMobKind.Spider)
                return "A cave spider bites!";
            return "A troll clubs you!";
        }

        public static string KillLine(int kind, int gold, bool stone)
        {
            string who = Name(kind);
            string fall = "The " + who + " falls. +" + gold.ToString() + "g";
            if (stone)
                fall += ", +1 stone.";
            else
                fall += ".";
            return fall;
        }
    }

    public sealed class CaveTroll
    {
        public Vector2 Pos;
        public int Dir;
        public float Anim;
        public bool Moving;
        public int Kind = (int)CaveMobKind.Troll;
        public int Hp;
        public int MaxHp = 28;
        public float HurtT;
        public float AtkCd;
        public float WanderT;
        public Vector2 Wander;
        public bool Alive = true;
    }

    public sealed class CaveGuest
    {
        public Vector2 Pos;
        public Action<int> Hurt;
    }

    public sealed class StoneBridge
    {
        public int X;
        public int Y;
        public int W;
        public int H;
        public bool NorthSouth;
    }

    public sealed class MineralSpot
    {
        public string InsideId;
        public int X;
        public int Y;
    }

    public static class CropCatalog
    {
        public static readonly CropDef Turnip = new CropDef("turnip", "Turnip", "Turnip seeds", 4, 20, 35, new Color(232, 212, 138), new Color(111, 191, 78));
        public static readonly CropDef Potato = new CropDef("potato", "Potato", "Potato seeds", 6, 30, 80, new Color(212, 180, 131), new Color(79, 154, 58));
        public static readonly CropDef Cabbage = new CropDef("cabbage", "Cabbage", "Cabbage seeds", 6, 40, 110, new Color(86, 118, 62), new Color(58, 88, 48));
        public static readonly CropDef Melon = new CropDef("melon", "Melon", "Melon seeds", 8, 80, 200, new Color(176, 72, 92), new Color(86, 118, 62));
        public static readonly CropDef Pumpkin = new CropDef("pumpkin", "Pumpkin", "Pumpkin seeds", 10, 100, 320, new Color(224, 122, 47), new Color(72, 102, 54));

        public static readonly CropDef[] All = { Turnip, Potato, Cabbage, Melon, Pumpkin };

        public static CropDef Find(string id)
        {
            for (int i = 0; i < All.Length; i++)
            {
                if (All[i].Id == id)
                    return All[i];
            }
            return null;
        }

        public static CropDef FromTool(ToolId tool)
        {
            switch (tool)
            {
                case ToolId.Turnip: return Turnip;
                case ToolId.Potato: return Potato;
                case ToolId.Cabbage: return Cabbage;
                case ToolId.Melon: return Melon;
                case ToolId.Pumpkin: return Pumpkin;
                default: return null;
            }
        }
    }

    public static class GameConst
    {
        public const int Tile = 32;
        public const float PlayerSpeed = 184f;
        public const int ShadeW = 20;
        public const int WoodsWidth = 24;
        public const int SummitW = 28 + ShadeW;
        public const int VillageH = 60;
        public const int MountainH = 40;
        public const int FarmH = 52;
        public const int LegacyFarmH = 32;
        public const int LegacyCountryH = 14;
        public const int CountryH = 40;
        public const int LegacyBeachH = 40;
        public const int BeachH = 64;
        public const int FarmOy = VillageH + MountainH;
        public const int CountryOy = FarmOy + FarmH;
        public const int BeachOy = CountryOy + CountryH;
        public const int LegacyFarmOx = 24;
        public const int LegacyMapW = 66;
        public const int FarmOx = ShadeW + WoodsWidth;
        public const int MapW = LegacyMapW + ShadeW;
        public const int MapH = BeachOy + BeachH;
        public const int LegacyMapH = VillageH + MountainH + LegacyFarmH + LegacyCountryH + LegacyBeachH;
        public const int SpineX = FarmOx + 20;

        /// <summary>
        /// Hollow River x, matching MapGen so beach looks and the channel agree.
        /// </summary>
        public static int RiverCenterX(int y)
        {
            if (y >= 28 && y <= 36)
                return 54 + ShadeW;
            int bend = (int)Math.Round((Math.Sin(y * 0.14) + 1.0) * 0.55);
            if (bend < 0) bend = 0;
            if (bend > 1) bend = 1;
            return 47 + ShadeW + bend;
        }

        /// <summary>
        /// 0 pond, 1 flowing stream (river into the bay), 2 deeper ocean.
        /// Saltwind keeps the Hollow River material across the shallows so the
        /// mouth is one current, then eases into a slightly calmer swell.
        /// </summary>
        public static int WaterLook(int tx, int ty)
        {
            if (ty < VillageH && tx < SpineX)
                return 0;
            if (ty < BeachOy + 36)
                return 1;
            return 2;
        }

        public static bool InFarmBand(int ty)
        {
            return ty >= FarmOy && ty < CountryOy;
        }

        public static bool InMoonveil(int tx, int ty)
        {
            return InFarmBand(ty) && tx < ShadeW;
        }

        public static bool InWoods(int tx, int ty)
        {
            return InFarmBand(ty) && tx >= ShadeW && tx < FarmOx;
        }

        public static bool InDeepForest(int tx, int ty)
        {
            return InMoonveil(tx, ty) || InWoods(tx, ty);
        }

        public static bool InSummit(int tx, int ty)
        {
            return ty >= VillageH && ty < FarmOy && tx < SummitW;
        }
        public const int MaxPlayers = 6;
        public const int NetPort = 27431;
        public const int MaxEnergy = 100;
        public const int CanCapacity = 40;
        public const int SiloCapacity = 240;
        public const float HayRegrowMinutes = 6 * 60;
        public const float TreeFallDur = 0.78f;
        public const int TestPlanks = 100;
        public const int WoolRegrowDays = 1;
        public const int GreenhouseInsideW = 12;
        public const int GreenhouseInsideH = 24;
        public const int BarnDoorApproach = 2;
        public const float BarnDoorSlide = 18f;
        public const int DayStart = 6 * 60;
        public const int DayEnd = 26 * 60;
        public const float MinutesPerSecond = 5f;
        public const int BarSlots = 9;
        public const int PackCols = 9;
        public const int PackBaseRows = 3;
        public const int PackBaseSlots = PackCols * PackBaseRows;
        public const int PackUpgradeSize = 5;
        public const int PackUpgradeMax = 5;
        public const int PackMaxSlots = PackBaseSlots + PackUpgradeSize * PackUpgradeMax;
        public const int PackSlots = PackMaxSlots;
        public const float CharScale = 0.5f;
        public const float TrollScale = 0.58f;
        public const float ToolScale = 0.58f;
        public const float HandScale = 0.52f;
        public const float BodyHalfW = 12f;
        public const float BodyHalfH = 10f;
        public const int MiraTx = 42 + ShadeW;
        public const int MiraTy = 18;
        public const int CobTx = 58 + ShadeW;
        public const int CobTy = 16;
        public const int LilaTx = 22 + ShadeW;
        public const int LilaTy = 37;
        public const int BramTx = 52 + ShadeW;
        public const int BramTy = 37;
        public const int NellTx = 10 + ShadeW;
        public const int NellTy = 51;
    }

    public enum TreeKind
    {
        Oak,
        Apple,
        Birch,
        Pine,
        Spruce,
        Willow,
        Blossom,
        Palm,
        Dead,
        Autumn,
        DarkOak
    }

    public sealed class FallingTree
    {
        public int Tx;
        public int Ty;
        public float Life;
        public float Dur;
        public int Sign;
    }

    public sealed class BarnSprite
    {
        public Texture2D Body;
        public Texture2D Left;
        public Texture2D Right;
        public int LeftX;
        public int LeftY;
        public int RightX;
        public int RightY;
        public int Slide;
    }

    public static class TreeSpecies
    {
        public static TreeKind KindAt(int tx, int ty)
        {
            if (tx == 12 + GameConst.ShadeW && ty == 16)
                return TreeKind.Willow;
            int h = ((tx * 73 + ty * 149) ^ (tx << 4)) & 255;
            if (ty < GameConst.VillageH)
            {
                if (tx >= 2 + GameConst.ShadeW && tx <= 24 + GameConst.ShadeW && ty >= 6 && ty <= 26)
                    return TreeKind.Willow;
                if (h < 150)
                    return TreeKind.Blossom;
                if (h < 210)
                    return TreeKind.Willow;
                return TreeKind.Oak;
            }
            if (ty < GameConst.FarmOy)
            {
                if (tx < GameConst.SummitW)
                    return (h % 5 == 0) ? TreeKind.Dead : TreeKind.Pine;
                return (h % 7 == 0) ? TreeKind.Spruce : TreeKind.Pine;
            }
            if (ty < GameConst.CountryOy)
            {
                if (GameConst.InMoonveil(tx, ty))
                {
                    if (h < 90)
                        return TreeKind.Pine;
                    if (h < 150)
                        return TreeKind.DarkOak;
                    if (h < 200)
                        return TreeKind.Spruce;
                    return TreeKind.Dead;
                }
                if (GameConst.InWoods(tx, ty))
                {
                    if (h < 48)
                        return TreeKind.Pine;
                    if (h < 88)
                        return TreeKind.Dead;
                    if (h < 128)
                        return TreeKind.Spruce;
                    return TreeKind.Autumn;
                }
                if (ty < GameConst.FarmOy + 6 && h < 110)
                    return (h % 3 == 0) ? TreeKind.Spruce : TreeKind.Pine;
                if (h < 50)
                    return TreeKind.Birch;
                if (h < 110)
                    return TreeKind.Oak;
                if (h < 200)
                    return TreeKind.Apple;
                return TreeKind.Birch;
            }
            if (ty < GameConst.BeachOy)
            {
                if (h < 80)
                    return TreeKind.Pine;
                if (h < 160)
                    return TreeKind.Oak;
                return TreeKind.Birch;
            }
            return TreeKind.Palm;
        }

        public static string Hint(TreeKind kind)
        {
            switch (kind)
            {
                case TreeKind.Pine: return "4 Axe - chop this pine";
                case TreeKind.Spruce: return "4 Axe - chop this spruce";
                case TreeKind.Willow: return "4 Axe - chop this willow";
                case TreeKind.Blossom: return "4 Axe - chop this blossom tree";
                case TreeKind.Palm: return "4 Axe - chop this palm";
                case TreeKind.Birch: return "4 Axe - chop this birch";
                case TreeKind.Apple: return "4 Axe - chop this apple tree";
                case TreeKind.Dead: return "4 Axe - chop this snag";
                case TreeKind.Autumn: return "4 Axe - chop this old oak";
                case TreeKind.DarkOak: return "4 Axe - chop this dark oak";
                default: return "4 Axe - chop this tree";
            }
        }

        public static bool ShedsLeaves(TreeKind kind)
        {
            return kind != TreeKind.Pine && kind != TreeKind.Spruce && kind != TreeKind.Palm && kind != TreeKind.Dead;
        }
    }

    public sealed class NpcDef
    {
        public string Id;
        public string Name;
        public int Tx;
        public int Ty;
        public string Line;

        public NpcDef(string id, string name, int tx, int ty, string line)
        {
            Id = id;
            Name = name;
            Tx = tx;
            Ty = ty;
            Line = line;
        }
    }

    public static class VillageFolk
    {
        public static readonly NpcDef[] Outdoor =
        {
            new NpcDef("mira", "Mira", GameConst.MiraTx, GameConst.MiraTy, "Mira: Taproom's in the inn. Rooms are up the stair. Don't track mud on the boards."),
            new NpcDef("cob", "Cob", GameConst.CobTx, GameConst.CobTy, "Cob: West of the woods the oaks go dark — Moonveil. Bess sells livestock south of Ash."),
            new NpcDef("lila", "Lila", GameConst.LilaTx, GameConst.LilaTy, "Lila: Bread's in the oven. Piper sells a loaf if you missed breakfast."),
            new NpcDef("bram", "Bram", GameConst.BramTx, GameConst.BramTy, "Bram: More houses means more fences. Mind the cobbles after rain."),
            new NpcDef("nell", "Nell", GameConst.NellTx, GameConst.NellTy, "Nell: South gardens are mine. Don't hoe the flower beds.")
        };
    }

    public static class BeachForage
    {
        public const string SeaweedId = "seaweed";
        public static readonly string[] ShellIds =
        {
            "shell.cockle", "shell.scallop", "shell.whelk", "shell.sanddollar", "shell.conch"
        };
        public static readonly string[] ShellNames =
        {
            "Cockle", "Scallop", "Whelk", "Sand dollar", "Conch"
        };

        public static int ShellKindAt(int tx, int ty)
        {
            int h = ((tx * 97 + ty * 53) ^ (tx << 3)) & 255;
            if (h < 70) return 0;
            if (h < 130) return 1;
            if (h < 185) return 2;
            if (h < 230) return 3;
            return 4;
        }

        public static string ShellIdAt(int tx, int ty)
        {
            return ShellIds[ShellKindAt(tx, ty)];
        }

        public static string ShellNameAt(int tx, int ty)
        {
            return ShellNames[ShellKindAt(tx, ty)];
        }

        public static bool IsForage(string id)
        {
            if (id == SeaweedId)
                return true;
            for (int i = 0; i < ShellIds.Length; i++)
            {
                if (ShellIds[i] == id)
                    return true;
            }
            return false;
        }
    }
}
