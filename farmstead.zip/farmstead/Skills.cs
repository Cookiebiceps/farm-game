using System.IO;

namespace HarvestHollow
{
    public enum SkillId
    {
        Attack = 0,
        Woodcutting = 1,
        Mining = 2
    }

    public sealed class SkillSet
    {
        public const int Count = 3;
        public const int MaxLevel = 10;

        public static readonly string[] Names = { "Attack", "Woodcutting", "Mining" };

        public int Points;
        public readonly int[] Level = { 1, 1, 1 };
        public readonly int[] Xp = { 0, 0, 0 };

        public void Reset()
        {
            Points = 0;
            for (int i = 0; i < Count; i++)
            {
                Level[i] = 1;
                Xp[i] = 0;
            }
        }

        public int Need(int skill)
        {
            int lv = Level[skill];
            if (lv >= MaxLevel)
                return 0;
            return 8 + lv * 7;
        }

        public int WoodHits()
        {
            if (Level[(int)SkillId.Woodcutting] >= 7)
                return 1;
            return 2;
        }

        public int MineHits()
        {
            int lv = Level[(int)SkillId.Mining];
            if (lv >= 8) return 1;
            if (lv >= 4) return 2;
            return 3;
        }

        public int WoodYield()
        {
            return 1 + Level[(int)SkillId.Woodcutting] / 3;
        }

        public int StoneYield()
        {
            return 1 + Level[(int)SkillId.Mining] / 4;
        }

        public bool Gain(SkillId id, int amount, out string leveled)
        {
            leveled = null;
            int i = (int)id;
            if (amount <= 0 || i < 0 || i >= Count)
                return false;
            if (Level[i] >= MaxLevel)
                return false;
            Xp[i] += amount;
            bool up = false;
            while (Level[i] < MaxLevel && Xp[i] >= Need(i))
            {
                Xp[i] -= Need(i);
                Level[i]++;
                Points++;
                up = true;
                leveled = Names[i] + " " + Level[i].ToString();
            }
            if (Level[i] >= MaxLevel)
                Xp[i] = 0;
            return up;
        }

        public bool Spend(SkillId id)
        {
            int i = (int)id;
            if (Points <= 0 || i < 0 || i >= Count)
                return false;
            if (Level[i] >= MaxLevel)
                return false;
            Points--;
            Level[i]++;
            return true;
        }

        public void Write(BinaryWriter w)
        {
            w.Write(Points);
            for (int i = 0; i < Count; i++)
            {
                w.Write(Level[i]);
                w.Write(Xp[i]);
            }
        }

        public void Read(BinaryReader r)
        {
            Points = r.ReadInt32();
            for (int i = 0; i < Count; i++)
            {
                Level[i] = r.ReadInt32();
                Xp[i] = r.ReadInt32();
                if (Level[i] < 1) Level[i] = 1;
                if (Level[i] > MaxLevel) Level[i] = MaxLevel;
                if (Xp[i] < 0) Xp[i] = 0;
            }
        }

        public void CopyFrom(SkillSet other)
        {
            Points = other.Points;
            for (int i = 0; i < Count; i++)
            {
                Level[i] = other.Level[i];
                Xp[i] = other.Xp[i];
            }
        }
    }
}
