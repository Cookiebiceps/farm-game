using System;
using System.IO;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    internal static class SaveRoundtrip
    {
        public static bool Run()
        {
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-self-test.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                World a = new World();
                a.Look.Body = 1;
                a.Look.Hair = 4;
                a.Look.Clothes = 2;
                a.Look.Hat = 3;
                a.Gold = 1876;
                a.Energy = 42;
                a.Day = 9;
                a.Minutes = 760f;
                a.PlayerPos = new Vector2((20.5f + GameConst.FarmOx) * GameConst.Tile, (8.5f + GameConst.FarmOy) * GameConst.Tile);
                a.Dir = 2;
                a.ZoneName = "Ridge Summit";
                a.OutdoorZone = "Ridge Summit";
                a.Bar[4].Set(ItemCatalog.SeedId("turnip"), 7);
                a.Pack[3].Set("wood", 11);
                a.Skills.Level[0] = 3;
                a.Skills.Xp[0] = 40;
                a.Skills.Points = 2;
                if (!SaveGame.Write(a, path))
                {
                    Console.WriteLine("write failed");
                    return false;
                }
                World b = new World();
                if (!SaveGame.Read(b, path))
                {
                    Console.WriteLine("read failed");
                    return false;
                }
                if (b.Gold != 1876 || b.Energy != 42 || b.Day != 9)
                {
                    Console.WriteLine("stats mismatch");
                    return false;
                }
                if (b.Look.Body != 1 || b.Look.Hair != 4 || b.Look.Clothes != 2 || b.Look.Hat != 3)
                {
                    Console.WriteLine("look mismatch");
                    return false;
                }
                if (b.Bar[4].Id != ItemCatalog.SeedId("turnip") || b.Bar[4].Count != 7)
                {
                    Console.WriteLine("hotbar mismatch");
                    return false;
                }
                if (b.Pack[3].Id != "wood" || b.Pack[3].Count != 11)
                {
                    Console.WriteLine("pack mismatch");
                    return false;
                }
                if (b.CountItem("plank") < GameConst.TestPlanks)
                {
                    Console.WriteLine("loaded save missing test planks " + b.CountItem("plank"));
                    return false;
                }
                if (b.Skills.Level[0] != 3 || b.Skills.Points != 2)
                {
                    Console.WriteLine("skills mismatch");
                    return false;
                }
                if (!RiverLooksRight(a))
                    return false;
                if (!InnLooksRight(a))
                    return false;
                if (!PiperLooksRight(a))
                    return false;
                if (!CarpenterLooksRight(a))
                    return false;
                if (!AnimalShopLooksRight(a))
                    return false;
                float expectX = (20.5f + GameConst.FarmOx) * GameConst.Tile;
                if (Math.Abs(b.PlayerPos.X - expectX) > 0.01f || b.Dir != 2)
                {
                    Console.WriteLine("position mismatch");
                    return false;
                }
                if (!RiverLooksRight(b))
                    return false;
                if (!InnLooksRight(b))
                    return false;
                if (!PiperLooksRight(b))
                    return false;
                if (!CarpenterLooksRight(b))
                    return false;
                if (!AnimalShopLooksRight(b))
                    return false;
                if (!CaveLooksRight(b))
                    return false;
                if (!CaveMobsLookRight(a) || !CaveMobsLookRight(b))
                    return false;
                if (!FarmLooksRight(a) || !FarmLooksRight(b))
                    return false;
                if (!GreenhouseLooksRight(a) || !GreenhouseLooksRight(b))
                    return false;
                if (!BarnLooksRight(a) || !BarnLooksRight(b))
                    return false;
                if (!BarnDoorsWork())
                    return false;
                if (!CottageLooksRight(a) || !CottageLooksRight(b))
                    return false;
                if (!FarmRepairWorks())
                    return false;
                if (!LivestockWorks())
                    return false;
                if (!CowMilkingWorks())
                    return false;
                if (!SheepShearWorks())
                    return false;
                if (!MoonveilLooksRight(a) || !MoonveilLooksRight(b))
                    return false;
                if (!MeadowLooksRight(a) || !MeadowLooksRight(b))
                    return false;
                if (!BeachLooksRight(a) || !BeachLooksRight(b))
                    return false;
                if (!SandRippleWorks())
                    return false;
                if (!ToolAnimWorks())
                    return false;
                if (!DockLooksRight(a) || !DockLooksRight(b))
                    return false;
                if (!InfiniteEnergyWorks())
                    return false;
                if (!AdminSpawnWorks())
                    return false;
                if (!FarmMoveWorks())
                    return false;
                if (!FarmRotateWorks())
                    return false;
                if (!MapEditorWorks())
                    return false;
                if (!MapEditorPlaceWorks())
                    return false;
                if (!SiloAndHayWorks())
                    return false;
                if (!TreeFallWorks())
                    return false;
                Console.WriteLine("save roundtrip ok");
                return true;
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
        }

        static bool RiverLooksRight(World w)
        {
            int bridges = 0;
            int river = 0;
            int villageFord = 0;
            int farmFord = 0;
            int dirtFord = 0;
            int farmY0 = GameConst.FarmOy + 4;
            int farmY1 = GameConst.FarmOy + 5;
            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    TileType t = w.Tiles[x, y];
                    if (t == TileType.Bridge)
                    {
                        bridges++;
                        if (y >= 16 && y <= 17 && x >= 46 + GameConst.ShadeW && x <= 52 + GameConst.ShadeW)
                            villageFord++;
                        if (y >= farmY0 && y <= farmY1 && x >= 46 + GameConst.ShadeW && x <= 52 + GameConst.ShadeW)
                            farmFord++;
                    }
                    if (t == TileType.Water && GameConst.WaterLook(x, y) == 1)
                        river++;
                    if (t == TileType.Path && y < GameConst.BeachOy)
                    {
                        TileType n = y > 0 ? w.Tiles[x, y - 1] : TileType.Grass;
                        TileType s = y < GameConst.MapH - 1 ? w.Tiles[x, y + 1] : TileType.Grass;
                        TileType e = x < GameConst.MapW - 1 ? w.Tiles[x + 1, y] : TileType.Grass;
                        TileType ww = x > 0 ? w.Tiles[x - 1, y] : TileType.Grass;
                        if ((n == TileType.Water && s == TileType.Water)
                            || (e == TileType.Water && ww == TileType.Water))
                        {
                            Console.WriteLine("dirt ford at " + x + "," + y);
                            dirtFord++;
                        }
                    }
                }
            }
            if (bridges < 8)
            {
                Console.WriteLine("too few wooden bridges: " + bridges);
                return false;
            }
            if (villageFord < 2)
            {
                Console.WriteLine("village street has no wooden bridge");
                return false;
            }
            if (farmFord < 2)
            {
                Console.WriteLine("farm road has no wooden bridge");
                return false;
            }
            if (dirtFord > 0)
            {
                Console.WriteLine("dirt path still crosses the river: " + dirtFord);
                return false;
            }
            if (river < 80)
            {
                Console.WriteLine("river channel missing: " + river);
                return false;
            }
            Console.WriteLine("river ok bridges=" + bridges + " village=" + villageFord + " farm=" + farmFord);
            return true;
        }

        static bool InnLooksRight(World w)
        {
            Building inn = null;
            for (int i = 0; i < w.Buildings.Count; i++)
            {
                if (w.Buildings[i].Id == "inn")
                    inn = w.Buildings[i];
            }
            if (inn == null || !inn.HasUpstairs)
            {
                Console.WriteLine("hearth inn has no upstairs");
                return false;
            }
            int lobbyBeds = 0;
            int roomBeds = 0;
            int kegs = 0;
            bool lobbyStairs = false;
            bool roomStairs = false;
            for (int y = 0; y < inn.Ih; y++)
            {
                for (int x = 0; x < inn.Iw; x++)
                {
                    if (inn.Interior[x, y] == TileType.Bed)
                        lobbyBeds++;
                    if (inn.Interior[x, y] == TileType.Stairs)
                        lobbyStairs = true;
                    if (inn.Upstairs[x, y] == TileType.Bed)
                        roomBeds++;
                    if (inn.Upstairs[x, y] == TileType.Stairs)
                        roomStairs = true;
                }
            }
            for (int i = 0; i < inn.Furnishings.Count; i++)
            {
                if (inn.Furnishings[i].Kind == FurnishKind.Keg)
                    kegs++;
            }
            if (lobbyBeds != 0)
            {
                Console.WriteLine("beds still in the lobby: " + lobbyBeds);
                return false;
            }
            if (roomBeds < 8)
            {
                Console.WriteLine("upstairs bedrooms missing beds: " + roomBeds);
                return false;
            }
            if (kegs < 4 || !lobbyStairs || !roomStairs)
            {
                Console.WriteLine("inn bar or stairs missing");
                return false;
            }
            Console.WriteLine("inn ok rooms beds=" + roomBeds + " kegs=" + kegs);
            return true;
        }

        static bool PiperLooksRight(World w)
        {
            Building shop = null;
            for (int i = 0; i < w.Buildings.Count; i++)
            {
                if (w.Buildings[i].Id == "piper")
                    shop = w.Buildings[i];
            }
            if (shop == null)
            {
                Console.WriteLine("piper's market missing");
                return false;
            }
            int fridges = 0, shelves = 0, checkout = 0;
            for (int i = 0; i < shop.Furnishings.Count; i++)
            {
                if (shop.Furnishings[i].Kind == FurnishKind.Fridge)
                    fridges++;
                if (shop.Furnishings[i].Kind == FurnishKind.Shelf)
                    shelves++;
            }
            int cy = shop.Ih - 3;
            for (int x = 0; x < shop.Iw; x++)
            {
                if (shop.Interior[x, cy] == TileType.Counter
                    && shop.FurnishAt(x, cy) == FurnishKind.None)
                    checkout++;
            }
            if (fridges < 6 || shelves < 8 || checkout < 4 || shop.NpcY < 0)
            {
                Console.WriteLine("piper shop incomplete fridge=" + fridges + " shelf=" + shelves + " counter=" + checkout);
                return false;
            }
            Console.WriteLine("piper ok fridge=" + fridges + " aisle=" + shelves + " checkout=" + checkout);
            return true;
        }

        static bool CarpenterLooksRight(World w)
        {
            Building shop = w.FindBuilding("ash");
            if (shop == null || shop.Kind != BuildingKind.Carpenter)
            {
                Console.WriteLine("carpenter workshop missing");
                return false;
            }
            if (shop.Y >= GameConst.VillageH)
            {
                Console.WriteLine("carpenter is not in the village");
                return false;
            }
            if (shop.Name.IndexOf("Forge", StringComparison.Ordinal) < 0 || shop.DoorDx != 1)
            {
                Console.WriteLine("ash forge footprint wrong name=" + shop.Name + " door=" + shop.DoorDx);
                return false;
            }
            if (w.Tiles[shop.DoorX, shop.DoorY + 1] != TileType.Path)
            {
                Console.WriteLine("ash forge door does not open onto a path");
                return false;
            }
            int stones = 0;
            int front = shop.Y + shop.H;
            for (int y = front; y <= front + 2 && y < GameConst.MapH; y++)
            {
                for (int x = shop.X + 3; x < shop.X + shop.W + 1 && x < GameConst.MapW; x++)
                {
                    if (w.Tiles[x, y] == TileType.Rock)
                        stones++;
                }
            }
            if (stones < 3)
            {
                Console.WriteLine("ash forge stepping stones missing stones=" + stones);
                return false;
            }
            int benches = 0;
            for (int y = 0; y < shop.Ih; y++)
            {
                for (int x = 0; x < shop.Iw; x++)
                {
                    if (shop.Interior[x, y] == TileType.Counter)
                        benches++;
                }
            }
            if (benches < 6 || shop.NpcY < 0)
            {
                Console.WriteLine("carpenter shop incomplete benches=" + benches);
                return false;
            }
            if (!PackedCuteFantasyLooksRight("forge", TileGen.ForgeAssetPath(), 117, 100, 7, 58, 50,
                145, 83, 59, 800,
                121, 46, 47, 800,
                63, 40, 50, 1000))
                return false;
            Console.WriteLine("carpenter ok packed Cute Fantasy sprite 32px benches=" + benches);
            return true;
        }

        static bool AnimalShopLooksRight(World w)
        {
            Building shop = w.FindBuilding("bess");
            if (shop == null || shop.Kind != BuildingKind.AnimalShop)
            {
                Console.WriteLine("animal shop missing");
                return false;
            }
            if (shop.Y >= GameConst.VillageH)
            {
                Console.WriteLine("animal shop is not in the village");
                return false;
            }
            int counters = 0;
            for (int y = 0; y < shop.Ih; y++)
            {
                for (int x = 0; x < shop.Iw; x++)
                {
                    if (shop.Interior[x, y] == TileType.Counter)
                        counters++;
                }
            }
            if (counters < 6 || shop.NpcY < 0)
            {
                Console.WriteLine("animal shop incomplete counters=" + counters);
                return false;
            }
            if (ItemCatalog.Livestock.Length != 6)
            {
                Console.WriteLine("expected 6 livestock kinds");
                return false;
            }
            for (int i = 0; i < ItemCatalog.Livestock.Length; i++)
            {
                if (ItemCatalog.Find(ItemCatalog.Livestock[i].Id) == null)
                {
                    Console.WriteLine("livestock missing from catalog " + ItemCatalog.Livestock[i].Id);
                    return false;
                }
            }
            Console.WriteLine("animal shop ok counters=" + counters);
            return true;
        }

        static bool MoonveilLooksRight(World w)
        {
            int oy = GameConst.FarmOy;
            if (World.ZoneAt(5, oy + 10) != "Moonveil Grove")
            {
                Console.WriteLine("moonveil zone missing at west farm band");
                return false;
            }
            if (World.ZoneAt(GameConst.ShadeW + 5, oy + 10) != "Forbidden Woods")
            {
                Console.WriteLine("woods did not stay east of moonveil");
                return false;
            }
            if (World.ZoneAt(GameConst.FarmOx + 5, oy + 10) != "Harvest Hollow")
            {
                Console.WriteLine("farm did not stay east of woods");
                return false;
            }
            int trees = 0;
            int flowers = 0;
            int water = 0;
            int path = 0;
            int darkOak = 0;
            int pine = 0;
            for (int y = oy; y < GameConst.CountryOy; y++)
            {
                for (int x = 0; x < GameConst.ShadeW; x++)
                {
                    TileType t = w.Tiles[x, y];
                    if (t == TileType.Tree)
                    {
                        trees++;
                        TreeKind kind = TreeSpecies.KindAt(x, y);
                        if (kind == TreeKind.DarkOak)
                            darkOak++;
                        if (kind == TreeKind.Pine || kind == TreeKind.Spruce)
                            pine++;
                    }
                    else if (t == TileType.Flower)
                        flowers++;
                    else if (t == TileType.Water)
                        water++;
                    else if (t == TileType.Path)
                        path++;
                }
            }
            if (trees < 80)
            {
                Console.WriteLine("moonveil too thin trees=" + trees);
                return false;
            }
            if (darkOak < 8 || pine < 8)
            {
                Console.WriteLine("moonveil missing dark oak/pine dark=" + darkOak + " pine=" + pine);
                return false;
            }
            if (water < 4)
            {
                Console.WriteLine("moonveil pool missing water=" + water);
                return false;
            }
            if (path < 20)
            {
                Console.WriteLine("moonveil path missing path=" + path);
                return false;
            }
            if (flowers < 8)
            {
                Console.WriteLine("moonveil flowers missing n=" + flowers);
                return false;
            }
            Building bess = w.FindBuilding("bess");
            if (bess == null || bess.X < GameConst.ShadeW)
            {
                Console.WriteLine("bess was not shifted with the village");
                return false;
            }
            bool groveGate = false;
            for (int i = 0; i < w.Gates.Count; i++)
            {
                if (w.Gates[i].Dest == "Moonveil Grove")
                    groveGate = true;
            }
            if (!groveGate)
            {
                Console.WriteLine("no moonveil grove gate");
                return false;
            }
            Console.WriteLine("moonveil ok trees=" + trees + " dark=" + darkOak + " pine=" + pine + " water=" + water);
            return true;
        }

        static bool MeadowLooksRight(World w)
        {
            int y0 = GameConst.CountryOy;
            int y1 = GameConst.BeachOy;
            int mid = y0 + (y1 - y0) / 2;
            if (World.ZoneAt(GameConst.SpineX, y0 + 2) != "Meadow Road"
                || World.ZoneAt(GameConst.SpineX, mid) != "Meadow Road"
                || World.ZoneAt(GameConst.SpineX, y1 - 2) != "Meadow Road")
            {
                Console.WriteLine("meadow road does not fill the south walk");
                return false;
            }
            if (World.ZoneAt(GameConst.SpineX, y1 + 2) != "Saltwind Beach")
            {
                Console.WriteLine("beach did not stay south of meadow");
                return false;
            }
            int path = 0;
            int trees = 0;
            int flowers = 0;
            int spine = GameConst.SpineX;
            for (int y = y0; y < y1; y++)
            {
                if (w.Tiles[spine, y] == TileType.Path)
                    path++;
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    TileType t = w.Tiles[x, y];
                    if (t == TileType.Tree)
                        trees++;
                    else if (t == TileType.Flower)
                        flowers++;
                }
            }
            if (path < 36)
            {
                Console.WriteLine("meadow spine broken path=" + path);
                return false;
            }
            if (trees < 30 || flowers < 12)
            {
                Console.WriteLine("meadow too bare trees=" + trees + " flowers=" + flowers);
                return false;
            }
            Building finn = w.FindBuilding("finn");
            if (finn == null || finn.Y < GameConst.BeachOy)
            {
                Console.WriteLine("finn is not on the beach south of meadow");
                return false;
            }
            bool beachGate = false;
            for (int i = 0; i < w.Gates.Count; i++)
            {
                if (w.Gates[i].Dest == "Saltwind Beach")
                    beachGate = true;
            }
            if (!beachGate)
            {
                Console.WriteLine("no beach gate at the end of meadow road");
                return false;
            }
            Console.WriteLine("meadow ok h=" + GameConst.CountryH + " path=" + path + " trees=" + trees);
            return true;
        }

        static bool BeachLooksRight(World w)
        {
            w.Inside = null;
            int y0 = GameConst.BeachOy;
            int sand = 0;
            int shells = 0;
            int weed = 0;
            int kinds = 0;
            bool[] seen = new bool[BeachForage.ShellIds.Length];
            for (int y = y0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    TileType t = w.Tiles[x, y];
                    if (t == TileType.Sand)
                        sand++;
                    else if (t == TileType.Shell)
                    {
                        shells++;
                        int k = BeachForage.ShellKindAt(x, y);
                        if (k >= 0 && k < seen.Length)
                            seen[k] = true;
                    }
                    else if (t == TileType.Seaweed)
                        weed++;
                }
            }
            for (int i = 0; i < seen.Length; i++)
            {
                if (seen[i])
                    kinds++;
            }
            if (sand < 400)
            {
                Console.WriteLine("beach sand too thin sand=" + sand);
                return false;
            }
            if (shells < 12 || weed < 8)
            {
                Console.WriteLine("beach forage missing shells=" + shells + " seaweed=" + weed);
                return false;
            }
            if (kinds < 4)
            {
                Console.WriteLine("not enough shell kinds kinds=" + kinds);
                return false;
            }
            for (int i = 0; i < ItemCatalog.BeachFinds.Length; i++)
            {
                if (ItemCatalog.Find(ItemCatalog.BeachFinds[i].Id) == null)
                {
                    Console.WriteLine("beach item missing " + ItemCatalog.BeachFinds[i].Id);
                    return false;
                }
            }
            int px = -1;
            int py = -1;
            for (int y = y0; y < GameConst.MapH && px < 0; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    if (w.Tiles[x, y] == TileType.Shell)
                    {
                        px = x;
                        py = y;
                        break;
                    }
                }
            }
            string id = BeachForage.ShellIdAt(px, py);
            w.PickBeachForage(px, py);
            if (w.Tiles[px, py] != TileType.Sand || w.CountItem(id) < 1)
            {
                Console.WriteLine("shell pickup failed");
                return false;
            }
            int sx = -1;
            int sy = -1;
            for (int y = y0; y < GameConst.MapH && sx < 0; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    if (w.Tiles[x, y] == TileType.Seaweed)
                    {
                        sx = x;
                        sy = y;
                        break;
                    }
                }
            }
            w.PickBeachForage(sx, sy);
            if (w.Tiles[sx, sy] != TileType.Sand || w.CountItem(BeachForage.SeaweedId) < 1)
            {
                Console.WriteLine("seaweed pickup failed");
                return false;
            }
            if (World.ZoneAt(GameConst.SpineX, y0 + 8) != "Saltwind Beach")
            {
                Console.WriteLine("beach zone missing");
                return false;
            }
            Console.WriteLine("beach ok sand=" + sand + " shells=" + shells + " seaweed=" + weed + " kinds=" + kinds);
            return true;
        }

        static bool SandRippleWorks()
        {
            Color[] dry = new Color[32 * 32];
            Color[] wet = new Color[32 * 32];
            TileGen.PaintWindSand(dry, 32, 32, 0, false);
            TileGen.PaintWindSand(wet, 32, 32, 0, true);
            int dryTones = CountTones(dry);
            int wetTones = CountTones(wet);
            if (dryTones < 4 || wetTones < 4)
            {
                Console.WriteLine("sand ripples too flat dry=" + dryTones + " wet=" + wetTones);
                return false;
            }
            int light = 0;
            int dark = 0;
            for (int i = 0; i < dry.Length; i++)
            {
                int lum = dry[i].R + dry[i].G + dry[i].B;
                if (lum >= 620)
                    light++;
                if (lum <= 430)
                    dark++;
            }
            if (light < 40 || dark < 40)
            {
                Console.WriteLine("sand missing crest/valley light=" + light + " dark=" + dark);
                return false;
            }
            Console.WriteLine("sand ripples ok tones=" + dryTones + " wet=" + wetTones + " crests=" + light);
            return true;
        }

        static int CountTones(Color[] d)
        {
            int n = 0;
            uint[] seen = new uint[16];
            for (int i = 0; i < d.Length; i++)
            {
                uint p = d[i].PackedValue;
                bool have = false;
                for (int k = 0; k < n; k++)
                {
                    if (seen[k] == p)
                    {
                        have = true;
                        break;
                    }
                }
                if (have)
                    continue;
                if (n >= seen.Length)
                    return n;
                seen[n++] = p;
            }
            return n;
        }

        static bool ToolAnimWorks()
        {
            if (World.ToolSwingAct(ItemCatalog.Pickaxe, "chop") != "pick")
            {
                Console.WriteLine("pickaxe chop should animate as pick");
                return false;
            }
            if (World.ToolSwingAct(ItemCatalog.Sword, "chop") != "slash")
            {
                Console.WriteLine("sword chop should animate as slash");
                return false;
            }
            if (World.ToolSwingAct(ItemCatalog.Axe, "chop") != "chop")
            {
                Console.WriteLine("axe should keep the chop swing");
                return false;
            }
            if (Characters.Pose(false, 1f, false, 0f) != Characters.PoseIdle)
            {
                Console.WriteLine("idle pose should be still");
                return false;
            }
            if (Characters.Pose(true, 0f, false, 0f) != Characters.PoseWalk0
                || Characters.Pose(true, 0.15f, false, 0f) != Characters.PoseWalk1
                || Characters.Pose(true, 0.25f, false, 0f) != Characters.PoseWalk2)
            {
                Console.WriteLine("walk cycle stuck pose=" + Characters.Pose(true, 0.15f, false, 0f));
                return false;
            }
            if (Characters.Pose(false, 0f, true, 0.2f) != Characters.PoseSwingUp
                || Characters.Pose(false, 0f, true, 0.7f) != Characters.PoseSwingHit)
            {
                Console.WriteLine("swing poses missing");
                return false;
            }
            if (World.SwingDuration("fish") < 0.5f || World.SwingDuration("pick") <= 0f
                || World.SwingDuration("slash") <= 0f)
            {
                Console.WriteLine("tool swing durations missing");
                return false;
            }
            ToolId[] ids =
            {
                ToolId.Hoe, ToolId.Can, ToolId.Scythe, ToolId.Axe, ToolId.Pickaxe,
                ToolId.Sword, ToolId.Rod, ToolId.MilkPail, ToolId.Shears
            };
            for (int i = 0; i < ids.Length; i++)
            {
                Vector2 g = HeldTools.GripOf(ids[i]);
                if (g.X < 12f || g.X > 52f || g.Y < 32f || g.Y > 62f)
                {
                    Console.WriteLine("grip off handle " + ids[i].ToString() + " " + g);
                    return false;
                }
            }
            World w = new World();
            w.Selected = 0;
            w.BeginSwing("fail");
            if (w.SwingAct != "hoe")
            {
                Console.WriteLine("hoe idle swing act=" + w.SwingAct);
                return false;
            }
            w.Selected = 1;
            w.BeginSwing("fail");
            if (w.SwingAct != "water")
            {
                Console.WriteLine("can idle swing act=" + w.SwingAct);
                return false;
            }
            w.Selected = 3;
            w.BeginSwing("chop");
            if (w.SwingAct != "chop")
            {
                Console.WriteLine("axe chop act=" + w.SwingAct);
                return false;
            }
            int pickSlot = -1;
            for (int i = 0; i < w.Pack.Length; i++)
            {
                if (!w.Pack[i].Empty && w.Pack[i].Id == "pickaxe")
                    pickSlot = i;
            }
            if (pickSlot < 0)
            {
                Console.WriteLine("starter pickaxe missing");
                return false;
            }
            w.MoveItem(SlotLoc.PackAt(pickSlot), SlotLoc.BarAt(0));
            w.Selected = 0;
            w.BeginSwing("chop");
            if (w.SwingAct != "pick")
            {
                Console.WriteLine("equipped pickaxe chop act=" + w.SwingAct);
                return false;
            }
            Console.WriteLine("tool anim ok grips=9 pick/slash/hoe/water walk=" + Characters.Pose(true, 0.15f, false, 0f));
            return true;
        }

        static bool DockLooksRight(World w)
        {
            Building finn = w.FindBuilding("finn");
            if (finn == null || finn.Kind != BuildingKind.FishMarket || finn.Y < GameConst.BeachOy)
            {
                Console.WriteLine("finn dock house missing on the beach");
                return false;
            }
            if (finn.Name.IndexOf("Dock House", StringComparison.Ordinal) < 0)
            {
                Console.WriteLine("finn building is not named dock house: " + finn.Name);
                return false;
            }
            if (w.Tiles[finn.DoorX, finn.DoorY + 1] != TileType.Dock)
            {
                Console.WriteLine("finn door does not open onto the dock");
                return false;
            }
            int y0 = GameConst.BeachOy;
            int best = 0;
            int spanY = -1;
            for (int y = y0; y < GameConst.MapH; y++)
            {
                int run = 0;
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    if (w.Tiles[x, y] == TileType.Dock)
                        run++;
                    else
                        run = 0;
                    if (run > best)
                    {
                        best = run;
                        spanY = y;
                    }
                }
            }
            if (best < 10 || spanY < y0 + 6)
            {
                Console.WriteLine("dock platform too small span=" + best + " y=" + spanY);
                return false;
            }
            int fingers = 0;
            for (int y = y0 + 14; y <= y0 + 22 && y < GameConst.MapH; y++)
            {
                for (int x = 1; x < GameConst.MapW - 1; x++)
                {
                    if (w.Tiles[x, y] == TileType.Dock && w.Tiles[x, y - 1] == TileType.Dock)
                        fingers++;
                }
            }
            if (fingers < 8)
            {
                Console.WriteLine("dock finger piers missing fingers=" + fingers);
                return false;
            }
            bool rack = false;
            bool shark = false;
            bool blue = false;
            bool brown = false;
            bool row = false;
            for (int i = 0; i < w.Decos.Count; i++)
            {
                int k = w.Decos[i].Kind;
                if (k == DecoKind.FishRack) rack = true;
                if (k == DecoKind.Shark) shark = true;
                if (k == DecoKind.SailBlue) blue = true;
                if (k == DecoKind.SailBrown) brown = true;
                if (k == DecoKind.Rowboat) row = true;
            }
            if (!rack || !shark || !blue || !brown || !row)
            {
                Console.WriteLine("dock dressing missing rack=" + rack + " shark=" + shark
                    + " blue=" + blue + " brown=" + brown + " row=" + row);
                return false;
            }
            Console.WriteLine("dock ok span=" + best + " fingers=" + fingers);
            return true;
        }

        static bool CaveLooksRight(World w)
        {
            Building cave = w.FindBuilding("ridge-cave");
            if (cave == null)
            {
                Console.WriteLine("ridge cave missing");
                return false;
            }
            int vaults = 0;
            int mazes = 0;
            for (int i = 0; i < CaveGen.Levels; i++)
            {
                CaveFloor f = cave.EnsureCave(i);
                if (f == null || f.Tiles == null)
                {
                    Console.WriteLine("cave floor missing " + (i + 1));
                    return false;
                }
                if (f.Tiles[CaveGen.BackX, CaveGen.Ih - 1] != TileType.Door)
                {
                    Console.WriteLine("cave " + (i + 1) + " has no mouth door");
                    return false;
                }
                if ((i + 1) % 10 == 0)
                {
                    vaults++;
                    if (f.ChestX.Length < 3)
                    {
                        Console.WriteLine("vault " + (i + 1) + " missing chests");
                        return false;
                    }
                    if (i + 1 < CaveGen.Levels && f.DeepX < 0)
                    {
                        Console.WriteLine("vault " + (i + 1) + " has no deeper door");
                        return false;
                    }
                    if (i + 1 == CaveGen.Levels && f.DeepX >= 0)
                    {
                        Console.WriteLine("bottom vault should not descend");
                        return false;
                    }
                }
                else
                {
                    mazes++;
                    if (f.DeepX < 0 || f.Tiles[f.DeepX, f.DeepY] != TileType.Door)
                    {
                        Console.WriteLine("labyrinth " + (i + 1) + " has no deeper door");
                        return false;
                    }
                }
            }
            if (vaults != 10 || mazes != 90)
            {
                Console.WriteLine("cave floors vaults=" + vaults + " mazes=" + mazes);
                return false;
            }
            int gold0 = w.Gold;
            w.Inside = cave;
            w.InsideFloor = 9;
            CaveFloor vault = cave.EnsureCave(9);
            w.OpenCaveChest(vault.ChestX[0], vault.ChestY[0]);
            if (w.Gold <= gold0)
            {
                Console.WriteLine("vault chest paid no gold");
                return false;
            }
            int paid = w.Gold - gold0;
            if (w.CaveChestsLooted == 0)
            {
                Console.WriteLine("vault loot bit not saved");
                return false;
            }
            Console.WriteLine("cave ok levels=" + CaveGen.Levels + " vaults=" + vaults + " chest=" + paid + "g");
            w.Inside = null;
            w.InsideFloor = 0;
            return true;
        }

        static bool CaveMobsLookRight(World w)
        {
            Building cave = w.FindBuilding("ridge-cave");
            if (cave == null)
            {
                Console.WriteLine("ridge cave missing for beasts");
                return false;
            }
            w.Inside = cave;
            w.InsideFloor = 0;
            w.SpawnCaveTrolls();
            int shallowKinds = CountMobKinds(w);
            if (w.Trolls.Count < 2 || shallowKinds < 2)
            {
                Console.WriteLine("shallow cave missing mixed beasts n=" + w.Trolls.Count + " kinds=" + shallowKinds);
                w.Inside = null;
                w.InsideFloor = 0;
                return false;
            }
            w.InsideFloor = 24;
            w.SpawnCaveTrolls();
            bool[] seen = new bool[CaveMobCatalog.Count];
            for (int i = 0; i < w.Trolls.Count; i++)
                seen[CaveMobCatalog.Clamp(w.Trolls[i].Kind)] = true;
            int deepKinds = 0;
            for (int i = 0; i < seen.Length; i++)
            {
                if (seen[i])
                    deepKinds++;
            }
            if (!seen[(int)CaveMobKind.Troll] || deepKinds < 4)
            {
                Console.WriteLine("deep cave missing roster kinds=" + deepKinds + " n=" + w.Trolls.Count);
                w.Inside = null;
                w.InsideFloor = 0;
                return false;
            }
            w.InsideFloor = 9;
            w.SpawnCaveTrolls();
            if (w.Trolls.Count != 0)
            {
                Console.WriteLine("vault floor should be quiet n=" + w.Trolls.Count);
                w.Inside = null;
                w.InsideFloor = 0;
                return false;
            }
            Console.WriteLine("cave beasts ok shallow=" + shallowKinds + " deep=" + deepKinds);
            w.Inside = null;
            w.InsideFloor = 0;
            w.SpawnCaveTrolls();
            return true;
        }

        static int CountMobKinds(World w)
        {
            bool[] seen = new bool[CaveMobCatalog.Count];
            for (int i = 0; i < w.Trolls.Count; i++)
                seen[CaveMobCatalog.Clamp(w.Trolls[i].Kind)] = true;
            int n = 0;
            for (int i = 0; i < seen.Length; i++)
            {
                if (seen[i])
                    n++;
            }
            return n;
        }

        static bool FarmLooksRight(World w)
        {
            Building barn = w.FindBuilding("barn");
            Building green = w.FindBuilding("greenhouse");
            Building coop = w.FindBuilding("coop");
            if (barn == null || green == null || coop == null)
            {
                Console.WriteLine("farm outbuildings missing");
                return false;
            }
            if (!barn.NeedsRepair || !green.NeedsRepair || !coop.NeedsRepair)
            {
                Console.WriteLine("outbuildings should start ruined");
                return false;
            }
            if (barn.RepairPlanks != 16 || green.RepairPlanks != 10 || coop.RepairPlanks != 6)
            {
                Console.WriteLine("plank costs wrong");
                return false;
            }
            int y = GameConst.FarmOy + 40;
            int x = GameConst.FarmOx + 8;
            TileType t = w.Tiles[x, y];
            if (t == TileType.Water || t == TileType.Sand)
            {
                Console.WriteLine("south farm is not farm land " + t);
                return false;
            }
            Console.WriteLine("farm ok h=" + GameConst.FarmH + " barn/greenhouse/coop ruined");
            return true;
        }

        static bool GreenhouseLooksRight(World w)
        {
            Building g = w.FindBuilding("greenhouse");
            if (g == null || g.Kind != BuildingKind.Greenhouse)
            {
                Console.WriteLine("greenhouse missing");
                return false;
            }
            if (g.W != 7 || g.H != 5 || g.DoorDx != 3)
            {
                Console.WriteLine("greenhouse footprint " + g.W + "x" + g.H + " door=" + g.DoorDx);
                return false;
            }
            if (g.Iw != GameConst.GreenhouseInsideW || g.Ih != GameConst.GreenhouseInsideH
                || g.Interior == null || g.Interior[g.InteriorDoorX, g.Ih - 1] != TileType.Door)
            {
                Console.WriteLine("greenhouse interior " + g.Iw + "x" + g.Ih + " door missing");
                return false;
            }
            if (g.Interior[6, 0] != TileType.HouseWindow)
            {
                Console.WriteLine("greenhouse back wall should be glass");
                return false;
            }
            int soil = 0;
            for (int y = 0; y < g.Ih; y++)
            {
                for (int x = 0; x < g.Iw; x++)
                {
                    if (g.Interior[x, y] == TileType.FarmSoil)
                        soil++;
                }
            }
            if (soil < 100)
            {
                Console.WriteLine("greenhouse soil beds " + soil);
                return false;
            }
            if (!PackedCuteFantasyLooksRight("greenhouse", TileGen.GreenhouseAssetPath(), 82, 115, 7, 41, 57,
                12, 46, 68, 1000,
                99, 187, 150, 500,
                30, 111, 80, 500))
                return false;
            Color[] inside;
            int iw, ih;
            TileGen.CaptureGreenhouseInside(out inside, out iw, out ih);
            if (!HipRoofLooksRight(inside, iw, ih, "greenhouse inside"))
                return false;
            int brick = 0;
            int ceil = 0;
            for (int i = 0; i < inside.Length; i++)
            {
                Color c = inside[i];
                if (c.A < 128)
                    continue;
                if (IsTealGlass(c))
                    ceil++;
                if (IsBrick(c))
                    brick++;
            }
            if (ceil < 200 || brick < 200)
            {
                Console.WriteLine("greenhouse inside glass=" + ceil + " brick=" + brick);
                return false;
            }
            Console.WriteLine("greenhouse ok packed Cute Fantasy sprite 32px inside " + g.Iw + "x" + g.Ih + " soil=" + soil);
            return true;
        }

        static bool BarnLooksRight(World w)
        {
            Building b = w.FindBuilding("barn");
            if (b == null || b.Kind != BuildingKind.Barn)
            {
                Console.WriteLine("barn missing");
                return false;
            }
            if (b.W != 8 || b.H != 6 || b.DoorDx != 3)
            {
                Console.WriteLine("barn footprint " + b.W + "x" + b.H + " door=" + b.DoorDx);
                return false;
            }
            if (!b.NeedsRepair || b.RepairPlanks != 16)
            {
                Console.WriteLine("barn should start ruined at 16 planks");
                return false;
            }
            if (w.Tiles[b.DoorX, b.DoorY + 1] != TileType.Path)
            {
                Console.WriteLine("barn door does not open onto the path");
                return false;
            }
            if (!PackedCuteFantasyLooksRight("barn", TileGen.BarnAssetPath(), 132, 101, 8, 66, 50,
                145, 83, 59, 2000,
                121, 46, 47, 800,
                201, 89, 74, 800))
                return false;
            Console.WriteLine("barn ok packed Cute Fantasy sprite 32px at " + b.X + "," + b.Y);
            return true;
        }

        static bool BarnDoorsWork()
        {
            World w = new World();
            w.Screen = Screen.Play;
            Building barn = w.FindBuilding("barn");
            if (barn == null)
            {
                Console.WriteLine("barn doors: missing barn");
                return false;
            }
            w.PlayerPos = new Vector2((barn.DoorX + 0.5f) * GameConst.Tile, (barn.DoorY + 1.5f) * GameConst.Tile);
            if (w.BarnDoorsAt((int)Math.Floor(w.PlayerPos.X / GameConst.Tile),
                    (int)Math.Floor(w.PlayerPos.Y / GameConst.Tile)) != barn)
            {
                Console.WriteLine("barn doors: not near the doors");
                return false;
            }
            for (int i = 0; i < 20; i++)
                w.CheckDoors(0.05f);
            if (w.DoorSwing != barn || w.DoorOpenU < 0.99f)
            {
                Console.WriteLine("barn doors did not open u=" + w.DoorOpenU);
                return false;
            }
            if (w.Inside != null)
            {
                Console.WriteLine("barn doors should not enter from in front");
                return false;
            }
            Color[] closed;
            Color[] opened;
            int cw, ch, ow, oh;
            TileGen.CaptureBarn(false, false, out closed, out cw, out ch);
            TileGen.CaptureBarn(true, false, out opened, out ow, out oh);
            if (cw != ow || ch != oh || closed == null || opened == null)
            {
                Console.WriteLine("barn door blit size mismatch");
                return false;
            }
            int scale = 2;
            int ox = (cw - 132 * scale) / 2;
            int midX = ox + 80 * scale;
            int midY = TileGen.BarnDoorSrcY0 * scale + 20;
            if (midX < 0 || midX >= cw || midY < 0 || midY >= ch)
            {
                Console.WriteLine("barn door sample out of range");
                return false;
            }
            Color shut = closed[midY * cw + midX];
            Color gap = opened[midY * ow + midX];
            if (shut.A < 200 || shut.R < 80)
            {
                Console.WriteLine("barn closed doors missing wood " + shut);
                return false;
            }
            if (gap.R > 70)
            {
                Console.WriteLine("barn open doors should show a dark gap " + gap);
                return false;
            }
            w.TryRepair(barn);
            w.PlayerPos = new Vector2((barn.DoorX + 0.5f) * GameConst.Tile, (barn.DoorY + 0.5f) * GameConst.Tile);
            w.DoorOpenU = 0f;
            w.DoorSwing = null;
            for (int i = 0; i < 20; i++)
                w.CheckDoors(0.05f);
            if (w.LoadingBuilding != barn || w.Screen != Screen.Loading)
            {
                Console.WriteLine("repaired barn should enter from the door tile");
                return false;
            }
            Console.WriteLine("barn doors slide open");
            return true;
        }

        static bool CottageLooksRight(World w)
        {
            Building c = w.FindBuilding("cottage");
            if (c == null || c.Kind != BuildingKind.Cottage)
            {
                Console.WriteLine("farm cottage missing");
                return false;
            }
            if (w.Tiles[c.DoorX, c.DoorY + 1] != TileType.Path)
            {
                Console.WriteLine("cottage door does not open onto the path");
                return false;
            }
            bool barrel = false;
            bool logs = false;
            for (int i = 0; i < w.Decos.Count; i++)
            {
                Deco p = w.Decos[i];
                if (Math.Abs(p.X - c.X) > 4 || Math.Abs(p.Y - (c.Y + c.H)) > 3)
                    continue;
                if (p.Kind == DecoKind.Barrel)
                    barrel = true;
                if (p.Kind == DecoKind.LogSlice)
                    logs = true;
            }
            if (!barrel || !logs)
            {
                Console.WriteLine("cottage yard missing barrel=" + barrel + " logs=" + logs);
                return false;
            }
            Color[] pix;
            int pw, ph;
            string assetPath = TileGen.CottageAssetPath();
            if (assetPath == null || !File.Exists(assetPath))
            {
                Console.WriteLine("cottage asset missing " + assetPath);
                return false;
            }
            Color[] src;
            int sw, sh;
            if (!PngRgba.TryLoad(assetPath, out src, out sw, out sh))
            {
                Console.WriteLine("cottage asset png failed " + assetPath);
                return false;
            }
            if (sw != 96 || sh != 128)
            {
                Console.WriteLine("cottage asset size " + sw + "x" + sh + " want 96x128");
                return false;
            }
            TileGen.CaptureFarmhouse(false, out pix, out pw, out ph);
            if (pw != 7 * 32 || ph != sh * 2)
            {
                Console.WriteLine("cottage blit size " + pw + "x" + ph);
                return false;
            }
            int ox = (pw - sw * 2) / 2;
            Color srcPx = src[40 * sw + 48];
            Color blitPx = pix[(40 * 2) * pw + (ox + 48 * 2)];
            if (blitPx.PackedValue != srcPx.PackedValue)
            {
                Console.WriteLine("cottage blit does not match asset pixel");
                return false;
            }
            int glass = 0;
            int wood = 0;
            int tealRoof = 0;
            for (int i = 0; i < pix.Length; i++)
            {
                Color px = pix[i];
                if (px.A < 200)
                    continue;
                if (px.R == 0 && px.G == 152 && px.B == 220)
                    glass++;
                if (px.R == 145 && px.G == 83 && px.B == 59)
                    wood++;
                if (px.R == 30 && px.G == 57 && px.B == 72)
                    tealRoof++;
            }
            if (glass < 200)
            {
                Console.WriteLine("cottage missing asset window glass " + glass);
                return false;
            }
            if (wood < 2000)
            {
                Console.WriteLine("cottage missing asset wood walls " + wood);
                return false;
            }
            if (tealRoof < 2000)
            {
                Console.WriteLine("cottage missing asset teal roof " + tealRoof);
                return false;
            }
            Console.WriteLine("cottage ok packed Cute Fantasy sprite 32px at " + c.X + "," + c.Y);
            return true;
        }

        static bool PackedCuteFantasyLooksRight(
            string name, string assetPath, int wantW, int wantH, int tilesW, int sampleX, int sampleY,
            params int[] colorNeed)
        {
            if (assetPath == null || !File.Exists(assetPath))
            {
                Console.WriteLine(name + " asset missing " + assetPath);
                return false;
            }
            Color[] src;
            int sw, sh;
            if (!PngRgba.TryLoad(assetPath, out src, out sw, out sh))
            {
                Console.WriteLine(name + " asset png failed " + assetPath);
                return false;
            }
            if (sw != wantW || sh != wantH)
            {
                Console.WriteLine(name + " asset size " + sw + "x" + sh + " want " + wantW + "x" + wantH);
                return false;
            }
            Color[] pix;
            int pw, ph;
            if (name == "barn")
                TileGen.CaptureBarn(false, false, out pix, out pw, out ph);
            else if (name == "greenhouse")
                TileGen.CaptureGreenhouse(false, false, out pix, out pw, out ph);
            else
                TileGen.CaptureBlacksmith(false, out pix, out pw, out ph);
            if (pw != tilesW * 32 || ph != sh * 2)
            {
                Console.WriteLine(name + " blit size " + pw + "x" + ph);
                return false;
            }
            int ox = (pw - sw * 2) / 2;
            int srcI = sampleY * sw + sampleX;
            if (srcI < 0 || srcI >= src.Length || src[srcI].A < 200)
            {
                Console.WriteLine(name + " sample pixel is empty");
                return false;
            }
            int dx = ox + sampleX * 2;
            int dy = sampleY * 2;
            if (dx < 0 || dx >= pw || dy < 0 || dy >= ph)
            {
                Console.WriteLine(name + " sample blit out of range");
                return false;
            }
            Color blitPx = pix[dy * pw + dx];
            if (blitPx.PackedValue != src[srcI].PackedValue)
            {
                Console.WriteLine(name + " blit does not match asset pixel");
                return false;
            }
            if (colorNeed == null || colorNeed.Length % 4 != 0)
                return true;
            int[] counts = new int[colorNeed.Length / 4];
            for (int i = 0; i < pix.Length; i++)
            {
                Color px = pix[i];
                if (px.A < 200)
                    continue;
                for (int n = 0; n < counts.Length; n++)
                {
                    int o = n * 4;
                    if (px.R == colorNeed[o] && px.G == colorNeed[o + 1] && px.B == colorNeed[o + 2])
                        counts[n]++;
                }
            }
            for (int n = 0; n < counts.Length; n++)
            {
                int o = n * 4;
                if (counts[n] < colorNeed[o + 3])
                {
                    Console.WriteLine(name + " missing asset color " + colorNeed[o] + "," + colorNeed[o + 1] + "," + colorNeed[o + 2] + " got " + counts[n]);
                    return false;
                }
            }
            return true;
        }

        static bool HipRoofLooksRight(Color[] d, int w, int h, string name)
        {
            int firstY = -1;
            int firstSpan = 0;
            int maxSpan = 0;
            for (int y = 0; y < h; y++)
            {
                int x0 = -1;
                int x1 = -1;
                for (int x = 0; x < w; x++)
                {
                    if (d[y * w + x].A < 128)
                        continue;
                    if (x0 < 0)
                        x0 = x;
                    x1 = x;
                }
                if (x0 < 0)
                    continue;
                int span = x1 - x0 + 1;
                if (span < 10)
                    continue;
                if (firstY < 0)
                {
                    firstY = y;
                    firstSpan = span;
                }
                if (span > maxSpan)
                    maxSpan = span;
            }
            if (firstY < 0 || maxSpan < 40)
            {
                Console.WriteLine(name + " sprite empty span=" + maxSpan);
                return false;
            }
            if (firstSpan * 5 < maxSpan * 2)
            {
                Console.WriteLine(name + " pointy A-frame peak span " + firstSpan + " vs eave " + maxSpan + " y=" + firstY);
                return false;
            }
            if (d[firstY * w + 4].A >= 128 || d[firstY * w + (w - 5)].A >= 128)
            {
                Console.WriteLine(name + " roof is not hipped — top corners filled y=" + firstY);
                return false;
            }
            if (maxSpan <= firstSpan + 8)
            {
                Console.WriteLine(name + " roof does not widen to eaves peak=" + firstSpan + " eave=" + maxSpan);
                return false;
            }
            return true;
        }

        static bool IsTealGlass(Color c)
        {
            return c.A > 200 && c.G > 90 && c.B > 60 && c.G >= c.R && c.R < 140;
        }

        static bool IsTimber(Color c)
        {
            return c.A > 200 && c.R > 80 && c.R > c.G + 10 && c.G > c.B && c.R - c.B > 40 && c.G < 140;
        }

        static bool IsBeigeStone(Color c)
        {
            return c.A > 200 && c.R > 140 && c.G > 130 && Math.Abs(c.R - c.G) < 40 && c.B < c.G + 8 && c.R + c.G + c.B > 420;
        }

        static bool IsBrick(Color c)
        {
            return c.A > 200 && c.R > 90 && c.R > c.G + 20 && c.G > c.B && c.B < 90;
        }

        static bool IsTerracotta(Color c)
        {
            return c.A > 200 && c.R > 140 && c.R > c.G + 30 && c.G > c.B && c.B < 110;
        }

        static bool IsPlaster(Color c)
        {
            return c.A > 200 && c.R > 180 && c.G > 160 && c.B > 130 && Math.Abs(c.R - c.G) < 50;
        }

        static bool FarmRepairWorks()
        {
            World w = new World();
            if (w.CountItem("plank") < GameConst.TestPlanks)
            {
                Console.WriteLine("test planks missing " + w.CountItem("plank"));
                return false;
            }
            int before = w.CountItem("wood");
            int planks = w.CountItem("plank");
            w.AddItem("wood", ItemCatalog.WoodPerPlank);
            w.CraftPlank();
            if (w.CountItem("plank") != planks + 1)
            {
                Console.WriteLine("plank mill failed");
                return false;
            }
            if (w.CountItem("wood") != before)
            {
                Console.WriteLine("plank mill wood leftover " + w.CountItem("wood") + " vs " + before);
                return false;
            }
            w.AddItem("plank", 40);
            Building barn = w.FindBuilding("barn");
            Building green = w.FindBuilding("greenhouse");
            Building coop = w.FindBuilding("coop");
            w.TryRepair(coop);
            w.TryRepair(green);
            w.TryRepair(barn);
            if (coop.NeedsRepair || green.NeedsRepair || barn.NeedsRepair)
            {
                Console.WriteLine("repair did not finish");
                return false;
            }
            if ((w.PackFarmRepairs() & 7) != 7)
            {
                Console.WriteLine("repair bits " + w.PackFarmRepairs());
                return false;
            }
            int soil = 0;
            for (int y = 0; y < green.Ih; y++)
            {
                for (int x = 0; x < green.Iw; x++)
                {
                    if (green.Interior[x, y] == TileType.FarmSoil)
                        soil++;
                }
            }
            if (soil < 100)
            {
                Console.WriteLine("greenhouse has no soil beds " + soil);
                return false;
            }
            Console.WriteLine("farm repair ok bits=" + w.PackFarmRepairs() + " soil=" + soil);
            return true;
        }

        static bool LivestockWorks()
        {
            World w = new World();
            w.Gold = 2000;
            for (int i = 0; i < ItemCatalog.Livestock.Length; i++)
                w.BuyAnimal(i);
            if (w.Gold != 2000 - 80 - 100 - 250 - 300 - 400 - 550)
            {
                Console.WriteLine("animal prices leftover gold " + w.Gold);
                return false;
            }
            for (int i = 0; i < ItemCatalog.Livestock.Length; i++)
            {
                if (w.CountItem(ItemCatalog.Livestock[i].Id) < 1)
                {
                    Console.WriteLine("buy failed " + ItemCatalog.Livestock[i].Id);
                    return false;
                }
            }
            int tx = -1;
            int ty = -1;
            for (int y = GameConst.FarmOy + 8; y < GameConst.FarmOy + 20 && tx < 0; y++)
            {
                for (int x = GameConst.FarmOx + 14; x < GameConst.FarmOx + 22; x++)
                {
                    if (w.AnimalCanStand(x, y))
                    {
                        tx = x;
                        ty = y;
                        break;
                    }
                }
            }
            if (tx < 0)
            {
                Console.WriteLine("no open farm pasture");
                return false;
            }
            w.Bar[4].Set("animal.chicken", 1);
            w.Selected = 4;
            int before = w.Animals.Count;
            string act = w.UseTool(tx, ty);
            if (act != "plant" || w.Animals.Count != before + 1)
            {
                Console.WriteLine("place chicken failed act=" + act + " n=" + w.Animals.Count);
                return false;
            }
            w.Bar[5].Set("animal.horse", 1);
            w.Selected = 5;
            int hx = tx + 1;
            if (!w.AnimalCanStand(hx, ty))
                hx = tx - 1;
            string horse = w.UseTool(hx, ty);
            if (horse != "plant" || w.Animals.Count != before + 2)
            {
                Console.WriteLine("place horse failed act=" + horse + " n=" + w.Animals.Count);
                return false;
            }
            FarmAnimal placedChicken = w.AnimalAtTile(tx, ty);
            FarmAnimal placedHorse = w.AnimalAtTile(hx, ty);
            if (placedChicken == null || placedChicken.Kind != AnimalKind.Chicken
                || placedHorse == null || placedHorse.Kind != AnimalKind.Horse)
            {
                Console.WriteLine("placed livestock not on tiles");
                return false;
            }
            float chickenX = placedChicken.Pos.X;
            float horseY = placedHorse.Pos.Y;
            int expect = before + 2;
            string path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "harvest-hollow-animals.sav");
            try
            {
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("animal save write failed");
                    return false;
                }
                World b = new World();
                if (!SaveGame.Read(b, path))
                {
                    Console.WriteLine("animal save read failed");
                    return false;
                }
                if (b.Animals.Count != expect)
                {
                    Console.WriteLine("animal roundtrip count " + b.Animals.Count);
                    return false;
                }
                FarmAnimal loadedChicken = b.AnimalAtTile(tx, ty);
                FarmAnimal loadedHorse = b.AnimalAtTile(hx, ty);
                if (loadedChicken == null || loadedChicken.Kind != AnimalKind.Chicken
                    || Math.Abs(loadedChicken.Pos.X - chickenX) > 0.01f)
                {
                    Console.WriteLine("chicken roundtrip mismatch");
                    return false;
                }
                if (loadedHorse == null || loadedHorse.Kind != AnimalKind.Horse
                    || Math.Abs(loadedHorse.Pos.Y - horseY) > 0.01f)
                {
                    Console.WriteLine("horse roundtrip mismatch");
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                }
                catch
                {
                }
            }
            if (!w.TryPickAnimal(tx, ty) || w.Animals.Count != expect - 1)
            {
                Console.WriteLine("pick animal failed n=" + w.Animals.Count);
                return false;
            }
            Console.WriteLine("livestock ok kinds=6 placed=2 roundtrip");
            return true;
        }

        static bool CowMilkingWorks()
        {
            World w = new World();
            if (ItemCatalog.Find("milk") == null || ItemCatalog.Find("pail") == null)
            {
                Console.WriteLine("milk catalog missing");
                return false;
            }
            if (ItemCatalog.Milk.Sell <= 0 || !ItemCatalog.Milk.Stackable)
            {
                Console.WriteLine("milk should stack and sell");
                return false;
            }
            w.EnsureMilkPail();
            if (w.CountItem("pail") < 1)
            {
                Console.WriteLine("milk pail missing");
                return false;
            }
            FarmAnimal cow = w.FindCow();
            if (cow == null)
                cow = w.SpawnCowNearBarn();
            if (cow == null)
            {
                Console.WriteLine("no cow to milk");
                return false;
            }
            int ctx = (int)Math.Floor(cow.Pos.X / GameConst.Tile);
            int cty = (int)Math.Floor(cow.Pos.Y / GameConst.Tile);
            int milkBefore = w.CountItem("milk");
            w.Interact(ctx, cty);
            if (w.CountItem("milk") != milkBefore + 1 || !cow.MilkedToday)
            {
                Console.WriteLine("first milk failed n=" + w.CountItem("milk") + " flag=" + cow.MilkedToday + " toast=" + w.Toast);
                return false;
            }
            string again = w.TryMilkCow(cow);
            if (again != "fail" || w.CountItem("milk") != milkBefore + 1)
            {
                Console.WriteLine("same-day milk should fail act=" + again + " n=" + w.CountItem("milk"));
                return false;
            }
            if (w.Toast.IndexOf("Already milked", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Console.WriteLine("already-milked toast missing: " + w.Toast);
                return false;
            }

            World packed = new World();
            packed.EnsureMilkPail();
            FarmAnimal packedCow = packed.FindCow();
            if (packedCow == null)
                packedCow = packed.SpawnCowNearBarn();
            if (packedCow == null)
            {
                Console.WriteLine("full-bag milk missing cow");
                return false;
            }
            for (int i = 0; i < packed.Bar.Length; i++)
            {
                if (packed.Bar[i].Empty)
                    packed.Bar[i].Set("wood", 999);
            }
            for (int i = 0; i < packed.PackOpen; i++)
            {
                if (packed.Pack[i].Empty)
                    packed.Pack[i].Set("wood", 999);
            }
            if (packed.CanFitItem("milk", 1))
            {
                Console.WriteLine("full bag still fits milk");
                return false;
            }
            string full = packed.TryMilkCow(packedCow);
            if (full != "fail" || packedCow.MilkedToday || packed.CountItem("milk") != 0)
            {
                Console.WriteLine("full bag milk should fail act=" + full + " flag=" + packedCow.MilkedToday);
                return false;
            }

            World none = new World();
            none.TakeItem("pail", none.CountItem("pail"));
            FarmAnimal dry = none.FindCow();
            if (dry == null)
                dry = none.SpawnCowNearBarn();
            if (dry == null)
            {
                Console.WriteLine("no-pail milk missing cow");
                return false;
            }
            string need = none.TryMilkCow(dry);
            if (need != "fail" || dry.MilkedToday || none.CountItem("milk") != 0)
            {
                Console.WriteLine("no pail should fail act=" + need);
                return false;
            }
            if (none.Toast.IndexOf("pail", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Console.WriteLine("need-pail toast missing: " + none.Toast);
                return false;
            }

            w.AdvanceDay(false);
            if (cow.MilkedToday)
            {
                Console.WriteLine("next day should clear milked flag");
                return false;
            }
            string morning = w.TryMilkCow(cow);
            if (morning != "milk" || w.CountItem("milk") != milkBefore + 2 || !cow.MilkedToday)
            {
                Console.WriteLine("next-day milk failed act=" + morning + " n=" + w.CountItem("milk"));
                return false;
            }

            w.CraftMilkPail();
            if (w.CountItem("pail") < 1)
            {
                Console.WriteLine("craft pail lost the original");
                return false;
            }

            string path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "harvest-hollow-milk.sav");
            try
            {
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("milk save write failed");
                    return false;
                }
                World b = new World();
                if (!SaveGame.Read(b, path))
                {
                    Console.WriteLine("milk save read failed");
                    return false;
                }
                if (b.CountItem("milk") < 2)
                {
                    Console.WriteLine("milk item missing after load n=" + b.CountItem("milk"));
                    return false;
                }
                if (b.CountItem("pail") < 1)
                {
                    Console.WriteLine("pail missing after load");
                    return false;
                }
                FarmAnimal loaded = b.FindCow();
                if (loaded == null || !loaded.MilkedToday)
                {
                    Console.WriteLine("milked flag missing after load");
                    return false;
                }
                string loadedAgain = b.TryMilkCow(loaded);
                if (loadedAgain != "fail")
                {
                    Console.WriteLine("loaded cow should stay milked act=" + loadedAgain);
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("cow milking ok milk=2 pail persist");
            return true;
        }

        static bool SheepShearWorks()
        {
            World w = new World();
            if (ItemCatalog.Find("wool") == null || ItemCatalog.Find("shears") == null)
            {
                Console.WriteLine("wool catalog missing");
                return false;
            }
            if (ItemCatalog.Wool.Sell != 48 || !ItemCatalog.Wool.Stackable)
            {
                Console.WriteLine("wool should stack and sell for 48g");
                return false;
            }
            w.EnsureShears();
            if (w.CountItem("shears") < 1)
            {
                Console.WriteLine("shears missing");
                return false;
            }
            FarmAnimal sheep = w.FindSheep();
            if (sheep == null)
                sheep = w.SpawnSheepNearBarn();
            if (sheep == null)
            {
                Console.WriteLine("no sheep to shear");
                return false;
            }
            sheep.HasWool = true;
            int stx = (int)Math.Floor(sheep.Pos.X / GameConst.Tile);
            int sty = (int)Math.Floor(sheep.Pos.Y / GameConst.Tile);
            int woolBefore = w.CountItem("wool");
            w.Interact(stx, sty);
            if (w.CountItem("wool") != woolBefore + 1 || sheep.HasWool)
            {
                Console.WriteLine("first shear failed n=" + w.CountItem("wool") + " wool=" + sheep.HasWool + " toast=" + w.Toast);
                return false;
            }
            string again = w.TryShearSheep(sheep);
            if (again != "fail" || w.CountItem("wool") != woolBefore + 1)
            {
                Console.WriteLine("same-day shear should fail act=" + again + " n=" + w.CountItem("wool"));
                return false;
            }
            if (w.Toast.IndexOf("growing", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Console.WriteLine("wool-growing toast missing: " + w.Toast);
                return false;
            }

            World packed = new World();
            packed.EnsureShears();
            FarmAnimal packedSheep = packed.FindSheep();
            if (packedSheep == null)
                packedSheep = packed.SpawnSheepNearBarn();
            if (packedSheep == null)
            {
                Console.WriteLine("full-bag shear missing sheep");
                return false;
            }
            packedSheep.HasWool = true;
            for (int i = 0; i < packed.Bar.Length; i++)
            {
                if (packed.Bar[i].Empty)
                    packed.Bar[i].Set("wood", 999);
            }
            for (int i = 0; i < packed.PackOpen; i++)
            {
                if (packed.Pack[i].Empty)
                    packed.Pack[i].Set("wood", 999);
            }
            if (packed.CanFitItem("wool", 1))
            {
                Console.WriteLine("full bag still fits wool");
                return false;
            }
            string full = packed.TryShearSheep(packedSheep);
            if (full != "fail" || !packedSheep.HasWool || packed.CountItem("wool") != 0)
            {
                Console.WriteLine("full bag shear should fail act=" + full + " wool=" + packedSheep.HasWool);
                return false;
            }

            World none = new World();
            none.TakeItem("shears", none.CountItem("shears"));
            FarmAnimal dry = none.FindSheep();
            if (dry == null)
                dry = none.SpawnSheepNearBarn();
            if (dry == null)
            {
                Console.WriteLine("no-shears missing sheep");
                return false;
            }
            dry.HasWool = true;
            string need = none.TryShearSheep(dry);
            if (need != "fail" || !dry.HasWool || none.CountItem("wool") != 0)
            {
                Console.WriteLine("no shears should fail act=" + need);
                return false;
            }
            if (none.Toast.IndexOf("shears", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Console.WriteLine("need-shears toast missing: " + none.Toast);
                return false;
            }

            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-wool.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("wool save write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("wool save read failed");
                    return false;
                }
                if (loaded.CountItem("wool") < 1)
                {
                    Console.WriteLine("wool item missing after load n=" + loaded.CountItem("wool"));
                    return false;
                }
                if (loaded.CountItem("shears") < 1)
                {
                    Console.WriteLine("shears missing after load");
                    return false;
                }
                FarmAnimal shorn = loaded.FindSheep();
                if (shorn == null || shorn.HasWool)
                {
                    Console.WriteLine("HasWool=false missing after load");
                    return false;
                }
                string loadedAgain = loaded.TryShearSheep(shorn);
                if (loadedAgain != "fail")
                {
                    Console.WriteLine("loaded sheep should stay shorn act=" + loadedAgain);
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }

            w.AdvanceDay(false);
            if (!sheep.HasWool)
            {
                Console.WriteLine("next morning should grow wool back");
                return false;
            }
            string morning = w.TryShearSheep(sheep);
            if (morning != "shear" || w.CountItem("wool") != woolBefore + 2 || sheep.HasWool)
            {
                Console.WriteLine("next-day shear failed act=" + morning + " n=" + w.CountItem("wool"));
                return false;
            }

            w.CraftShears();
            if (w.CountItem("shears") < 1)
            {
                Console.WriteLine("craft shears lost the original");
                return false;
            }
            Console.WriteLine("sheep shear ok wool=2 HasWool persist");
            return true;
        }

        static bool InfiniteEnergyWorks()
        {
            World w = new World();
            if (!w.InfiniteEnergy)
            {
                Console.WriteLine("infinite energy should default on");
                return false;
            }
            w.Energy = 10;
            if (!w.SpendEnergy(4) || w.Energy != GameConst.MaxEnergy)
            {
                Console.WriteLine("infinite spend should refill to max");
                return false;
            }
            w.InfiniteEnergy = false;
            w.Energy = 10;
            if (!w.SpendEnergy(4) || w.Energy != 6)
            {
                Console.WriteLine("finite spend should drain");
                return false;
            }
            w.Energy = 1;
            if (w.SpendEnergy(4) || w.Energy != 1)
            {
                Console.WriteLine("tired spend should fail");
                return false;
            }
            Console.WriteLine("infinite energy ok");
            return true;
        }

        static bool AdminHasRoom(World w, string id)
        {
            ItemDef def = ItemCatalog.Find(id);
            int max = def != null && def.Stackable ? def.MaxStack : 1;
            if (SlotHasRoom(w.Pack, w.PackOpen, id, max))
                return true;
            return SlotHasRoom(w.Bar, w.Bar.Length, id, max);
        }

        static bool SlotHasRoom(InvSlot[] slots, int cap, string id, int max)
        {
            int last = cap < slots.Length ? cap : slots.Length;
            for (int i = 0; i < last; i++)
            {
                if (slots[i].Empty)
                    return true;
                if (slots[i].Id == id && slots[i].Count < max)
                    return true;
            }
            return false;
        }

        static bool AdminSpawnWorks()
        {
            ItemDef[] all = ItemCatalog.All;
            if (all == null || all.Length == 0)
            {
                Console.WriteLine("admin spawn ok (empty catalog)");
                return true;
            }

            World w = new World();
            int spawned = 0;
            int full = 0;
            for (int i = 0; i < all.Length; i++)
            {
                ItemDef d = all[i];
                if (d == null || string.IsNullOrEmpty(d.Id))
                    continue;
                int before = w.CountItem(d.Id);
                w.AddItem(d.Id, 1);
                int after = w.CountItem(d.Id);
                if (after >= before + 1)
                    spawned++;
                else if (!AdminHasRoom(w, d.Id))
                    full++;
                else
                {
                    Console.WriteLine("admin spawn failed " + d.Id);
                    return false;
                }
            }
            if (spawned < 1)
            {
                Console.WriteLine("admin spawn added nothing");
                return false;
            }

            World packed = new World();
            for (int i = 0; i < packed.Bar.Length; i++)
            {
                if (packed.Bar[i].Empty)
                    packed.Bar[i].Set("wood", 999);
            }
            for (int i = 0; i < packed.PackOpen; i++)
            {
                if (packed.Pack[i].Empty)
                    packed.Pack[i].Set("wood", 999);
            }
            int geodeBefore = packed.CountItem("geode");
            packed.AddItem("geode", 1);
            if (packed.CountItem("geode") != geodeBefore)
            {
                Console.WriteLine("admin spawn should not add geode to a full bag");
                return false;
            }
            if (packed.Toast != "Your satchel is full.")
            {
                Console.WriteLine("full bag should toast");
                return false;
            }

            Console.WriteLine("admin spawn ok items=" + spawned.ToString() + " full=" + full.ToString());
            return true;
        }

        static bool FarmMoveWorks()
        {
            World w = new World();
            w.Energy = 42;
            Building ash = w.FindBuilding("ash");
            Building cottage = w.FindBuilding("cottage");
            Building barn = w.FindBuilding("barn");
            if (ash == null || cottage == null || barn == null)
            {
                Console.WriteLine("farm move missing buildings");
                return false;
            }
            int ashX = ash.X;
            int ashY = ash.Y;
            if (World.IsMovableFarmBuilding(ash))
            {
                Console.WriteLine("ash's forge should stay in the village");
                return false;
            }
            if (w.MoveFarmBuilding(ash, GameConst.FarmOx + 16, GameConst.FarmOy + 16))
            {
                Console.WriteLine("ash's forge should not relocate onto the farm");
                return false;
            }
            if (ash.X != ashX || ash.Y != ashY)
            {
                Console.WriteLine("ash moved when refused");
                return false;
            }
            int cx, cy;
            if (!FindFarmSite(w, cottage, out cx, out cy))
            {
                Console.WriteLine("no clear pasture for the cottage");
                return false;
            }
            int oldX = cottage.X;
            int oldY = cottage.Y;
            TileType oldDoor = w.Tiles[cottage.DoorX, cottage.DoorY];
            if (oldDoor != TileType.Door)
            {
                Console.WriteLine("cottage door missing before move");
                return false;
            }
            if (!w.MoveFarmBuilding(cottage, cx, cy))
            {
                Console.WriteLine("cottage move failed at " + cx + "," + cy);
                return false;
            }
            if (cottage.X != cx || cottage.Y != cy)
            {
                Console.WriteLine("cottage x/y not updated");
                return false;
            }
            if (w.Tiles[cottage.DoorX, cottage.DoorY] != TileType.Door)
            {
                Console.WriteLine("moved cottage has no door tile");
                return false;
            }
            if (w.Tiles[cottage.DoorX, cottage.DoorY + 1] != TileType.Path)
            {
                Console.WriteLine("moved cottage door path missing");
                return false;
            }
            if (w.Tiles[oldX + cottage.DoorDx, oldY + cottage.H - 1] == TileType.Door)
            {
                Console.WriteLine("old cottage door still stamped");
                return false;
            }
            int bx, by;
            if (!FindFarmSite(w, barn, out bx, out by))
            {
                Console.WriteLine("no clear pasture for the barn");
                return false;
            }
            if (!w.MoveFarmBuilding(barn, bx, by))
            {
                Console.WriteLine("barn move failed at " + bx + "," + by);
                return false;
            }
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-farm-move.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("farm move write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("farm move read failed");
                    return false;
                }
                if (loaded.Energy != 42)
                {
                    Console.WriteLine("farm move energy should stay 42");
                    return false;
                }
                Building lc = loaded.FindBuilding("cottage");
                Building lb = loaded.FindBuilding("barn");
                Building la = loaded.FindBuilding("ash");
                if (lc == null || lb == null || la == null)
                {
                    Console.WriteLine("farm move load missing buildings");
                    return false;
                }
                if (lc.X != cx || lc.Y != cy)
                {
                    Console.WriteLine("cottage site did not persist " + lc.X + "," + lc.Y);
                    return false;
                }
                if (lb.X != bx || lb.Y != by)
                {
                    Console.WriteLine("barn site did not persist " + lb.X + "," + lb.Y);
                    return false;
                }
                if (la.X != ashX || la.Y != ashY)
                {
                    Console.WriteLine("ash should stay put after load");
                    return false;
                }
                if (loaded.Tiles[lc.DoorX, lc.DoorY] != TileType.Door
                    || loaded.Tiles[lb.DoorX, lb.DoorY] != TileType.Door)
                {
                    Console.WriteLine("loaded doors missing after farm move");
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("farm move ok cottage=" + cx + "," + cy + " barn=" + bx + "," + by);
            return true;
        }

        static bool FarmRotateWorks()
        {
            World w = new World();
            w.Energy = 42;
            Building ash = w.FindBuilding("ash");
            Building cottage = w.FindBuilding("cottage");
            if (ash == null || cottage == null)
            {
                Console.WriteLine("farm rotate missing buildings");
                return false;
            }
            if (w.RotateFarmBuilding(ash))
            {
                Console.WriteLine("ash's forge should not rotate");
                return false;
            }
            if (cottage.W != 7 || cottage.H != 5)
            {
                Console.WriteLine("cottage canonical size " + cottage.W + "x" + cottage.H);
                return false;
            }
            bool turned = false;
            for (int attempt = 0; attempt < 40 && !turned; attempt++)
            {
                int cx, cy;
                if (!FindFarmSite(w, cottage, out cx, out cy))
                    break;
                if (!w.MoveFarmBuilding(cottage, cx, cy))
                {
                    Console.WriteLine("cottage move before rotate failed at " + cx + "," + cy);
                    return false;
                }
                turned = w.RotateFarmBuilding(cottage);
            }
            if (!turned)
            {
                Console.WriteLine("cottage rotate failed");
                return false;
            }
            if (cottage.Rot != 1 || cottage.FootW != 5 || cottage.FootH != 7)
            {
                Console.WriteLine("cottage rotate footprint rot=" + cottage.Rot
                    + " " + cottage.FootW + "x" + cottage.FootH);
                return false;
            }
            if (cottage.DoorX != cottage.X)
            {
                Console.WriteLine("rotated cottage door is not on the west wall door="
                    + cottage.DoorX + " x=" + cottage.X);
                return false;
            }
            if (w.Tiles[cottage.DoorX, cottage.DoorY] != TileType.Door)
            {
                Console.WriteLine("rotated cottage has no door tile");
                return false;
            }
            if (w.Tiles[cottage.ApproachX, cottage.ApproachY] != TileType.Path)
            {
                Console.WriteLine("rotated cottage approach path missing");
                return false;
            }
            for (int i = 0; i < 3; i++)
            {
                if (!w.RotateFarmBuilding(cottage))
                {
                    Console.WriteLine("cottage cycle rotate " + (i + 2) + " failed");
                    return false;
                }
            }
            if (cottage.Rot != 0 || cottage.FootW != 7)
            {
                Console.WriteLine("four rotates should restore rot=0 foot=" + cottage.FootW
                    + " rot=" + cottage.Rot);
                return false;
            }
            if (!w.RotateFarmBuilding(cottage))
            {
                Console.WriteLine("cottage rotate before save failed");
                return false;
            }
            w.Energy = 42;
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-farm-rotate.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("farm rotate write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("farm rotate read failed");
                    return false;
                }
                if (loaded.Energy != 42)
                {
                    Console.WriteLine("farm rotate energy should stay 42");
                    return false;
                }
                Building lc = loaded.FindBuilding("cottage");
                Building la = loaded.FindBuilding("ash");
                if (lc == null || la == null)
                {
                    Console.WriteLine("farm rotate load missing buildings");
                    return false;
                }
                if (lc.Rot != 1 || lc.FootW != 5 || lc.FootH != 7)
                {
                    Console.WriteLine("cottage rot did not persist rot=" + lc.Rot
                        + " " + lc.FootW + "x" + lc.FootH);
                    return false;
                }
                if (lc.X != cottage.X || lc.Y != cottage.Y)
                {
                    Console.WriteLine("cottage site did not persist after rotate " + lc.X + "," + lc.Y);
                    return false;
                }
                if (la.Rot != 0)
                {
                    Console.WriteLine("ash should stay unrotated after load");
                    return false;
                }
                if (loaded.Tiles[lc.DoorX, lc.DoorY] != TileType.Door
                    || loaded.Tiles[lc.ApproachX, lc.ApproachY] != TileType.Path)
                {
                    Console.WriteLine("loaded door/path missing after farm rotate");
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("farm rotate ok rot=" + cottage.Rot + " " + cottage.FootW + "x" + cottage.FootH
                + " at " + cottage.X + "," + cottage.Y);
            return true;
        }

        static bool FindFarmSite(World w, Building b, out int x, out int y)
        {
            x = 0;
            y = 0;
            if (w == null || b == null)
                return false;
            for (int ty = GameConst.FarmOy; ty <= GameConst.CountryOy - b.FootH; ty++)
            {
                for (int tx = GameConst.FarmOx; tx <= GameConst.MapW - b.FootW; tx++)
                {
                    if (tx == b.X && ty == b.Y)
                        continue;
                    if (tx < b.X + b.FootW && tx + b.FootW > b.X && ty < b.Y + b.FootH && ty + b.FootH > b.Y)
                        continue;
                    if (w.CanPlaceFarmBuilding(b, tx, ty))
                    {
                        x = tx;
                        y = ty;
                        return true;
                    }
                }
            }
            return false;
        }

        static bool SiloAndHayWorks()
        {
            World w = new World();
            w.Energy = 42;
            Building silo = w.FindBuilding("silo");
            if (silo == null || silo.Kind != BuildingKind.Silo)
            {
                Console.WriteLine("silo missing");
                return false;
            }
            if (silo.W != 2 || silo.H != 3)
            {
                Console.WriteLine("silo footprint " + silo.W + "x" + silo.H);
                return false;
            }
            if (w.Tiles[silo.DoorX, silo.DoorY] != TileType.Door)
            {
                Console.WriteLine("silo hatch missing");
                return false;
            }
            int hayTiles = w.CountHayTiles();
            if (hayTiles < 40)
            {
                Console.WriteLine("hayfields too small " + hayTiles);
                return false;
            }
            int hx = -1, hy = -1;
            for (int y = GameConst.FarmOy; y < GameConst.CountryOy && hx < 0; y++)
            {
                for (int x = GameConst.FarmOx; x < GameConst.MapW; x++)
                {
                    if (w.Tiles[x, y] == TileType.Hay)
                    {
                        hx = x;
                        hy = y;
                        break;
                    }
                }
            }
            if (hx < 0)
            {
                Console.WriteLine("no ripe hay to cut");
                return false;
            }
            w.Selected = 2;
            string act = w.UseTool(hx, hy);
            if (act != "scythe" || w.Tiles[hx, hy] != TileType.HayCut || w.CountItem("hay") < 1)
            {
                Console.WriteLine("scythe hay failed act=" + act + " tile=" + w.Tiles[hx, hy] + " hay=" + w.CountItem("hay"));
                return false;
            }
            w.AdvanceDay(false);
            if (w.Tiles[hx, hy] != TileType.Hay)
            {
                Console.WriteLine("hay did not regrow overnight");
                return false;
            }
            int cut = w.CountItem("hay");
            w.UseSilo();
            if (w.HayInSilo != cut || w.CountItem("hay") != 0)
            {
                Console.WriteLine("silo store failed stored=" + w.HayInSilo + " bag=" + w.CountItem("hay"));
                return false;
            }
            w.UseSilo();
            if (w.HayInSilo != 0 || w.CountItem("hay") != cut)
            {
                Console.WriteLine("silo take failed stored=" + w.HayInSilo + " bag=" + w.CountItem("hay"));
                return false;
            }
            w.UseSilo();
            w.Energy = 42;
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-silo.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("silo write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("silo read failed");
                    return false;
                }
                if (loaded.Energy != 42)
                {
                    Console.WriteLine("silo energy should stay 42");
                    return false;
                }
                Building ls = loaded.FindBuilding("silo");
                if (ls == null || ls.X != silo.X || ls.Y != silo.Y)
                {
                    Console.WriteLine("silo site did not persist");
                    return false;
                }
                if (loaded.HayInSilo != cut)
                {
                    Console.WriteLine("silo hay did not persist " + loaded.HayInSilo);
                    return false;
                }
                if (loaded.CountHayTiles() < 40)
                {
                    Console.WriteLine("loaded hayfields missing " + loaded.CountHayTiles());
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("silo ok hayfields=" + hayTiles + " stored=" + cut);
            return true;
        }

        static bool TreeFallWorks()
        {
            World w = new World();
            w.Energy = 42;
            int tx = -1, ty = -1;
            for (int y = GameConst.FarmOy; y < GameConst.CountryOy && tx < 0; y++)
            {
                for (int x = GameConst.FarmOx; x < GameConst.MapW; x++)
                {
                    if (w.Tiles[x, y] == TileType.Tree)
                    {
                        tx = x;
                        ty = y;
                        break;
                    }
                }
            }
            if (tx < 0)
            {
                Console.WriteLine("no farm tree to chop");
                return false;
            }
            int woodBefore = w.CountItem("wood");
            w.Selected = 3;
            string act = w.UseTool(tx, ty);
            if (act != "chop" || w.Tiles[tx, ty] != TileType.Tree)
            {
                Console.WriteLine("first chop failed act=" + act + " tile=" + w.Tiles[tx, ty]);
                return false;
            }
            if (w.FallingTrees.Count != 0)
            {
                Console.WriteLine("tree fell on first hit");
                return false;
            }
            act = w.UseTool(tx, ty);
            if (act != "chop" || w.Tiles[tx, ty] != TileType.Stump)
            {
                Console.WriteLine("felling chop failed act=" + act + " tile=" + w.Tiles[tx, ty]);
                return false;
            }
            if (w.FallingTrees.Count != 1)
            {
                Console.WriteLine("no falling tree after chop " + w.FallingTrees.Count);
                return false;
            }
            FallingTree fall = w.FallingTrees[0];
            if (fall.Tx != tx || fall.Ty != ty || fall.Dur != GameConst.TreeFallDur || fall.Life != GameConst.TreeFallDur)
            {
                Console.WriteLine("fall state wrong life=" + fall.Life + " dur=" + fall.Dur);
                return false;
            }
            if (w.CountItem("wood") <= woodBefore)
            {
                Console.WriteLine("no wood from felled tree");
                return false;
            }
            bool landed = false;
            int ticks = 0;
            while (w.FallingTrees.Count > 0 && ticks < 200)
            {
                if (w.TickFallingTrees(0.05f))
                    landed = true;
                ticks++;
            }
            if (w.FallingTrees.Count != 0)
            {
                Console.WriteLine("fall never finished");
                return false;
            }
            if (!landed)
            {
                Console.WriteLine("fall never landed");
                return false;
            }
            if (w.Tiles[tx, ty] != TileType.Stump)
            {
                Console.WriteLine("stump gone after fall");
                return false;
            }
            act = w.UseTool(tx, ty);
            if (act != "fail" || w.Tiles[tx, ty] != TileType.Stump)
            {
                Console.WriteLine("stump should stay after extra swing act=" + act + " tile=" + w.Tiles[tx, ty]);
                return false;
            }
            w.Energy = 42;
            Console.WriteLine("tree fall ok at " + tx + "," + ty);
            return true;
        }

        static bool MapEditorWorks()
        {
            World w = new World();
            int treeX = -1, treeY = -1;
            int grassX = -1, grassY = -1;
            int paintX = -1, paintY = -1;
            int wallX = -1, wallY = -1;
            for (int y = 0; y < GameConst.MapH; y++)
            {
                for (int x = 0; x < GameConst.MapW; x++)
                {
                    if (w.BuildingOccupies(x, y))
                        continue;
                    TileType t = w.Tiles[x, y];
                    if (t == TileType.Tree && treeX < 0)
                    {
                        treeX = x;
                        treeY = y;
                    }
                    else if (t == TileType.Grass)
                    {
                        if (grassX < 0)
                        {
                            grassX = x;
                            grassY = y;
                        }
                        else if (paintX < 0 && (x != grassX || y != grassY))
                        {
                            paintX = x;
                            paintY = y;
                        }
                        else if (wallX < 0 && (x != grassX || y != grassY) && (x != paintX || y != paintY))
                        {
                            wallX = x;
                            wallY = y;
                        }
                    }
                }
            }
            if (treeX < 0 || grassX < 0 || paintX < 0 || wallX < 0)
            {
                Console.WriteLine("map editor missing tree or grass tiles");
                return false;
            }
            if (grassX == treeX && grassY == treeY)
            {
                Console.WriteLine("map editor grass collided with tree");
                return false;
            }
            MapEditPick tree = w.EditorHit(treeX, treeY);
            if (tree.Kind != MapEditKind.Tile || tree.Tile != TileType.Tree)
            {
                Console.WriteLine("map editor did not pick tree at " + treeX + "," + treeY + " kind=" + tree.Kind);
                return false;
            }
            if (!w.MoveEditorPick(tree, grassX, grassY))
            {
                Console.WriteLine("map editor tree move failed to " + grassX + "," + grassY);
                return false;
            }
            if (w.Tiles[treeX, treeY] == TileType.Tree)
            {
                Console.WriteLine("tree still at old tile after move");
                return false;
            }
            if (w.Tiles[grassX, grassY] != TileType.Tree)
            {
                Console.WriteLine("tree missing at new tile");
                return false;
            }
            if (!w.EditorPaintCell(paintX, paintY, TileType.Water, false, false))
            {
                Console.WriteLine("map editor paint water failed");
                return false;
            }
            if (w.Tiles[paintX, paintY] != TileType.Water)
            {
                Console.WriteLine("painted tile is not water");
                return false;
            }
            if (!w.EditorSetWallCell(wallX, wallY, true) || !w.HasHiddenWall(wallX, wallY))
            {
                Console.WriteLine("invisible wall did not place");
                return false;
            }
            float wx = wallX * GameConst.Tile + GameConst.Tile / 2f;
            float wy = wallY * GameConst.Tile + GameConst.Tile / 2f;
            if (!w.Blocked(wx, wy))
            {
                Console.WriteLine("player can walk through invisible wall");
                return false;
            }
            if (w.Tiles[wallX, wallY] != TileType.Grass)
            {
                Console.WriteLine("invisible wall should keep the grass tile");
                return false;
            }
            Building ash = w.FindBuilding("ash");
            if (ash == null)
            {
                Console.WriteLine("map editor missing ash");
                return false;
            }
            int ashX = ash.X;
            int ashY = ash.Y;
            int destX = ashX;
            int destY = ashY + 2;
            if (destY + ash.FootH < GameConst.MapH && w.CanPlaceEditorBuilding(ash, destX, destY))
            {
                if (!w.MoveEditorBuilding(ash, destX, destY))
                {
                    Console.WriteLine("admin should be able to move ash's forge");
                    return false;
                }
                if (ash.X == ashX && ash.Y == ashY)
                {
                    Console.WriteLine("ash did not move in map editor");
                    return false;
                }
            }
            else
            {
                bool moved = false;
                for (int y = 2; y < GameConst.VillageH - 8 && !moved; y++)
                {
                    for (int x = 2; x < GameConst.MapW - ash.FootW - 2 && !moved; x++)
                    {
                        if (!w.CanPlaceEditorBuilding(ash, x, y))
                            continue;
                        if (!w.MoveEditorBuilding(ash, x, y))
                            continue;
                        moved = true;
                    }
                }
                if (!moved)
                {
                    Console.WriteLine("admin could not relocate ash");
                    return false;
                }
            }
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-map-editor.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("map editor write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("map editor read failed");
                    return false;
                }
                if (loaded.Tiles[grassX, grassY] != TileType.Tree)
                {
                    Console.WriteLine("moved tree did not persist");
                    return false;
                }
                if (loaded.Tiles[treeX, treeY] == TileType.Tree)
                {
                    Console.WriteLine("old tree tile came back after load");
                    return false;
                }
                if (loaded.Tiles[paintX, paintY] != TileType.Water)
                {
                    Console.WriteLine("painted water did not persist");
                    return false;
                }
                if (!loaded.HasHiddenWall(wallX, wallY))
                {
                    Console.WriteLine("invisible wall did not persist");
                    return false;
                }
                if (!loaded.Blocked(wx, wy))
                {
                    Console.WriteLine("loaded invisible wall is not solid");
                    return false;
                }
                Building la = loaded.FindBuilding("ash");
                if (la == null || (la.X == ashX && la.Y == ashY))
                {
                    Console.WriteLine("ash site did not persist from map editor");
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("map editor ok tree=" + grassX + "," + grassY + " water=" + paintX + "," + paintY
                + " wall=" + wallX + "," + wallY);
            return true;
        }

        static bool FindOpenGrass(World w, int skipX, int skipY, int needW, int needH, out int ox, out int oy)
        {
            ox = -1;
            oy = -1;
            for (int y = 2; y < GameConst.MapH - needH - 2; y++)
            {
                for (int x = 2; x < GameConst.MapW - needW - 2; x++)
                {
                    if (x == skipX && y == skipY)
                        continue;
                    bool ok = true;
                    for (int dy = 0; dy < needH && ok; dy++)
                    {
                        for (int dx = 0; dx < needW; dx++)
                        {
                            int tx = x + dx;
                            int ty = y + dy;
                            if (w.BuildingOccupies(tx, ty))
                            {
                                ok = false;
                                break;
                            }
                            if (w.Tiles[tx, ty] != TileType.Grass)
                            {
                                ok = false;
                                break;
                            }
                            if (w.HasHiddenWall(tx, ty))
                            {
                                ok = false;
                                break;
                            }
                        }
                    }
                    if (!ok)
                        continue;
                    ox = x;
                    oy = y;
                    return true;
                }
            }
            return false;
        }

        static MapStamp StampNamed(string name)
        {
            MapStamp[] all = MapEdit.Catalog;
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i].Name == name)
                    return all[i];
            }
            return null;
        }

        static bool MapEditorPlaceWorks()
        {
            World w = new World();
            MapStamp tree = StampNamed("Oak tree");
            MapStamp rock = StampNamed("Rock");
            MapStamp fence = StampNamed("Fence");
            MapStamp silo = StampNamed("Silo");
            if (tree == null || rock == null || fence == null)
            {
                Console.WriteLine("place catalog missing tree/rock/fence");
                return false;
            }
            int treeX, treeY;
            if (!FindOpenGrass(w, -1, -1, 1, 1, out treeX, out treeY))
            {
                Console.WriteLine("place editor no grass for tree");
                return false;
            }
            string placedId;
            if (!w.CanStampEditor(tree, treeX, treeY, 0) || !w.StampEditor(tree, treeX, treeY, 0, out placedId))
            {
                Console.WriteLine("place tree failed at " + treeX + "," + treeY);
                return false;
            }
            if (w.Tiles[treeX, treeY] != TileType.Tree)
            {
                Console.WriteLine("placed tree missing");
                return false;
            }
            int rockX, rockY;
            if (!FindOpenGrass(w, treeX, treeY, 1, 1, out rockX, out rockY))
            {
                Console.WriteLine("place editor no grass for rock");
                return false;
            }
            if (!w.StampEditor(rock, rockX, rockY, 0, out placedId))
            {
                Console.WriteLine("place rock failed");
                return false;
            }
            if (w.Tiles[rockX, rockY] != TileType.Rock)
            {
                Console.WriteLine("placed rock missing");
                return false;
            }
            int fenceX, fenceY;
            if (!FindOpenGrass(w, rockX, rockY, 1, 1, out fenceX, out fenceY))
            {
                Console.WriteLine("place editor no grass for fence");
                return false;
            }
            if (fenceX == treeX && fenceY == treeY)
            {
                if (!FindOpenGrass(w, treeX, treeY, 1, 1, out fenceX, out fenceY))
                {
                    Console.WriteLine("place editor no third grass");
                    return false;
                }
            }
            if (!w.StampEditor(fence, fenceX, fenceY, 0, out placedId))
            {
                Console.WriteLine("place fence failed");
                return false;
            }
            if (w.Tiles[fenceX, fenceY] != TileType.Fence)
            {
                Console.WriteLine("placed fence missing");
                return false;
            }
            if (!w.CanStampEditor(tree, treeX, treeY, 0))
            {
                // occupied is expected
            }
            else
            {
                Console.WriteLine("should not restamp a tree on a tree");
                return false;
            }
            int siloX = -1, siloY = -1;
            string siloId = "";
            int beforeHouses = w.Buildings.Count;
            if (silo != null)
            {
                for (int y = 4; y < GameConst.MapH - 8 && siloX < 0; y++)
                {
                    for (int x = 4; x < GameConst.MapW - 8; x++)
                    {
                        if (!w.CanStampEditor(silo, x, y, 0))
                            continue;
                        if (!w.StampEditor(silo, x, y, 0, out siloId))
                            continue;
                        siloX = x;
                        siloY = y;
                        break;
                    }
                }
            }
            if (siloX < 0 || w.Buildings.Count != beforeHouses + 1)
            {
                Console.WriteLine("place silo failed houses=" + w.Buildings.Count);
                return false;
            }
            Building stamped = w.FindBuilding(siloId);
            if (stamped == null || stamped.Kind != BuildingKind.Silo || stamped.X != siloX)
            {
                Console.WriteLine("stamped silo not in building list");
                return false;
            }
            string path = Path.Combine(Path.GetTempPath(), "harvest-hollow-map-place.sav");
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                if (!SaveGame.Write(w, path))
                {
                    Console.WriteLine("place editor write failed");
                    return false;
                }
                World loaded = new World();
                if (!SaveGame.Read(loaded, path))
                {
                    Console.WriteLine("place editor read failed");
                    return false;
                }
                if (loaded.Tiles[treeX, treeY] != TileType.Tree)
                {
                    Console.WriteLine("placed tree did not persist");
                    return false;
                }
                if (loaded.Tiles[rockX, rockY] != TileType.Rock)
                {
                    Console.WriteLine("placed rock did not persist");
                    return false;
                }
                if (loaded.Tiles[fenceX, fenceY] != TileType.Fence)
                {
                    Console.WriteLine("placed fence did not persist");
                    return false;
                }
                Building loadedSilo = loaded.FindBuilding(siloId);
                if (loadedSilo == null || loadedSilo.Kind != BuildingKind.Silo
                    || loadedSilo.X != siloX || loadedSilo.Y != siloY)
                {
                    Console.WriteLine("placed silo did not persist id=" + siloId);
                    return false;
                }
            }
            finally
            {
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                }
                catch
                {
                }
            }
            Console.WriteLine("map editor place ok tree=" + treeX + "," + treeY + " rock=" + rockX + "," + rockY
                + " fence=" + fenceX + "," + fenceY + " silo=" + siloX + "," + siloY);
            return true;
        }
    }
}
