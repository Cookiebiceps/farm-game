using System;
using System.IO;
using System.IO.Compression;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    /// <summary>
    /// Minimal 8-bit RGBA PNG reader for packed sprites (no interlacing).
    /// </summary>
    public static class PngRgba
    {
        public static bool TryLoad(string path, out Color[] pixels, out int width, out int height)
        {
            pixels = null;
            width = 0;
            height = 0;
            if (path == null || !File.Exists(path))
                return false;
            byte[] file = File.ReadAllBytes(path);
            return TryDecode(file, out pixels, out width, out height);
        }

        static bool TryDecode(byte[] file, out Color[] pixels, out int width, out int height)
        {
            pixels = null;
            width = 0;
            height = 0;
            if (file == null || file.Length < 33)
                return false;
            if (file[0] != 137 || file[1] != 80 || file[2] != 78 || file[3] != 71)
                return false;
            int w = 0;
            int h = 0;
            bool haveHdr = false;
            MemoryStream idat = new MemoryStream();
            int i = 8;
            while (i + 12 <= file.Length)
            {
                int len = (file[i] << 24) | (file[i + 1] << 16) | (file[i + 2] << 8) | file[i + 3];
                if (len < 0 || i + 12 + len > file.Length)
                    return false;
                char c0 = (char)file[i + 4];
                char c1 = (char)file[i + 5];
                char c2 = (char)file[i + 6];
                char c3 = (char)file[i + 7];
                string typ = new string(new[] { c0, c1, c2, c3 });
                int data = i + 8;
                if (typ == "IHDR")
                {
                    if (len < 13)
                        return false;
                    w = (file[data] << 24) | (file[data + 1] << 16) | (file[data + 2] << 8) | file[data + 3];
                    h = (file[data + 4] << 24) | (file[data + 5] << 16) | (file[data + 6] << 8) | file[data + 7];
                    int bit = file[data + 8];
                    int color = file[data + 9];
                    int comp = file[data + 10];
                    int filt = file[data + 11];
                    int inter = file[data + 12];
                    if (bit != 8 || color != 6 || comp != 0 || filt != 0 || inter != 0)
                        return false;
                    if (w <= 0 || h <= 0 || w > 4096 || h > 4096)
                        return false;
                    haveHdr = true;
                }
                else if (typ == "IDAT")
                    idat.Write(file, data, len);
                else if (typ == "IEND")
                    break;
                i = data + len + 4;
            }
            if (!haveHdr || idat.Length == 0)
                return false;
            byte[] raw;
            try
            {
                idat.Position = 0;
                using (ZLibStream zs = new ZLibStream(idat, CompressionMode.Decompress, true))
                using (MemoryStream ms = new MemoryStream())
                {
                    zs.CopyTo(ms);
                    raw = ms.ToArray();
                }
            }
            catch
            {
                return false;
            }
            int stride = w * 4;
            int need = h * (stride + 1);
            if (raw.Length < need)
                return false;
            pixels = new Color[w * h];
            byte[] prev = new byte[stride];
            byte[] row = new byte[stride];
            int src = 0;
            for (int y = 0; y < h; y++)
            {
                int filter = raw[src++];
                Buffer.BlockCopy(raw, src, row, 0, stride);
                src += stride;
                if (!Unfilter(filter, row, prev, stride, 4))
                    return false;
                for (int x = 0; x < w; x++)
                {
                    int o = x * 4;
                    pixels[y * w + x] = new Color(row[o], row[o + 1], row[o + 2], row[o + 3]);
                }
                Buffer.BlockCopy(row, 0, prev, 0, stride);
            }
            width = w;
            height = h;
            return true;
        }

        static bool Unfilter(int filter, byte[] row, byte[] prev, int stride, int bpp)
        {
            if (filter == 0)
                return true;
            for (int x = 0; x < stride; x++)
            {
                byte a = x >= bpp ? row[x - bpp] : (byte)0;
                byte b = prev[x];
                byte c = x >= bpp ? prev[x - bpp] : (byte)0;
                if (filter == 1)
                    row[x] = (byte)(row[x] + a);
                else if (filter == 2)
                    row[x] = (byte)(row[x] + b);
                else if (filter == 3)
                    row[x] = (byte)(row[x] + ((a + b) / 2));
                else if (filter == 4)
                    row[x] = (byte)(row[x] + Paeth(a, b, c));
                else
                    return false;
            }
            return true;
        }

        static byte Paeth(byte a, byte b, byte c)
        {
            int p = a + b - c;
            int pa = Math.Abs(p - a);
            int pb = Math.Abs(p - b);
            int pc = Math.Abs(p - c);
            if (pa <= pb && pa <= pc)
                return a;
            if (pb <= pc)
                return b;
            return c;
        }
    }
}
