using System;
using System.IO;

namespace HarvestHollow
{
    public static class SaveGame
    {
        public const int Version = 9;
        const int Magic = 0x48565348;

        public static string FilePath()
        {
            try
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HarvestHollow");
                Directory.CreateDirectory(dir);
                return Path.Combine(dir, "valley.sav");
            }
            catch
            {
                return "harvest-valley.sav";
            }
        }

        public static bool Exists()
        {
            try
            {
                return File.Exists(FilePath());
            }
            catch
            {
                return false;
            }
        }

        public static bool Write(World world)
        {
            return Write(world, FilePath());
        }

        public static bool Write(World world, string path)
        {
            if (world == null || string.IsNullOrEmpty(path))
                return false;
            string tmp = path + ".tmp";
            try
            {
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir))
                    Directory.CreateDirectory(dir);
                using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
                using (BinaryWriter w = new BinaryWriter(fs))
                {
                    w.Write(Magic);
                    w.Write(Version);
                    world.WriteSave(w);
                }
                if (File.Exists(path))
                    File.Delete(path);
                File.Move(tmp, path);
                return true;
            }
            catch
            {
                try
                {
                    if (File.Exists(tmp))
                        File.Delete(tmp);
                }
                catch
                {
                }
                return false;
            }
        }

        public static bool Read(World world)
        {
            return Read(world, FilePath());
        }

        public static bool Read(World world, string path)
        {
            if (world == null || string.IsNullOrEmpty(path) || !File.Exists(path))
                return false;
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                using (BinaryReader r = new BinaryReader(fs))
                {
                    if (r.ReadInt32() != Magic)
                        return false;
                    int ver = r.ReadInt32();
                    if (ver < 1 || ver > Version)
                        return false;
                    world.ReadSave(r, ver);
                }
                world.RemeshOutdoorKeepingFarm();
                world.RebuildHouseInteriors();
                world.ApplyFarmRepairFlags();
                world.EnsureTestPlanks();
                world.EnsureMilkPail();
                world.EnsureShears();
                world.EnsureStarterCows();
                world.EnsureStarterSheep();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
