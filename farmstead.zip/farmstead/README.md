# Harvest Hollow

A **32×32** tile farming game written in **C#** against the **Microsoft XNA 4.0 API** (`Microsoft.Xna.Framework.Game`, `SpriteBatch`, `Texture2D`, `Keyboard`, `Mouse`, `GameTime`).

XNA Game Studio 4.0 shipped with Visual Studio 2010 and is no longer installable on modern Windows. This project uses **MonoGame**, the maintained implementation of that same XNA 4.0 framework, so the game code is the XNA 4.0 style you would write in Game Studio — it just builds on current .NET.

## Play

Requires the [.NET 8 SDK](https://dotnet.microsoft.com/download).

```bash
dotnet restore
dotnet run
```

A 1280×720 window opens. Linux needs the usual MonoGame DesktopGL libraries (`libsdl2`, `libopenal`).

The looping piano theme is also saved as **`HarvestHollowTheme.wav`** (about 53 seconds, 22 kHz stereo). Play it in any audio app. To regenerate it:

```bash
dotnet run -- --export-theme HarvestHollowTheme.wav
```

```bash
dotnet build -c Release
dotnet run -c Release
```

## How to farm

Till soil with the hoe, plant seeds, water every day (or wait for rain), harvest when the crop glows, and drop produce in the shipping crate south of the field. The farm is a **wide hollow** of open grass — hoe anywhere you like. South of the cottage a lane runs to a **broken barn** (packed Cute Fantasy red gable — double doors **slide open** when you walk up), **broken greenhouse**, **broken chicken coop**, and a **silo**. **Shift+C** mills **1 wooden plank from 10 wood**. Press **E** on a ruin to spend planks (**6** coop, **10** greenhouse, **16** barn). A satchel starts with **100 wooden planks** for testing. Cut **hayfields** with the scythe and press **E** on the silo to store hay (up to **240**) or take it back. The repaired greenhouse is a packed Cute Fantasy glasshouse (teal frame) with a brick-and-glass interior **24 tiles long** over two soil beds. Chop trees for **wood** — they fall, and a **stump** stays. Press **C** to craft a **fence** (1 wood = 1 fence), and plant it from the hotbar. **E** packs a placed fence back into your bag. The **pickaxe** starts in your satchel — mine **stone** along the roads. Sparkling **mineral veins** on **Ridge Summit** and inside **Ridge Hollow** drop **1–10 gold ore, silver ore, or geodes**, with a small chance of **diamond, emerald, sapphire, or jade**. A **sword** is in the satchel too. **K** opens skills (Attack, Woodcutting, Mining). Walk into **Ridge Hollow** on Ridge Summit: the cave is a **100-floor labyrinth**. Stone doors deeper in the maze drop you a floor; the mouth door climbs back (or leaves on floor 1). Every **tenth** depth is a vault with three chests of gold coins. **Bats, slimes, spiders, and trolls** hunt the maze floors and will strike if you linger; vaults are quiet. Equip the sword and swing to fight them (Attack XP and gold on a kill; trolls also drop stone). Gold from the shipping bin arrives the next morning. The farmer and villagers are chunky ¾ sprites about a tile and a half tall. Each tool is a shaded in-hand model gripped at the handle (hoe, watering can, scythe, axe, pickaxe, sword, fishing pole, milk pail, shears, or a seed pouch). The farmer **walks on a four-step cycle**; using a tool winds the body up and strikes, with a matching slam, chop, stab, sweep, slash, pour, snip, or cast. Rainy mornings sometimes break into thunderstorms — darker sky, heavier rain, lightning, and a delayed rumble — and a quiet rain day can still grow a storm cell later.

Houses are **instanced**: one shared exterior sprite per size and roof style, each with a unique interior. Homes split into a **kitchen** (stove, sink, table) and a **bedroom** with a real two-tile bed. Interior walls are flat plaster that tiles without a wood frame on every block. Walk into a door (or press **E**) to load that house's rooms. Sleep in **Your Cottage**, drawn from the Cute Fantasy wood house sprite at 32×32 (steep blue gable, not a generated hip roof). Buy seeds from **Rowan** inside his shop. **Ash's Forge** on the east square mills **1 wooden plank from 10 wood** (same as Shift+C), or press **2** at his bench to open an overhead of Harvest Hollow and move the farm buildings — **R** rotates a house 90°. The forge is a packed Cute Fantasy wood-and-stone house with a red gable, blitted onto the existing lot. **Piper's Market** is a grocery: glass coolers, aisles of stock, and a checkout counter she stands behind. Sell saltwater fish to **Finn** inside his dock house at the beach.

The map uses original **32×32 PNG tiles** in `Content/pack` (flat grass and dirt fills for lawns and roads, Wang autotiles for the beach shore, plus tree and prop sprites). **Saltwind Beach** is wind-rippled dune sand (light crests, darker valleys) generated in `TileGen`, with wetter sand at the waterline. The Hollow River and ocean are animated in `TileGen` so the current runs south into the sea; dirt fords are small wooden decks. Mountain ground is grey stone with stone lips that hang down onto roads, grass, water, and cliff faces. Lawn next to a dirt road stays a thin grass rim, not a cliff. This repo does **not** include paid third-party packs.

Walk **west** from the farm into the **Forbidden Woods**, then farther west into **Moonveil Grove** — a darker oak and pine wood with a moonlit pool and fireflies. Walk **north** on the dirt spine onto the **Mountain Path** (grey stone ground, the Hollow River beside the road) to Hearth Village. Mid-ridge a signed road runs **west** into **Ridge Summit** and the cave. Walk **south** on the same spine along **Meadow Road**, a long wildflower walk, until the river meets **Saltwind Beach** and Finn's dock house — a thatched plank shack on a timber pier with drying racks, fish crates, and moored boats. The shore is wide: **E** picks up **cockles, scallops, whelks, sand dollars, conches, and seaweed**. The farm pond is gone — fill the watering can from the river or the sea.

Talk to townsfolk in Hearth Village, a cottage-core hamlet of thatched homes, flower gardens, and blossom trees. **Ash's Forge** sits south of Cob's cabin — a packed Cute Fantasy wood-and-stone forge with a red gable. Press **1** at the bench to mill a plank, **3** to craft a **milk pail** from **4 wooden planks**, **4** to craft **shears** from **3 wooden planks**, or **2** to lift and place farm buildings from an overhead of the hollow. On the site plan, **R** rotates the picked or hovered building 90°, and right-click cancels a pick. **Bess's Stockyard** is south of Ash on the east lane: buy **chickens, rabbits, sheep, pigs, cows, and horses** (keys **1–6**), then set them on Harvest Hollow pasture from the hotbar. Two **cows** and two **sheep** graze by the barn. A **milk pail** and **shears** start in the satchel (or craft them at Ash). Face a cow and press **E** to milk — **one Milk a day** per cow (ships for **90g**). Face a woolly sheep and press **E** to shear — **Wool** grows back the next morning (ships for **48g**). **E** packs other animals; hold a livestock crate and **E** to pack a cow or sheep. **Hearth Inn** has a lobby bar downstairs (Mira sells cider, tea, ale, and cocoa) and two guest rooms upstairs. Sleep in a guest bed or in your cottage. Finn pays on the spot for every fish in your hotbar and satchel.

## Local multiplayer

Up to **six** farmers can share one valley on the same LAN. The host is the authority: tiles, crops, trees, weather, and the clock are the same for everyone. Bags, gold, energy, and hotbars stay personal.

A new **Solo** or **Host** farm writes a save as soon as you finish making your farmer. After that, the valley autosaves about every 20 seconds, when you sleep, when a day rolls over, when you return to the title from settings, and when you quit. **Continue Farm** appears on the title once a save exists and restores that farmer (look, inventory, skills, gold) and the land.

The file is `%AppData%/HarvestHollow/valley.sav` on Windows, or `~/.config/HarvestHollow/valley.sav` on Linux. Joining someone else's LAN farm does not overwrite your save.

On the title screen pick **Continue Farm**, **Solo**, **Host LAN farm**, or **Join LAN farm**. Each new game opens **Make your farmer**: girl or boy, six faces, six hairstyles, six outfits, six hats (including none), and five glasses (including none). **Q** / **E** turn the preview. Starting Solo or Host again replaces the save with a fresh valley.

The host HUD shows your computer’s LAN address. Guests type that IPv4 address (example `192.168.1.20`). Traffic uses TCP port **27431** — allow it through the host firewall if friends cannot connect.

Farmers are tinted by join order so you can tell them apart. Everyone sees the same outdoor map (no blacked-out neighbor zones). Interiors are still instanced: you only see people who are in the same house or cave as you.

| Input | Action |
| --- | --- |
| Esc | Settings — **Back to main menu** is the last row while a farm is running |
| WASD / arrows | Walk |
| 1–9 | Hotbar (hoe, can, scythe, axe, four seed types, fishing pole) |
| Click / Space | Use tool on the highlighted tile. On Ash's site plan: click a farm building, then click pasture to set it down |
| R | On Ash's site plan: rotate the picked or hovered farm building 90°. Right-click cancels a pick |
| E | Bed, shops, shipping bin, talk, pick up a fence or animal, repair ruins, milk a cow, shear a sheep |
| I | Satchel — character sheet and skills on the left; drag items on the right |
| K | Skills (Attack, Woodcutting, Mining) |
| C | Craft 1 fence from 1 wood |
| Shift+C | Mill 1 wooden plank from 10 wood |
| H / F1 | Handbook |
| F3 | Toggle infinite energy (on by default for testing) |
| F4 | Admin spawn menu (testing) — browse every item and put it in your bag. Click **MAP EDITOR** to paint tiles, move world objects, stamp new buildings/trees/placeables, and place invisible walls |
| Map editor | **1** Select/Move  **2** Paint  **3** Erase  **4** Invisible wall  **5** Eyedropper  **6** Place. Place opens a catalog: click a name (or **[ ]** / mouse wheel to cycle), then click empty ground to stamp. Ghost preview; "can't place here" if blocked. **R** rotates a building stamp 90°. LMB paint/place, RMB sample/cancel, **[ ]** brush size (paint tools), **G** grid, **Z** undo, WASD/arrows pan, **Esc** back to admin. Edits save with the farm. |
| M | Mute / unmute the piano theme |
| Enter | Start game / confirm sleep / sell fish to Finn |

## XNA 4.0 layout

The loop is the classic XNA pattern in `HarvestHollowGame.cs`:

- `Initialize`
- `LoadContent` (textures created with `Texture2D.SetData`, the same runtime path XNA games used for procedural art)
- `Update(GameTime)` with `Keyboard.GetState` / `Mouse.GetState`
- `Draw` via `SpriteBatch.Begin` / `Draw` / `End`

If you still have Visual Studio 2010 + XNA Game Studio 4.0, the gameplay files are ordinary C# using `Microsoft.Xna.Framework.*`. You would retarget `HarvestHollow.csproj` to .NET Framework 4.0 and add the XNA 4.0 assemblies (`Microsoft.Xna.Framework`, `.Game`, `.Graphics`, `.Input`) instead of the MonoGame package.
