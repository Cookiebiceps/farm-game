using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// Farm livestock sprites: four facings, two walk frames. Left is a
    /// horizontal flip of the right-facing pose, same trick as the trolls.
    /// </summary>
    public static class Animals
    {
        public const int W = 40;
        public const int H = 28;

        static readonly Color Ink = new Color(58, 40, 28);
        static readonly Color White = new Color(244, 236, 220);
        static readonly Color Cream = new Color(236, 222, 196);
        static readonly Color Pink = new Color(232, 168, 168);
        static readonly Color PinkLo = new Color(196, 118, 118);

        public static Texture2D Sprite(GraphicsDevice gd, AnimalKind kind, int dir, int frame)
        {
            return Sprite(gd, kind, dir, frame, true);
        }

        public static Texture2D Sprite(GraphicsDevice gd, AnimalKind kind, int dir, int frame, bool woolly)
        {
            if (dir == 1)
                return FlipH(gd, Paint(kind, 2, frame, woolly));
            return Bake(gd, Paint(kind, dir, frame, woolly));
        }

        static Color[] Paint(AnimalKind kind, int dir, int frame)
        {
            return Paint(kind, dir, frame, true);
        }

        static Color[] Paint(AnimalKind kind, int dir, int frame, bool woolly)
        {
            if (kind == AnimalKind.Rabbit)
                return PaintRabbit(dir, frame);
            if (kind == AnimalKind.Sheep)
                return PaintSheep(dir, frame, woolly);
            if (kind == AnimalKind.Pig)
                return PaintPig(dir, frame);
            if (kind == AnimalKind.Cow)
                return PaintCow(dir, frame);
            if (kind == AnimalKind.Horse)
                return PaintHorse(dir, frame);
            return PaintChicken(dir, frame);
        }

        static Color[] PaintChicken(int dir, int frame)
        {
            Color[] d = Blank();
            int bob = frame == 1 ? 1 : 0;
            int step = frame;
            Color body = new Color(236, 226, 210);
            Color bodyLo = new Color(196, 176, 150);
            Color comb = new Color(196, 48, 48);
            Color combLo = new Color(148, 28, 32);
            Color beak = new Color(232, 176, 48);
            Color feet = new Color(214, 148, 40);
            bool back = dir == 3;
            if (dir == 2)
            {
                int y = 16 + bob;
                Oval(d, 16, y + 2, 8, 6, body, bodyLo, true);
                Oval(d, 24, y - 3, 5, 5, body, bodyLo, true);
                Rect(d, 8, y + 1, 5, 4, Mix(body, new Color(214, 92, 72), 35), bodyLo);
                Plot(d, 29, y - 4, comb);
                Plot(d, 28, y - 5, comb);
                Plot(d, 30, y - 5, combLo);
                Plot(d, 29, y - 6, comb);
                Rect(d, 28, y - 2, 4, 2, beak, Mix(beak, Ink, 25));
                Plot(d, 26, y - 4, White);
                Plot(d, 27, y - 4, Ink);
                Leg(d, 13, 22 + step, 3, 5, feet, Ink);
                Leg(d, 19, 22 + (1 - step), 3, 5, feet, Ink);
            }
            else
            {
                int y = 17 + bob;
                Oval(d, 20, y + 1, 7, 6, back ? bodyLo : body, bodyLo, true);
                Oval(d, 20, y - 5, 5, 5, back ? bodyLo : body, bodyLo, true);
                if (!back)
                {
                    Plot(d, 20, y - 9, comb);
                    Plot(d, 19, y - 8, comb);
                    Plot(d, 21, y - 8, combLo);
                    Plot(d, 20, y - 10, comb);
                    Rect(d, 19, y - 3, 3, 2, beak, Mix(beak, Ink, 20));
                    Plot(d, 18, y - 6, White);
                    Plot(d, 17, y - 6, Ink);
                    Plot(d, 22, y - 6, White);
                    Plot(d, 23, y - 6, Ink);
                    Plot(d, 20, y - 1, new Color(214, 86, 86));
                }
                else
                    Oval(d, 20, y - 8, 4, 3, Mix(body, new Color(214, 92, 72), 40), bodyLo, true);
                Leg(d, 16, 23 + step, 3, 4, feet, Ink);
                Leg(d, 22, 23 + (1 - step), 3, 4, feet, Ink);
            }
            return d;
        }

        static Color[] PaintRabbit(int dir, int frame)
        {
            Color[] d = Blank();
            int hop = frame == 1 ? -2 : 0;
            int step = frame;
            Color fur = new Color(186, 168, 148);
            Color furLo = new Color(132, 112, 96);
            Color earIn = new Color(232, 176, 186);
            Color tail = White;
            bool back = dir == 3;
            if (dir == 2)
            {
                int y = 17 + hop;
                Oval(d, 17, y + 2, 8, 6, fur, furLo, true);
                Oval(d, 25, y - 2, 5, 5, fur, furLo, true);
                Ear(d, 24, y - 12, 3, 9, fur, earIn, furLo);
                Ear(d, 28, y - 11, 3, 8, fur, earIn, furLo);
                Oval(d, 10, y + 3, 3, 3, tail, Mix(tail, Ink, 15), true);
                Plot(d, 28, y - 3, White);
                Plot(d, 29, y - 3, Ink);
                Plot(d, 30, y - 1, Pink);
                Leg(d, 13, 23 + step, 3, 4, furLo, Ink);
                Leg(d, 20, 23 + (1 - step), 4, 5, furLo, Ink);
            }
            else
            {
                int y = 17 + hop;
                Oval(d, 20, y + 2, 7, 6, back ? furLo : fur, furLo, true);
                Oval(d, 20, y - 3, 5, 5, back ? furLo : fur, furLo, true);
                Ear(d, 16, y - 13, 3, 10, fur, earIn, furLo);
                Ear(d, 22, y - 13, 3, 10, fur, earIn, furLo);
                if (!back)
                {
                    Plot(d, 18, y - 4, White);
                    Plot(d, 17, y - 4, Ink);
                    Plot(d, 22, y - 4, White);
                    Plot(d, 23, y - 4, Ink);
                    Plot(d, 20, y - 1, Pink);
                }
                else
                    Oval(d, 20, y + 6, 3, 3, tail, Mix(tail, Ink, 15), true);
                Leg(d, 16, 23 + step, 3, 4, furLo, Ink);
                Leg(d, 22, 23 + (1 - step), 3, 4, furLo, Ink);
            }
            return d;
        }

        static Color[] PaintSheep(int dir, int frame, bool woolly)
        {
            Color[] d = Blank();
            int step = frame;
            Color wool = woolly ? Cream : new Color(132, 118, 102);
            Color woolLo = woolly ? new Color(196, 180, 150) : new Color(92, 80, 68);
            Color face = new Color(48, 42, 40);
            Color faceHi = new Color(78, 70, 64);
            bool back = dir == 3;
            int bodyRx = woolly ? 11 : 8;
            int bodyRy = woolly ? 8 : 6;
            int bodyY = woolly ? 17 : 18;
            if (dir == 2)
            {
                Oval(d, 18, bodyY, bodyRx, bodyRy, wool, woolLo, true);
                if (woolly)
                {
                    WoolBump(d, 12, 12);
                    WoolBump(d, 20, 11);
                    WoolBump(d, 26, 14);
                }
                Oval(d, 29, 16, 5, 5, faceHi, face, true);
                Plot(d, 32, 15, White);
                Plot(d, 33, 15, new Color(232, 214, 80));
                Plot(d, 33, 17, Pink);
                Leg(d, 12, 23 + step, 3, 5, face, Ink);
                Leg(d, 18, 23 + (1 - step), 3, 5, face, Ink);
                Leg(d, 24, 23 + step, 3, 5, face, Ink);
            }
            else
            {
                Oval(d, 20, bodyY, woolly ? 10 : 7, bodyRy, back ? woolLo : wool, woolLo, true);
                if (woolly)
                {
                    WoolBump(d, 14, 12);
                    WoolBump(d, 20, 11);
                    WoolBump(d, 26, 12);
                }
                if (!back)
                {
                    Oval(d, 20, 14, 5, 5, faceHi, face, true);
                    Plot(d, 18, 13, White);
                    Plot(d, 17, 13, new Color(232, 214, 80));
                    Plot(d, 22, 13, White);
                    Plot(d, 23, 13, new Color(232, 214, 80));
                    Plot(d, 20, 16, Pink);
                }
                else
                    Oval(d, 20, 12, 4, 4, face, Mix(face, Ink, 20), true);
                Leg(d, 14, 23 + step, 3, 5, face, Ink);
                Leg(d, 24, 23 + (1 - step), 3, 5, face, Ink);
            }
            return d;
        }

        static Color[] PaintPig(int dir, int frame)
        {
            Color[] d = Blank();
            int step = frame;
            Color hide = Pink;
            Color hideLo = PinkLo;
            Color snout = new Color(214, 128, 128);
            bool back = dir == 3;
            if (dir == 2)
            {
                Oval(d, 18, 17, 10, 7, hide, hideLo, true);
                Oval(d, 28, 16, 5, 5, hide, hideLo, true);
                Rect(d, 32, 16, 4, 3, snout, Mix(snout, Ink, 20));
                Plot(d, 34, 17, Ink);
                Plot(d, 35, 17, Ink);
                Plot(d, 30, 14, White);
                Plot(d, 31, 14, Ink);
                Plot(d, 28, 12, hideLo);
                Plot(d, 29, 11, hide);
                Oval(d, 8, 16, 2, 3, hideLo, Mix(hideLo, Ink, 20), true);
                Leg(d, 12, 22 + step, 3, 5, hideLo, Ink);
                Leg(d, 18, 22 + (1 - step), 3, 5, hideLo, Ink);
                Leg(d, 24, 22 + step, 3, 5, hideLo, Ink);
            }
            else
            {
                Oval(d, 20, 17, 9, 7, back ? hideLo : hide, hideLo, true);
                if (!back)
                {
                    Oval(d, 20, 14, 6, 5, hide, hideLo, true);
                    Rect(d, 18, 16, 5, 3, snout, Mix(snout, Ink, 20));
                    Plot(d, 19, 17, Ink);
                    Plot(d, 21, 17, Ink);
                    Plot(d, 17, 13, White);
                    Plot(d, 16, 13, Ink);
                    Plot(d, 23, 13, White);
                    Plot(d, 24, 13, Ink);
                    Plot(d, 16, 11, hide);
                    Plot(d, 24, 11, hide);
                }
                else
                {
                    Oval(d, 20, 13, 5, 4, hideLo, Mix(hideLo, Ink, 15), true);
                    Oval(d, 20, 10, 2, 2, hide, hideLo, true);
                }
                Leg(d, 14, 22 + step, 3, 5, hideLo, Ink);
                Leg(d, 23, 22 + (1 - step), 3, 5, hideLo, Ink);
            }
            return d;
        }

        static Color[] PaintCow(int dir, int frame)
        {
            Color[] d = Blank();
            int step = frame;
            Color hide = new Color(236, 228, 210);
            Color hideLo = new Color(196, 180, 150);
            Color spot = new Color(118, 78, 48);
            Color nose = Pink;
            bool back = dir == 3;
            if (dir == 2)
            {
                Oval(d, 17, 16, 12, 8, hide, hideLo, true);
                Oval(d, 14, 14, 4, 3, spot, Mix(spot, Ink, 20), false);
                Oval(d, 22, 18, 3, 3, spot, Mix(spot, Ink, 20), false);
                Oval(d, 29, 14, 6, 6, hide, hideLo, true);
                Plot(d, 27, 10, Cream);
                Plot(d, 32, 10, Cream);
                Rect(d, 33, 15, 4, 3, nose, Mix(nose, Ink, 20));
                Plot(d, 35, 16, Ink);
                Plot(d, 32, 13, White);
                Plot(d, 33, 13, Ink);
                Oval(d, 16, 22, 3, 2, Pink, PinkLo, true);
                Leg(d, 10, 22 + step, 3, 6, spot, Ink);
                Leg(d, 16, 22 + (1 - step), 3, 6, hideLo, Ink);
                Leg(d, 22, 22 + step, 3, 6, spot, Ink);
            }
            else
            {
                Oval(d, 20, 16, 11, 8, back ? hideLo : hide, hideLo, true);
                Oval(d, 16, 14, 4, 3, spot, Mix(spot, Ink, 20), false);
                Oval(d, 24, 18, 3, 3, spot, Mix(spot, Ink, 20), false);
                if (!back)
                {
                    Oval(d, 20, 12, 6, 6, hide, hideLo, true);
                    Plot(d, 16, 8, Cream);
                    Plot(d, 24, 8, Cream);
                    Rect(d, 18, 14, 5, 3, nose, Mix(nose, Ink, 20));
                    Plot(d, 19, 15, Ink);
                    Plot(d, 21, 15, Ink);
                    Plot(d, 17, 11, White);
                    Plot(d, 16, 11, Ink);
                    Plot(d, 23, 11, White);
                    Plot(d, 24, 11, Ink);
                    Oval(d, 20, 22, 4, 2, Pink, PinkLo, true);
                }
                else
                {
                    Oval(d, 20, 11, 5, 5, hideLo, Mix(hideLo, Ink, 15), true);
                    Plot(d, 16, 8, Cream);
                    Plot(d, 24, 8, Cream);
                    Oval(d, 20, 8, 3, 2, spot, Mix(spot, Ink, 10), false);
                }
                Leg(d, 13, 22 + step, 3, 6, spot, Ink);
                Leg(d, 24, 22 + (1 - step), 3, 6, hideLo, Ink);
            }
            return d;
        }

        static Color[] PaintHorse(int dir, int frame)
        {
            Color[] d = Blank();
            int step = frame;
            Color hide = new Color(148, 92, 48);
            Color hideLo = new Color(108, 62, 32);
            Color mane = new Color(72, 44, 28);
            Color muzzle = new Color(214, 196, 168);
            bool back = dir == 3;
            if (dir == 2)
            {
                Oval(d, 16, 15, 12, 7, hide, hideLo, true);
                Rect(d, 26, 8, 5, 8, hide, hideLo);
                Oval(d, 32, 10, 5, 4, hide, hideLo, true);
                Rect(d, 35, 11, 4, 3, muzzle, Mix(muzzle, Ink, 20));
                Plot(d, 31, 8, White);
                Plot(d, 32, 8, Ink);
                for (int i = 0; i < 7; i++)
                    Plot(d, 26, 6 + i, mane);
                for (int i = 0; i < 5; i++)
                    Plot(d, 8 + i / 2, 12 + i, mane);
                Plot(d, 30, 6, hideLo);
                Leg(d, 10, 20 + step, 3, 8, hideLo, Ink);
                Leg(d, 16, 20 + (1 - step), 3, 8, Mix(hide, White, 10), Ink);
                Leg(d, 22, 20 + step, 3, 8, hideLo, Ink);
            }
            else
            {
                Oval(d, 20, 15, 10, 7, back ? hideLo : hide, hideLo, true);
                if (!back)
                {
                    Rect(d, 18, 6, 5, 8, hide, hideLo);
                    Oval(d, 20, 7, 5, 4, hide, hideLo, true);
                    Rect(d, 18, 9, 5, 3, muzzle, Mix(muzzle, Ink, 20));
                    Plot(d, 17, 6, White);
                    Plot(d, 16, 6, Ink);
                    Plot(d, 23, 6, White);
                    Plot(d, 24, 6, Ink);
                    for (int i = 0; i < 6; i++)
                    {
                        Plot(d, 16, 4 + i, mane);
                        Plot(d, 24, 4 + i, mane);
                    }
                }
                else
                {
                    Oval(d, 20, 8, 5, 5, hideLo, Mix(hideLo, Ink, 15), true);
                    for (int i = 0; i < 8; i++)
                        Plot(d, 20, 4 + i, mane);
                    for (int i = 0; i < 6; i++)
                        Plot(d, 20, 18 + i, mane);
                }
                Leg(d, 14, 20 + step, 3, 8, hideLo, Ink);
                Leg(d, 24, 20 + (1 - step), 3, 8, Mix(hide, White, 8), Ink);
            }
            return d;
        }

        static void Ear(Color[] d, int x, int y, int w, int h, Color fur, Color inner, Color shade)
        {
            Rect(d, x, y, w, h, fur, shade);
            if (w >= 3 && h >= 4)
                Rect(d, x + 1, y + 2, Math.Max(1, w - 2), h - 4, inner, Mix(inner, Ink, 20));
        }

        static void WoolBump(Color[] d, int cx, int cy)
        {
            Oval(d, cx, cy, 4, 3, Mix(Cream, White, 20), new Color(196, 180, 150), true);
        }

        static void Leg(Color[] d, int x, int y, int w, int h, Color fill, Color shade)
        {
            Rect(d, x, y, w, h, fill, shade);
        }

        static Color[] Blank()
        {
            return new Color[W * H];
        }

        static void Oval(Color[] d, int cx, int cy, int rx, int ry, Color fill, Color shade, bool outline)
        {
            int rx2 = rx * rx;
            int ry2 = ry * ry;
            int rr = rx2 * ry2;
            for (int y = cy - ry; y <= cy + ry; y++)
            {
                for (int x = cx - rx; x <= cx + rx; x++)
                {
                    int dx = x - cx;
                    int dy = y - cy;
                    int v = dx * dx * ry2 + dy * dy * rx2;
                    if (v > rr)
                        continue;
                    Color c = fill;
                    if (dx + dy < -2)
                        c = Mix(fill, White, 28);
                    else if (dx + dy > 3)
                        c = shade;
                    if (outline && v > rr - Math.Max(rx, ry) * Math.Max(rx2, ry2) / 6)
                        c = Ink;
                    Plot(d, x, y, c);
                }
            }
        }

        static void Rect(Color[] d, int x0, int y0, int bw, int bh, Color fill, Color shade)
        {
            for (int y = 0; y < bh; y++)
            {
                for (int x = 0; x < bw; x++)
                {
                    Color c = x < 2 ? Mix(fill, White, 20) : x > bw - 3 ? shade : fill;
                    if (x == 0 || y == 0 || x == bw - 1 || y == bh - 1)
                        c = Ink;
                    Plot(d, x0 + x, y0 + y, c);
                }
            }
        }

        static void Plot(Color[] d, int x, int y, Color c)
        {
            if (x < 0 || y < 0 || x >= W || y >= H)
                return;
            d[y * W + x] = c;
        }

        static Color Mix(Color a, Color b, int bAmt)
        {
            int ia = 100 - bAmt;
            return new Color((a.R * ia + b.R * bAmt) / 100, (a.G * ia + b.G * bAmt) / 100, (a.B * ia + b.B * bAmt) / 100);
        }

        static Texture2D Bake(GraphicsDevice gd, Color[] data)
        {
            return TileGen.Scale2(gd, data, W, H);
        }

        static Texture2D FlipH(GraphicsDevice gd, Color[] src)
        {
            Color[] dst = new Color[W * H];
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                    dst[y * W + x] = src[y * W + (W - 1 - x)];
            }
            return Bake(gd, dst);
        }
    }
}
