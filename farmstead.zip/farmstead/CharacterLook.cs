using System.IO;

namespace HarvestHollow
{
    public struct FarmerLook
    {
        public const int BodyCount = 2;
        public const int FaceCount = 6;
        public const int HairCount = 6;
        public const int ClothesCount = 6;
        public const int HatCount = 6;
        public const int GlassesCount = 5;

        public int Body;
        public int Face;
        public int Hair;
        public int Clothes;
        public int Hat;
        public int Glasses;

        public static FarmerLook Classic
        {
            get
            {
                FarmerLook l = new FarmerLook();
                l.Body = 1;
                l.Hat = 1;
                return l;
            }
        }

        public bool Girl { get { return Body == 0; } }

        public void Clamp()
        {
            Body = Wrap(Body, BodyCount);
            Face = Wrap(Face, FaceCount);
            Hair = Wrap(Hair, HairCount);
            Clothes = Wrap(Clothes, ClothesCount);
            Hat = Wrap(Hat, HatCount);
            Glasses = Wrap(Glasses, GlassesCount);
        }

        public void Cycle(int part, int delta)
        {
            if (part == 0) Body += delta;
            else if (part == 1) Face += delta;
            else if (part == 2) Hair += delta;
            else if (part == 3) Clothes += delta;
            else if (part == 4) Hat += delta;
            else if (part == 5) Glasses += delta;
            Clamp();
        }

        public int Packed
        {
            get
            {
                Clamp();
                return Body
                    + Face * BodyCount
                    + Hair * BodyCount * FaceCount
                    + Clothes * BodyCount * FaceCount * HairCount
                    + Hat * BodyCount * FaceCount * HairCount * ClothesCount
                    + Glasses * BodyCount * FaceCount * HairCount * ClothesCount * HatCount;
            }
        }

        public void Write(BinaryWriter w)
        {
            Clamp();
            w.Write((byte)Body);
            w.Write((byte)Face);
            w.Write((byte)Hair);
            w.Write((byte)Clothes);
            w.Write((byte)Hat);
            w.Write((byte)Glasses);
        }

        public static FarmerLook ReadFrom(BinaryReader r)
        {
            FarmerLook l = new FarmerLook();
            l.Body = r.ReadByte();
            l.Face = r.ReadByte();
            l.Hair = r.ReadByte();
            l.Clothes = r.ReadByte();
            l.Hat = r.ReadByte();
            l.Glasses = r.ReadByte();
            l.Clamp();
            return l;
        }

        public static string PartName(int part)
        {
            if (part == 0) return "BODY";
            if (part == 1) return "FACE";
            if (part == 2) return "HAIR";
            if (part == 3) return "CLOTHES";
            if (part == 4) return "HAT";
            if (part == 5) return "GLASSES";
            return "";
        }

        public string PartValue(int part)
        {
            Clamp();
            if (part == 0) return Body == 0 ? "Girl" : "Boy";
            if (part == 1) return Faces[Face];
            if (part == 2) return Hairs[Hair];
            if (part == 3) return Outfits[Clothes];
            if (part == 4) return Hats[Hat];
            if (part == 5) return Specs[Glasses];
            return "";
        }

        public static readonly string[] Faces =
        {
            "Soft", "Blush", "Keen", "Sleepy", "Grin", "Freckles"
        };
        public static readonly string[] Hairs =
        {
            "Short brown", "Long black", "Auburn bob", "Blonde bun", "Silver waves", "Copper crop"
        };
        public static readonly string[] Outfits =
        {
            "Overalls", "Denim jacket", "Red flannel", "Sky work shirt", "Rose dress", "Forest poncho"
        };
        public static readonly string[] Hats =
        {
            "None", "Straw brim", "Wool beanie", "Trail hat", "Newsboy cap", "Flower clip"
        };
        public static readonly string[] Specs =
        {
            "None", "Round frames", "Square frames", "Sunglasses", "Half-rim"
        };

        static int Wrap(int v, int n)
        {
            if (n <= 0) return 0;
            v %= n;
            if (v < 0) v += n;
            return v;
        }
    }
}
