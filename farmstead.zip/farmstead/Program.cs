using System;

namespace HarvestHollow
{
    /// <summary>
    /// XNA 4.0-style entry point. MonoGame implements the Microsoft.Xna.Framework APIs.
    /// </summary>
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            if (args != null && args.Length > 0 && args[0] == "--export-theme")
            {
                string path = args.Length > 1 ? args[1] : "HarvestHollowTheme.wav";
                PianoTheme.WriteWav(path);
                Console.WriteLine("Wrote " + path);
                return;
            }
            if (args != null && args.Length > 0 && args[0] == "--export-drops")
            {
                string dir = args.Length > 1 ? args[1] : "/tmp/hh-drops";
                TileGen.WriteMountainPreview(dir);
                Console.WriteLine("Wrote " + dir);
                return;
            }
            if (args != null && args.Length > 0 && args[0] == "--export-water")
            {
                string dir = args.Length > 1 ? args[1] : "/tmp/hh-water";
                TileGen.WriteWaterPreview(dir);
                Console.WriteLine("Wrote " + dir);
                return;
            }
            if (args != null && args.Length > 0 && args[0] == "--export-houses")
            {
                string dir = args.Length > 1 ? args[1] : "/tmp/hh-houses";
                TileGen.WriteCottagePreview(dir);
                Console.WriteLine("Wrote " + dir);
                return;
            }
            if (args != null && args.Length > 0 && args[0] == "--self-test-save")
            {
                Environment.Exit(SaveRoundtrip.Run() ? 0 : 1);
                return;
            }
            using (HarvestHollowGame game = new HarvestHollowGame())
            {
                game.Run();
            }
        }
    }
}
