namespace HarvestHollow
{
    /// <summary>
    /// Decorative waymarker beside a zone mouth. Dir matches the farmer: 0 down, 1 left, 2 right, 3 up.
    /// </summary>
    public sealed class Deco
    {
        public int X;
        public int Y;
        public int Kind;
    }

    public static class DecoKind
    {
        public const int Barrel = 0;
        public const int Crate = 1;
        public const int Picnic = 2;
        public const int Bush = 3;
        public const int FishCrate = 4;
        public const int FishRack = 5;
        public const int Shark = 6;
        public const int Sack = 7;
        public const int Rowboat = 8;
        public const int SailBlue = 9;
        public const int SailBrown = 10;
        public const int LogSlice = 11;
    }

    public sealed class GateSign
    {
        public int X;
        public int Y;
        public string Dest;
        public int Dir;
    }
}
