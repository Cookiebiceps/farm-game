using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HarvestHollow
{
    /// <summary>
    /// High-resolution 3/4 character sprites. Feet sit on the last row;
    /// world draw is 1:1 so they read about two tiles tall.
    /// </summary>
    public static class Characters
    {
        public const int W = 32;
        public const int H = 48;

        static readonly Color Ink = new Color(58, 40, 28);
        static readonly Color Skin = new Color(232, 190, 152);
        static readonly Color SkinHi = new Color(244, 214, 178);
        static readonly Color SkinLo = new Color(196, 142, 108);
        static readonly Color Straw = new Color(214, 176, 72);
        static readonly Color StrawHi = new Color(236, 206, 112);
        static readonly Color StrawLo = new Color(168, 128, 42);
        static readonly Color Hair = new Color(108, 68, 40);
        static readonly Color HairLo = new Color(72, 44, 28);
        static readonly Color Shirt = new Color(224, 214, 196);
        static readonly Color ShirtLo = new Color(184, 172, 154);
        static readonly Color Overall = new Color(78, 108, 72);
        static readonly Color OverallHi = new Color(108, 138, 88);
        static readonly Color OverallLo = new Color(52, 78, 50);
        static readonly Color Boot = new Color(82, 52, 34);
        static readonly Color BootHi = new Color(118, 76, 48);
        static readonly Color White = new Color(240, 232, 216);

        public const int PoseIdle = 0;
        public const int PoseWalk0 = 1;
        public const int PoseWalk1 = 2;
        public const int PoseWalk2 = 3;
        public const int PoseWalk3 = 4;
        public const int PoseSwingUp = 5;
        public const int PoseSwingHit = 6;
        public const int PoseCount = 7;

        public static int Pose(bool moving, float anim, bool swinging, float swingU)
        {
            if (swinging)
                return swingU < 0.38f ? PoseSwingUp : PoseSwingHit;
            if (!moving)
                return PoseIdle;
            return PoseWalk0 + (((int)(anim * 10f)) & 3);
        }

        public static Texture2D Farmer(GraphicsDevice gd, int dir, int frame)
        {
            return Farmer(gd, dir, frame, FarmerLook.Classic);
        }

        public static Texture2D Farmer(GraphicsDevice gd, int dir, int frame, FarmerLook look)
        {
            look.Clamp();
            if (dir == 1)
                return FlipH(gd, PaintFarmer(2, frame, look));
            return Bake(gd, PaintFarmer(dir, frame, look));
        }

        public static Texture2D Mira(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(0));
        }

        public static Texture2D Cob(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(1));
        }

        public static Texture2D Rowan(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(2));
        }

        public static Texture2D Finn(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(3));
        }

        public static Texture2D Piper(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(4));
        }

        public static Texture2D Lila(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(5));
        }

        public static Texture2D Bram(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(6));
        }

        public static Texture2D Nell(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(7));
        }

        public static Texture2D Ash(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(8));
        }

        public static Texture2D Bess(GraphicsDevice gd)
        {
            return Bake(gd, PaintVillager(9));
        }

        public static Texture2D Troll(GraphicsDevice gd, int dir, int frame)
        {
            return CaveMob(gd, (int)CaveMobKind.Troll, dir, frame);
        }

        public static Texture2D CaveMob(GraphicsDevice gd, int kind, int dir, int frame)
        {
            kind = CaveMobCatalog.Clamp(kind);
            if (dir == 1)
            {
                if (kind == (int)CaveMobKind.Troll)
                    return FlipH(gd, PaintTroll(2, frame));
                if (kind == (int)CaveMobKind.Bat)
                    return FlipH(gd, PaintBat(2, frame));
                if (kind == (int)CaveMobKind.Slime)
                    return FlipH(gd, PaintSlime(2, frame));
                return FlipH(gd, PaintSpider(2, frame));
            }
            if (kind == (int)CaveMobKind.Troll)
                return Bake(gd, PaintTroll(dir, frame));
            if (kind == (int)CaveMobKind.Bat)
                return Bake(gd, PaintBat(dir, frame));
            if (kind == (int)CaveMobKind.Slime)
                return Bake(gd, PaintSlime(dir, frame));
            return Bake(gd, PaintSpider(dir, frame));
        }

        public static Texture2D GroundShadow(GraphicsDevice gd)
        {
            int tw = 28;
            int th = 10;
            Color[] d = new Color[tw * th];
            Color s = new Color(32, 38, 36, 88);
            for (int y = 0; y < th; y++)
            {
                for (int x = 0; x < tw; x++)
                {
                    int dx = x - 14;
                    int dy = y - 5;
                    if (dx * dx + dy * dy * 8 < 120)
                        d[y * tw + x] = s;
                }
            }
            return TileGen.Scale2(gd, d, tw, th);
        }

        static Color[] PaintFarmer(int dir, int frame, FarmerLook look)
        {
            Color[] d = new Color[W * H];
            if (frame < 0)
                frame = 0;
            if (frame >= PoseCount)
                frame = PoseIdle;
            int cx = 16;
            bool girl = look.Girl;
            Color shirt, shirtLo, pant, pantHi, pantLo, hair, hairLo, accent;
            OutfitColors(look.Clothes, out shirt, out shirtLo, out pant, out pantHi, out pantLo, out accent);
            HairColors(look.Hair, out hair, out hairLo);
            int torsoW = girl ? 7 : 8;
            int hipW = girl ? 9 : 8;
            int lean = 0;
            if (frame == PoseSwingUp)
                lean = dir == 2 ? -1 : (dir == 0 ? 0 : 0);
            if (frame == PoseSwingHit)
                lean = dir == 2 ? 1 : 0;
            cx += lean;

            if (dir == 3)
            {
                Oval(d, cx, 28, torsoW, 9, shirt, shirtLo, true);
                PaintTorso(d, cx, true, girl, look.Clothes, shirt, shirtLo, pant, pantHi, pantLo, accent);
                DrawLegs(d, cx, frame, true, false, pant, pantLo);
                DrawArmsBack(d, cx, frame, shirt, shirtLo);
                PaintHair(d, cx, 14, look.Hair, 3, hair, hairLo, girl);
                PaintHat(d, cx, look.Hat, 3, false, hair, accent);
                return d;
            }

            DrawLegs(d, cx, frame, false, dir == 2, pant, pantLo);
            Oval(d, cx, 28, hipW, girl ? 11 : 10, pant, pantLo, true);
            PaintTorso(d, cx, false, girl, look.Clothes, shirt, shirtLo, pant, pantHi, pantLo, accent);
            if (girl && look.Clothes != 5)
                Oval(d, cx, 34, 9, 6, pant, pantLo, false);

            int laY, raY, laX, raX;
            bool hideTool;
            ArmPose(frame, dir == 0, out laX, out laY, out raX, out raY, out hideTool);

            if (dir == 0)
            {
                DrawArm(d, (girl ? 8 : 7) + laX, 22 + laY, false, shirt, shirtLo);
                if (!hideTool)
                    DrawArm(d, (girl ? 21 : 22) + raX, 22 + raY, true, shirt, shirtLo);
                PaintHair(d, cx, 14, look.Hair, 0, hair, hairLo, girl);
                Oval(d, cx, 16, 6, 7, Skin, SkinLo, true);
                PaintFaceFront(d, cx, 16, look.Face);
                PaintHat(d, cx, look.Hat, 0, true, hair, accent);
                PaintGlasses(d, cx, 16, 0, look.Glasses);
            }
            else
            {
                if (!hideTool)
                    DrawArm(d, 21 + raX, 22 + raY, true, shirt, shirtLo);
                PaintHair(d, cx + 1, 14, look.Hair, 2, hair, hairLo, girl);
                Oval(d, cx + 2, 16, 5, 7, Skin, SkinLo, true);
                PaintFaceSide(d, cx + 3, 16, look.Face);
                PaintHat(d, cx + 1, look.Hat, 2, true, hair, accent);
                PaintGlasses(d, cx + 3, 16, 2, look.Glasses);
                DrawArm(d, 8 + laX, 23 + laY, false, shirt, shirtLo);
            }
            return d;
        }

        static void ArmPose(int pose, bool faceDown, out int laX, out int laY, out int raX, out int raY, out bool hideTool)
        {
            laX = 0;
            raX = 0;
            laY = 0;
            raY = 0;
            hideTool = false;
            if (pose == PoseWalk0)
            {
                laY = 3;
                raY = -2;
            }
            else if (pose == PoseWalk1)
            {
                laY = 1;
                raY = 1;
            }
            else if (pose == PoseWalk2)
            {
                laY = -2;
                raY = 3;
            }
            else if (pose == PoseWalk3)
            {
                laY = 0;
                raY = 0;
            }
            else if (pose == PoseSwingUp)
            {
                hideTool = true;
                laY = 2;
                raY = -8;
                raX = faceDown ? 1 : 2;
                laX = faceDown ? -1 : -1;
            }
            else if (pose == PoseSwingHit)
            {
                hideTool = true;
                laY = 1;
                raY = 4;
                raX = faceDown ? 2 : 3;
                laX = -1;
            }
            if (faceDown && hideTool)
                hideTool = true;
        }

        static void OutfitColors(int clothes, out Color shirt, out Color shirtLo, out Color pant, out Color pantHi, out Color pantLo, out Color accent)
        {
            if (clothes == 1)
            {
                shirt = new Color(72, 108, 156);
                shirtLo = new Color(42, 68, 108);
                pant = new Color(176, 148, 98);
                pantHi = new Color(204, 176, 124);
                pantLo = new Color(124, 98, 62);
                accent = new Color(232, 196, 92);
            }
            else if (clothes == 2)
            {
                shirt = new Color(176, 64, 52);
                shirtLo = new Color(124, 40, 36);
                pant = new Color(72, 58, 48);
                pantHi = new Color(98, 78, 62);
                pantLo = new Color(48, 38, 32);
                accent = new Color(214, 186, 124);
            }
            else if (clothes == 3)
            {
                shirt = new Color(118, 176, 214);
                shirtLo = new Color(72, 124, 168);
                pant = new Color(48, 62, 98);
                pantHi = new Color(72, 88, 128);
                pantLo = new Color(32, 42, 68);
                accent = new Color(244, 232, 210);
            }
            else if (clothes == 4)
            {
                shirt = new Color(214, 168, 176);
                shirtLo = new Color(168, 112, 124);
                pant = new Color(196, 92, 108);
                pantHi = new Color(224, 148, 158);
                pantLo = new Color(148, 58, 72);
                accent = new Color(244, 232, 214);
            }
            else if (clothes == 5)
            {
                shirt = new Color(62, 98, 72);
                shirtLo = new Color(36, 68, 48);
                pant = new Color(48, 52, 46);
                pantHi = new Color(72, 78, 68);
                pantLo = new Color(32, 36, 30);
                accent = new Color(176, 148, 72);
            }
            else
            {
                shirt = Shirt;
                shirtLo = ShirtLo;
                pant = Overall;
                pantHi = OverallHi;
                pantLo = OverallLo;
                accent = new Color(214, 186, 92);
            }
        }

        static void HairColors(int hair, out Color fill, out Color shade)
        {
            if (hair == 1) { fill = new Color(32, 28, 28); shade = new Color(18, 16, 16); }
            else if (hair == 2) { fill = new Color(148, 64, 42); shade = new Color(102, 40, 28); }
            else if (hair == 3) { fill = new Color(228, 196, 112); shade = new Color(176, 140, 64); }
            else if (hair == 4) { fill = new Color(176, 180, 188); shade = new Color(120, 124, 132); }
            else if (hair == 5) { fill = new Color(186, 86, 48); shade = new Color(132, 52, 32); }
            else { fill = Hair; shade = HairLo; }
        }

        static void PaintTorso(Color[] d, int cx, bool back, bool girl, int clothes, Color shirt, Color shirtLo, Color pant, Color pantHi, Color pantLo, Color accent)
        {
            int y = back ? 26 : 22;
            if (clothes == 0)
            {
                Rect(d, 10, y, 12, 8, pantHi, pantLo);
                if (!back)
                {
                    Plot(d, 12, 24, accent);
                    Plot(d, 13, 25, accent);
                    Rect(d, 11, 20, 10, 5, shirt, shirtLo);
                    HLine(d, 12, 21, 8, pantLo);
                    HLine(d, 13, 22, 2, pant);
                    HLine(d, 17, 22, 2, pant);
                }
                else
                    Rect(d, 9, 26, 14, 10, pant, pantLo);
            }
            else if (clothes == 1)
            {
                Rect(d, 9, y - 1, 14, 12, shirt, shirtLo);
                if (!back)
                    HLine(d, 11, 26, 10, accent);
            }
            else if (clothes == 2)
            {
                Rect(d, 10, y, 12, 10, shirt, shirtLo);
                HLine(d, 11, y + 2, 10, Mix(shirt, Ink, 25));
                HLine(d, 11, y + 4, 10, Mix(shirt, White, 18));
            }
            else if (clothes == 3)
            {
                Rect(d, 10, y, 12, 9, shirt, shirtLo);
                if (!back)
                {
                    HLine(d, 14, 22, 4, accent);
                    Plot(d, 16, 24, accent);
                }
            }
            else if (clothes == 4)
            {
                Oval(d, cx, 30, girl ? 10 : 9, 12, pant, pantLo, true);
                Rect(d, 11, 20, 10, 6, shirt, shirtLo);
                if (!back)
                    HLine(d, 12, 24, 8, accent);
            }
            else
            {
                Oval(d, cx, 28, 11, 12, shirt, shirtLo, true);
                HLine(d, 8, 24, 16, accent);
                Rect(d, 12, 20, 8, 4, Mix(shirt, White, 20), shirtLo);
            }
        }

        static void PaintHair(Color[] d, int cx, int cy, int style, int dir, Color hair, Color hairLo, bool girl)
        {
            if (dir == 3)
            {
                Oval(d, cx, cy, 8, 8, hair, hairLo, true);
                if (style == 1 || style == 4)
                {
                    Oval(d, cx - 6, 22, 3, 8, hair, hairLo, true);
                    Oval(d, cx + 6, 22, 3, 8, hair, hairLo, true);
                }
                if (style == 3)
                    Oval(d, cx, 8, 4, 4, hair, hairLo, true);
                return;
            }
            if (style == 1)
            {
                Oval(d, cx, cy, 8, 9, hair, hairLo, true);
                Oval(d, cx - 7, 20, 3, 9, hair, hairLo, true);
                Oval(d, cx + 7, 20, 3, 9, hair, hairLo, true);
            }
            else if (style == 2)
            {
                Oval(d, cx, cy + 1, 8, 8, hair, hairLo, true);
                Oval(d, cx - 6, 18, 3, 6, hair, hairLo, true);
                Oval(d, cx + 6, 18, 3, 6, hair, hairLo, true);
            }
            else if (style == 3)
            {
                Oval(d, cx, cy, 7, 8, hair, hairLo, true);
                Oval(d, cx, 8, 4, 4, Mix(hair, White, 18), hairLo, true);
            }
            else if (style == 4)
            {
                Oval(d, cx, cy, 8, 8, hair, hairLo, true);
                Oval(d, cx - 8, 18, 4, 8, hair, hairLo, true);
                Oval(d, cx + 8, 18, 4, 8, hair, hairLo, true);
                HLine(d, cx - 4, 22, 8, hairLo);
            }
            else if (style == 5)
            {
                Oval(d, cx, cy, 6, 6, hair, hairLo, true);
            }
            else
            {
                Oval(d, cx, cy, girl ? 8 : 7, 8, hair, hairLo, true);
            }
        }

        static void PaintFaceFront(Color[] d, int cx, int cy, int face)
        {
            Plot(d, cx - 4, cy - 2, White);
            Plot(d, cx - 3, cy - 2, White);
            Plot(d, cx + 2, cy - 2, White);
            Plot(d, cx + 3, cy - 2, White);
            Plot(d, cx - 3, cy - 1, Ink);
            Plot(d, cx - 2, cy - 1, Ink);
            Plot(d, cx + 2, cy - 1, Ink);
            Plot(d, cx + 3, cy - 1, Ink);
            if (face == 2)
            {
                HLine(d, cx - 5, cy - 3, 4, Ink);
                HLine(d, cx + 2, cy - 3, 4, Ink);
            }
            if (face == 3)
            {
                HLine(d, cx - 4, cy - 1, 3, SkinLo);
                HLine(d, cx + 2, cy - 1, 3, SkinLo);
                Plot(d, cx - 3, cy - 1, Ink);
                Plot(d, cx + 3, cy - 1, Ink);
            }
            Plot(d, cx - 4, cy, SkinLo);
            Plot(d, cx + 4, cy, SkinLo);
            Plot(d, cx, cy + 1, SkinHi);
            if (face == 1)
            {
                Plot(d, cx - 5, cy + 1, new Color(232, 148, 140));
                Plot(d, cx - 4, cy + 2, new Color(232, 148, 140));
                Plot(d, cx + 5, cy + 1, new Color(232, 148, 140));
                Plot(d, cx + 4, cy + 2, new Color(232, 148, 140));
            }
            if (face == 4)
            {
                HLine(d, cx - 3, cy + 3, 7, Ink);
                Plot(d, cx - 3, cy + 2, SkinLo);
                Plot(d, cx + 3, cy + 2, SkinLo);
                Plot(d, cx, cy + 4, White);
            }
            else
            {
                Plot(d, cx, cy + 3, SkinLo);
                Plot(d, cx - 1, cy + 3, SkinLo);
                Plot(d, cx + 1, cy + 3, SkinLo);
            }
            if (face == 5)
            {
                Plot(d, cx - 5, cy + 2, Mix(SkinLo, Ink, 40));
                Plot(d, cx + 5, cy + 2, Mix(SkinLo, Ink, 40));
                Plot(d, cx - 3, cy + 4, Mix(SkinLo, Ink, 35));
                Plot(d, cx + 2, cy + 5, Mix(SkinLo, Ink, 35));
                Plot(d, cx, cy + 5, Mix(SkinLo, Ink, 30));
            }
        }

        static void PaintFaceSide(Color[] d, int cx, int cy, int face)
        {
            Plot(d, cx + 1, cy - 1, White);
            Plot(d, cx + 2, cy - 1, Ink);
            Plot(d, cx + 3, cy, SkinHi);
            Plot(d, cx + 2, cy + 2, SkinLo);
            if (face == 1)
                Plot(d, cx + 3, cy + 1, new Color(232, 148, 140));
            if (face == 4)
                HLine(d, cx, cy + 3, 3, Ink);
            else
                Plot(d, cx, cy + 3, SkinLo);
            if (face == 5)
            {
                Plot(d, cx + 1, cy + 2, Mix(SkinLo, Ink, 30));
                Plot(d, cx, cy + 4, Mix(SkinLo, Ink, 25));
            }
            if (face == 2)
                HLine(d, cx, cy - 2, 3, Ink);
        }

        static void PaintGlasses(Color[] d, int cx, int cy, int dir, int g)
        {
            if (g == 0)
                return;
            Color rim = g == 3 ? new Color(28, 26, 24) : new Color(36, 40, 52);
            Color lens = g == 3 ? new Color(42, 48, 62) : new Color(140, 186, 214);
            if (g == 4)
                lens = new Color(186, 208, 224);
            if (dir == 0)
            {
                if (g == 2 || g == 3)
                {
                    Rect(d, cx - 6, cy - 3, 5, 4, lens, rim);
                    Rect(d, cx + 1, cy - 3, 5, 4, lens, rim);
                }
                else
                {
                    Oval(d, cx - 4, cy - 1, 4, 3, lens, rim, true);
                    Oval(d, cx + 4, cy - 1, 4, 3, lens, rim, true);
                }
                HLine(d, cx - 1, cy - 1, 3, rim);
                if (g == 4)
                {
                    Plot(d, cx - 4, cy + 1, Skin);
                    Plot(d, cx + 4, cy + 1, Skin);
                }
            }
            else
            {
                if (g == 2)
                    Rect(d, cx, cy - 2, 4, 3, lens, rim);
                else
                    Oval(d, cx + 1, cy - 1, 3, 2, lens, rim, true);
            }
        }

        static void PaintHat(Color[] d, int cx, int hat, int dir, bool showFace, Color hair, Color accent)
        {
            if (hat == 0)
                return;
            int brimY = showFace ? 6 : 8;
            if (dir == 3)
                brimY = 9;
            if (hat == 1)
                StrawHat(d, cx, brimY, showFace);
            else if (hat == 2)
            {
                Color wool = new Color(72, 86, 118);
                Color woolLo = new Color(44, 54, 82);
                Oval(d, cx, brimY, 9, 6, wool, woolLo, true);
                Rect(d, cx - 8, brimY + 2, 16, 4, wool, woolLo);
                HLine(d, cx - 4, brimY + 5, 8, accent);
            }
            else if (hat == 3)
            {
                Color felt = new Color(92, 64, 42);
                Color feltLo = new Color(62, 42, 28);
                Oval(d, cx, brimY + 3, 13, 4, felt, feltLo, true);
                Oval(d, cx, brimY - 1, 7, 5, Mix(felt, White, 18), feltLo, true);
                HLine(d, cx - 12, brimY + 4, 24, feltLo);
            }
            else if (hat == 4)
            {
                Color cap = new Color(86, 48, 36);
                Rect(d, cx - 8, brimY, 16, 5, cap, Ink);
                Oval(d, cx - (showFace ? 2 : 0), brimY + 1, 8, 4, Mix(cap, White, 15), cap, true);
                HLine(d, cx - 8, brimY + 5, 10, Mix(cap, White, 20));
            }
            else
            {
                Oval(d, cx + 7, 10, 3, 3, new Color(214, 92, 118), new Color(148, 48, 72), true);
                Plot(d, cx + 7, 10, new Color(244, 214, 140));
                Oval(d, cx + 5, 12, 2, 3, hair, Mix(hair, Ink, 20), false);
            }
        }

        static Color[] PaintVillager(int who)
        {
            Color[] d = new Color[W * H];
            int cx = 16;
            Color dress, dressLo, hair, hairLo, accent;
            if (who == 0)
            {
                dress = new Color(196, 92, 86);
                dressLo = new Color(148, 56, 54);
                hair = new Color(186, 92, 48);
                hairLo = new Color(132, 58, 32);
                accent = new Color(244, 232, 210);
            }
            else if (who == 1)
            {
                dress = new Color(72, 86, 118);
                dressLo = new Color(44, 54, 82);
                hair = new Color(168, 160, 148);
                hairLo = new Color(112, 104, 96);
                accent = new Color(92, 64, 42);
            }
            else if (who == 3)
            {
                dress = new Color(214, 176, 48);
                dressLo = new Color(156, 118, 28);
                hair = new Color(72, 58, 48);
                hairLo = new Color(48, 38, 32);
                accent = new Color(48, 86, 118);
            }
            else if (who == 4)
            {
                dress = new Color(148, 72, 48);
                dressLo = new Color(108, 48, 32);
                hair = new Color(214, 186, 92);
                hairLo = new Color(168, 132, 48);
                accent = new Color(232, 212, 168);
            }
            else if (who == 5)
            {
                dress = new Color(214, 168, 176);
                dressLo = new Color(168, 112, 124);
                hair = new Color(92, 48, 36);
                hairLo = new Color(62, 32, 24);
                accent = new Color(244, 232, 214);
            }
            else if (who == 6)
            {
                dress = new Color(92, 78, 62);
                dressLo = new Color(62, 52, 40);
                hair = new Color(48, 40, 36);
                hairLo = new Color(32, 26, 24);
                accent = new Color(176, 92, 48);
            }
            else if (who == 7)
            {
                dress = new Color(88, 128, 78);
                dressLo = new Color(58, 92, 52);
                hair = new Color(196, 148, 72);
                hairLo = new Color(148, 102, 48);
                accent = new Color(214, 96, 118);
            }
            else if (who == 8)
            {
                dress = new Color(138, 92, 54);
                dressLo = new Color(96, 62, 36);
                hair = new Color(72, 48, 32);
                hairLo = new Color(48, 32, 22);
                accent = new Color(214, 186, 124);
            }
            else if (who == 9)
            {
                dress = new Color(168, 108, 62);
                dressLo = new Color(118, 72, 40);
                hair = new Color(186, 124, 62);
                hairLo = new Color(132, 82, 40);
                accent = new Color(232, 214, 168);
            }
            else
            {
                dress = new Color(62, 118, 78);
                dressLo = new Color(36, 82, 52);
                hair = new Color(92, 56, 34);
                hairLo = new Color(58, 34, 22);
                accent = new Color(214, 168, 78);
            }

            DrawLegs(d, cx, 0, false);
            Oval(d, cx, 30, 9, 12, dress, dressLo, true);
            Rect(d, 10, 22, 12, 8, Mix(dress, White, 30), dressLo);
            if (who == 0)
            {
                Rect(d, 12, 26, 8, 10, accent, Mix(accent, Ink, 25));
                HLine(d, 12, 30, 8, dressLo);
            }
            else if (who == 1)
            {
                Rect(d, 11, 22, 10, 4, accent, Mix(accent, Ink, 20));
                Oval(d, cx, 20, 5, 4, hair, hairLo, false);
            }
            else if (who == 3)
            {
                Rect(d, 10, 22, 12, 10, Mix(dress, White, 20), dressLo);
                HLine(d, 10, 28, 12, accent);
                HLine(d, 11, 29, 10, Mix(accent, Ink, 20));
            }
            else if (who == 4)
            {
                Rect(d, 10, 22, 12, 12, accent, Mix(accent, Ink, 20));
                HLine(d, 10, 30, 12, dressLo);
            }
            else if (who == 5)
            {
                Rect(d, 11, 24, 10, 12, accent, Mix(accent, Ink, 15));
            }
            else if (who == 6)
            {
                Rect(d, 11, 22, 10, 6, accent, Mix(accent, Ink, 20));
                Plot(d, 13, 26, Ink);
                Plot(d, 19, 26, Ink);
            }
            else if (who == 7)
            {
                Rect(d, 12, 26, 8, 10, accent, Mix(accent, Ink, 20));
            }
            else if (who == 8)
            {
                Rect(d, 10, 22, 12, 10, accent, Mix(accent, Ink, 18));
                HLine(d, 10, 28, 12, dressLo);
                Plot(d, 12, 25, Ink);
                Plot(d, 20, 25, Ink);
            }
            else if (who == 9)
            {
                Rect(d, 10, 22, 12, 12, accent, Mix(accent, Ink, 15));
                HLine(d, 10, 30, 12, dressLo);
            }
            else
            {
                Rect(d, 11, 23, 10, 7, accent, Mix(accent, Ink, 20));
                Plot(d, 14, 26, Ink);
                Plot(d, 18, 26, Ink);
            }

            DrawArm(d, 7, 23, false);
            DrawArm(d, 22, 23, true);
            Oval(d, cx, 14, 7, 8, hair, hairLo, true);
            Oval(d, cx, 16, 6, 7, Skin, SkinLo, true);
            FaceFront(d, cx, 16);
            if (who == 0)
            {
                Oval(d, 10, 18, 3, 6, hair, hairLo, true);
                Oval(d, 22, 18, 3, 6, hair, hairLo, true);
            }
            else if (who == 1)
            {
                Rect(d, 8, 6, 16, 4, new Color(48, 72, 96), new Color(28, 44, 64));
                HLine(d, 8, 6, 16, Ink);
            }
            else if (who == 3)
            {
                Rect(d, 8, 6, 16, 5, new Color(196, 72, 48), new Color(132, 42, 32));
                HLine(d, 8, 6, 16, Ink);
                Oval(d, cx, 20, 6, 3, hair, hairLo, false);
                HLine(d, cx - 3, 19, 7, hair);
            }
            else if (who == 4)
            {
                Rect(d, 7, 6, 18, 4, new Color(86, 48, 36), Ink);
                HLine(d, 8, 7, 16, accent);
            }
            else if (who == 5)
            {
                Oval(d, 10, 18, 3, 6, hair, hairLo, true);
                Oval(d, 22, 18, 3, 6, hair, hairLo, true);
            }
            else if (who == 6)
            {
                Rect(d, 9, 6, 14, 3, new Color(48, 44, 40), Ink);
            }
            else if (who == 7)
            {
                StrawHat(d, cx, 7, true);
                Plot(d, 22, 12, accent);
            }
            else if (who == 8)
            {
                Rect(d, 8, 5, 16, 5, new Color(96, 64, 40), new Color(62, 40, 24));
                HLine(d, 8, 5, 16, Ink);
                HLine(d, 8, 9, 16, Mix(accent, Ink, 20));
            }
            else if (who == 9)
            {
                StrawHat(d, cx, 7, true);
                Plot(d, 22, 12, new Color(92, 148, 72));
            }
            else
            {
                Rect(d, 9, 6, 14, 3, new Color(86, 56, 36), Ink);
            }
            return d;
        }

        static void StrawHat(Color[] d, int cx, int brimY, bool showFace)
        {
            Oval(d, cx, brimY + 2, 12, 5, Straw, StrawLo, true);
            Oval(d, cx, brimY - 1, 8, 5, StrawHi, StrawLo, true);
            HLine(d, cx - 11, brimY + 3, 22, StrawLo);
            if (showFace)
            {
                HLine(d, cx - 6, brimY + 4, 12, Mix(Straw, Ink, 20));
            }
        }

        static void FaceFront(Color[] d, int cx, int cy)
        {
            Plot(d, cx - 3, cy - 1, White);
            Plot(d, cx - 2, cy - 1, Ink);
            Plot(d, cx + 2, cy - 1, White);
            Plot(d, cx + 3, cy - 1, Ink);
            Plot(d, cx - 3, cy, SkinLo);
            Plot(d, cx + 3, cy, SkinLo);
            Plot(d, cx, cy + 1, SkinHi);
            Plot(d, cx, cy + 3, SkinLo);
            Plot(d, cx - 1, cy + 3, SkinLo);
            Plot(d, cx + 1, cy + 3, SkinLo);
        }

        static void FaceSide(Color[] d, int cx, int cy)
        {
            Plot(d, cx + 1, cy - 1, White);
            Plot(d, cx + 2, cy - 1, Ink);
            Plot(d, cx + 3, cy, SkinHi);
            Plot(d, cx + 2, cy + 2, SkinLo);
            Plot(d, cx, cy + 3, SkinLo);
        }

        static void DrawArm(Color[] d, int x, int y, bool right)
        {
            DrawArm(d, x, y, right, Shirt, ShirtLo);
        }

        static void DrawArm(Color[] d, int x, int y, bool right, Color shirt, Color shirtLo)
        {
            int s = right ? 1 : -1;
            Oval(d, x, y, 3, 5, shirt, shirtLo, true);
            Oval(d, x + s * 2, y + 6, 3, 4, Skin, SkinLo, true);
        }

        static void DrawArmsBack(Color[] d, int cx, int pose, Color shirt, Color shirtLo)
        {
            int laY, raY, laX, raX;
            bool hide;
            ArmPose(pose, false, out laX, out laY, out raX, out raY, out hide);
            Oval(d, cx - 9 + laX, 24 + laY, 3, 5, shirt, shirtLo, true);
            if (!hide)
                Oval(d, cx + 9 + raX, 24 + raY, 3, 5, shirt, shirtLo, true);
        }

        static void DrawLegs(Color[] d, int cx, int step, bool back)
        {
            DrawLegs(d, cx, step == 0 ? PoseIdle : PoseWalk0, back, false, Overall, OverallLo);
        }

        static Color[] PaintBat(int dir, int frame)
        {
            Color[] d = new Color[W * H];
            int flap = frame == 0 ? 0 : 2;
            int cx = 16;
            Color hide = new Color(72, 58, 92);
            Color hideL = new Color(118, 92, 148);
            Color hideD = new Color(42, 32, 58);
            Color wing = new Color(58, 44, 78);
            Color wingL = new Color(96, 78, 118);
            bool back = dir == 3;
            int wingY = 26 - flap;
            if (dir != 2)
            {
                for (int i = 0; i < 8; i++)
                {
                    int wy = wingY + i / 3;
                    Plot(d, cx - 10 + i / 2, wy, wing);
                    Plot(d, cx - 11 + i / 2, wy + 1, wingL);
                    Plot(d, cx + 9 - i / 2, wy, wing);
                    Plot(d, cx + 10 - i / 2, wy + 1, hideD);
                }
            }
            else
            {
                for (int i = 0; i < 8; i++)
                    Plot(d, cx + 6 + i / 2, wingY + i / 3, wingL);
            }
            Oval(d, cx, 30, 6, 5, hide, hideD, true);
            if (back)
                Oval(d, cx, 22, 5, 4, hideD, hide, true);
            else
            {
                Oval(d, cx, 22, 5, 5, hide, hideD, true);
                Plot(d, cx - 3, 21, White);
                Plot(d, cx - 2, 21, Ink);
                Plot(d, cx + 2, 21, White);
                Plot(d, cx + 3, 21, Ink);
                Plot(d, cx - 4, 19, hideL);
                Plot(d, cx + 4, 19, hideL);
            }
            return d;
        }

        static Color[] PaintSlime(int dir, int frame)
        {
            Color[] d = new Color[W * H];
            int bounce = frame == 0 ? 0 : 2;
            int cx = 16;
            int cy = 34 - bounce;
            Color body = new Color(86, 176, 92);
            Color bodyL = new Color(148, 220, 132);
            Color bodyD = new Color(48, 118, 64);
            Oval(d, cx, cy, 10, 8, body, bodyD, true);
            Oval(d, cx - 2, cy - 2, 4, 3, bodyL, body, false);
            if (dir != 3)
            {
                Plot(d, cx - 4, cy - 2, White);
                Plot(d, cx - 3, cy - 2, Ink);
                Plot(d, cx + 2, cy - 2, White);
                Plot(d, cx + 3, cy - 2, Ink);
                Plot(d, cx, cy + 1, Mix(bodyD, Ink, 25));
            }
            else
                Oval(d, cx, cy - 3, 6, 4, bodyD, Mix(bodyD, Ink, 20), true);
            return d;
        }

        static Color[] PaintSpider(int dir, int frame)
        {
            Color[] d = new Color[W * H];
            int step = frame == 0 ? 0 : 1;
            int cx = 16;
            Color body = new Color(48, 40, 44);
            Color bodyL = new Color(86, 72, 78);
            Color bodyD = new Color(28, 22, 26);
            Color leg = new Color(36, 30, 34);
            bool back = dir == 3;
            for (int i = 0; i < 4; i++)
            {
                int ly = 32 + i + (i % 2 == 0 ? step : 1 - step);
                Plot(d, cx - 10 + i, ly, leg);
                Plot(d, cx - 11 + i, ly + 1, bodyD);
                Plot(d, cx + 9 - i, ly, leg);
                Plot(d, cx + 10 - i, ly + 1, bodyD);
            }
            Oval(d, cx, 32, 7, 6, body, bodyD, true);
            if (back)
                Oval(d, cx, 24, 5, 4, bodyD, body, true);
            else
            {
                Oval(d, cx, 24, 5, 5, bodyL, bodyD, true);
                Plot(d, cx - 3, 23, new Color(214, 64, 58));
                Plot(d, cx + 2, 23, new Color(214, 64, 58));
                Plot(d, cx - 4, 26, White);
                Plot(d, cx + 3, 26, White);
            }
            return d;
        }

        static Color[] PaintTroll(int dir, int frame)
        {
            Color[] d = new Color[W * H];
            int step = frame == 0 ? 0 : 1;
            int cx = 16;
            Color hide = new Color(86, 118, 64);
            Color hideHi = new Color(124, 154, 88);
            Color hideLo = new Color(52, 74, 40);
            Color rag = new Color(98, 68, 46);
            Color ragLo = new Color(68, 44, 30);
            Color tusk = new Color(236, 228, 204);
            Color club = new Color(118, 78, 42);
            Color clubLo = new Color(78, 48, 26);
            bool back = dir == 3;

            Oval(d, cx, 30, 10, 11, hide, hideLo, true);
            DrawLegs(d, cx, step == 0 ? PoseIdle : PoseWalk0, back, dir == 2, rag, ragLo);
            Rect(d, cx - 7, 32, 14, 7, rag, ragLo);
            if (dir == 2)
            {
                Oval(d, cx + 1, 16, 7, 7, hide, hideLo, true);
                Rect(d, cx + 8, 18 + step, 3, 10, club, clubLo);
                Rect(d, cx + 7, 16 + step, 6, 5, Mix(club, White, 12), clubLo);
            }
            else if (back)
            {
                Oval(d, cx, 15, 8, 8, hide, hideLo, true);
                Oval(d, cx, 10, 6, 5, hideLo, Mix(hideLo, Ink, 20), true);
                Rect(d, cx + 6, 20, 3, 12, club, clubLo);
            }
            else
            {
                Oval(d, cx, 16, 8, 8, hide, hideLo, true);
                Oval(d, cx - 1, 17, 7, 6, hideHi, hideLo, false);
                Plot(d, cx - 4, 15, White);
                Plot(d, cx - 3, 15, Ink);
                Plot(d, cx + 2, 15, White);
                Plot(d, cx + 3, 15, Ink);
                Plot(d, cx - 1, 18, Mix(hideLo, Ink, 30));
                Plot(d, cx, 18, Mix(hideLo, Ink, 30));
                Plot(d, cx - 6, 19, tusk);
                Plot(d, cx - 6, 20, tusk);
                Plot(d, cx - 7, 20, Ink);
                Plot(d, cx + 5, 19, tusk);
                Plot(d, cx + 5, 20, tusk);
                Plot(d, cx + 6, 20, Ink);
                Rect(d, cx + 7, 22 + step, 3, 12, club, clubLo);
                Rect(d, cx + 6, 20 + step, 6, 4, Mix(club, White, 10), clubLo);
            }
            return d;
        }

        static void DrawLegs(Color[] d, int cx, int pose, bool back, bool side, Color pant, Color pantLo)
        {
            Color fill = back ? pantLo : pant;
            int leftDip, rightDip, leftX, rightX;
            LegStride(pose, side, out leftDip, out rightDip, out leftX, out rightX);
            int y = 36;
            int lh = 8 - Math.Max(0, -leftDip);
            int rh = 8 - Math.Max(0, -rightDip);
            Rect(d, cx - 6 + leftX, y + leftDip, 5, lh, fill, pantLo);
            Rect(d, cx + 1 + rightX, y + rightDip, 5, rh, fill, pantLo);
            Rect(d, cx - 6 + leftX, y + lh - 1 + leftDip, 6, 4, BootHi, Boot);
            Rect(d, cx + 1 + rightX, y + rh - 1 + rightDip, 6, 4, Boot, Mix(Boot, Ink, 20));
            int ground = H - 1;
            if (leftDip >= 0)
                HLine(d, cx - 6 + leftX, ground, 6, Ink);
            if (rightDip >= 0)
                HLine(d, cx + 1 + rightX, ground, 6, Ink);
        }

        static void LegStride(int pose, bool side, out int leftDip, out int rightDip, out int leftX, out int rightX)
        {
            leftDip = 0;
            rightDip = 0;
            leftX = 0;
            rightX = 0;
            int sx = side ? 2 : 1;
            if (pose == PoseWalk0)
            {
                leftDip = -3;
                rightDip = 2;
                leftX = -sx;
                rightX = sx;
            }
            else if (pose == PoseWalk1)
            {
                leftDip = 0;
                rightDip = 0;
                leftX = -1;
                rightX = 1;
            }
            else if (pose == PoseWalk2)
            {
                leftDip = 2;
                rightDip = -3;
                leftX = sx;
                rightX = -sx;
            }
            else if (pose == PoseWalk3)
            {
                leftDip = 0;
                rightDip = 0;
                leftX = 1;
                rightX = -1;
            }
            else if (pose == PoseSwingUp)
            {
                leftDip = -1;
                rightDip = 1;
                leftX = -1;
                rightX = 1;
            }
            else if (pose == PoseSwingHit)
            {
                leftDip = 2;
                rightDip = -1;
                leftX = 1;
                rightX = -1;
            }
        }

        static void Oval(Color[] d, int cx, int cy, int rx, int ry, Color fill, Color shade, bool outline)
        {
            int rx2 = rx * rx;
            int ry2 = ry * ry;
            int rr = rx2 * ry2;
            for (int y = cy - ry; y <= cy + ry; y++)
            {
                for (int x = cx - rx; x <= cx + rx; x++)
                {
                    int dx = x - cx;
                    int dy = y - cy;
                    int v = dx * dx * ry2 + dy * dy * rx2;
                    if (v > rr)
                        continue;
                    Color c = fill;
                    if (dx + dy < -2)
                        c = Mix(fill, White, 28);
                    else if (dx + dy > 3)
                        c = shade;
                    if (outline && v > rr - Math.Max(rx, ry) * Math.Max(rx2, ry2) / 6)
                        c = Ink;
                    Plot(d, x, y, c);
                }
            }
        }

        static void Rect(Color[] d, int x0, int y0, int bw, int bh, Color fill, Color shade)
        {
            for (int y = 0; y < bh; y++)
            {
                for (int x = 0; x < bw; x++)
                {
                    Color c = x < 2 ? Mix(fill, White, 20) : x > bw - 3 ? shade : fill;
                    if (x == 0 || y == 0 || x == bw - 1 || y == bh - 1)
                        c = Ink;
                    Plot(d, x0 + x, y0 + y, c);
                }
            }
        }

        static void HLine(Color[] d, int x, int y, int n, Color c)
        {
            for (int i = 0; i < n; i++)
                Plot(d, x + i, y, c);
        }

        static void Plot(Color[] d, int x, int y, Color c)
        {
            if (x < 0 || y < 0 || x >= W || y >= H)
                return;
            d[y * W + x] = c;
        }

        static Color Mix(Color a, Color b, int bAmt)
        {
            int ia = 100 - bAmt;
            return new Color((a.R * ia + b.R * bAmt) / 100, (a.G * ia + b.G * bAmt) / 100, (a.B * ia + b.B * bAmt) / 100);
        }

        static Texture2D Bake(GraphicsDevice gd, Color[] data)
        {
            return TileGen.Scale2(gd, data, W, H);
        }

        static Texture2D FlipH(GraphicsDevice gd, Color[] src)
        {
            Color[] dst = new Color[W * H];
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                    dst[y * W + x] = src[y * W + (W - 1 - x)];
            }
            return Bake(gd, dst);
        }
    }
}
