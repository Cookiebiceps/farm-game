using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace HarvestHollow
{
    public enum BuildingKind
    {
        Cottage,
        Shop,
        Inn,
        Home,
        FishMarket,
        GeneralStore,
        Cave,
        Barn,
        Greenhouse,
        Coop,
        Carpenter,
        AnimalShop,
        Silo
    }

    public enum FurnishKind
    {
        None = 0,
        Stove = 1,
        Sink = 2,
        Table = 3,
        Keg = 4,
        Fridge = 5,
        Shelf = 6
    }

    public struct Furnish
    {
        public int X;
        public int Y;
        public FurnishKind Kind;
    }

    /// <summary>
    /// One placed house: shared exterior sprite (style + size) and a unique interior map.
    /// </summary>
    public sealed class Building
    {
        public string Id;
        public string Name;
        public int X;
        public int Y;
        public int W;
        public int H;
        public int DoorDx;
        public int Rot;
        public int Style;
        public int Theme;
        public BuildingKind Kind;
        public TileType[,] Interior;
        public TileType[,] Upstairs;
        public readonly CaveFloor[] CaveFloors = new CaveFloor[CaveGen.Levels];
        public int Iw;
        public int Ih;
        public int InteriorDoorX;
        public int StairX;
        public int StairY;
        public int UpStairX;
        public int UpStairY;
        public int NpcX = -1;
        public int NpcY = -1;
        public bool Repaired = true;
        public readonly List<Furnish> Furnishings = new List<Furnish>();

        public bool IsFarmOutbuilding
        {
            get
            {
                return Kind == BuildingKind.Barn || Kind == BuildingKind.Greenhouse || Kind == BuildingKind.Coop;
            }
        }

        public bool NeedsRepair
        {
            get { return IsFarmOutbuilding && !Repaired; }
        }

        public int RepairPlanks
        {
            get
            {
                if (Kind == BuildingKind.Barn)
                    return 16;
                if (Kind == BuildingKind.Greenhouse)
                    return 10;
                if (Kind == BuildingKind.Coop)
                    return 6;
                return 0;
            }
        }

        public string RepairName
        {
            get
            {
                if (Kind == BuildingKind.Barn)
                    return Repaired ? "Barn" : "Broken Barn";
                if (Kind == BuildingKind.Greenhouse)
                    return Repaired ? "Greenhouse" : "Broken Greenhouse";
                if (Kind == BuildingKind.Coop)
                    return Repaired ? "Chicken Coop" : "Broken Chicken Coop";
                return Name;
            }
        }

        public int DoorX { get { return X + DoorLocalX; } }
        public int DoorY { get { return Y + DoorLocalY; } }

        public int FootW
        {
            get { return FootWFor(Rot, W, H); }
        }

        public int FootH
        {
            get { return FootHFor(Rot, W, H); }
        }

        public int DoorLocalX
        {
            get
            {
                int lx, ly;
                DoorLocal(W, H, DoorDx, Rot, out lx, out ly);
                return lx;
            }
        }

        public int DoorLocalY
        {
            get
            {
                int lx, ly;
                DoorLocal(W, H, DoorDx, Rot, out lx, out ly);
                return ly;
            }
        }

        public int ApproachX
        {
            get
            {
                int ax, ay;
                ApproachAt(X, Y, Rot, out ax, out ay);
                return ax;
            }
        }

        public int ApproachY
        {
            get
            {
                int ax, ay;
                ApproachAt(X, Y, Rot, out ax, out ay);
                return ay;
            }
        }

        public static int FootWFor(int rot, int w, int h)
        {
            return (rot & 1) == 1 ? h : w;
        }

        public static int FootHFor(int rot, int w, int h)
        {
            return (rot & 1) == 1 ? w : h;
        }

        public static void DoorLocal(int w, int h, int doorDx, int rot, out int lx, out int ly)
        {
            rot &= 3;
            if (rot == 0)
            {
                lx = doorDx;
                ly = h - 1;
            }
            else if (rot == 1)
            {
                lx = 0;
                ly = doorDx;
            }
            else if (rot == 2)
            {
                lx = w - 1 - doorDx;
                ly = 0;
            }
            else
            {
                lx = h - 1;
                ly = w - 1 - doorDx;
            }
        }

        public void ApproachAt(int x, int y, int rot, out int ax, out int ay)
        {
            int lx, ly;
            DoorLocal(W, H, DoorDx, rot, out lx, out ly);
            ax = x + lx;
            ay = y + ly;
            rot &= 3;
            if (rot == 0)
                ay++;
            else if (rot == 1)
                ax--;
            else if (rot == 2)
                ay--;
            else
                ax++;
        }

        public bool ContainsTile(int tx, int ty)
        {
            return tx >= X && tx < X + FootW && ty >= Y && ty < Y + FootH;
        }

        public bool HitsRect(int x, int y, int w, int h)
        {
            return X < x + w && x < X + FootW && Y < y + h && y < Y + FootH;
        }

        public Vector2 OutdoorExit
        {
            get
            {
                return new Vector2((ApproachX + 0.5f) * GameConst.Tile, (ApproachY + 0.5f) * GameConst.Tile);
            }
        }

        public Vector2 InteriorSpawn
        {
            get
            {
                return new Vector2((InteriorDoorX + 0.5f) * GameConst.Tile, (Ih - 1.65f) * GameConst.Tile);
            }
        }

        public bool HasUpstairs
        {
            get { return Upstairs != null; }
        }

        public TileType[,] FloorTiles(int floor)
        {
            if (Kind == BuildingKind.Cave)
                return EnsureCave(floor).Tiles;
            if (floor == 1 && Upstairs != null)
                return Upstairs;
            return Interior;
        }

        public Vector2 FloorSpawn(int floor)
        {
            if (Kind == BuildingKind.Cave)
                return CaveArriveDown ? CaveGen.SpawnBack() : CaveSpawnDeep(floor);
            if (floor == 1 && Upstairs != null)
                return new Vector2((UpStairX - 0.5f) * GameConst.Tile, (UpStairY + 1.55f) * GameConst.Tile);
            if (HasUpstairs)
                return new Vector2((StairX - 0.5f) * GameConst.Tile, (StairY + 1.55f) * GameConst.Tile);
            return InteriorSpawn;
        }

        public bool CaveArriveDown;

        Vector2 CaveSpawnDeep(int floor)
        {
            CaveFloor f = EnsureCave(floor);
            if (f.DeepX < 0)
                return CaveGen.SpawnBack();
            return CaveGen.SpawnAt(f.DeepX, f.DeepY);
        }

        public string FloorName(int floor)
        {
            if (Kind == BuildingKind.Cave)
            {
                int depth = floor + 1;
                if (depth % 10 == 0)
                    return "Ridge Hollow Vault " + depth.ToString();
                return "Ridge Hollow " + depth.ToString() + "/100";
            }
            if (floor == 1 && HasUpstairs)
                return "Inn Rooms";
            return Name;
        }

        public CaveFloor EnsureCave(int floor)
        {
            if (floor < 0)
                floor = 0;
            if (floor >= CaveGen.Levels)
                floor = CaveGen.Levels - 1;
            if (CaveFloors[floor] == null)
                CaveFloors[floor] = CaveGen.Build(floor + 1);
            return CaveFloors[floor];
        }

        public bool IsCaveDeepDoor(int floor, int tx, int ty)
        {
            CaveFloor f = EnsureCave(floor);
            return f.DeepX == tx && f.DeepY == ty;
        }

        public int CaveChestIndex(int floor, int tx, int ty)
        {
            CaveFloor f = EnsureCave(floor);
            for (int i = 0; i < f.ChestX.Length; i++)
            {
                if (f.ChestX[i] == tx && f.ChestY[i] == ty)
                    return i;
            }
            return -1;
        }

        public bool Contains(int tx, int ty)
        {
            return ContainsTile(tx, ty);
        }

        public static Building Make(
            string id, string name, int x, int y, int w, int h, int doorDx, int style, BuildingKind kind)
        {
            Building b = new Building();
            b.Id = id;
            b.Name = name;
            b.X = x;
            b.Y = y;
            b.W = w;
            b.H = h;
            b.DoorDx = doorDx;
            b.Style = style;
            b.Kind = kind;
            b.Theme = ThemeFor(id);
            if (b.IsFarmOutbuilding)
            {
                b.Repaired = false;
                b.Name = b.RepairName;
            }
            b.BuildInterior();
            return b;
        }

        public bool IsResidence
        {
            get { return Kind == BuildingKind.Cottage || Kind == BuildingKind.Home; }
        }

        public void RebuildInterior()
        {
            if (Kind == BuildingKind.Cave)
                return;
            Furnishings.Clear();
            Upstairs = null;
            NpcX = -1;
            NpcY = -1;
            _windows = 0;
            BuildInterior();
        }

        public FurnishKind FurnishAt(int x, int y)
        {
            for (int i = 0; i < Furnishings.Count; i++)
            {
                if (Furnishings[i].X == x && Furnishings[i].Y == y)
                    return Furnishings[i].Kind;
            }
            return FurnishKind.None;
        }

        static int ThemeFor(string id)
        {
            if (id == "cottage") return 0;
            if (id == "rowan") return 1;
            if (id == "mira-home") return 2;
            if (id == "inn") return 3;
            if (id == "cob") return 4;
            if (id == "ash") return 4;
            if (id == "bess") return 1;
            if (id == "piper") return 6;
            if (id == "ridge-cave") return 7;
            if (id == "barn") return 8;
            if (id == "greenhouse") return 9;
            if (id == "coop") return 10;
            if (id == "silo") return 11;
            if (id == "lila") return 2;
            if (id == "bram") return 4;
            if (id == "ash") return 4;
            if (id == "nell") return 0;
            return 4;
        }

        void BuildInterior()
        {
            if (Kind == BuildingKind.Cave)
            {
                LayoutCaveSystem();
                return;
            }
            Iw = W + 4;
            Ih = H + 4;
            if (Id == "piper")
            {
                Iw = 14;
                Ih = 12;
            }
            if (Iw < 10) Iw = 10;
            if (Ih < 8) Ih = 8;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;

            if (Id == "cottage")
                LayoutResidence(3, 7);
            else if (Id == "rowan")
                LayoutShop();
            else if (Id == "inn")
                LayoutInn();
            else if (Id == "mira-home")
                LayoutResidence(2, 6);
            else if (Id == "finn")
                LayoutFishMarket();
            else if (Id == "piper")
                LayoutGeneral();
            else if (Id == "lila")
                LayoutResidence(3, Iw - 3);
            else if (Id == "bram")
                LayoutResidence(2, 6);
            else if (Id == "nell")
                LayoutResidence(4, Iw - 3);
            else if (Kind == BuildingKind.Barn)
                LayoutBarn();
            else if (Kind == BuildingKind.Greenhouse)
                LayoutGreenhouse();
            else if (Kind == BuildingKind.Coop)
                LayoutCoop();
            else if (Kind == BuildingKind.Silo)
                LayoutSilo();
            else if (Kind == BuildingKind.Carpenter)
                LayoutCarpenter();
            else if (Kind == BuildingKind.AnimalShop)
                LayoutAnimalShop();
            else
                LayoutResidence(4, 0);
        }

        void LayoutCarpenter()
        {
            Iw = 12;
            Ih = 10;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            for (int x = 2; x <= Iw - 3; x++)
            {
                Put(x, 2, TileType.Counter);
                if (x == InteriorDoorX)
                    Mark(x, 2, FurnishKind.Table);
            }
            Put(2, 3, TileType.Counter);
            Put(Iw - 3, 3, TileType.Counter);
            Put(3, 5, TileType.Flower);
            Put(Iw - 4, 5, TileType.Flower);
            Put(2, 7, TileType.Flower);
            Put(Iw - 3, 7, TileType.Flower);
            NpcX = InteriorDoorX;
            NpcY = 3;
            PutWindow(3, 0);
            PutWindow(Iw / 2, 0);
            PutWindow(Iw - 4, 0);
        }

        void LayoutAnimalShop()
        {
            Iw = 12;
            Ih = 10;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            for (int x = 2; x <= Iw - 3; x++)
            {
                Put(x, 2, TileType.Counter);
                if (x == InteriorDoorX)
                    Mark(x, 2, FurnishKind.Table);
            }
            Put(2, 3, TileType.Counter);
            Put(Iw - 3, 3, TileType.Counter);
            Put(3, 5, TileType.Flower);
            Put(Iw - 4, 5, TileType.Flower);
            Put(2, 7, TileType.Flower);
            Put(Iw - 3, 7, TileType.Flower);
            Put(5, 7, TileType.Flower);
            Put(Iw - 6, 7, TileType.Flower);
            NpcX = InteriorDoorX;
            NpcY = 3;
            PutWindow(3, 0);
            PutWindow(Iw / 2, 0);
            PutWindow(Iw - 4, 0);
        }

        void LayoutBarn()
        {
            Iw = 16;
            Ih = 12;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            Put(2, 2, TileType.Counter);
            Mark(2, 2, FurnishKind.Keg);
            Put(3, 2, TileType.Counter);
            Mark(3, 2, FurnishKind.Keg);
            Put(Iw - 3, 2, TileType.Counter);
            Put(Iw - 4, 2, TileType.Counter);
            Put(5, 3, TileType.Flower);
            Put(Iw - 6, 3, TileType.Flower);
            Put(4, 6, TileType.Flower);
            Put(Iw - 5, 7, TileType.Flower);
            Put(8, 4, TileType.Rock);
            PutWindow(4, 0);
            PutWindow(Iw - 5, 0);
        }

        void LayoutGreenhouse()
        {
            Iw = GameConst.GreenhouseInsideW;
            Ih = GameConst.GreenhouseInsideH;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                {
                    if (y == 0)
                        Interior[x, y] = TileType.HouseWindow;
                    else
                        Interior[x, y] = TileType.HouseFloor;
                }
            }
            Interior[0, 0] = TileType.HouseWall;
            Interior[Iw - 1, 0] = TileType.HouseWall;
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            int bedY1 = Ih - 3;
            for (int x = 2; x <= 4; x++)
            {
                for (int y = 2; y <= bedY1; y++)
                    Interior[x, y] = TileType.FarmSoil;
            }
            for (int x = 7; x <= 9; x++)
            {
                for (int y = 2; y <= bedY1; y++)
                    Interior[x, y] = TileType.FarmSoil;
            }
            for (int y = 2; y <= bedY1; y += 5)
            {
                Put(1, y, TileType.Flower);
                Put(Iw - 2, y, TileType.Flower);
            }
        }

        void LayoutCoop()
        {
            Iw = 10;
            Ih = 8;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            Put(2, 2, TileType.Counter);
            Put(3, 2, TileType.Counter);
            Put(Iw - 3, 2, TileType.Counter);
            Put(2, 4, TileType.Flower);
            Put(Iw - 3, 4, TileType.Flower);
            Put(5, 3, TileType.Flower);
            PutWindow(3, 0);
            PutWindow(Iw - 4, 0);
        }

        void LayoutSilo()
        {
            Iw = 8;
            Ih = 8;
            InteriorDoorX = Iw / 2;
            Interior = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Interior[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            Interior[InteriorDoorX, Ih - 1] = TileType.Door;
            Put(2, 2, TileType.Counter);
            Put(3, 2, TileType.Counter);
            Put(4, 2, TileType.Counter);
            Put(2, 4, TileType.Flower);
        }

        void LayoutCaveSystem()
        {
            Iw = CaveGen.Iw;
            Ih = CaveGen.Ih;
            InteriorDoorX = CaveGen.BackX;
            CaveFloor first = EnsureCave(0);
            Interior = first.Tiles;
        }

        void LayoutResidence(int winA, int winB)
        {
            int split = InteriorDoorX;
            int kx0 = 1;
            int kx1 = split - 1;
            int n = 0;
            for (int x = kx0; x <= kx1; x++)
            {
                Put(x, 1, TileType.Counter);
                if (n == 0)
                    Mark(x, 1, FurnishKind.Stove);
                else if (n == 1)
                    Mark(x, 1, FurnishKind.Sink);
                n++;
            }
            int tableX = kx0 + (kx1 - kx0 > 2 ? 1 : 0);
            int tableY = 4;
            if (tableY < 3)
                tableY = 3;
            if (tableX + 1 < split && tableY < Ih - 2)
                Mark(tableX, tableY, FurnishKind.Table);

            int bx = split + 1;
            int by = 1;
            Put(bx, by, TileType.Bed);
            Put(bx + 1, by, TileType.Bed);
            Put(bx, by + 1, TileType.Bed);
            Put(bx + 1, by + 1, TileType.Bed);
            if (bx + 2 < Iw - 1)
                Put(bx + 2, by, TileType.Flower);
            else if (by + 2 < Ih - 1)
                Put(bx, by + 2, TileType.Flower);

            PutWindow(winA, 0);
            PutWindow(winB, 0);
        }

        void Mark(int x, int y, FurnishKind kind)
        {
            Furnish f = new Furnish();
            f.X = x;
            f.Y = y;
            f.Kind = kind;
            Furnishings.Add(f);
        }

        void LayoutShop()
        {
            for (int x = 2; x <= Iw - 3; x++)
                Put(x, 2, TileType.Counter);
            Put(2, 3, TileType.Counter);
            Put(2, 4, TileType.Counter);
            Put(Iw - 3, 5, TileType.Flower);
            Put(Iw - 4, 5, TileType.Flower);
            PutWindow(2, 0);
            PutWindow(Iw - 3, 0);
        }

        void LayoutInn()
        {
            // Lobby and taproom. Beds live upstairs.
            for (int x = 2; x <= 8; x++)
            {
                Put(x, 1, TileType.Counter);
                Mark(x, 1, FurnishKind.Keg);
                Put(x, 2, TileType.Counter);
            }
            Mark(4, 5, FurnishKind.Table);
            Mark(7, 6, FurnishKind.Table);
            Put(2, 7, TileType.Flower);
            Put(8, 8, TileType.Flower);
            StairX = Iw - 2;
            StairY = 2;
            Put(StairX, StairY, TileType.Stairs);
            PutWindow(3, 0);
            PutWindow(6, 0);
            PutWindow(10, 0);
            LayoutInnUpstairs();
        }

        void LayoutInnUpstairs()
        {
            Upstairs = new TileType[Iw, Ih];
            for (int y = 0; y < Ih; y++)
            {
                for (int x = 0; x < Iw; x++)
                    Upstairs[x, y] = y == 0 ? TileType.HouseWall : TileType.HouseFloor;
            }
            for (int x = 0; x < Iw; x++)
                Upstairs[x, Ih - 1] = TileType.HouseWall;

            int split = 6;
            for (int y = 1; y <= 5; y++)
                Upstairs[split, y] = TileType.HouseWall;
            for (int x = 1; x <= 5; x++)
                Upstairs[x, 5] = TileType.HouseWall;
            for (int x = 7; x <= Iw - 2; x++)
                Upstairs[x, 5] = TileType.HouseWall;
            Upstairs[3, 5] = TileType.HouseFloor;
            Upstairs[9, 5] = TileType.HouseFloor;

            PutUp(2, 1, TileType.Bed);
            PutUp(3, 1, TileType.Bed);
            PutUp(2, 2, TileType.Bed);
            PutUp(3, 2, TileType.Bed);
            PutUp(4, 3, TileType.Flower);

            PutUp(8, 1, TileType.Bed);
            PutUp(9, 1, TileType.Bed);
            PutUp(8, 2, TileType.Bed);
            PutUp(9, 2, TileType.Bed);
            PutUp(10, 3, TileType.Flower);

            if (3 < Iw)
                Upstairs[3, 0] = TileType.HouseWindow;
            if (9 < Iw)
                Upstairs[9, 0] = TileType.HouseWindow;

            UpStairX = Iw - 2;
            UpStairY = 7;
            PutUp(UpStairX, UpStairY, TileType.Stairs);
        }

        void PutUp(int x, int y, TileType t)
        {
            if (Upstairs == null)
                return;
            if (x <= 0 || y <= 0 || x >= Iw - 1 || y >= Ih - 1)
                return;
            Upstairs[x, y] = t;
        }

        void LayoutFishMarket()
        {
            for (int x = 2; x <= Iw - 3; x++)
                Put(x, 2, TileType.Counter);
            Put(2, 4, TileType.Flower);
            Put(Iw - 3, 4, TileType.Flower);
            Put(Iw - 3, 5, TileType.Flower);
            Put(3, 5, TileType.Counter);
            Put(Iw - 4, 5, TileType.Counter);
            PutWindow(3, 0);
            PutWindow(Iw - 4, 0);
        }

        void LayoutGeneral()
        {
            // Back wall of glass coolers, two gondola aisles, checkout up front.
            for (int x = 2; x <= Iw - 3; x++)
            {
                Put(x, 1, TileType.Counter);
                Mark(x, 1, FurnishKind.Fridge);
            }
            for (int y = 3; y <= 6; y++)
            {
                Put(2, y, TileType.Counter);
                Mark(2, y, FurnishKind.Shelf);
                Put(3, y, TileType.Counter);
                Mark(3, y, FurnishKind.Shelf);
                Put(Iw - 4, y, TileType.Counter);
                Mark(Iw - 4, y, FurnishKind.Shelf);
                Put(Iw - 3, y, TileType.Counter);
                Mark(Iw - 3, y, FurnishKind.Shelf);
            }
            int cy = Ih - 3;
            for (int x = 2; x <= Iw - 3; x++)
            {
                if (x >= InteriorDoorX - 1 && x <= InteriorDoorX + 1)
                    continue;
                Put(x, cy, TileType.Counter);
            }
            NpcX = InteriorDoorX - 3;
            NpcY = cy - 1;
            if (NpcX < 2)
                NpcX = 2;
            Put(Iw - 3, 8, TileType.Flower);
            Put(2, 8, TileType.Flower);
            PutWindow(3, 0);
            PutWindow(7, 0);
            PutWindow(Iw - 4, 0);
        }

        void Put(int x, int y, TileType t)
        {
            if (x <= 0 || y <= 0 || x >= Iw - 1 || y >= Ih - 1)
                return;
            if (x == InteriorDoorX && y == Ih - 1)
                return;
            Interior[x, y] = t;
        }

        int _windows;

        void PutWindow(int x, int y)
        {
            if (_windows >= 3)
                return;
            if (x < 0 || y < 0 || x >= Iw || y >= Ih)
                return;
            if (Interior[x, y] != TileType.HouseWall)
                return;
            if (x == InteriorDoorX && y == Ih - 1)
                return;
            Interior[x, y] = TileType.HouseWindow;
            _windows++;
        }
    }
}
