using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;

namespace HarvestHollow
{
    /// <summary>
    /// Cozy looping piano theme, synthesized at load (XNA SoundEffect from PCM).
    /// </summary>
    public sealed class PianoTheme : IDisposable
    {
        const int SampleRate = 22050;
        const float Bpm = 72f;
        const float BaseVolume = 0.42f;
        float _userVolume = 0.70f;

        SoundEffect _effect;
        SoundEffectInstance _instance;
        bool _muted;

        public bool Muted
        {
            get { return _muted; }
        }

        public void SetMuted(bool muted)
        {
            _muted = muted;
            ApplyVolume();
        }

        public void SetUserVolume(float volume)
        {
            if (volume < 0f) volume = 0f;
            if (volume > 1f) volume = 1f;
            _userVolume = volume;
            ApplyVolume();
        }

        public void ApplyVolume()
        {
            if (_instance == null)
                return;
            _instance.Volume = _muted ? 0f : BaseVolume * _userVolume;
        }

        public static void WriteWav(string path)
        {
            byte[] pcm = RenderLoop();
            byte[] wav = WrapWav(pcm, SampleRate, 2);
            string dir = System.IO.Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir))
                System.IO.Directory.CreateDirectory(dir);
            System.IO.File.WriteAllBytes(path, wav);
        }

        public void Load()
        {
            try
            {
                byte[] pcm = RenderLoop();
                _effect = new SoundEffect(pcm, SampleRate, AudioChannels.Stereo);
                _instance = _effect.CreateInstance();
                _instance.IsLooped = true;
                _instance.Volume = BaseVolume * _userVolume;
                _instance.Play();
            }
            catch
            {
                _effect = null;
                _instance = null;
            }
        }

        public void ToggleMute()
        {
            if (_instance == null)
                return;
            _muted = !_muted;
            ApplyVolume();
        }

        public void Dispose()
        {
            if (_instance != null)
            {
                _instance.Stop();
                _instance.Dispose();
                _instance = null;
            }
            if (_effect != null)
            {
                _effect.Dispose();
                _effect = null;
            }
        }

        struct Note
        {
            public float Beat;
            public int Midi;
            public float Dur;
            public float Vel;
            public bool Bass;
        }

        static byte[] RenderLoop()
        {
            float beatSec = 60f / Bpm;
            const float bars = 16f;
            float totalBeats = bars * 4f;
            int totalSamples = (int)(totalBeats * beatSec * SampleRate);
            float[] mixL = new float[totalSamples];
            float[] mixR = new float[totalSamples];

            List<Note> notes = new List<Note>();
            Compose(notes);

            for (int i = 0; i < notes.Count; i++)
            {
                Note n = notes[i];
                double freq = 440.0 * Math.Pow(2.0, (n.Midi - 69) / 12.0);
                int start = (int)(n.Beat * beatSec * SampleRate);
                int len = (int)((n.Dur * beatSec + 1.6f) * SampleRate);
                if (start >= totalSamples)
                    continue;
                if (start + len > totalSamples)
                    len = totalSamples - start;
                RenderPiano(mixL, mixR, start, len, freq, n.Vel, n.Dur * beatSec, n.Bass, totalSamples);
            }

            // Very short crossfade so the loop breathes instead of clicking.
            int fade = Math.Min(SampleRate / 4, totalSamples / 8);
            for (int i = 0; i < fade; i++)
            {
                float t = i / (float)fade;
                int a = i;
                int b = totalSamples - fade + i;
                mixL[a] = mixL[a] * t + mixL[b] * (1f - t);
                mixR[a] = mixR[a] * t + mixR[b] * (1f - t);
                mixL[b] = mixL[a];
                mixR[b] = mixR[a];
            }

            SoftReverb(mixL, mixR, SampleRate);
            return ToPcm16(mixL, mixR);
        }

        static void Compose(List<Note> n)
        {
            // Eight-bar hymn, then a quieter answering phrase.
            int[][] prog =
            {
                new[] { 48, 52, 55, 60 }, // C
                new[] { 48, 52, 55, 64 },
                new[] { 43, 47, 50, 59 }, // G
                new[] { 43, 50, 55, 62 },
                new[] { 45, 48, 52, 60 }, // Am
                new[] { 45, 52, 57, 64 },
                new[] { 41, 45, 48, 60 }, // F
                new[] { 43, 47, 50, 62 }  // G
            };

            for (int rep = 0; rep < 2; rep++)
            {
                float origin = rep * 32f;
                for (int bar = 0; bar < 8; bar++)
                {
                    float b0 = origin + bar * 4f;
                    int[] chord = prog[bar];
                    // Broken-chord accompaniment, like a quiet parlor piano.
                    float arpVel = 0.22f;
                    n.Add(Make(b0 + 0.00f, chord[0], 1.9f, arpVel + 0.06f, true));
                    n.Add(Make(b0 + 0.50f, chord[2], 0.9f, arpVel, true));
                    n.Add(Make(b0 + 1.00f, chord[1], 0.9f, arpVel, false));
                    n.Add(Make(b0 + 1.50f, chord[3], 0.9f, arpVel + 0.04f, false));
                    n.Add(Make(b0 + 2.00f, chord[0] + 12, 1.0f, arpVel, false));
                    n.Add(Make(b0 + 2.50f, chord[2], 0.9f, arpVel, true));
                    n.Add(Make(b0 + 3.00f, chord[1], 0.9f, arpVel, false));
                    n.Add(Make(b0 + 3.50f, chord[2], 0.55f, arpVel - 0.02f, false));
                }
            }

            // Melody: first statement
            AddMelody(n, 0f, 0.62f);
            // Softer echo an octave down in the repeat, plus the tune again
            AddMelody(n, 32f, 0.55f);
            // A few held pedal fifths for warmth
            n.Add(Make(0f, 67, 7.5f, 0.08f, false));
            n.Add(Make(16f, 64, 7.5f, 0.07f, false));
            n.Add(Make(32f, 72, 6f, 0.06f, false));
            n.Add(Make(48f, 67, 8f, 0.07f, false));
        }

        static void AddMelody(List<Note> n, float origin, float vel)
        {
            // Original lullaby in C — slow neighbor tones, lots of air.
            Add(n, origin, 0.00f, 76, 1.5f, vel);
            Add(n, origin, 1.50f, 79, 0.5f, vel);
            Add(n, origin, 2.00f, 81, 1.0f, vel * 0.92f);
            Add(n, origin, 3.00f, 79, 1.0f, vel);

            Add(n, origin, 4.00f, 76, 2.0f, vel);
            Add(n, origin, 6.00f, 74, 1.5f, vel * 0.9f);
            Add(n, origin, 7.50f, 72, 0.5f, vel * 0.85f);

            Add(n, origin, 8.00f, 72, 1.0f, vel);
            Add(n, origin, 9.00f, 74, 1.0f, vel);
            Add(n, origin, 10.00f, 76, 2.0f, vel);

            Add(n, origin, 12.00f, 74, 1.0f, vel * 0.9f);
            Add(n, origin, 13.00f, 72, 1.0f, vel);
            Add(n, origin, 14.00f, 71, 2.0f, vel * 0.88f);

            Add(n, origin, 16.00f, 72, 1.5f, vel);
            Add(n, origin, 17.50f, 76, 0.5f, vel);
            Add(n, origin, 18.00f, 79, 1.0f, vel * 0.95f);
            Add(n, origin, 19.00f, 81, 1.0f, vel * 0.9f);

            Add(n, origin, 20.00f, 79, 2.0f, vel);
            Add(n, origin, 22.00f, 77, 1.0f, vel * 0.88f);
            Add(n, origin, 23.00f, 76, 1.0f, vel);

            Add(n, origin, 24.00f, 74, 1.5f, vel * 0.9f);
            Add(n, origin, 25.50f, 72, 0.5f, vel);
            Add(n, origin, 26.00f, 71, 1.0f, vel * 0.85f);
            Add(n, origin, 27.00f, 67, 1.0f, vel * 0.82f);

            Add(n, origin, 28.00f, 69, 2.0f, vel * 0.9f);
            Add(n, origin, 30.00f, 71, 2.0f, vel * 0.88f);
        }

        static void Add(List<Note> n, float origin, float beat, int midi, float dur, float vel)
        {
            n.Add(Make(origin + beat, midi, dur, vel, false));
        }

        static Note Make(float beat, int midi, float dur, float vel, bool bass)
        {
            Note note = new Note();
            note.Beat = beat;
            note.Midi = midi;
            note.Dur = dur;
            note.Vel = vel;
            note.Bass = bass;
            return note;
        }

        static void RenderPiano(float[] l, float[] r, int start, int len, double freq, float vel, float durSec, bool bass, int wrap)
        {
            double twoPi = Math.PI * 2.0;
            for (int i = 0; i < len; i++)
            {
                float t = i / (float)SampleRate;
                float attack = 1f - (float)Math.Exp(-t * 90.0);
                float decay = (float)Math.Exp(-t * (bass ? 1.7 : 2.6));
                float rel = 1f;
                if (t > durSec)
                    rel = (float)Math.Exp(-(t - durSec) * 6.5);
                float env = attack * decay * rel * vel;

                double w = twoPi * freq * t;
                // Inharmonic partials, like a small upright piano.
                float s = 0f;
                s += (float)Math.Sin(w) * 0.55f;
                s += (float)Math.Sin(w * 2.003) * 0.22f * (float)Math.Exp(-t * 2.4);
                s += (float)Math.Sin(w * 3.012) * 0.10f * (float)Math.Exp(-t * 3.8);
                s += (float)Math.Sin(w * 4.03) * 0.05f * (float)Math.Exp(-t * 5.0);
                s += (float)Math.Sin(w * 5.04) * 0.03f * (float)Math.Exp(-t * 7.0);
                // Felt hammer
                if (t < 0.02f)
                    s += (Hash(i + start) - 0.5f) * 0.12f * (1f - t / 0.02f);

                s *= env;
                float panL = bass ? 0.72f : 0.58f;
                float panR = bass ? 0.50f : 0.78f;
                int idx = start + i;
                if (idx >= wrap)
                    idx -= wrap;
                l[idx] += s * panL;
                r[idx] += s * panR;
            }
        }

        static void SoftReverb(float[] l, float[] r, int sr)
        {
            int d1 = (int)(0.18f * sr);
            int d2 = (int)(0.11f * sr);
            float[] ol = (float[])l.Clone();
            float[] orr = (float[])r.Clone();
            for (int i = 0; i < l.Length; i++)
            {
                float e1 = i >= d1 ? ol[i - d1] : 0f;
                float e2 = i >= d2 ? orr[i - d2] : 0f;
                l[i] += e1 * 0.22f + e2 * 0.10f;
                r[i] += e2 * 0.22f + e1 * 0.10f;
            }
        }

        static byte[] WrapWav(byte[] pcm, int sampleRate, int channels)
        {
            int dataLen = pcm.Length;
            int byteRate = sampleRate * channels * 2;
            int blockAlign = channels * 2;
            byte[] wav = new byte[44 + dataLen];
            System.Buffer.BlockCopy(System.Text.Encoding.ASCII.GetBytes("RIFF"), 0, wav, 0, 4);
            WriteInt32(wav, 4, 36 + dataLen);
            System.Buffer.BlockCopy(System.Text.Encoding.ASCII.GetBytes("WAVE"), 0, wav, 8, 4);
            System.Buffer.BlockCopy(System.Text.Encoding.ASCII.GetBytes("fmt "), 0, wav, 12, 4);
            WriteInt32(wav, 16, 16);
            WriteInt16(wav, 20, 1);
            WriteInt16(wav, 22, (short)channels);
            WriteInt32(wav, 24, sampleRate);
            WriteInt32(wav, 28, byteRate);
            WriteInt16(wav, 32, (short)blockAlign);
            WriteInt16(wav, 34, 16);
            System.Buffer.BlockCopy(System.Text.Encoding.ASCII.GetBytes("data"), 0, wav, 36, 4);
            WriteInt32(wav, 40, dataLen);
            System.Buffer.BlockCopy(pcm, 0, wav, 44, dataLen);
            return wav;
        }

        static void WriteInt16(byte[] d, int o, short v)
        {
            d[o] = (byte)(v & 0xff);
            d[o + 1] = (byte)((v >> 8) & 0xff);
        }

        static void WriteInt32(byte[] d, int o, int v)
        {
            d[o] = (byte)(v & 0xff);
            d[o + 1] = (byte)((v >> 8) & 0xff);
            d[o + 2] = (byte)((v >> 16) & 0xff);
            d[o + 3] = (byte)((v >> 24) & 0xff);
        }

        static byte[] ToPcm16(float[] l, float[] r)
        {
            byte[] pcm = new byte[l.Length * 4];
            for (int i = 0; i < l.Length; i++)
            {
                float sl = Clamp(l[i] * 0.72f, -0.95f, 0.95f);
                float sr = Clamp(r[i] * 0.72f, -0.95f, 0.95f);
                short ls = (short)(sl * 32767f);
                short rs = (short)(sr * 32767f);
                pcm[i * 4] = (byte)(ls & 0xff);
                pcm[i * 4 + 1] = (byte)((ls >> 8) & 0xff);
                pcm[i * 4 + 2] = (byte)(rs & 0xff);
                pcm[i * 4 + 3] = (byte)((rs >> 8) & 0xff);
            }
            return pcm;
        }

        static float Clamp(float v, float a, float b)
        {
            if (v < a) return a;
            if (v > b) return b;
            return v;
        }

        static float Hash(int n)
        {
            n = (n << 13) ^ n;
            return (float)(((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483648.0);
        }
    }
}
